package com.kmhc.model.handler.impl.c100;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;

import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.framework.util.ConvertionUtil;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;

public abstract class AbstractParentHandlerC100 extends AbstractHandler {
    public final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public final SimpleDateFormat yyMMddHHmmss = new SimpleDateFormat("yyMMddHHmmss");
    private byte version = (byte)0x06 ;
    private byte reserve = (byte)0x00 ;
    private Logger log;
    public final int VP_BASE = 4200 ;

    public AbstractParentHandlerC100(Logger log) {
        this.log = log;
    }

    @Override
    public ReplyMessageContent handleMessage(byte[] msg){ return null; }

    public Logger getLog() {
        return log;
    }

    public void setLog(Logger log) {
        this.log = log;
    }
    
    
    protected void writeDebugLog(byte[] msg, String type) {
        String byte2hex = TripleDesHelper.byte2hex(msg, msg.length);
        log.debug("【type=C100,command=0x{}】收到数据：{}，处理中。。。", type, byte2hex);
    }

    public String parseSn(byte[] data, int index) {
        String sn = ConvertionUtil.Bytes2HexString(Arrays.copyOfRange(data, index + 5, index + 14));
        return sn.substring(0, sn.indexOf('F'));
    }

    /**
     * @Title: parseCells
     * @Description: 解析byte数组中的基站数据集(小区)
     * @param data
     *            报文byte数组
     * @param index
     *            解析的开始下标位置
     * @return cell list
     */

    public List<Cell> parseCells(byte[] data, int index) {
        List<Cell> list = new ArrayList<Cell>();
        for (int i = 0; i < 6; i++) {
            short mcc = ConvertionUtil.getShort(Arrays.copyOfRange(data, i * 9 + index, i * 9 + index + 2), false);
            short mnc = ConvertionUtil.getShort(Arrays.copyOfRange(data, i * 9 + index + 2, i * 9 + index + 4), false);
            short lac = ConvertionUtil.getShort(Arrays.copyOfRange(data, i * 9 + index + 4, i * 9 + index + 6), false);
            short cellId = ConvertionUtil.getShort(Arrays.copyOfRange(data, i * 9 + index + 6, i * 9 + index + 8),
                    false);
            short rssi = data[i * 9 + index + 8];
            if (mcc != 0) {
                list.add(new Cell(mcc, mnc, lac, cellId, rssi));
            } else {
                break;
            }
        }
        return list;
    }

    /**
     * @Title: parseWifis
     * @Description: 解析出WIFI数据集
     * @param data
     * @param index
     * @return
     */

    public List<Wifi> parseWifis(byte[] data, int index) {
        List<Wifi> list = new ArrayList<Wifi>();
        for (int i = 0; i < 5; i++) {
            String wifiMac = ConvertionUtil.Bytes2HexString(Arrays.copyOfRange(data, i * 8 + index, i * 8 + index + 6));
            if (wifiMac.startsWith("0000")) {
                break;
            }
            short signalFlag = data[i * 8 + index + 6];
            short wifiSignal = data[i * 8 + index + 7];
            if (signalFlag == 1) {
                wifiSignal = (short) (0 - wifiSignal);
            }
            Wifi wifi = new Wifi();
            wifi.setWifiMac(wifiMac);
            wifi.setWifiSignal(wifiSignal);
            list.add(wifi);
        }
        return list;
    }

    /**
     * @Title: parseGPS
     * @Description: 经纬度连续分别占用4个字节，采用4字节有附号整型表示，把经纬度放大1000000倍后转为整型存储。东经或北纬为正，
     *               西经或南纬为负
     * @param data
     *            总体字节数组
     * @param index
     *            字节数组起始位置
     * @return GPS数据对象
     */

    public Gps parseGps(byte[] data, int index) {
        String EW = "E";
        String NS = "N";
        Gps gps = null;
        try {
            int lng_int = ConvertionUtil.bigEndBytesToInt(data, index);
            int lat_int = ConvertionUtil.bigEndBytesToInt(data, index + 4);
            if (lng_int == 0 || lat_int == 0) {
                return gps;
            }
            if (lng_int < 0)
                EW = "W";
            if (lat_int < 0)
                NS = "S";
            double lng = (double) Math.abs(lng_int) / 10000;
            double lat = (double) Math.abs(lat_int) / 10000;
            gps = new Gps(lat, lng, NS, EW, "Y");
        } catch (Exception e) {
            log.error("解析协议GPS经纬度出错", e);
        }
        return gps;
    }

    public boolean gpsStatus(short signalStatus) {
        return (signalStatus & 0x03) == 1 ? true : false;
    }

    public boolean wifiStatus(short signalStatus, byte reserved) {
        return ((signalStatus >> 2 & 0x03) == 1) && ((reserved & 0x01) == 1) ? true : false;
    }

    /**
     * @Title: getMv
     * @Description: 获取电量的百分比，信号状态指示的D4~D7
     * @param signalStatus
     * @return
     */

    public int getVolagePrecent(short signalStatus) {
        return signalStatus >> 4 & 0x0F;
    }
    
    public byte[] generateResponse(byte function){
        return generateResponse(null,function);
    }
    public byte[] generateResponse(byte[] body, byte function){
        int len = 6 ;
        byte[] response = new byte[len] ;
        if(body != null){
            len +=body.length ;
            response = new byte[len] ;
            System.arraycopy(body, 0, response, 5, body.length);
        }
        byte[] totalLength = ConvertionUtil.shortToByteArray((short)response.length) ;
        response[0] = totalLength[0] ;
        response[1] = totalLength[1] ;
        response[2] = function ;
        response[3] = version ;
        response[4] = reserve ;
        response[response.length-1] = checkSum(response,response.length-1) ;
        return response ;
    }
    
    private byte checkSum(byte[] data,int endIndex){
        byte checkSum = 0 ;
        for(int i = 0 ; i<endIndex ; i++){
            checkSum += data[i] ;
        }
        return checkSum ;
    }
}
