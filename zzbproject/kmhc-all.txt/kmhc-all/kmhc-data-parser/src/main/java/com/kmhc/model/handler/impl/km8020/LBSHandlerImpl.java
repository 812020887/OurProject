package com.kmhc.model.handler.impl.km8020;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PrCellIMapper;
import com.kmhc.model.datacenter.dao.PrIMapper;
import com.kmhc.model.datacenter.dao.PrMMapper;
import com.kmhc.model.datacenter.dao.T9DeviceStatusMapper;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.PrCellI;
import com.kmhc.model.datacenter.model.PrI;
import com.kmhc.model.datacenter.model.PrM;
import com.kmhc.model.datacenter.model.T9DeviceStatus;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type = "KM8020", command = "0x543836")
public class LBSHandlerImpl extends AbstractParentHandlerKM8020 {
	
	private static final Logger log = LoggerFactory.getLogger(LBSHandlerImpl.class);
	private PrMMapper prMMapper = (PrMMapper) SpringBeanFacotry.getInstance().getBean("prMMapper");
    private PrIMapper prIMapper = (PrIMapper) SpringBeanFacotry.getInstance().getBean("prIMapper");
    private PrCellIMapper prCellIMapper = (PrCellIMapper) SpringBeanFacotry.getInstance().getBean("prCellIMapper");
	private T9DeviceStatusMapper t9DeviceStatusMapper = (T9DeviceStatusMapper) SpringBeanFacotry.getInstance().getBean("t9DeviceStatusMapper");

	public LBSHandlerImpl() {
		super(log);
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		log.info(new String(msg));
//		zu1jgjwp80veawu,1,abcd,2011-12-15 10:00:00,1-2, 356511170035899,8,T86,4.10,
//		mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
//		126751160 9
		String function = "S86";
		String content[] = new String(msg).split(",");
		String uid = content[0];
		String timeStr = content[3];
		String imei = content[5];
		String tzStr = "GMT+" + content[6];
		int voltage = (int) (Float.valueOf(content[8]) * 1000);
		String cellStr = content[9];
//		String timeStamp = content[10];
		Date dt = com.kmhc.model.util.Date.getDate(timeStr,"yyyy-MM-dd HH:mm:ss",tzStr);
//		log.debug(sdf.format(dt));
		
		List<Cell> cells = parseCellList(cellStr);
		
		PrM prm = parsePrM(imei, function);			
		PrI pri = getPrI(cells, imei, dt, voltage);
		List<PrCellI> prcelllist = getPrCellI(cells, prm);
		if(prIMapper.selectByPrDate(pri) == 0){
			if(prm != null){
				try{
					prMMapper.insertSelective(prm);
				}catch(Exception e){
					prMMapper.updateByPrimaryKey(prm);
				}
			}
			if(pri != null && pri.getLocStatus().equals("Y")){
				try{
					prIMapper.insertSelective(pri);
				}catch(Exception e){
					prIMapper.updateByPrimaryKey(pri);
				}
			}
			for( int i = 0; prcelllist != null && i < prcelllist.size(); i++){		
				if(prcelllist.get(i).getLocStatus().equals("Y")){
					try{
						prCellIMapper.insertSelective(prcelllist.get(i));
					}catch(Exception e){
						prCellIMapper.updateByPrimaryKey(prcelllist.get(i));
					}
				}
			}
			
			T9DeviceStatus device = t9DeviceStatusMapper.selectByImei(imei);
	
			if (device != null) {
				if(pri != null && pri.getIsvalid().equals("Y")){
					device.setLatitude(pri.getGpsLat());
					device.setLongitude(pri.getGpsLng());
					device.setLbstime(dt);
				}
				device.setVoltage(voltage);
				device.setUpdatetime(dt);
				t9DeviceStatusMapper.updateByPrimaryKey(device);
				push8000Gps(imei,"KM8020","S86");
			}
		}
		dt = new Date();
		String out[] = { uid, content[1], content[2], sdf.format(dt), imei, function };
		return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"), generateResponse(out));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
