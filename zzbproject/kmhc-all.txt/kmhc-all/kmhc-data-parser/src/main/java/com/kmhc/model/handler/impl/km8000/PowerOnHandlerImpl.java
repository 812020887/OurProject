package com.kmhc.model.handler.impl.km8000;


import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.EmgIMapper;
import com.kmhc.model.datacenter.dao.EmgMMapper;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.EmgI;
import com.kmhc.model.datacenter.model.EmgM;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.StringUtil;

/**
 * Name: PowerOnHandlerImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8000.PowerOnHandlerImpl.java]
 * Description: 开机通知协议处理
 * 
 * @since JDK1.7
 * @see
 *
 * @author: xl
 * @date: 2015年11月13日 上午10:40:13
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
@MessageCommand(type="KM8000",command="0x2E")
public class PowerOnHandlerImpl extends AbstractParentHandlerKM8000 {

    private static final Logger log = LoggerFactory.getLogger(PowerOnHandlerImpl.class);
   
    private byte[] ACK_7F_40 = {0, 11, 127, 1, 64};
    private String type = "2e";
    
    public PowerOnHandlerImpl(){
        super(log);
    }
    
    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
        byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
        writeDebugLog(msg,type);
        ReplyMessageContent result = null ;
        EmgM emgm = null ;
        try {
            emgm = byte2Pojo(msg);
        }catch(Exception e){
            log.error("【type=KM8000,command=0x{}】解码失败",type);
            result = new ReplyMessageContent(imeiBytes,ACK_ERROR_KM8000);
            log.error("异常信息：",e);
        }
        try{
            List<Cell> cellList = parseCellList(msg,START_FRAME+51);
            emgm.setCellidCount((short)cellList.size());
            //入数据库Emg_M表
            EmgMMapper emgMMapper = (EmgMMapper) SpringBeanFacotry.getInstance().getBean("emgMMapper");
            int insert = emgMMapper.insertSelective(emgm);
            if(insert>0){
                result = new ReplyMessageContent(imeiBytes,process());
                push8000Gps(emgm.getImei(),"KM8000","0x2E");
            }
            if(cellList.size() >0 ){
                List<EmgI> emgIList = getEmgIList(cellList,emgm.getEmgDetailKey(),emgm.getCreateDate(),emgm.getUpdateDate());
                EmgIMapper emgIMapper = (EmgIMapper) SpringBeanFacotry.getInstance().getBean("emgIMapper");
                emgIMapper.insertList(emgIList);
            }
        } catch (Exception e) {
            result = new ReplyMessageContent(imeiBytes,ACK_ERROR_KM8000);
            log.error("【type=KM8000,command=0x{}】操作数据出现异常",type+e.getMessage());
            log.error("异常信息：",e);
        }
       
        return result;
    }

    private EmgM byte2Pojo(byte[] data) throws ParseException{
        
        EmgM entry = parseEmgBase(data, START_FRAME);
        entry.setEmgDate(sdf.parse(parseDateTime_KM8000(data, START_FRAME+16)));
        entry.setFwDate(sdf.parse(parseDateTime_KM8000(data, START_FRAME+23)));
        entry.setVoltage(Integer.parseInt(StringUtil.toHexStringPadded(data,START_FRAME+38,2),16));
        Cell cell = parseCell(data,START_FRAME+40);
        setCell(entry, cell);
        entry.setType(type);
        entry.setIsvalid("Y");
        entry.setLocStatus("Z");
        return entry;
    }
    
    private byte[][] process(){
        String hexAck00 ="001900yyyyMMddHHmmss000000000000000000";
        byte[] byteDate = toByteUTC_KM8000(new Date());
        String hexDate = TripleDesHelper.byte2hex(byteDate, byteDate.length).toLowerCase();
        hexAck00 = hexAck00.replace("yyyyMMddHHmmss",hexDate);
        byte[][] result = {TripleDesHelper.hex2byte(hexAck00),ACK_7F_40};
        return result;
    }

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}