package com.kmhc.model.handler.impl.km8020;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.handler.impl.PushAlert;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.Publish;

public class BaseReply8020 extends AbstractParentHandlerKM8020 {

	private static final Logger log = LoggerFactory.getLogger(BaseReply8020.class);
	private final byte[] function;

	public BaseReply8020(byte[] function) {
		super(log);
		this.function = function;
		if (function.length > 0)
			this.function[0] = 0x53;
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		log.info(new String(msg));

		String funcStr = new String(this.function);
		String content[] = new String(msg).split(",");

		String uid = content[0];
		String timeStr = content[3];
		String imei = content[5];
		String tzStr = "GMT+" + content[6];

		if (imei == null || imei.equals(""))
			return null;

		TimeZone tz = TimeZone.getTimeZone(tzStr);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		sdf.setTimeZone(tz);
		Date dt = null;
		try {
			dt = sdf.parse(timeStr);
		} catch (ParseException e) {
			dt = new Date();
		}
		log.debug(sdf.format(dt));

		if (funcStr.startsWith("S5") || funcStr.startsWith("S13") || funcStr.startsWith("S88")) { // 定位,S88久坐
			String extras = "";
			int builder_id = INotification.ANDROID_MAKER_DEFAULT;
			String alert = "";
			String title = "";
			extras = String.format("imei=%s|", imei);
			extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_LOW);
			extras += String.format("builder_id=%d|", builder_id);
			extras += String.format("device=%s|", "KM8020");
			if (funcStr.startsWith("S5")) {
				title = "current_hr_title_key";
				alert = new PushAlert(new Object[] { imei }, "current_hr_start_key").toString();
				extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_IMMEDIATE_HR);
			} else if (funcStr.startsWith("S13")) {
				title = "discovery_address_key";
				alert = new PushAlert(new Object[] { imei }, "discovery_address_start_key").toString();
				extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_IMMEDIATE_ADDRESS);
				//取消立即寻址推送
				return null;
			}
			// }else if(funcStr.startsWith("S88")){
			// title = "久坐提醒";
			// alert = String.format("%s 久坐提醒通知", imei);
			// }
			Publish.push(imei, alert, title, builder_id, extras);
			if (funcStr.startsWith("S5") || funcStr.startsWith("S13")) {
				return null;
			}
		}

		dt = new Date();
		String out[] = { uid, content[1], content[2], sdf.format(dt), imei, funcStr };
		return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"), generateResponse(out));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
