package com.kmhc.model.notification;


public interface INotification {
	
	public static int ANDROID_MAKER_DEFAULT = 0;
	public static int ANDROID_MAKER_BATTARY = 1;
	public static int ANDROID_MAKER_SOS = 2;
	public static int ANDROID_MAKER_FALL_DETECTION = 3;
	public static int ANDROID_MAKER_HEALTH_HIGH = 4;
	public static int ANDROID_MAKER_HEALTH_MID = 5;
	public static int ANDROID_MAKER_HEALTH_LOW = 6;
	
	public static int NOTIFICATION_LEVEL_LOW = 1;
	public static int NOTIFICATION_LEVEL_MID = 2;
	public static int NOTIFICATION_LEVEL_HIGH = 3;
	
	public static String NOTIFICATION_TYPE_SOS = "SOS";
	public static String NOTIFICATION_TYPE_FALL_DETRCTION = "FALL";
	public static String NOTIFICATION_TYPE_BATTERY = "BATTERY";
	public static String NOTIFICATION_TYPE_BP = "BP";
	public static String NOTIFICATION_TYPE_BS = "BS";
	public static String NOTIFICATION_TYPE_BO = "BO";
	public static String NOTIFICATION_TYPE_BU = "BU";
	public static String NOTIFICATION_TYPE_HR = "HR";
	public static String NOTIFICATION_TYPE_TEMP = "TEMP";
	public static String NOTIFICATION_TYPE_VOICE = "VOICE";
	public static String NOTIFICATION_TYPE_RECORD = "RECORD";
	public static String NOTIFICATION_TYPE_DEFAULT = "DEFALT";
	public static String NOTIFICATION_TYPE_STP = "STP";
	
	public static String NOTIFICATION_TYPE_SETTING_BODY = "BODYSET";
	public static String NOTIFICATION_TYPE_SETTING_REMIND = "REMINDSET";
	public static String NOTIFICATION_TYPE_SETTING_EMG_CONTACT = "EMGCNTSET";
	public static String NOTIFICATION_TYPE_SETTING_FMY_CONTACT = "FMYCNTSET";
	public static String NOTIFICATION_TYPE_SETTING_HR_TIME_RANGE = "HRTRSET";
	public static String NOTIFICATION_TYPE_SETTING_HR_ALERT = "HRALTSET";
	public static String NOTIFICATION_TYPE_SETTING_LBS_TIME_RANGE = "LBSTRSET";
	public static String NOTIFICATION_TYPE_SETTING_SEDENTARY = "SEDSET";
	public static String NOTIFICATION_TYPE_SETTING_SILENT = "SILENTSET";
	public static String NOTIFICATION_TYPE_SETTING_SLEEP = "SLEEPSET";
	public static String NOTIFICATION_TYPE_SETTING_STEP = "STEPSET";
	public static String NOTIFICATION_TYPE_SETTING_IP_PORT = "IPSET";
	
	public static String NOTIFICATION_TYPE_IMMEDIATE_ADDRESS = "IMADD";
	public static String NOTIFICATION_TYPE_IMMEDIATE_HR = "IMHR";
	
	public static String NOTIFICATION_TYPE_LEAVE_GFENCE = "LVGF";
	
}
