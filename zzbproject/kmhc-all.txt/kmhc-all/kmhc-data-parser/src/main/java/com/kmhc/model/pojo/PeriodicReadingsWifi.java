/*     */ package com.kmhc.model.pojo;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;

import com.kmhc.framework.util.PacketUtil;
/*     */ 
/*     */ public class PeriodicReadingsWifi
/*     */ {
/*  12 */   private String dateString = "";
/*  13 */   private int mVol = 0;
/*  14 */   private Cell cellID = new Cell();
/*     */   boolean[] dmArray;
/*  16 */   private byte DataMap1 = 0;
/*  17 */   private byte DataMap2 = 0;
/*  18 */   private double temp = 0.0D;
/*  19 */   private double pa = 0.0D;
/*  20 */   private GPS gps = new GPS();
/*  21 */   private List<Cell> effectiveCellID = null;
/*     */   private WiFi wifi;
/*  23 */   private List<WiFi> effectiveWifi = null;
/*  24 */   private int gSensorMax = 0;
/*  25 */   private int gSensorAvg = 0;
/*  26 */   private int gyroSensorMax = 0;
/*  27 */   private int gyroSensorAvg = 0;
/*     */ 
/*  29 */   private String imei = "";
/*  30 */   private String imsi = "";
/*     */ 
/*     */   public PeriodicReadingsWifi(byte[] dataBuffer, int offset, int length, boolean[] dmArr) {
/*  34 */     String year = Integer.toString(PacketUtil.toShort(dataBuffer[offset], dataBuffer[(offset + 1)]));
/*  35 */     String month = Integer.toString(PacketUtil.unsignedShort(dataBuffer[(offset + 2)]));
/*  36 */     String day = Integer.toString(PacketUtil.unsignedShort(dataBuffer[(offset + 3)]));
/*  37 */     String hh = Integer.toString(PacketUtil.unsignedShort(dataBuffer[(offset + 4)]));
/*  38 */     String mm = Integer.toString(PacketUtil.unsignedShort(dataBuffer[(offset + 5)]));
/*  39 */     String ss = Integer.toString(PacketUtil.unsignedShort(dataBuffer[(offset + 6)]));
/*  40 */     StringBuffer sB = new StringBuffer("");
/*  41 */     this.dateString = 
/*  42 */       year + "-" + month + "-" + day + " " + hh + ":" + mm + ":" + ss;
/*  43 */     Date currentDate = new Date();
/*  44 */     SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*     */     Date eventDate;
/*     */     try {
/*  46 */       eventDate = dateFormat.parse(this.dateString);
/*     */     }
/*     */     catch (ParseException e) {
/*  49 */       e.printStackTrace();
/*     */     }
/*  51 */     this.dmArray = dmArr;
/*     */ 
/*  54 */     this.mVol = PacketUtil.unsignedInt(PacketUtil.toShort(dataBuffer[(offset + 7)], dataBuffer[(offset + 8)]));
/*     */ 
/*  60 */     char[] mcc_Buffer = new char[3];
/*  61 */     mcc_Buffer[0] = (char)dataBuffer[(offset + 9)];
/*  62 */     mcc_Buffer[1] = (char)dataBuffer[(offset + 10)];
/*  63 */     mcc_Buffer[2] = (char)dataBuffer[(offset + 11)];
/*     */ 
/*  67 */     int len = 0;
/*  68 */     if (dataBuffer[(offset + 12)] != 0) ++len;
/*  69 */     if (dataBuffer[(offset + 13)] != 0) ++len;
/*  70 */     if (dataBuffer[(offset + 14)] != 0) ++len;
/*  71 */     char[] mnc_Buffer = new char[len];
/*     */ 
/*  73 */     if (len == 1) {
/*  74 */       mnc_Buffer[0] = (char)dataBuffer[(offset + 12)];
/*     */     }
/*  76 */     if (len == 2) {
/*  77 */       mnc_Buffer[0] = (char)dataBuffer[(offset + 12)];
/*  78 */       mnc_Buffer[1] = (char)dataBuffer[(offset + 13)];
/*     */     }
/*  80 */     if (len == 3) {
/*  81 */       mnc_Buffer[0] = (char)dataBuffer[(offset + 12)];
/*  82 */       mnc_Buffer[1] = (char)dataBuffer[(offset + 13)];
/*  83 */       mnc_Buffer[2] = (char)dataBuffer[(offset + 14)];
/*     */     }
/*     */ 
/*  91 */     String mccString = String.valueOf(mcc_Buffer);
/*  92 */     String mncString = String.valueOf(mnc_Buffer);
/*     */ 
/*  94 */     System.out.println("MCC:" + mccString + " MNC:" + mncString);
/*     */ 
/*  97 */     this.cellID.setMcc(Integer.valueOf(mccString).intValue());
/*  98 */     this.cellID.setMnc(Integer.valueOf(mncString).intValue());
/*     */ 
/* 103 */     this.cellID.setLac(PacketUtil.unsignedInt(PacketUtil.toShort(dataBuffer[(offset + 15)], dataBuffer[(offset + 16)])));
/* 104 */     this.cellID.setCellid(PacketUtil.unsignedInt(PacketUtil.toShort(dataBuffer[(offset + 17)], dataBuffer[(offset + 18)])));
/* 105 */     this.cellID.setRssi(dataBuffer[(offset + 19)]);
/* 106 */     this.DataMap1 = dataBuffer[(offset + 20)];
/* 107 */     this.DataMap1 = dataBuffer[(offset + 21)];
/* 108 */     offset += 22;
/* 109 */     if (dmArr[1] != false)
/*     */     {
/* 111 */       int Int_temp = PacketUtil.unsignedInt(dataBuffer[(offset++)]);
/* 112 */       int Fract_temp = PacketUtil.unsignedInt(PacketUtil.toShort(dataBuffer[(offset++)], dataBuffer[(offset++)]));
/* 113 */       StringBuffer tempSB = new StringBuffer("");
/* 114 */       tempSB.append(Integer.toString(Int_temp));
/* 115 */       tempSB.append(".");
/* 116 */       tempSB.append(Integer.toString(Fract_temp));
/* 117 */       this.temp = new Double(tempSB.toString()).doubleValue();
/*     */     }
/*     */ 
/* 120 */     if (dmArr[2] != false)
/*     */     {
/* 122 */       int pa_int = PacketUtil.toInt((byte)0, dataBuffer[(offset++)], dataBuffer[(offset++)], dataBuffer[(offset++)]);
/* 123 */       this.pa = (pa_int / 10000.0D);
/*     */     }
/*     */ 
/* 127 */     if (dmArr[3] != false)
/*     */     {
/* 130 */       int latDisp = PacketUtil.unsignedInt(dataBuffer[(offset++)]);
/* 131 */       if (latDisp == 0)
/*     */       {
/* 133 */         this.gps.setLatDispStr("N");
/*     */       }
/* 135 */       else if (latDisp == 8)
/*     */       {
/* 137 */         this.gps.setLatDispStr("S");
/*     */       }
/* 139 */       else if (latDisp == 128)
/*     */       {
/* 142 */         this.gps.setLatDispStr("0");
/*     */       }
/* 144 */       else if (latDisp == 136)
/*     */       {
/* 147 */         this.gps.setLatDispStr("8");
/*     */       }
/*     */       else
/*     */       {
/* 151 */         this.gps.setLatDispStr("F");
/*     */       }
/*     */ 
/* 157 */       int Int_lat = PacketUtil.unsignedInt(dataBuffer[(offset++)]);
/*     */ 
/* 159 */       int Fract_lat = 10000000 + PacketUtil.toInt((byte)00, dataBuffer[(offset++)], dataBuffer[(offset++)], dataBuffer[(offset++)]);
/*     */ 
/* 161 */       StringBuffer latSB = new StringBuffer("");
/* 162 */       latSB.append(Integer.toString(Int_lat));
/* 163 */       latSB.append(".");
/* 164 */       String s = Integer.toString(Fract_lat);
/* 165 */       latSB.append(s.toCharArray(), 1, 7);
/*     */ 
/* 169 */       if ((this.gps.getLatDispStr().equals("S")) || 
/* 170 */         (this.gps.getLatDispStr().equals("8")))
/* 171 */         this.gps.setLat(0.0D - new Double(latSB.toString()).doubleValue());
/*     */       else {
/* 173 */         this.gps.setLat(new Double(latSB.toString()).doubleValue());
/*     */       }
/* 175 */       int lngDisp = PacketUtil.unsignedInt(dataBuffer[(offset++)]);
/* 176 */       if (lngDisp == 0)
/*     */       {
/* 178 */         this.gps.setLngDispStr("E");
/*     */       }
/* 180 */       else if (lngDisp == 8)
/*     */       {
/* 182 */         this.gps.setLngDispStr("W");
/*     */       }
/* 184 */       else if (lngDisp == 128)
/*     */       {
/* 187 */         this.gps.setLngDispStr("0");
/*     */       }
/* 189 */       else if (lngDisp == 136)
/*     */       {
/* 192 */         this.gps.setLngDispStr("8");
/*     */       }
/*     */       else
/*     */       {
/* 196 */         this.gps.setLngDispStr("F");
/*     */       }
/*     */ 
/* 201 */       int Int_lng = PacketUtil.unsignedInt(dataBuffer[(offset++)]);
/*     */ 
/* 203 */       int Fract_lng = 10000000 + PacketUtil.toInt((byte)00, dataBuffer[(offset++)], dataBuffer[(offset++)], dataBuffer[(offset++)]);
/*     */ 
/* 205 */       StringBuffer lngSB = new StringBuffer("");
/* 206 */       lngSB.append(Integer.toString(Int_lng));
/* 207 */       lngSB.append(".");
/* 208 */       s = Integer.toString(Fract_lng);
/* 209 */       lngSB.append(s.toCharArray(), 1, 7);
/*     */ 
/* 213 */       if ((this.gps.getLngDispStr().equals("W")) || 
/* 214 */         (this.gps.getLngDispStr().equals("8")))
/* 215 */         this.gps.setLng(0.0D - new Double(lngSB.toString()).doubleValue());
/*     */       else
/* 217 */         this.gps.setLng(new Double(lngSB.toString()).doubleValue());
/*     */     }
/*     */     int i;
/* 223 */     if (dmArr[4] != false)
/*     */     {
/* 225 */       int cellCount = PacketUtil.unsignedInt(dataBuffer[(offset++)]);
/*     */ 
/* 227 */       for (i = 0; i < cellCount; ++i) {
/* 228 */         Cell cid = new Cell();
/*     */ 
/* 234 */         mcc_Buffer[0] = (char)dataBuffer[offset];
/* 235 */         mcc_Buffer[1] = (char)dataBuffer[(offset + 1)];
/* 236 */         mcc_Buffer[2] = (char)dataBuffer[(offset + 2)];
/*     */ 
/* 240 */         len = 0;
/* 241 */         if (dataBuffer[(offset + 3)] != 0) ++len;
/* 242 */         if (dataBuffer[(offset + 4)] != 0) ++len;
/* 243 */         if (dataBuffer[(offset + 5)] != 0) ++len;
/* 244 */         mnc_Buffer = new char[len];
/*     */ 
/* 246 */         if (len == 1) {
/* 247 */           mnc_Buffer[0] = (char)dataBuffer[(offset + 3)];
/*     */         }
/* 249 */         if (len == 2) {
/* 250 */           mnc_Buffer[0] = (char)dataBuffer[(offset + 3)];
/* 251 */           mnc_Buffer[1] = (char)dataBuffer[(offset + 4)];
/*     */         }
/* 253 */         if (len == 3) {
/* 254 */           mnc_Buffer[0] = (char)dataBuffer[(offset + 3)];
/* 255 */           mnc_Buffer[1] = (char)dataBuffer[(offset + 4)];
/* 256 */           mnc_Buffer[2] = (char)dataBuffer[(offset + 5)];
/*     */         }
/*     */ 
/* 264 */         mccString = String.valueOf(mcc_Buffer);
/* 265 */         mncString = String.valueOf(mnc_Buffer);
/*     */ 
/* 267 */         System.out.println("MCC:" + mccString + " MNC:" + mncString);
/*     */ 
/* 269 */         cid.setMcc(Integer.valueOf(mccString).intValue());
/* 270 */         cid.setMnc(Integer.valueOf(mncString).intValue());
/*     */ 
/* 274 */         cid.setLac(PacketUtil.unsignedInt(PacketUtil.toShort(dataBuffer[(offset + 6)], dataBuffer[(offset + 7)])));
/* 275 */         cid.setCellid(PacketUtil.unsignedInt(PacketUtil.toShort(dataBuffer[(offset + 8)], dataBuffer[(offset + 9)])));
/* 276 */         cid.setRssi(dataBuffer[(offset + 10)]);
/* 277 */         if (this.effectiveCellID == null) {
/* 278 */           this.effectiveCellID = new ArrayList();
/*     */         }
/* 280 */         this.effectiveCellID.add(cid);
/*     */ 
/* 282 */         offset += 11;
/*     */       }
/*     */     }
/*     */ 
/* 286 */     if (dmArr[5] != false)
/*     */     {
/* 302 */       int wifiNum = PacketUtil.unsignedShort(dataBuffer[offset]);
/* 303 */       System.out.println("===> time: " + this.dateString + " WIFI count: " + wifiNum);
/* 304 */       ++offset;
/* 305 */       for (i = 0; i < wifiNum; ++i) {
/* 306 */         WiFi wifi = new WiFi();
/*     */ 
/* 308 */         byte[] wifimacbuf = new byte[6];
/* 309 */         for (int j = 0; j < 6; ++j) {
/* 310 */           wifimacbuf[j] = dataBuffer[(offset + j)];
/*     */         }
/* 312 */         wifi.setMac(PacketUtil.toHexString("", wifimacbuf, 6));
/* 313 */         System.out.println("wifiMac: " + wifi.getMac());
/* 314 */         wifi.setSignalLevel(PacketUtil.unsignedInt(dataBuffer[(offset + 6)]));
/* 315 */         wifi.setChannel(PacketUtil.unsignedInt(dataBuffer[(offset + 7)]));
/* 316 */         wifi.setSignal_dB(PacketUtil.unsignedInt(dataBuffer[(offset + 8)]));
/* 317 */         if (this.effectiveWifi == null) {
/* 318 */           this.effectiveWifi = new ArrayList();
/*     */         }
/* 320 */         this.effectiveWifi.add(wifi);
/* 321 */         offset += 9;
/*     */       }
/*     */     }
/*     */ 
/* 325 */     if (dmArr[6] != false)
/*     */     {
/* 327 */       offset += 4;
/*     */     }
/*     */ 
/* 330 */     if (dmArr[7] == false)
/*     */       return;
/* 332 */     offset += 4;
/*     */   }
/*     */ 
/*     */   public String getDateString()
/*     */   {
/* 337 */     return this.dateString;
/*     */   }
/*     */ 
/*     */   public void setDateString(String dateString) {
/* 341 */     this.dateString = dateString;
/*     */   }
/*     */ 
/*     */   public int getmVol() {
/* 345 */     return this.mVol;
/*     */   }
/*     */ 
/*     */   public void setmVol(int mVol) {
/* 349 */     this.mVol = mVol;
/*     */   }
/*     */ 
/*     */   public Cell getCellID() {
/* 353 */     return this.cellID;
/*     */   }
/*     */ 
/*     */   public void setCellID(Cell cellID) {
/* 357 */     this.cellID = cellID;
/*     */   }
/*     */ 
/*     */   public byte getDataMap1() {
/* 361 */     return this.DataMap1;
/*     */   }
/*     */ 
/*     */   public void setDataMap1(byte dataMap1) {
/* 365 */     this.DataMap1 = dataMap1;
/*     */   }
/*     */ 
/*     */   public byte getDataMap2() {
/* 369 */     return this.DataMap2;
/*     */   }
/*     */ 
/*     */   public void setDataMap2(byte dataMap2) {
/* 373 */     this.DataMap2 = dataMap2;
/*     */   }
/*     */ 
/*     */   public double getTemp() {
/* 377 */     return this.temp;
/*     */   }
/*     */ 
/*     */   public void setTemp(double temp) {
/* 381 */     this.temp = temp;
/*     */   }
/*     */ 
/*     */   public double getPa() {
/* 385 */     return this.pa;
/*     */   }
/*     */ 
/*     */   public void setPa(double pa) {
/* 389 */     this.pa = pa;
/*     */   }
/*     */ 
/*     */   public GPS getGps() {
/* 393 */     return this.gps;
/*     */   }
/*     */ 
/*     */   public void setGps(GPS gps) {
/* 397 */     this.gps = gps;
/*     */   }
/*     */ 
/*     */   public List<Cell> getEffectiveCellID() {
/* 401 */     return this.effectiveCellID;
/*     */   }
/*     */ 
/*     */   public void setEffectiveCellID(List<Cell> effectiveCellID) {
/* 405 */     this.effectiveCellID = effectiveCellID;
/*     */   }
/*     */ 
/*     */   public WiFi getWifi() {
/* 409 */     return this.wifi;
/*     */   }
/*     */ 
/*     */   public void setWifi(WiFi wifi) {
/* 413 */     this.wifi = wifi;
/*     */   }
/*     */ 
/*     */   public int getgSensorMax() {
/* 417 */     return this.gSensorMax;
/*     */   }
/*     */ 
/*     */   public void setgSensorMax(int gSensorMax) {
/* 421 */     this.gSensorMax = gSensorMax;
/*     */   }
/*     */ 
/*     */   public int getgSensorAvg() {
/* 425 */     return this.gSensorAvg;
/*     */   }
/*     */ 
/*     */   public void setgSensorAvg(int gSensorAvg) {
/* 429 */     this.gSensorAvg = gSensorAvg;
/*     */   }
/*     */ 
/*     */   public int getGyroSensorMax() {
/* 433 */     return this.gyroSensorMax;
/*     */   }
/*     */ 
/*     */   public void setGyroSensorMax(int gyroSensorMax) {
/* 437 */     this.gyroSensorMax = gyroSensorMax;
/*     */   }
/*     */ 
/*     */   public int getGyroSensorAvg() {
/* 441 */     return this.gyroSensorAvg;
/*     */   }
/*     */ 
/*     */   public void setGyroSensorAvg(int gyroSensorAvg) {
/* 445 */     this.gyroSensorAvg = gyroSensorAvg;
/*     */   }
/*     */ 
/*     */   public boolean[] getDmArray() {
/* 449 */     return this.dmArray;
/*     */   }
/*     */ 
/*     */   public void setDmArray(boolean[] dmArray) {
/* 453 */     this.dmArray = dmArray;
/*     */   }
/*     */ 
/*     */   public String getImei() {
/* 457 */     return this.imei;
/*     */   }
/*     */ 
/*     */   public void setImei(String imei) {
/* 461 */     this.imei = imei;
/*     */   }
/*     */ 
/*     */   public String getImsi() {
/* 465 */     return this.imsi;
/*     */   }
/*     */ 
/*     */   public void setImsi(String imsi) {
/* 469 */     this.imsi = imsi;
/*     */   }
/*     */ 
/*     */   public List<WiFi> getEffectiveWifi() {
/* 473 */     return this.effectiveWifi;
/*     */   }
/*     */ 
/*     */   public void setEffectiveWifi(List<WiFi> effectiveWifi) {
/* 477 */     this.effectiveWifi = effectiveWifi;
/*     */   }
/*     */ }

/* Location:           E:\doc\康美手表Server\Guider\台北蓋德_安裝光碟公版_台灣20140515\2.Gateway Program\icare2\WEB-INF\classes\
 * Qualified Name:     com.paralucent.gateway2.model.PeriodicReadingsWifi
 * JD-Core Version:    0.5.3
 */