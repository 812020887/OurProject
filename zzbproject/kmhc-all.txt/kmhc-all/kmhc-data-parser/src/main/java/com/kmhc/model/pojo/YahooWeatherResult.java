package com.kmhc.model.pojo;

import java.io.Serializable;

public class YahooWeatherResult implements Serializable{
//	{
//	"query":
//		{
//			"count":1,
//			"created":"2016-03-10T08:05:15Z",
//			"lang":"zh-CN",
//			"results":
//				{
//					"channel":
//						{	
//							"item":
//								{
//									"condition":
//										{
//											"code":"26",
//											"date":"Thu, 10 Mar 2016 3:01 pm CST",
//											"temp":"11",
//											"text":"Cloudy"},
//									"forecast":
//										{
//											"code":"11",
//											"date":"10 Mar 2016",
//											"day":"Thu",
//											"high":"11",
//											"low":"8",
//											"text":"Showers"}
//				}}}}}
	private static final long serialVersionUID = -5468437288037393408L;
	private Query query;
	
	public Query getQuery() {
		return query;
	}

	public void setQuery(Query query) {
		this.query = query;
	}
	
	public class Query implements Serializable{
		private static final long serialVersionUID = -1479714309605050023L;
		private int count;
		private String created;
		private String lang;
		private Results results;

		public int getCount() {
			return count;
		}

		public void setCount(int count) {
			this.count = count;
		}

		public String getCreated() {
			return created;
		}

		public void setCreated(String created) {
			this.created = created;
		}

		public String getLang() {
			return lang;
		}

		public void setLang(String lang) {
			this.lang = lang;
		}

		public Results getResults() {
			return results;
		}

		public void setResults(Results results) {
			this.results = results;
		}
		
		public class Results implements Serializable{
			private static final long serialVersionUID = -103444348841253294L;
			private Channel channel;
			
			public Channel getChannel() {
				return channel;
			}

			public void setChannel(Channel channel) {
				this.channel = channel;
			}
			
			public class Channel implements Serializable{
				private static final long serialVersionUID = 7784941317831899675L;				
				private Item item;
//				private Forecast forecast;
						
				public Item getItem() {
					return item;
				}

				public void setItem(Item item) {
					this.item = item;
				}

//				public Forecast getForecast() {
//					return forecast;
//				}
//
//				public void setForecast(Forecast forecast) {
//					this.forecast = forecast;
//				}

				public class Item implements Serializable{

					private static final long serialVersionUID = 8911546986628503246L;
					private Condition condition;
					private Forecast forecast;
					
					public Condition getCondition() {
						return condition;
					}
					public void setCondition(Condition condition) {
						this.condition = condition;
					}			
					public Forecast getForecast() {
						return forecast;
					}
					public void setForecast(Forecast forecast) {
						this.forecast = forecast;
					}
					
					public class Condition implements Serializable{

						private static final long serialVersionUID = -1444701296647533706L;

						
						private String code;
						private String date;
						private String temp;
						private String text;
						
						public String getCode() {
							return code;
						}
						public void setCode(String code) {
							this.code = code;
						}
						public String getDate() {
							return date;
						}
						public void setDate(String date) {
							this.date = date;
						}
						public String getTemp() {
							return temp;
						}
						public void setTemp(String temp) {
							this.temp = temp;
						}
						public String getText() {
							return text;
						}
						public void setText(String text) {
							this.text = text;
						}
						
					}
					
					public class Forecast implements Serializable{

						private static final long serialVersionUID = 3972434351643471143L;
						private String code;
						private String date;
						private String day;
						private String high;
						private String low;
						private String text;
						public String getCode() {
							return code;
						}
						public void setCode(String code) {
							this.code = code;
						}
						public String getDate() {
							return date;
						}
						public void setDate(String date) {
							this.date = date;
						}
						public String getDay() {
							return day;
						}
						public void setDay(String day) {
							this.day = day;
						}
						public String getHigh() {
							return high;
						}
						public void setHigh(String high) {
							this.high = high;
						}
						public String getLow() {
							return low;
						}
						public void setLow(String low) {
							this.low = low;
						}
						public String getText() {
							return text;
						}
						public void setText(String text) {
							this.text = text;
						}
					}
				}
			}		
		}
		
	}
}
