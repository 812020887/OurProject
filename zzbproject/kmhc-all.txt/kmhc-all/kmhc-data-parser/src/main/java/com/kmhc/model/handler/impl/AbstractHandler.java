/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月7日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import com.kmhc.model.datacenter.dao.*;
import com.kmhc.model.datacenter.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.gson.JsonObject;
import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.handler.IHandler;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.Publish;
import com.kmhc.model.util.StringUtil;

/**
 * Name: AbstractHandler.java ProjectName: [kmhc-data-parser] Package:
 * [com.kmhc.model.handler.impl.AbstractHandler.java] Description:
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月7日 上午11:25:24
 *
 *        Update-User: @author Update-Time: Update-Remark:
 * 
 *        Check-User: Check-Time: Check-Remark:
 * 
 *        Company: kmhc Copyright: kmhc
 */
public abstract class AbstractHandler implements IHandler{
    public static final byte[] ACK_ERROR_KM8000 = { 0, 9, 1 };
    public static final byte[] ACK_SUCCESS_KM8000 = { 0, 9, 0 };
    public static final byte[] ACK_SUCCESS_KM8010 = { 1, -128, -2 };
    public static final byte[] ACK_ERROR_KM8010 = { 16, 8, -17 };
    public static final byte[] PID_KM8010 = { 1, 1 };

    private static final Logger log = LoggerFactory.getLogger(AbstractHandler.class);

    public final SimpleDateFormat yyMMddHHmmss = new SimpleDateFormat("yyMMddHHmmss");

    @SuppressWarnings("finally")
    @Override
    public ReplyMessageContent handleBasicMessage(MessageContent msg) {

        try {
        } catch (Exception e) {

        } finally {
            return handleMessage(msg.getMsg());
        }
    }

    protected Gps parseGps(byte[] data, int index) throws Exception {
        Gps gps = null;
        try {
            int latFlag = 0xFF & data[index];
            int lngFlag = 0xFF & data[index + 5];
            String direction_lat = "F";
            String direction_lng = "F";
            if (latFlag == 0) {
                direction_lat = "N";
            } else if (latFlag == 8) {
                direction_lat = "S";
            }

            if (lngFlag == 0) {
                direction_lng = "E";
            } else if (lngFlag == 8) {
                direction_lng = "W";
            }
            BigDecimal lng = new BigDecimal(0);
            BigDecimal lat = new BigDecimal(0);
            if ("NS".contains(direction_lat) && "WE".contains(direction_lng)) {
                int lat_integer = 0xFF & data[index + 1];
                int lng_integer = 0xFF & data[index + 6];
                String lat_decimal = String.valueOf(Integer.parseInt(StringUtil.toHexString(data, index + 2, 3), 16));
                String lng_decimal = String.valueOf(Integer.parseInt(StringUtil.toHexString(data, index + 7, 3), 16));
                lat_decimal = "0000000".substring(0, 7 - lat_decimal.length()) + lat_decimal;
                lng_decimal = "0000000".substring(0, 7 - lng_decimal.length()) + lng_decimal;
                String lat_str = lat_integer + "." + lat_decimal;
                String lng_str = lng_integer + "." + lng_decimal;
//                log.debug("===============================");
//                log.debug(lat_str);
//                log.debug(lng_str);
//                log.debug("=============================== ");
                lat = new BigDecimal(lat_str).setScale(6, RoundingMode.HALF_EVEN);
                lng = new BigDecimal(lng_str).setScale(6, RoundingMode.HALF_EVEN);
                // lat = Double.parseDouble(lat_str.length() > 10 ?
                // lat_str.substring(0, 10) : lat_str);
                // lng = Double.parseDouble(lng_str.length() > 10 ?
                // lng_str.substring(0, 10) : lng_str);
            }
            gps = new Gps(lat, lng, direction_lat, direction_lng, "Y");
            return gps;
        } catch (Exception e) {
            throw new Exception("解析协议GPS经纬度出错", e);
        }
    }

    protected EmgM setGps(EmgM emgm, Gps gps) {
        if (gps != null) {
            emgm.setGpsLat(gps.getLat());
            emgm.setGpsLng(gps.getLng());
            emgm.setGpsEwLng(gps.getDirectionLng());
            emgm.setGpsNsLat(gps.getDirectionLat());
            emgm.setIsvalid(gps.getIsValid());
            if (gps.getAddress() != null && !gps.getAddress().equals(""))
                emgm.setAddress(gps.getAddress());
        }
        return emgm;
    }

    protected EmgM setCell(EmgM emgm, Cell cell) {
        if (cell != null) {
            emgm.setMcc(cell.getMcc());
            emgm.setMnc(cell.getMnc());
            emgm.setLac(cell.getLac());
            emgm.setCellid(cell.getCellid());
            emgm.setRssi(cell.getRssi());
        }
        return emgm;
    }

    protected void setWifiList(EmgM emgm, List<Wifi> wifi) {
        for (int i = 0; i < wifi.size() && i < 10; i++) {
            try {
                MethodHandle mac = MethodHandles.publicLookup().findVirtual(EmgM.class, "setWifiMac" + (i + 1),
                        MethodType.methodType(void.class, String.class));
                // Method mac =
                // emgmClass.getMethod("setWifiMac"+(i+1),String.class);
                MethodHandle signal = MethodHandles.publicLookup().findVirtual(EmgM.class, "setWifiSignal" + (i + 1),
                        MethodType.methodType(void.class, Short.class));
                MethodHandle channel = MethodHandles.publicLookup().findVirtual(EmgM.class, "setWifiChannel" + (i + 1),
                        MethodType.methodType(void.class, Short.class));
                MethodHandle ratio = MethodHandles.publicLookup().findVirtual(EmgM.class, "setWifiRatio" + (i + 1),
                        MethodType.methodType(void.class, Short.class));
                mac.invoke(emgm, wifi.get(i).getWifiMac());
                signal.invoke(emgm, wifi.get(i).getWifiSignal());
                channel.invoke(emgm, wifi.get(i).getWifiChannel());
                ratio.invoke(emgm, wifi.get(i).getWifiRatio());
            } catch (IllegalAccessException e) {
                e.printStackTrace();
                log.error("设置WiFi数据出错", e);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
                log.error("设置WiFi数据出错", e);
            } catch (InvocationTargetException e) {
                e.printStackTrace();
                log.error("设置WiFi数据出错", e);
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
                log.error("设置WiFi数据出错", e);
            } catch (SecurityException e) {
                e.printStackTrace();
                log.error("设置WiFi数据出错", e);
            } catch (Throwable e) {
                e.printStackTrace();
                log.error("设置WiFi数据出错", e);
            }
        }
    }

    protected EmgI getEmgI(Cell cell, String emgKeyDetail, short itemno, Date createDate, Date update) {
        EmgI emgI = new EmgI();
        emgI.setEmgDetailKey(emgKeyDetail);
        emgI.setMcc(cell.getMcc());
        emgI.setMnc(cell.getMnc());
        emgI.setLac(cell.getLac());
        emgI.setCellid(cell.getCellid());
        emgI.setRssi(cell.getRssi());
        emgI.setItemno(itemno);
        emgI.setCreateDate(createDate);
        emgI.setUpdateDate(update);
        return emgI;
    }

    protected List<EmgI> getEmgIList(List<Cell> list, String emgKeyDetail, Date createDate, Date update) {
        ArrayList<EmgI> emgIlist = new ArrayList<EmgI>();
        for (short i = 0; i < list.size(); i++) {
            EmgI cell = getEmgI(list.get(i), emgKeyDetail, i, createDate, update);
            emgIlist.add(cell);
        }
        return emgIlist;
    }

    protected void requestGFenceNotice(String imei, BigDecimal lat, BigDecimal lng, Double hpe,String device) {
        if (lat != null && lng != null) {
            String pushStr = String.format("5,@%s,@%f,@%f,@%f,@%s", imei, lat.doubleValue(), lng.doubleValue(), hpe,device);
            Publish.push(pushStr);
        }
    }

    protected void sendNotification(EmgM emgm, String device, String phone) {
        String extras = "";
        String alert = "";
        String title = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        int builder_id = INotification.ANDROID_MAKER_DEFAULT;

        extras = String.format("imei=%s|", emgm.getImei());
        extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_HIGH);
        extras += String.format("NS=%s|", emgm.getGpsNsLat());
        extras += String.format("EW=%s|", emgm.getGpsEwLng());
        if (emgm != null && emgm.getIsvalid() != null && emgm.getIsvalid().equals("Y"))
            extras += String.format("lat=%f|", emgm.getGpsLat().doubleValue());
        if (emgm != null && emgm.getIsvalid() != null && emgm.getIsvalid().equals("Y"))
            extras += String.format("lon=%f|", emgm.getGpsLng().doubleValue());
        extras += String.format("hpe=%f|", emgm.getHpe());
        extras += String.format("address=%s|", emgm.getAddress().replace(",", ""));
        extras += String.format("device=%s|", device);
       
        
        String type = emgm.getType();
        if (type.equals("22") || type.equals("S89") || type.equals("S85")|| type.equals("A10SOS")) {
        	if(type.equals("A10SOS")){
        		title = "a10_sos_urgent_title_key";
        		 alert = new PushAlert(new Object[] { emgm.getImei() }, "a10sos_urgent_alert_key").toString();
        	}else{
        		 title = "sos_urgent_title_key";
        		 alert = new PushAlert(new Object[] { emgm.getImei() }, "sos_urgent_alert_key").toString();
        	}
            builder_id = INotification.ANDROID_MAKER_SOS;
            extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_SOS);
            extras += String.format("builder_id=%d|", INotification.ANDROID_MAKER_SOS);
            extras += "gps=false|";
        } else if (type.equals("23")) {
            title = "sos_fall_title_key";
            alert = new PushAlert(new Object[] { emgm.getImei() }, "sos_fall_alert_key").toString();
            builder_id = INotification.ANDROID_MAKER_FALL_DETECTION;
            extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_FALL_DETRCTION);
            extras += String.format("builder_id=%d|", INotification.ANDROID_MAKER_FALL_DETECTION);
            extras += "gps=false|";
        } else if (type.equals("24")) {
            title = "sos_urgent_title_key";
            alert = new PushAlert(new Object[] { emgm.getImei() }, "sos_urgent_alert_key").toString();
            builder_id = INotification.ANDROID_MAKER_SOS;
            extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_SOS);
            extras += String.format("builder_id=%d|", INotification.ANDROID_MAKER_SOS);
            extras += "gps=true|";
        } else if (type.equals("25")) {
            title = "sos_fall_title_key";
            alert = new PushAlert(new Object[] { emgm.getImei() }, "sos_fall_alert_key").toString();
            builder_id = INotification.ANDROID_MAKER_FALL_DETECTION;
            extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_FALL_DETRCTION);
            extras += String.format("builder_id=%d|", INotification.ANDROID_MAKER_FALL_DETECTION);
            extras += "gps=true|";
        } else {
        }
        if (!title.equals("")) {
        	
        	Publish.push(emgm.getImei(), alert, title, builder_id, extras);  
        		String Method ="";
        		if(type.equals("24") || type.equals("25")){
        			Method = Method+"G";
        		}
        		if(emgm.getCellidCount()!=null&&emgm.getCellidCount()>0){
        			Method = Method+"C";
        		}
        		if(emgm.getWifiStatus()!=null&&emgm.getWifiStatus().equals("Y")){
        			Method = Method+"W";
        		}
        		
        		extras="";
        	    extras += String.format("IMEI=%s|", emgm.getImei());
                extras += String.format("EmgDate=%s|", emgm.getEmgDate().getTime());
                extras += String.format("Address=%s|", emgm.getAddress());
                extras += String.format("Lat=%s|", emgm.getGpsLat());
                extras += String.format("Lng=%s|", emgm.getGpsLng());
                extras += String.format("Hpe=%s|", emgm.getHpe());
                extras += String.format("Method=%s|", Method);
                extras += String.format("device=%s|", device);
                log.debug("sos_urgent_title_key_extras:"+extras);
                //gps紧急推送不 推送到档案
                if(!type.equals("A10SOS"))
                Publish.pushHL(emgm.getImei(), alert, title, builder_id, extras);  
        	
            if(phone == null ) phone="";
			JsonObject callCenterParam = new JsonObject();
			callCenterParam.addProperty("imei", emgm.getImei());
			callCenterParam.addProperty("SosPhoneNumber", phone);
			callCenterParam.addProperty("SosGpsAddress", emgm.getAddress().replace(",", ""));
			callCenterParam.addProperty("SosGpsLng", String.format("%f", emgm.getGpsLng().doubleValue()));
			callCenterParam.addProperty("SosGpsLat", String.format("%f", emgm.getGpsLat().doubleValue()));
			callCenterParam.addProperty("SosTime", sdf.format(new Date()));
			String msg = "TPARTY,@CALLCENTER,@" + callCenterParam.toString();
			ReplyMessageContent content = new ReplyMessageContent(msg.getBytes(StandardCharsets.UTF_8));
			//gps紧急推送不 推送到callCenter
            if(!type.equals("A10SOS"))
			Publish.send(content);
        }
    }

    /**
     * 血氧推送，高于或者低于进行推送
     * 
     * @param imei
     * 
     */
    protected void push(String imei, short spo2, String device) {
        MemberSettingBloodoxygenMapper oxygenMapper = (MemberSettingBloodoxygenMapper) SpringBeanFacotry.getInstance()
                .getBean("memberSettingBloodoxygenMapper");

        MemberSettingBloodoxygen oxygen = oxygenMapper.selectByPrimaryKey(imei);
        boolean isPush = false;
        String extras = "";
        String alert = "";
        String title = "oxygent_title_key";
        int builder_id = INotification.ANDROID_MAKER_HEALTH_HIGH;

        if (oxygen != null) {
            if (oxygen.getBoH() < spo2) {
                alert = new PushAlert(new Object[] { imei }, "oxygent_alert_key").toString();
                builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
                extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_MID);
                isPush = true;
            } else if (oxygen.getBoL() > spo2) {
                if (spo2 > 90) {
                    alert = new PushAlert(new Object[] { imei }, "oxygent_alert_low").toString();
                    builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
                    extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_MID);
                } else {
                    alert = new PushAlert(new Object[] { imei }, "oxygent_alert_serious_low").toString();
                    builder_id = INotification.ANDROID_MAKER_HEALTH_HIGH;
                    extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_HIGH);
                }
                isPush = true;
            }
        } else {
            if (spo2 > 98) {
                alert = new PushAlert(new Object[] { imei }, "oxygent_alert_key").toString();
                builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
                extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_MID);
                isPush = true;
            } else if (spo2 > 90 && spo2 < 95) {
                alert = new PushAlert(new Object[] { imei }, "oxygent_alert_low").toString();
                builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
                extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_MID);
                isPush = true;
            } else if (spo2 <= 90) {
                alert = new PushAlert(new Object[] { imei }, "oxygent_alert_serious_low").toString();
                builder_id = INotification.ANDROID_MAKER_HEALTH_HIGH;
                extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_HIGH);
                isPush = true;
            }
        }
        if (isPush) {
            // new Pusher().push("17", imei);
            extras = String.format("imei=%s|", imei);
            extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_BO);
            extras += String.format("builder_id=%d|", builder_id);
            extras += String.format("spo2=%d|", spo2);
            extras += String.format("device=%s|", device);
            Publish.push(imei, alert, title, builder_id, extras);
        }
    }

    /**
     * 心率推送，高于或者低于进行推送
     * 
     * @param imei
     * 
     */
    protected void push(String imei, int hr, String device) {
        MemberSettingHeartrateMapper hrMapper = (MemberSettingHeartrateMapper) SpringBeanFacotry.getInstance()
                .getBean("memberSettingHeartrateMapper");
        T9DeviceStatusMapper t9Mapper = (T9DeviceStatusMapper) SpringBeanFacotry.getInstance()
                .getBean("t9DeviceStatusMapper");

        MemberSettingHeartrate record = hrMapper.selectByPrimaryKey(imei);
        boolean isPush = false;
        String extras = "";
        String alert = "";
        String title = "ecg_title_key";
        int builder_id = INotification.ANDROID_MAKER_HEALTH_MID;

        if (hr <= 1 && device.endsWith("KM8020")) {
            alert = new PushAlert(new Object[] { imei }, "ecg_alert_fall").toString();
            builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
            extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_MID);
            isPush = true;
        } else {
            if (record != null && record.getHeartRateHigh() != null && record.getHeartRateLow() != null) {
                if (record.getHeartRateHigh() < hr) {
                    alert = new PushAlert(new Object[] { imei }, "ecg_alert_high").toString();
                    builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
                    extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_MID);
                    isPush = true;
                } else if (record.getHeartRateLow() > hr) {
                    alert = new PushAlert(new Object[] { imei }, "ecg_alert_low").toString();
                    builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
                    extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_MID);
                    isPush = true;
                }
            } else {
                if (hr > 100) {
                    alert = new PushAlert(new Object[] { imei }, "ecg_alert_high").toString();
                    builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
                    extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_MID);
                    isPush = true;
                } else if (hr <= 60) {
                    alert = new PushAlert(new Object[] { imei }, "ecg_alert_low").toString();
                    builder_id = INotification.ANDROID_MAKER_HEALTH_HIGH;
                    extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_HIGH);
                    isPush = true;
                }
            }
        }
        T9DeviceStatus t9 = t9Mapper.selectByImei(imei);
        if (t9 != null && t9.getHrAlarmStatus() == 0) {
            isPush = false;
        }
        if (isPush) {
            extras = String.format("imei=%s|", imei);
            extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_HR);
            extras += String.format("builder_id=%d|", builder_id);
            extras += String.format("hr=%d|", hr);
            extras += String.format("device=%s|", device);
            Publish.push(imei, alert, title, builder_id, extras);
        }
    }

    /**
     * <pre>
     * 本方法是上送的包体温数据进行判断是否发送推送信息，并且进行发送
     * 判断的逻辑如下：
     *    根据手表上送的imei号，去数据库表member_setting_temperature查询对应的设置信息，
     * </pre>
     */
    protected void push(String imei, Double temperature, String device) {
        boolean isPush = false;

        MemberSettingTemperatureMapper tempMapper = SpringBeanFacotry.getInstance().getBean(MemberSettingTemperatureMapper.class);

        MemberSettingTemperature record = tempMapper.selectByPrimaryKey(imei);
        if (record != null) {
            if (record.getTempHigh() > 0 && temperature > record.getTempHigh()) {
                log.debug("【imei:{}】体温超过设定上限,{}(手表上传的体温值) > {}(设定的体温上限)", imei, temperature, record.getTempHigh());
                isPush = true;
            }
            else if (record.getTempLow() > 0 && temperature < record.getTempLow()) {
                log.debug("【imei:{}】体温低于设定下限,{}(手表上传的体温值) < {}(设定的体温下限)", imei, temperature, record.getTempLow());
                isPush = true;
            }
            else if (record.getTempHigh() == 0 && record.getTempLow() == 0) {
                if (temperature > 37.5 || temperature < 35)
                    isPush = true;
            }
        } else if (temperature > 37.5 || temperature < 35){
            log.debug("【imei:{}】体温值：{}", imei, temperature);
            isPush = true;
        }
        if (isPush) {
            log.debug("【imei:{}】推送体温不正常消息通知,type=7", imei);
            // new Pusher().push("7", imei);
            String extras = "";
            String title = "temperature_title_key";
            String alert = new PushAlert(new Object[] { imei }, "temperature_alert_key").toString();
            int builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
            extras = String.format("imei=%s|", imei);
            extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_MID);
            extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_TEMP);
            extras += String.format("builder_id=%d|", builder_id);
            extras += String.format("temperature=%f|", temperature);
            extras += String.format("device=%s|", device);
            Publish.push(imei, alert, title, builder_id, extras);
        }
    }

    /**
     * <pre>
      * 本方法是上送的包血压数据进行判断是否发送推送信息，并且进行发送
      * 判断的逻辑如下：
      *    根据手表上送的imei号，去数据库表product_per_setting_m查询对应的设置信息，
      *    即：U_SYSTOLIC_UPPER_LIMIT(高压上限)，U_SYSTOLIC_LOWER_LIMIT(高压下限)
      *    U_DIASTOLIC_UPPER_LIMIT(低压上限)，U_DAISTOLIC_LOWER_LIMIT(低压下限)
      *    如果未查到对应设置信息，则使用默认高血压上限(120)和默认低血压上限(80)进行判断,
      *    以下五种表达式为true会进行消息推送
      *    a、systolic > 高压上限 
      *    b、systolic < 高压下限 
      *    c、diastolic > 低压上限 
      *    d、diastolic < 低压下限
     * </pre>
     * 
     * @param imei
     * @param systolic
     *            心脏收缩(高压)
     * @param diastolic
     *            心脏舒张(低压)
     */
    protected void push(String imei, int systolic, int diastolic, int puls, String device) {
        boolean isPush = false;

        MemberSettingBloodpressureMapper bpMapper = (MemberSettingBloodpressureMapper) SpringBeanFacotry.getInstance()
                .getBean("memberSettingBloodpressureMapper");

        MemberSettingBloodpressure record = bpMapper.selectByPrimaryKey(imei);
        if (record != null) {
            if (record.getBpsH() > 0 && systolic > record.getBpsH()) {
                log.debug("【imei:{}】心脏收缩超过设定上限,{}(手表上传的心脏收缩值) > {}(设定的心脏收缩上限)", imei, systolic, record.getBpsH());
                isPush = true;
            }
            if (record.getBpsL() > 0 && systolic < record.getBpsL()) {
                log.debug("【imei:{}】心脏收缩低于设定下限,{}(手表上传的心脏收缩值) < {}(设定的心脏收缩下限)", imei, systolic, record.getBpsL());
                isPush = true;
            }
            if (record.getBpdH() > 0 && diastolic > record.getBpdH()) {
                log.debug("【imei:{}】心脏舒张超过设定上限,{}(手表上传的心脏舒张值) > {}(设定的心脏舒张上限)", imei, systolic, record.getBpdH());
                isPush = true;
            }
            if (record.getBpdL() > 0 && diastolic < record.getBpdL()) {
                log.debug("【imei:{}】心脏舒张低于设定下限,{}(手表上传的心脏舒张值) < {}(设定的心脏舒张下限)", imei, systolic, record.getBpdL());
                isPush = true;
            }
            if (record.getBpsH() == 0 && record.getBpsL() == 0) {
                if (systolic > 139 || systolic < 90)
                    isPush = true;
            }
            if (record.getBpdH() == 0 && record.getBpdL() == 0) {
                if (diastolic > 89 || diastolic < 60)
                    isPush = true;
            }
        } else {
            if (systolic > 139 || diastolic > 89) {
                log.debug("【imei:{}】心脏收缩值：{} , 心脏舒张值：{}", imei, systolic, diastolic);
                isPush = true;
            }
            if (systolic < 90 || diastolic < 60) {
                log.debug("【imei:{}】心脏收缩值：{} , 心脏舒张值：{}", imei, systolic, diastolic);
                isPush = true;
            }
        }
        if (isPush) {
            log.debug("【imei:{}】推送血压不正常消息通知,type=7", imei);
            // new Pusher().push("7", imei);
            String extras = "";
            String title = "blood_pressure_title_key";
            String alert = new PushAlert(new Object[] { imei }, "blood_pressure_alert_key").toString();
            int builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
            extras = String.format("imei=%s|", imei);
            extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_MID);
            extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_BP);
            extras += String.format("builder_id=%d|", builder_id);
            extras += String.format("systolic=%d|", systolic);
            extras += String.format("diastolic=%d|", diastolic);
            extras += String.format("puls=%d|", puls);
            extras += String.format("device=%s|", device);
            Publish.push(imei, alert, title, builder_id, extras);
        }
    }
    /**
     * <pre>
      * 本方法是上送的包血压数据进行判断是否发送推送信息，并且进行发送
      * 判断的逻辑如下：
      *  根据手表上送的imei号，去数据库表product_per_setting_m查询对应的设置信息，
      *  然后推送到健康档案
     * @param date 
      *   
     */
    protected void pushBP(String imei, int systolic, int diastolic, int puls, String device, Date date) {
            String extras = "";
            String title = "blood_pressure_title_key";
            String alert = new PushAlert(new Object[] { imei }, "blood_pressure_alert_key").toString();
            int builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
            
            SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    	    String b = dateFormater.format(date);
    	    
            extras = String.format("imei=%s|", imei);
            extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_MID);
            extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_BP);
            extras += String.format("builder_id=%d|", builder_id);
            extras += String.format("systolic=%d|", systolic);
            extras += String.format("diastolic=%d|", diastolic);
            extras += String.format("puls=%d|", puls);
            extras += String.format("device=%s|", device);
            extras += String.format("time=%s|", b);
            Publish.pushHL(imei, alert, title, builder_id, extras);
    }
    /**
     * <pre>
     *  然后推送体温数据到健康档案
     * @param date
     */
    protected void pushTemp(String imei, Double temperature, String device, Date date) {
        String extras = "";
        String title = "temperature_title_key";
        String alert = new PushAlert(new Object[] { imei }, "temperature_alert_key").toString();
        int builder_id = INotification.ANDROID_MAKER_HEALTH_MID;

        SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String b = dateFormater.format(date);

        extras = String.format("imei=%s|", imei);
        extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_MID);
        extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_BP);
        extras += String.format("builder_id=%d|", builder_id);
        extras += String.format("temperature=%f|", temperature);
        extras += String.format("device=%s|", device);
        extras += String.format("time=%s|", b);
        Publish.pushHL(imei, alert, title, builder_id, extras);
    }
    
    /**
     * 血氧推送到健康档案
     * @param imei
     * 
     */
    protected void pushBO(String imei, short spo2, String device,Date date) {
        String extras = "";
        String alert = "";
        String title = "oxygent_title_key";
        int builder_id = INotification.ANDROID_MAKER_HEALTH_HIGH;
        SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    String b = dateFormater.format(date);
        
        extras = String.format("imei=%s|", imei);
        extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_BO);
        extras += String.format("builder_id=%d|", builder_id);
        extras += String.format("spo2=%d|", spo2);
        extras += String.format("device=%s|", device);
        extras += String.format("time=%s|", b);
        
        Publish.pushHL(imei, alert, title, builder_id, extras);
    }
    
    /**
     * 8000定位记录同步,8020 公用
     * @param imei
     * 
     */
    protected void push8000Gps(String imei,String device ,String commd) {
        String extras = "";
        String title = device+"GPS_title_key";
        int builder_id = INotification.ANDROID_MAKER_HEALTH_HIGH;
        extras = String.format("imei=%s|", imei);
        extras += String.format("device=%s|", device);
        Publish.push8000Gps(imei, commd, title, builder_id, extras);
    }
    
    /**
     * 血糖推送送到健康档案
     */
    protected void pushBS(String imei, int glucose, Date bsTime, short mealSelection, String device) {
            // new Pusher().push("9", imei);
            String extras = "";
            String title = "glucose_title_key";
            String alert = new PushAlert(new Object[] { imei }, "glucose_alert_key").toString();
    	    SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    	    String b = dateFormater.format(bsTime);
            
            int builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
            extras = String.format("imei=%s|", imei);
            extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_MID);
            extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_BS);
            extras += String.format("builder_id=%d|", builder_id);
            extras += String.format("time=%s|", b);
            extras += String.format("glucose=%d|", glucose);
            extras += String.format("device=%s|", device);
            Publish.pushHL(imei, alert, title, builder_id, extras);

    }
    /**
     * 心率推送送到健康档案
     * @param imei
     * @param date 
     */
    protected void pushHR(String imei, int hr, String device, Date date) {
        String extras = "";
        String alert = "";
        String title = "hr_title_key";
        
        SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    String b = dateFormater.format(date);
	    
        int builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
            extras = String.format("imei=%s|", imei);
            extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_HR);
            extras += String.format("builder_id=%d|", builder_id);
            extras += String.format("hr=%d|", hr);
            extras += String.format("device=%s|", device);
            extras += String.format("time=%s|", b);
            Publish.pushHL(imei, alert, title, builder_id, extras);
    }
    
    /**
     * 步数送到健康档案
     * @param imei
     */
    protected void pushSTP(String imei, int step, int calorie,int distance,String device,Date date) {
        String extras = "";
        String alert = "";
        String title = "step_title_key";
        
        SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    String b = dateFormater.format(date);
        int builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
            extras = String.format("imei=%s|", imei);
            extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_STP);
            extras += String.format("builder_id=%d|", builder_id);
            extras += String.format("step=%d|", step);
            extras += String.format("calorie=%d|", calorie);
            extras += String.format("distance=%d|", distance);
            extras += String.format("device=%s|", device);
            extras += String.format("time=%s|", b);
            Publish.pushHL(imei, alert, title, builder_id, extras);
    }

    /**
     * 血糖推送
     * 
     * @param imei
     */
    protected void push(String imei, int glucose, Date bsTime, short mealSelection, String device) {

        MemberSettingBloodglucoseMapper glucoseMapper = (MemberSettingBloodglucoseMapper) SpringBeanFacotry
                .getInstance().getBean("memberSettingBloodglucoseMapper");

        MemberSettingBloodglucose settingGlucose = glucoseMapper.selectByPrimaryKey(imei);

        boolean isPush = false;
        if (settingGlucose != null) {

            if (mealSelection == 0) {
                Long bTimeS = transferDateToLong(settingGlucose.getBreakfastS());
                Long bTimeE = transferDateToLong(settingGlucose.getBreakfastE());

                Long lTimeS = transferDateToLong(settingGlucose.getLunchS());
                Long lTimeE = transferDateToLong(settingGlucose.getLunchE());

                Long dTimeS = transferDateToLong(settingGlucose.getDinnerS());
                Long dTimeE = transferDateToLong(settingGlucose.getDinnerE());

                Long b = transferDateToLong(bsTime);

                if ((b > bTimeS && b < bTimeE) || (b > lTimeS && b < lTimeE) || (b > dTimeS && b < dTimeE)) {// 餐内时间段
                    int h = settingGlucose.getAfterMealH();
                    int l = settingGlucose.getAfterMealL();

                    if (glucose > h || glucose < l) {
                        isPush = true;
                    }

                } else {
                    int h = settingGlucose.getBeforeMealH();
                    int l = settingGlucose.getBeforeMealL();

                    if (glucose > h || glucose < l) {
                        isPush = true;
                    }
                }
            } else if (mealSelection == 1) {
                int h = settingGlucose.getBeforeMealH();
                int l = settingGlucose.getBeforeMealL();

                if (glucose > h || glucose < l) {
                    isPush = true;
                }
            } else if (mealSelection == 2) {
                int h = settingGlucose.getAfterMealH();
                int l = settingGlucose.getAfterMealL();

                if (glucose > h || glucose < l) {
                    isPush = true;
                }
            }else{
            	int h = 124;
                int l = 72;

                if (glucose > h || glucose < l) {
                    isPush = true;
                }
            }

        } else {
            int h = 124;
            int l = 72;
            if (mealSelection == 2) {
                h = 140;
                l = 200;
            }
            if (glucose > h || glucose < l) {
                isPush = true;
            }
        }
        if (isPush) {
            // new Pusher().push("9", imei);
            String extras = "";
            String title = "glucose_title_key";
            String alert = new PushAlert(new Object[] { imei }, "glucose_alert_key").toString();
            int builder_id = INotification.ANDROID_MAKER_HEALTH_MID;
            extras = String.format("imei=%s|", imei);
            extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_MID);
            extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_BS);
            extras += String.format("builder_id=%d|", builder_id);
            extras += String.format("glucose=%d|", glucose);
            extras += String.format("device=%s|", device);
            Publish.push(imei, alert, title, builder_id, extras);
        }

    }

    /**
     * 将date装换为一个长整形用于比较
     * 
     * @param date
     * @return
     */
    private long transferDateToLong(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);

        return cal.get(Calendar.HOUR_OF_DAY) * 1000000 + cal.get(Calendar.MINUTE) * 10000
                + cal.get(Calendar.SECOND) * 100 + cal.get(Calendar.MILLISECOND);
    }

    /**
     * @Title: toByteNowDate
     * @Description: 将当前时间转换成yyyyMMddHHmmss 16进制形式的byte数组
     * @return byte[]
     */
    public byte[] toByteNowDate_KM8000() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String date = sdf.format(new Date());
        byte[] byteDate = TripleDesHelper.date2byteArray(date);
        return byteDate;
    }

    /**
     * @Title: toByteNowDate
     * @Description: 将当前时间转换成yyyyMMddHHmmss 16进制形式的byte数组
     * @return byte[]
     */
    public byte[] toByteUTC_KM8000(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+0"));
        String dateStr = sdf.format(date);
        byte[] byteDate = TripleDesHelper.date2byteArray(dateStr);
        return byteDate;
    }

    /**
     * @Title: dataTimeParse_KM8000
     * @Description: 解析KM8000协议中的时间字节段，最终格式为数据可接受格式 yyyy-MM-dd HH:mm:ss
     * @param data
     *            需要解析的数据byte数组
     * @param index
     *            数组起始下标
     * @param length
     *            需要解析的字节长度
     * @return String
     * @throws Exception
     */
    public String parseDateTime_KM8000(byte[] data, int index) {
        int year = Integer.parseInt(StringUtil.toHexString(data, index, 2), 16);
        int month = 0xff & data[index + 2];
        int dd = 0xFF & data[index + 3];
        int hour = 0xff & data[index + 4];
        int mm = 0xff & data[index + 5];
        int ss = 0xff & data[index + 6];
        return year + "-" + month + "-" + dd + " " + hour + ":" + mm + ":" + ss;
    }

    /**
     * @Title: parseImeiOrImsi_KM8000
     * @Description: 获取Imei、Imsi号，以String返回
     * @param data
     * @param index
     * @return String
     */
    public String parseImeiOrImsi_KM8000(byte[] data, int index) {
        byte[] imei = Arrays.copyOfRange(data, index, index + 8);
        String hexImei = TripleDesHelper.byte2hex(imei, 8);
        return hexImei.substring(0, hexImei.length() - 1);
    }

    /**
     * @Title: parseImei_KM8010
     * @Description: 获取Imei号，以String返回
     * @param data
     * @param index
     * @return String
     */
    public String parseImei_KM8010(byte[] data, int index) {
        // String hexImei = StringUtil.toHexStringPadded(data,index,8);
        byte[] imei = Arrays.copyOfRange(data, index, 8);
        String imeiStr = TripleDesHelper.byte2hex(imei, 8);
        return imeiStr.substring(1);
    }

    public byte[] parseImeiOrImsiBytes_KM8000(byte[] data, int index) {
        return Arrays.copyOfRange(data, index, 8);
    }

    // 别扭的写法，后续了解改进 2015年11月24日 18:15:21
    public byte[] parseImeiBytes_KM8010(byte[] data, int index) {
        byte[] imei = Arrays.copyOfRange(data, index, 8);
        String imeiStr = TripleDesHelper.byte2hex(imei, 8);
        String imeiConvertion = imeiStr.substring(1, imeiStr.length()) + "0";
        return TripleDesHelper.hex2byte(imeiConvertion);
    }

    protected PrI getPrI(Gps gps, String imei, Date updateDate, int battery) {
        PrI pri = new PrI();
        Date nowDate = new Date();
        pri.setImei(imei);
        pri.setCreateDate(nowDate);
        pri.setUpdateDate(nowDate);
        pri.setPrDate(updateDate);
        pri.setBatchKey(yyMMddHHmmss.format(nowDate));
        pri.setItemno((short) 0);
        pri.setBatchDetailKey(yyMMddHHmmss.format(nowDate) + imei + "0");
        pri.setGpsNsLat(gps.getDirectionLat());
        pri.setGpsEwLng(gps.getDirectionLng());
        pri.setGpsLat(gps.getLat());
        pri.setGpsLng(gps.getLng());
        pri.setIsvalid(gps.getIsValid());
        pri.setLocStatus(gps.getIsValid());
        pri.setMcellLat(gps.getLat());
        pri.setMcellLng(gps.getLng());
        pri.setMcellStatus(gps.getIsValid());
        pri.setWifiLat(gps.getLat());
        pri.setWifiLng(gps.getLng());
        pri.setHpe((double) 10);
        pri.setVoltage(battery);
//        log.debug("=====pri gps=====");
        return pri;
    }

    protected PrI getPrI(Gps gps, List<Cell> cells, List<Wifi> wifis, String imei, Date updateDate, int battery) {
        PrI pri = new PrI();
        Date nowDate = new Date();
        LocResult locresult = null;
        pri.setImei(imei);
        pri.setCreateDate(nowDate);
        pri.setUpdateDate(nowDate);
        pri.setPrDate(updateDate);
        pri.setBatchKey(yyMMddHHmmss.format(nowDate));
        pri.setItemno((short) 0);
        pri.setBatchDetailKey(yyMMddHHmmss.format(nowDate) + imei + "0");
        pri.setIsvalid("N");
        pri.setLocStatus("N");
        pri.setMcellStatus("N");
        Cell cell = cells.get(0);
        pri.setMcc(cell.getMcc());
        pri.setMnc(cell.getMnc());
        pri.setLac(cell.getLac());
        pri.setCellid(cell.getCellid());
        pri.setRssi(cell.getRssi());
        if (cells.size() > 1)
            locresult = LocUtil.loc(imei, null, cells.get(0), cells.subList(1, cells.size()), wifis);
        else
            locresult = LocUtil.loc(imei, null, cells.get(0), null, wifis);
        if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {
            LocDetailResult result = locresult.getResult();
            String[] lngLat = result.getLocation().split(",");
            BigDecimal lng = new BigDecimal(lngLat[0]).setScale(6, RoundingMode.HALF_EVEN);
            BigDecimal lat = new BigDecimal(lngLat[1]).setScale(6, RoundingMode.HALF_EVEN);
            String address = LocUtil.reverseGeocoding(lat, lng);
            pri.setGpsNsLat("N");
            pri.setGpsEwLng("E");
            pri.setGpsLat(lat);
            pri.setGpsLng(lng);
            pri.setIsvalid("Y");
            pri.setLocStatus("Y");
            pri.setMcellLat(lat);
            pri.setMcellLng(lng);
            pri.setMcellStatus("Y");
            pri.setWifiLat(lat);
            pri.setWifiLng(lng);
            pri.setVoltage(battery);
            pri.setAddress(address);
            pri.setHpe((double) result.getRadius());
        } else {
            if (locresult != null) {
                log.info("定位失败，status:{},info:{},result.type:{}", locresult.getStatus(), locresult.getInfo(),
                        locresult.getResult() == null ? "" : locresult.getResult().getType());
            } else {
                log.info("定位结果返回NULL");
            }
        }
        if(gps != null){
        	pri.setGpsNsLat(gps.getDirectionLat());
            pri.setGpsEwLng(gps.getDirectionLng());
            pri.setGpsLat(gps.getLat());
            pri.setGpsLng(gps.getLng());
        }
//        log.debug("=====get pri=====");
        return pri;
    }

    protected List<PrCellI> getPrCellI(List<Cell> cellList, PrM prm) {
        List<PrCellI> prcelllist = new ArrayList<PrCellI>();
        Iterator<Cell> it = cellList.iterator();
        short i = 0;
        while (it.hasNext()) {

            Cell cell = it.next();
            PrCellI prcelli = new PrCellI();
            prcelli.setBatchDetailKey(prm.getBatchKey() + prm.getImei() + "0");
            prcelli.setItemno(i);
            prcelli.setIsvalid("N");
            prcelli.setLocStatus("N");
            prcelli.setMcc(cell.getMcc());
            prcelli.setMnc(cell.getMnc());
            prcelli.setCellid(cell.getCellid());
            prcelli.setRssi(cell.getRssi());
            prcelli.setUpdateDate(prm.getUpdateDate());
            prcelli.setCreateDate(new Date());
            LocResult locresult = LocUtil.loc(prm.getImei(), null, cellList.get(0), null, null);
            if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {
                LocDetailResult result = locresult.getResult();
                String[] lngLat = result.getLocation().split(",");
                BigDecimal lng = new BigDecimal(lngLat[0]).setScale(6, RoundingMode.HALF_EVEN);
                BigDecimal lat = new BigDecimal(lngLat[1]).setScale(6, RoundingMode.HALF_EVEN);
                prcelli.setGpsEwLng("E");
                prcelli.setGpsNsLat("N");
                prcelli.setIsvalid("Y");
                prcelli.setLocStatus("Y");
                prcelli.setGpsLat(lat);
                prcelli.setGpsLng(lng);
            } else {
                if (locresult != null) {
                    log.info("定位失败，status:{},info:{},result.type:{}", locresult.getStatus(), locresult.getInfo(),
                            locresult.getResult() == null ? "" : locresult.getResult().getType());
                } else {
                    log.info("定位结果返回NULL");
                }
            }
            prcelllist.add(prcelli);
            i++;
        }
        return prcelllist;
    }

    /**
     * 
     * @Title: handleMessage @Description: 子类实现 @param @param msg @return
     *         void @throws
     */
    public abstract ReplyMessageContent handleMessage(byte[] msg);
    public abstract boolean handleMessage(String json);

}
