package com.kmhc.model.handler.impl.c100;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.ConvertionUtil;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.DeviceListMapper;
import com.kmhc.model.datacenter.model.DeviceList;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type = "C100", command = "0x01")
public class LoginHandlerImpl extends AbstractParentHandlerC100 {

	private String function = "01";
	private static final Logger log = LoggerFactory.getLogger(LoginHandlerImpl.class);
	
    private DeviceListMapper deviceListMapper = (DeviceListMapper) SpringBeanFacotry.getInstance().getBean("deviceListMapper");

	
	public LoginHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,function);
		int index = 0 ;
		byte[] snBytes= Arrays.copyOfRange(msg, index, index + 9) ;

		int[] sections = new int[]{9,4,24,8,8,14,1,msg.length-69};
		String[] types= new String[]{"SN","TIMESTAMP_SECOND","IGNORE","IMESI","IMESI","IGNORE","TZ","STRING"};
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);	
		Object[] objs = BytesConvertionUtil.generateProperty4C100(msg, sections, types, indexMapPolishing);
		
		DeviceList deviceList = deviceListMapper.selectBySn((String) objs[0]) ;
		
		byte[] body = {0,0,0,0,1};
		if(deviceList != null){
			Date dt = new Date();
			
			int time = ((int) (dt.getTime() / 1000));
			byte[] bs = ConvertionUtil.intToBigEndBytes(time);
			
			System.arraycopy(bs, 0, body, 0, bs.length);
			body[4] = 0;
		}
		
		return MessageBuilder.buildReplyMessageContent(snBytes, generateResponse(body, (byte) 0x81));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
