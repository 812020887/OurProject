package com.kmhc.model.handler.impl.km8020;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.handler.IContext;
import com.kmhc.model.handler.impl.ContextHandler;
import com.kmhc.model.handler.impl.HandlerFactory;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.SystemConfigUtil;


@MessageCommand(type = "KM8020", command = "0x543130")
public class UploadHistoricalDataImpl extends AbstractParentHandlerKM8020 {

    private String function = "S10";
    private static final Logger log = LoggerFactory.getLogger(UploadHistoricalDataImpl.class);

    public UploadHistoricalDataImpl() {
        super(log);
    }

    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
        //[V1.0.0,460001515535328,1,abcd,2011-12-1510:00:00,355372020827303,S10] by reponse
        //[V1.0.0,460001515535328,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T10,1267518888] request
        String s = new String(msg);
        log.info(new String(s));

        String t10[] = s.split("},");
        String s_t10 = s.substring(0, s.indexOf("T10") + 4) + s.split(",")[s.split(",").length - 1];
        String content[] = s_t10.split(",");
        for (int i = 0; i < t10.length - 1; i++) {
            String t = t10[i].substring(t10[i].indexOf("{") + 1, t10[i].length()) + "," + content[5];
            String className = SystemConfigUtil.protocolMap.get(t.split(",")[0]);
            if (!StringUtils.isEmpty(className)) {
                IContext context = new ContextHandler(new HandlerFactory().createClass("com.kmhc.model.handler.impl.km8020." + className));
                context.handleBasicMessage(t);
            }
        }
        String out[] = {content[0], content[1], content[2], sdf.format(new Date()), content[5], function};
        return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(content[5] + "0"), generateResponse(out));
    }

    @Override
    public boolean handleMessage(String json) {
        // TODO Auto-generated method stub
        return false;
    }
}
