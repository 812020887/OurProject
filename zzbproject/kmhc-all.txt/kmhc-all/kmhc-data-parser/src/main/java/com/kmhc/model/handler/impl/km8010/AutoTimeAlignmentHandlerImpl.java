package com.kmhc.model.handler.impl.km8010;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.pojo.TimeZoneResult;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.TimeZoneUtil;

@MessageCommand(type="KM8010",command="0xA2")
public class AutoTimeAlignmentHandlerImpl extends AbstractParentHandlerKM8010 {

	private static final Logger log = LoggerFactory.getLogger(AutoTimeAlignmentHandlerImpl.class);
	private static final String TIME_ZONE[] = {
			"None","Abu Dhabi","Amsterdam","Apia","Athens","Auckland","Anchorage","Bangkok",
			"Beijing","Berlin","Bogota","Brasilia","Brisbane","Brussels","Bucharest","Budapest",
			"Buenos Aires","Cairo","Canberra","Cape Town","Casablanca","Central Atlantic","Chicago",
			"Copenhagen","Dhaka","Easter Island","Geneva","Guam","Hong Kong","Honolulu","Islamabad",
			"Istanbul","Jakarta","Johannesburg","Kabul","Kathmandu","Kiev","Kuala Lumpur","Kwajalein",
			"La Paz","Lisbon","London","Los Angeles","Luxembourg","Madrid","Manila", "Melbourne",
			"Mexico City","Montreal","Moscow","New Delhi","New York","Norfolk Island","Paris", 
			"Phoenix","Polynesia","Prague","Praia","Rabat","Rome","San Francisco","Santiago","Singapore",
			"Sofia","Solomon","Stockholm","Sydney","Taipei","Tehran","Tokyo","Tonga","Vancouver","Vienna",
			"Vladivostok","Warsaw","Wellington","Yangon","Zurich","Hanoi"
			};
	
	public AutoTimeAlignmentHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);
		int index = 0;
		Gps gps = null;
		
		String imei = parseImei_KM8010(msg, index);
		index += 8;
		index += 5;
		LocResult locresult = null;
		switch(msg[index]){
		case 0://GPS
			gps = parseGps(Arrays.copyOfRange(msg, index+1, msg.length));		
			break;
		case 1://GSM
			List<Cell> cellList = parseCellList(Arrays.copyOfRange(msg, index+1, msg.length));
			
			if( cellList.size() > 1)
				locresult = LocUtil.loc(imei, null, cellList.get(0), cellList.subList(1, cellList.size()), null);
			else if(cellList.size() == 1)
				locresult = LocUtil.loc(imei, null, cellList.get(0), null, null);
			if(locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0){
	            LocDetailResult result = locresult.getResult();
	            String[] lngLat = result.getLocation().split(",");         
	            BigDecimal lng = new BigDecimal(lngLat[0]);
	            BigDecimal lat = new BigDecimal(lngLat[1]);
	            gps = new Gps(lat,lng,"N","E","Y");          
	        }else{
	            if(locresult != null){
	                log.info("定位失败，status:{},info:{},result.type:{}",locresult.getStatus(),locresult.getInfo(),locresult.getResult() == null?"":locresult.getResult().getType());
	            }else{
	                log.info("定位结果返回NULL");
	            }
	        }
			break;
		case 4://GPS + GSM
			gps = parseGps(Arrays.copyOfRange(msg, index+1, index+11));		
			break;
		case 0x08:
			Cell cell = parseCell(msg, index + 1, null);
			List<Cell> cells = parseCells(msg, index + 9, cell.getMcc());
			List<Wifi> wifis = parseWifiList(msg, index + 10 + cells.size()*6);
			if( cells.size() > 1)
				locresult = LocUtil.loc(imei, null, cell, cells.subList(1, cells.size()), wifis);
			else
				locresult = LocUtil.loc(imei, null, cell, null, wifis);
			if(locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0){
	            LocDetailResult result = locresult.getResult();
	            String[] lngLat = result.getLocation().split(",");         
	            BigDecimal lng = new BigDecimal(lngLat[0]);
	            BigDecimal lat = new BigDecimal(lngLat[1]);
	            gps = new Gps(lat,lng,"N","E","Y");          
	        }else{
	            if(locresult != null){
	                log.info("定位失败，status:{},info:{},result.type:{}",locresult.getStatus(),locresult.getInfo(),locresult.getResult() == null?"":locresult.getResult().getType());
	            }else{
	                log.info("定位结果返回NULL");
	            }
	        }
			break;
		case 0x16:
			gps = parseGps(Arrays.copyOfRange(msg, index+1, msg.length));	
			gps = LocUtil.conver(gps);
			break;
		default:
			break;		
		}
		if( gps != null ){
			TimeZoneResult tzresult = TimeZoneUtil.time(gps);
			if(tzresult != null){
				int tzId = 0;	
				for(int i = 1; i < 79; i ++){
					if(tzresult.getTimezoneId().contains(TIME_ZONE[i])){
						tzId = i;
						break;
					}
				}
				
				if(tzId == 0 && tzresult.getCountryName().contains("China")){
					tzId = 8;
				}else if(tzId == 0 && tzresult.getCountryName().contains("Malaysia")){
					tzId = 38;
				}else if(tzId == 0 && tzresult.getCountryName().contains("Taiwan")){
					tzId = 67;
				}else if(tzId == 0 && tzresult.getCountryName().contains("Japan")){
					tzId = 69;
				}else if( tzId ==0){
					return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) -94));
				}
				
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				sdf.setTimeZone(TimeZone.getTimeZone(tzresult.getTimezoneId()));
	
//					Date dt = sdf.parse(tzresult.getTime());
				Date dt = tzresult.getTime();
				sdf.applyPattern("yy-MM-dd-HH-mm");
				String tmp[] = sdf.format(dt).split("-");
				int year = Integer.valueOf(tmp[0]);
				int month = Integer.valueOf(tmp[1]);
				int day = Integer.valueOf(tmp[2]);
				int hour = Integer.valueOf(tmp[3]);
				int min = Integer.valueOf(tmp[4]);

				byte[] content = new byte[6];
				content[0] = (byte) tzId;
				content[1] = (byte) year;
				content[2] = (byte) month;
				content[3] = (byte) day;
				content[4] = (byte) hour;
				content[5] = (byte) min;
				return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(content,(byte) -94));
			}
		}
		return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) -94));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
