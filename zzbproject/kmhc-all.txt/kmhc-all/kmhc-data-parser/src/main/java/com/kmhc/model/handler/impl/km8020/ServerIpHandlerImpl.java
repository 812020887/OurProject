package com.kmhc.model.handler.impl.km8020;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.ProductSysSettingMMapper;
import com.kmhc.model.datacenter.dao.ServerActionHisMapper;
import com.kmhc.model.datacenter.model.ProductSysSettingM;
import com.kmhc.model.datacenter.model.ServerActionHis;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;

@MessageCommand(type = "KM8020", command = "0x543733")
public class ServerIpHandlerImpl extends AbstractParentHandlerKM8020 {
	
	private static final Logger log = LoggerFactory.getLogger(ServerIpHandlerImpl.class);
	private ServerActionHisMapper serverActionHisMapper = (ServerActionHisMapper) SpringBeanFacotry.getInstance().getBean("serverActionHisMapper");
    private ProductSysSettingMMapper pSSM = (ProductSysSettingMMapper) SpringBeanFacotry.getInstance().getBean("productSysSettingMMapper");

	public ServerIpHandlerImpl() {
		super(log);
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		//a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,355372020827303,S73,192.168.0.3:8876  in server_action_his content
		//[V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T73]
		log.info(new String(msg));
		String protocol = "S73";
		String content[] = new String(msg).split(",");
		String uid = content[0];
		String imei = content[5];
		
		ServerActionHis record = serverActionHisMapper.selectByPrimaryKey(uid, imei, protocol);
		if( record != null){
			String command[] = record.getContent().split(",");
			String ipPort = command[7];
			
			ProductSysSettingM setting = null;
			setting = pSSM.selectByPrimaryKey(imei);
			if( setting == null ) setting = new ProductSysSettingM();
			setting.setImei(imei);
			setting.setIp1(ipPort);
			setting.setIp2(ipPort);
			setting.setIp3(ipPort);
			setting.setChecksumS((short) ((setting.getChecksumS() + 1)));
			setting.setUpdateDate(new Date());
			
			int success = 0;
			try{
				success = pSSM.updateByPrimaryKey(setting);
			}catch(Exception e){
				log.error(e.toString());
			}
			if(success > 0){
				serverActionHisMapper.deleteByPrimaryKey(record.getUid(), record.getImei(), protocol);
				pushSettingFinish(imei,INotification.NOTIFICATION_TYPE_SETTING_IP_PORT);
			}
		}
//		log.info("push fail notification to app");
		return null;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
