package com.kmhc.model.handler.impl.km8020;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrBsMapper;
import com.kmhc.model.datacenter.model.PsrBs;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type = "KM8020", command = "0x543937")
public class BsWithMealSelectionHandlerImpl extends AbstractParentHandlerKM8020 {

	private String function = "S97";
	private static final Logger log = LoggerFactory.getLogger(BsWithMealSelectionHandlerImpl.class);
	private PsrBsMapper psrBsMapper = (PsrBsMapper) SpringBeanFacotry.getInstance().getBean("psrBsMapper");
	
	public BsWithMealSelectionHandlerImpl() {
		super(log);
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		log.info(new String(msg));

		// sbg6x3mtexzc9r8,1,abcd,2017-11-24 16:17:32,1-2,865946021011026,8,T97,blood_sugar,185,1,2017-11-24 16:19:00,1511540252

		String content[] = new String(msg).split(",");
//		Date messureTime = new Date(Long.parseLong(content[12] + "000"));
		String uid = content[0];
		String imei = content[5];
		short Glu = Short.parseShort(content[9]);
		short mealSelection = Short.parseShort(content[10]); // 0 no, 1 before meal, 2 after meal
		String tzStr = "GMT+" + content[6];
		String timeStr = content[3];
		
		String measureTime = content[11];
		//血糖帮健康档案处理重复判定问题给时间加1秒，的暂带方案，非自身业务需求。
		measureTime=measureTime.substring(0, 17)+"01";

		Date dt = com.kmhc.model.util.Date.getDate(timeStr,"yyyy-MM-dd HH:mm:ss",tzStr);
		Date mDt = com.kmhc.model.util.Date.getDate(measureTime ,"yyyy-MM-dd HH:mm:ss",tzStr);
		log.debug(sdf.format(dt));
		log.debug(sdf.format(mDt));

		PsrBs psrBs = new PsrBs();
		psrBs.setImei(imei);
		psrBs.setImsi("");
		psrBs.setBsCount((short) 1);
		psrBs.setBsTime(mDt);
//		psrBs.setBsTime(messureTime);
		psrBs.setUnit(mealSelection);
		psrBs.setGlu(Glu);
		psrBs.setItemno((short) 1);
		psrBs.setCreateDate(new Date());
		psrBs.setTypeid(97);

		Date now = new Date();
		Boolean flag = true;
		if((now.getTime() + (10 * 60 * 1000L))<mDt.getTime()){
			flag = false;
		}
		if((now.getTime() - mDt.getTime()) > (30 * 24 * 60 * 60 * 1000L)){
			flag = false;
		}

		if(psrBsMapper.selectByBsTime(psrBs) == 0 && flag){
			psrBsMapper.insert(psrBs);
			push(psrBs.getImei(), psrBs.getGlu(), psrBs.getBsTime(), psrBs.getUnit(),"KM8020");
			pushBS(psrBs.getImei(), psrBs.getGlu(), psrBs.getBsTime(), psrBs.getUnit(),"KM8020");
		}else{
			log.info("收到血糖历史数据不予保存：{}",uid+":"+content[1]+":"+content[2]+":"+sdf.format(new Date())+":"+imei+function);
		}
		String out[] = { content[0], content[1], content[2], sdf.format(dt), imei, function };
		return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"), generateResponse(out));

	}

	@Override
	public boolean handleMessage(String json) {
		// T97,blood_sugar,180,1,2017-11-24 16:28:00,1511540790
		try{
			log.info(json);
			String tzStr = "GMT+8";
			String content[] = json.split(",");
			String imei = content[content.length-1];
			short Glu = Short.parseShort(content[2]);
			short mealSelection = Short.parseShort(content[3]); // 0 no, 1 before meal, 2 after meal

			Date messureTime = com.kmhc.model.util.Date.getDate(content[4] ,"yyyy-MM-dd HH:mm:ss",tzStr);
			log.debug(sdf.format(messureTime));
			
			PsrBs psrBs = new PsrBs();
			psrBs.setImei(imei);
			psrBs.setImsi("");
			psrBs.setBsCount((short) 1);
			psrBs.setBsTime(messureTime);
			psrBs.setUnit(mealSelection);
			psrBs.setGlu(Glu);
			psrBs.setItemno((short) 1);
			psrBs.setCreateDate(new Date());
			psrBs.setTypeid(97);

			Date now = new Date();
			Boolean flag = true;
			if((now.getTime() + (10 * 60 * 1000L))<messureTime.getTime()){
				flag = false;
			}
			if((now.getTime() - messureTime.getTime()) > (30 * 24 * 60 * 60 * 1000L)){
				flag = false;
			}

			if(psrBsMapper.selectByBsTime(psrBs) == 0 && flag){
				psrBsMapper.insert(psrBs);
				push(psrBs.getImei(), psrBs.getGlu(), psrBs.getBsTime(), psrBs.getUnit(),"KM8020");
				pushBS(psrBs.getImei(), psrBs.getGlu(), psrBs.getBsTime(), psrBs.getUnit(),"KM8020");
			}else{
				log.info("收到血糖历史数据不予保存：{}",content[1]+":"+content[2]+":"+sdf.format(new Date())+":"+imei+function);
			}
		}catch (Exception e) {
			return false;
		}
		return true;
	}

}
