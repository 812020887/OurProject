package com.kmhc.model.pojo;

import java.util.Date;

import com.kmhc.model.datacenter.model.ProductPerSettingM;
import com.kmhc.model.datacenter.model.ProductSysSettingM;

public class SystemSetup_View {
	private String type;
	private String imei = "";
	private String imsi = "";
	private String year;
	private String month;
	private String day;
	private String hh;
	private String mm;
	private String ss;
	private Date eventDate;
	private String dateString;
	private String server1;
	private String server2;
	private String server3;
	private String serverDName;
	private int echoT;
	private int echoBaseHour;
	private int echoBaseMin;
	private int echoBaseSec;
	private int echoGpsT;
	private int lineLimitOn;
	private int lineLimit = 10;
	private int lineLimitMode;
	private int lineLimitByCustomer = 10;

	private int lineLimitCallout = 0;
	private int lineLimitCalloutFromDay = 1;

	private int autoReadSMS = 0;
	private int logo = 0;
	private int checksum = 0;
	
	public static SystemSetup_View build(ProductSysSettingM sysSettingM){
		SystemSetup_View sv = new SystemSetup_View();
		sv.setServer1(sysSettingM.getIp1());
		sv.setServer2(sysSettingM.getIp2());
		sv.setServer3(sysSettingM.getIp3());
		sv.setServerDName(sysSettingM.getHostdn());		
		sv.setEchoT(sysSettingM.getEchoPrT());
		sv.setEchoBaseHour(sysSettingM.getEchoPrH());
		sv.setEchoBaseMin(sysSettingM.getEchoPrM());
		sv.setEchoBaseSec(sysSettingM.getEchoPrS());
		sv.setEchoGpsT(sysSettingM.getEchoGpsT());
		sv.setLineLimitOn(sysSettingM.getPhoneLimitOnoff());
		sv.setLineLimit(sysSettingM.getPhoneLimitTime());
		sv.setLineLimitMode(sysSettingM.getPhoneLimitMode());
		sv.setLineLimitByCustomer(sysSettingM.getPhoneLimitByCustomer());
		sv.setLineLimitCallout(sysSettingM.getDialoutLimitTime());
		sv.setLineLimitCalloutFromDay(sysSettingM.getDialoutLimitStartday());
		sv.setChecksum(sysSettingM.getChecksumS());
		sv.setAutoReadSMS(sysSettingM.getAutoread());
		sv.setLogo(sysSettingM.getPoweronLogo());
		sv.setImei(sysSettingM.getImei());
		sv.setImsi(sysSettingM.getImsi());
		return sv;
	}
	
	public static SystemSetup_View build(ProductPerSettingM perSettingM){
		SystemSetup_View sv = new SystemSetup_View();
		
		sv.setChecksum(perSettingM.getChecksum());
		sv.setImei(perSettingM.getImei());
		sv.setImsi(perSettingM.getImsi());
		return sv;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getImei() {
		return this.imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getImsi() {
		return this.imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public String getYear() {
		return this.year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMonth() {
		return this.month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getDay() {
		return this.day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getHh() {
		return this.hh;
	}

	public void setHh(String hh) {
		this.hh = hh;
	}

	public String getMm() {
		return this.mm;
	}

	public void setMm(String mm) {
		this.mm = mm;
	}

	public String getSs() {
		return this.ss;
	}

	public void setSs(String ss) {
		this.ss = ss;
	}

	public Date getEventDate() {
		return this.eventDate;
	}

	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}

	public String getDateString() {
		return this.dateString;
	}

	public void setDateString(String dateString) {
		this.dateString = dateString;
	}

	public String getServer1() {
		return this.server1;
	}

	public void setServer1(String server1) {
		this.server1 = server1;
	}

	public String getServer2() {
		return this.server2;
	}

	public void setServer2(String server2) {
		this.server2 = server2;
	}

	public String getServer3() {
		return this.server3;
	}

	public void setServer3(String server3) {
		this.server3 = server3;
	}

	public int getEchoT() {
		return this.echoT;
	}

	public void setEchoT(int echoT) {
		this.echoT = echoT;
	}

	public int getEchoBaseHour() {
		return this.echoBaseHour;
	}

	public void setEchoBaseHour(int echoBaseHour) {
		this.echoBaseHour = echoBaseHour;
	}

	public int getEchoBaseMin() {
		return this.echoBaseMin;
	}

	public void setEchoBaseMin(int echoBaseMin) {
		this.echoBaseMin = echoBaseMin;
	}

	public int getEchoBaseSec() {
		return this.echoBaseSec;
	}

	public void setEchoBaseSec(int echoBaseSec) {
		this.echoBaseSec = echoBaseSec;
	}

	public int getEchoGpsT() {
		return this.echoGpsT;
	}

	public void setEchoGpsT(int echoGpsT) {
		this.echoGpsT = echoGpsT;
	}

	public int getLineLimitOn() {
		return this.lineLimitOn;
	}

	public void setLineLimitOn(int lineLimitOn) {
		this.lineLimitOn = lineLimitOn;
	}

	public int getLineLimit() {
		return this.lineLimit;
	}

	public void setLineLimit(int lineLimit) {
		this.lineLimit = lineLimit;
	}

	public int getLineLimitMode() {
		return this.lineLimitMode;
	}

	public void setLineLimitMode(int lineLimitMode) {
		this.lineLimitMode = lineLimitMode;
	}

	public int getLineLimitByCustomer() {
		return this.lineLimitByCustomer;
	}

	public void setLineLimitByCustomer(int lineLimitByCustomer) {
		this.lineLimitByCustomer = lineLimitByCustomer;
	}

	public int getLineLimitCallout() {
		return this.lineLimitCallout;
	}

	public void setLineLimitCallout(int lineLimitCallout) {
		this.lineLimitCallout = lineLimitCallout;
	}

	public int getLineLimitCalloutFromDay() {
		return this.lineLimitCalloutFromDay;
	}

	public void setLineLimitCalloutFromDay(int lineLimitCalloutFromDay) {
		this.lineLimitCalloutFromDay = lineLimitCalloutFromDay;
	}

	public int getAutoReadSMS() {
		return this.autoReadSMS;
	}

	public void setAutoReadSMS(int autoReadSMS) {
		this.autoReadSMS = autoReadSMS;
	}

	public int getLogo() {
		return this.logo;
	}

	public void setLogo(int logo) {
		this.logo = logo;
	}

	public int getChecksum() {
		return this.checksum;
	}

	public void setChecksum(int checksum) {
		this.checksum = checksum;
	}

	public String getServerDName() {
		return this.serverDName;
	}

	public void setServerDName(String serverDName) {
		this.serverDName = serverDName;
	}
}
