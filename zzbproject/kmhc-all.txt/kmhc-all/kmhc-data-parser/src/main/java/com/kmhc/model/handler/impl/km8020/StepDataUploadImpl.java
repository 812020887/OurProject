/**
 * Copyright (C) 2016 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2016年7月25日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8020;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrStepMapper;
import com.kmhc.model.datacenter.model.PsrStep;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;

/**
 * Name: StepDataUploadImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8020.StepDataUploadImpl.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * Date: 2016年7月25日 下午6:06:23
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmy
 * Copyright: kmy
 */

//T30
@MessageCommand(type="KM8020",command="0x543330")
public class StepDataUploadImpl extends AbstractParentHandlerKM8020 {
    	
    private static final Logger log = LoggerFactory.getLogger(StepDataUploadImpl.class);
    private PsrStepMapper psrStepMapper = (PsrStepMapper) SpringBeanFacotry.getInstance().getBean("psrStepMapper");
    
    public StepDataUploadImpl() {
	super(log);

    }

    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
		log.info(new String(msg));
		//[a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T30,pedo,4057,2231,120.21,1267511609]
		String content[] = new String(msg).split(",");
		String imei = content[5];
		//String uid = content[0];
		PsrStep step = new PsrStep();
		step.setImei(imei);
		step.setImsi("");
		step.setsTime(new Date((Long.parseLong(content[12]) - (Long.parseLong(content[6])*3600))*1000));
		step.seteTime(new Date((Long.parseLong(content[12]) - (Long.parseLong(content[6])*3600))*1000));
		step.setWeight(0);
		step.setStepLong(0);
		step.setSteps(Integer.parseInt(content[9]));
		step.setDistance(Integer.parseInt(content[10]));
		step.setCal((int) (Float.parseFloat(content[11] ) * 1000 ));
		step.setTypeid("T30");
		int count = psrStepMapper.selectByETime(step);
		if(count == 0){
			psrStepMapper.insert(step);
			pushSTP(step.getImei(), step.getSteps(), step.getCal(), step.getDistance(), "KM8020",step.geteTime());
		}
		
		String out[] = { content[0], content[1], content[2],content[3], imei, "S30" };
		return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"), generateResponse(out));
    }

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		//[T30,pedo,4057,2231,120.21,1267511609]
		log.info(json);
		try{
			String content[] = json.split(",");
			PsrStep step = new PsrStep();
			step.setImei(content[content.length-1]);
			step.setsTime(new Date((Long.parseLong(content[5]) - (Long.parseLong("8")*3600))*1000));
			step.seteTime(new Date((Long.parseLong(content[5]) - (Long.parseLong("8")*3600))*1000));
			step.setWeight(0);
			step.setStepLong(0);
			step.setSteps(Integer.parseInt(content[2]));
			step.setDistance(Integer.parseInt(content[3]));
			step.setCal((int) (Float.parseFloat(content[4] ) * 1000 ));
			step.setTypeid("T30");
			int count = psrStepMapper.selectByETime(step);
			if(count == 0){
				psrStepMapper.insert(step);
				pushSTP(step.getImei(), step.getSteps(), step.getCal(), step.getDistance(), "KM8020",step.geteTime());
			}
		}catch(Exception e){
			return false;
		}
		
		return true;
	}
}
