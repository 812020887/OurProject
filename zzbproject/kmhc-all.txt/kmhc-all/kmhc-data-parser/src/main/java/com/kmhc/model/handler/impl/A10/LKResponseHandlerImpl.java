package com.kmhc.model.handler.impl.A10;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.A10DeviceStatusMapper;
import com.kmhc.model.datacenter.dao.DeviceListMapper;
import com.kmhc.model.datacenter.model.A10DeviceStatus;
import com.kmhc.model.datacenter.model.DeviceList;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;;

@MessageCommand(type="A10",command="0x4C4B")
public class LKResponseHandlerImpl extends AbstractParentHandlerA10{
	private static final Logger log = LoggerFactory.getLogger(LKResponseHandlerImpl.class);
    private String type = "10";
    private A10DeviceStatusMapper a10DeviceStatusMapper = (A10DeviceStatusMapper) SpringBeanFacotry.getInstance().getBean("a10DeviceStatusMapper");
    private DeviceListMapper deviceListMapper = (DeviceListMapper) SpringBeanFacotry.getInstance().getBean("deviceListMapper");
    
	public LKResponseHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,type);
		//9403094122*00CD*UD,180916,025723,A,22.570733,N,113.8626083,E,0.00,249.5,0.0,6,100,60,0,0,00000010,7,255,460,1,9529,21809,158,9529,63555,133,9529,63554,129,9529,21405,126,9529,21242,124,9529,21151,120,9529,63556,119,0,40.7
	    log.info(new String(msg));
		String function = "LK";
		String content[] = new String(msg).split(",");
		String sn = content[0].substring(0,content[0].indexOf("*"));
		DeviceList deviceList = deviceListMapper.selectBySn(sn);
		String imei = deviceList.getImei();
		A10DeviceStatus  a10DeviceStatus = new A10DeviceStatus();
		a10DeviceStatus.setImei(imei);
		A10DeviceStatus  a10 = a10DeviceStatusMapper.selectByImei(imei);
		
       if(a10!=null){
    	   if(content.length>2){
    		   a10.setPower(content[3]); 
    	   }
    	   a10.setUpdateTime(new Date());
    	   a10DeviceStatusMapper.updateByPrimaryKeySelective(a10) ;
       }else{
    	   if(content.length>2){
    		   a10DeviceStatus.setPower(content[3]);
    	   }
    	   a10DeviceStatus.setUpdateTime(new Date());
    	   a10DeviceStatus.setCreateTime(new Date());
    	   a10DeviceStatusMapper.insertSelective(a10DeviceStatus) ;
       }
		String out[] = {sn,getLengh(function.length()), function };
		//[3G*8800000015*0002*AL]
		//[V1.0.0,zu1jgjwp80veawu,1,abcd,2011-12-15 10:00:00,356511170035899,S86]
		return MessageBuilder.buildReplyMessageContent(TripleDesHelper.hex2byte(sn + "0"), generateResponse(out));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
