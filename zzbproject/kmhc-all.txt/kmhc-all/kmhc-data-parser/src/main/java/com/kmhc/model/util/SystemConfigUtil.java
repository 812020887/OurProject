/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月11日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Properties;

import com.kmhc.model.pojo.MqConnectionDeclaration;
import com.kmhc.model.pojo.WeatherDeclaration;

/**
 * Name: SystemConfigUtil.java ProjectName: [kmhc-data-parser] Package:
 * [com.kmhc.model.util.SystemConfigUtil.java] Description: TODO
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月11日 上午8:57:24
 *
 *        Update-User: @author Update-Time: Update-Remark:
 * 
 *        Check-User: Check-Time: Check-Remark:
 * 
 *        Company: kmhc Copyright: kmhc
 */
public class SystemConfigUtil {

	public static Properties p = new Properties();

	public static HashMap<String, MqConnectionDeclaration> consumerMapConnection = new HashMap<String, MqConnectionDeclaration>();
	public static HashMap<String, MqConnectionDeclaration> publisherMapConnection = new HashMap<String, MqConnectionDeclaration>();

	public static HashMap<String, MqConnectionDeclaration> systemConsumerMapConnection = new HashMap<String, MqConnectionDeclaration>();

	// 消费者对应返回消息的Queue名称
	public static HashMap<String, String> consumerMapReplyQueueName = new HashMap<String, String>();

	public static HashMap<String, WeatherDeclaration> weatcherCodeMapDeclaration = new HashMap<String, WeatherDeclaration>();

	public static HashMap<String, String> protocolMap = new HashMap<String, String>();

	public static String host;
	public static String port;
	public static String userName;
	public static String password;
	public static String localServiceUrl;
	public static Integer consumerThreadSum;
	public static Integer publishThreadSum;
	public static boolean isDebug;
	public static Integer loggerFlushTime;
	public static String kmhcAutonaviUrl;
	public static String kmhcGeonamesUrl;
	public static String kmhcYahooweatherUrl;
	public static String kmhcOpenWeatherMapUrl;
	public static int kmhcAutonaviConnectTimeout;
	public static int kmhcAutonaviSocketTimeout;
	public static String handlerPackagePath;
	public static String restapiPath;
	public static String restapiConvertPath;
	public static String weatherKeyUrl;
	public static String weatherUrl;
	public static String weatherPrivateKey;
	public static String weatherAppid;
	public static String pushUrl;
	public static String foreign;
	public static String skyhookUrl;
	public static String googleapiGeocode;

	public static String pushMethod;
	public static String pushHLMethod;
	public static String push8000GPSMethod;
	public static String pushTarget;
	public static String pushTargetEnv;
	
	public static String timeZoneOffset;
	public static String storageRoot;
	public static String storageAudio;
	
	public static String T28;
	public static String T30;
	public static String T61;
	public static String T62;
	public static String T82;
	public static String T85;
	public static String T89;
	public static String T91;
	public static String T94;
	public static String T97;

	static {
		InputStream in = SystemConfigUtil.class.getClassLoader().getResourceAsStream("SystemConfig.properties");
		try {
			p.load(in);
			host = p.getProperty("host");
			port = p.getProperty("port");
			userName = p.getProperty("userName");
			password = p.getProperty("password");
			localServiceUrl = p.getProperty("local.service.url");
			consumerThreadSum = Integer.parseInt(p.getProperty("consumer.sum"));
			publishThreadSum = Integer.parseInt(p.getProperty("publish.sum"));
			isDebug = Boolean.parseBoolean(p.getProperty("isDebug"));
			loggerFlushTime = Integer.parseInt(p.getProperty("logger2Flush"));
			kmhcAutonaviUrl = p.getProperty("kmhc.autonavi.url");
			kmhcGeonamesUrl = p.getProperty("kmhc.geonames.url");
			kmhcYahooweatherUrl = p.getProperty("kmhc.yahooweather.url");
			kmhcOpenWeatherMapUrl = p.getProperty("kmhc.openweathermap.url");
			kmhcAutonaviConnectTimeout = Integer.parseInt(p.getProperty("kmhc.autonavi.connectTimeout"));
			kmhcAutonaviSocketTimeout = Integer.parseInt(p.getProperty("kmhc.autonavi.socketTimeout"));
			handlerPackagePath = p.getProperty("handler.scan.package");
			restapiPath = p.getProperty("kmhc.restapi.url");
			restapiConvertPath = p.getProperty("kmhc.restapi.convert.url");
			weatherKeyUrl = p.getProperty("kmhc.weather.key.url");
			weatherUrl = p.getProperty("kmhc.weather.url");
			weatherPrivateKey = p.getProperty("kmhc.weather.private.key");
			weatherAppid = p.getProperty("kmhc.appid");
			pushUrl = p.getProperty("kmhc.push.url");
			foreign = p.getProperty("kmhc.loc.foreign");
			skyhookUrl = p.getProperty("kmhc.log.skyhook.url");
			googleapiGeocode = p.getProperty("kmhc.googleapi.geocode");

			pushMethod = p.getProperty("kmhc.push.method");
			pushHLMethod = p.getProperty("kmhc.pushHL.method");
			push8000GPSMethod=p.getProperty("kmhc.push8000GPS.method");
			pushTarget = p.getProperty("kmhc.push.target");
			pushTargetEnv = p.getProperty("kmhc.push.targetEnv");

			timeZoneOffset = p.getProperty("timeZoneOffset");
			storageRoot = p.getProperty("kmhc.storage.root");
			storageAudio = p.getProperty("kmhc.storage.audio");
			
			T28 = p.getProperty("mkhc.protocol.codeT28");
			T30 = p.getProperty("mkhc.protocol.codeT30");
			T61 = p.getProperty("mkhc.protocol.codeT61");
			T62 = p.getProperty("mkhc.protocol.codeT62");
			T82 = p.getProperty("mkhc.protocol.codeT82");
			T85 = p.getProperty("mkhc.protocol.codeT85");
			T89 = p.getProperty("mkhc.protocol.codeT89");
			T91 = p.getProperty("mkhc.protocol.codeT91");
			T94 = p.getProperty("mkhc.protocol.codeT94");
			T97 = p.getProperty("mkhc.protocol.codeT97");
			
			initCode();
			initBasic();
			initWeatherCode();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
    
	public static void initCode(){
		protocolMap.put("T28",T28);
		protocolMap.put("T30",T30);
		protocolMap.put("T61",T61);
		protocolMap.put("T62",T62);
		protocolMap.put("T82",T82);
		protocolMap.put("T85",T85);
		protocolMap.put("T89",T89);
		protocolMap.put("T91",T91);
		protocolMap.put("T94",T94);
		protocolMap.put("T97",T97);
	}
	
	public static void initBasic() {
		String[] consumers = p.getProperty("consumer.type").split(",");
		String[] publishers = p.getProperty("publisher.type").split(",");
		String[] systemConsumers = p.getProperty("system.consumer.type").split(",");
		String[] thirdPartPush = p.getProperty("publish.thrid.part").split(",");
		if (consumers.length == 0 || publishers.length == 0) {
			StringBuilder sb = new StringBuilder();
			sb.append("the sum of consumer.type = ").append(consumers.length).append(" the sum of publisher.type =")
					.append(publishers.length);
			LogCenter.root.info(sb.toString());
		}

		for (String consumer : consumers) {
			String connectionDeclaration = p.getProperty(consumer);
			MqConnectionDeclaration mq = loadConnectionDeclaration(consumer, connectionDeclaration, true);
			consumerMapConnection.put(consumer, mq);
		}

		for (String publisher : publishers) {
			String connectionDeclaration = p.getProperty(publisher);
			MqConnectionDeclaration mq = loadConnectionDeclaration(publisher, connectionDeclaration, false);
			publisherMapConnection.put(publisher, mq);
		}

		for (String systemConsumer : systemConsumers) {
			String connectionDeclaration = p.getProperty(systemConsumer);
			MqConnectionDeclaration mq = loadConnectionDeclaration(systemConsumer, connectionDeclaration, true);
			systemConsumerMapConnection.put(systemConsumer, mq);
		}

		for (String tp : thirdPartPush) {
			consumerMapReplyQueueName.put(tp, tp);
		}

	}

	public static MqConnectionDeclaration loadConnectionDeclaration(String companyName, String connectionDeclaration,
			boolean buildConsumer) {
		String[] declarations = connectionDeclaration.split(",");
		MqConnectionDeclaration mq = new MqConnectionDeclaration();
		for (String declaration : declarations) {
			String[] keyValus = declaration.split("=");
			String key = keyValus[0];
			String value = keyValus[1];
			switch (key) {
			case "exchange":
				mq.setExchangeName(value);
				break;
			case "queue":
				mq.setQueueName(value);
				break;
			case "routekey":
				mq.setRoutingKey(value);
				break;
			case "basicQos":
				mq.setBasicQos(Integer.valueOf(value));
				break;
			case "threadSum":
				mq.setThreadSum(Integer.valueOf(value));
				break;
			case "reply":
				if (buildConsumer)
					consumerMapReplyQueueName.put(companyName, value);
				mq.setCompanyName(companyName);
				break;
			case "content":
				if (buildConsumer) {
					String[] function = value.split("\\|");
					Integer[] functionIndexs = new Integer[2];
					functionIndexs[0] = Integer.parseInt(function[0]);
					functionIndexs[1] = Integer.parseInt(function[1]);
					mq.setContentIndex(functionIndexs);
				}
				break;
			case "function":
				if (buildConsumer) {
					String[] function = value.split("\\|");
					Integer[] functionIndexs = new Integer[2];
					functionIndexs[0] = Integer.parseInt(function[0]);
					functionIndexs[1] = Integer.parseInt(function[1]);
					mq.setFunctionIndex(functionIndexs);
				}

				break;
			default:
				break;
			}

		}
		mq.setHost(host);
		mq.setPort(port);
		mq.setUserName(userName);
		mq.setPassword(password);
		return mq;
	}

	public static void initWeatherCode() {
		String declarations = "";
		if (SystemConfigUtil.foreign.equals("false"))
			declarations = p.getProperty("weather.declaration");
		else
			declarations = p.getProperty("weather.yahoo.declaration");

		String[] declaration = declarations.split("\\|");
		for (String d : declaration) {
			String[] item = d.split(",");
			WeatherDeclaration wd = new WeatherDeclaration(Integer.parseInt(item[0]), item[1], item[2],
					Integer.parseInt(item[3]));
			weatcherCodeMapDeclaration.put(item[1], wd);
		}
	}

}
