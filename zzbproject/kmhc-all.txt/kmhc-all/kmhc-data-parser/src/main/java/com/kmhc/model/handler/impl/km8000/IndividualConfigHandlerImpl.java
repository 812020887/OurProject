package com.kmhc.model.handler.impl.km8000;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.PacketUtil;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.ProductPerSettingMMapper;
import com.kmhc.model.datacenter.dao.PsrSettingMapper;
import com.kmhc.model.datacenter.model.ProductPerSettingM;
import com.kmhc.model.datacenter.model.PsrSetting;
import com.kmhc.model.datacenter.service.IWatchUpdateService;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;

@MessageCommand(type="KM8000",command="0x11") 
public class IndividualConfigHandlerImpl  extends AbstractHandler  {

	private static final Logger log = LoggerFactory.getLogger(IndividualConfigHandlerImpl.class);
	
	//用于转换电话编码
	private static char[] cellNO_tab = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '#', '+' };
	private static String[] cellNO_digit = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "#", "+" };
	
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		
		String imei = null;
		byte[] reMsg = null;
		byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
		try{
			ProductPerSettingMMapper  pPMMapper = 
					(ProductPerSettingMMapper) SpringBeanFacotry.getInstance().getBean("productPerSettingMMapper");
			
			IWatchUpdateService watchUpdateService = (IWatchUpdateService) SpringBeanFacotry.getInstance().getBean("watchUpdateServiceImpl");
			
			imei = parseImeiOrImsi_KM8000(msg,0);		   
			
			ProductPerSettingM record = pPMMapper.selectByPrimaryKey(imei);			
			
		    boolean handlerOutput = false;
		    boolean isNew = false;
		    if(record==null){
		    	record = new ProductPerSettingM();
		    	
		    	isNew=true;
		    }
		    constructRecord(msg,record);
		    	    
		    handlerOutput= watchUpdateService.updateOx11Data(record, isNew);
		    
			if(handlerOutput == true){
				reMsg = AbstractHandler.ACK_SUCCESS_KM8000;
			}else{
				reMsg = AbstractHandler.ACK_ERROR_KM8000;
			}
			
		}catch(Exception e){
			log.error("记录报文{}信息出错。","0x11");
			log.error("出错信息：",e);
			reMsg = AbstractHandler.ACK_ERROR_KM8000;
		}
	
		ReplyMessageContent replyMessageContent = null;
		if(imei != null && reMsg != null ){
			replyMessageContent = new ReplyMessageContent(imeiBytes,reMsg);
			push8000Gps(imei,"KM8000","0x11");		
		}
	
		return replyMessageContent;
	}
	
	
	/**
	 * 根据上传的封包入库
	 * @throws UnsupportedEncodingException 
	 */
	public ProductPerSettingM constructRecord(byte[] msg,ProductPerSettingM record) throws UnsupportedEncodingException{
		
		PsrSettingMapper  psrSettingMapper = 
				(PsrSettingMapper) SpringBeanFacotry.getInstance().getBean("psrSettingMapper");
		
		PsrSetting setting = null;
		String tmp = null;
		
		
		int offset = 0 ;
		String imei = parseImeiOrImsi_KM8000(msg,offset+0);
	    String imsi = parseImeiOrImsi_KM8000(msg,offset+8);
	 
	    record.setImei(imei);
	    record.setImsi(imsi);
	    
	    offset = offset+16;
	    
	    record.setSosKeyDelay((short)(0xFF & msg[offset++]));
	    record.setFmlyKeyDelay((short)(0xFF & msg[offset++]));
	    record.setSosSms((short)(0xFF & msg[offset++]));
		record.setFallSms((short)(0xFF & msg[offset++]));
		record.setNonDistrub((short)(0xFF & msg[offset++]));
		record.setTimezone((short)(0xFF & msg[offset++]));
		
		record.setSosPhoneNo1(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setSosPhoneNo2(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setSosPhoneNo3(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		
		record.setFallPhoneNo1(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setFallPhoneNo2(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setFallPhoneNo3(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		
		record.setFamilyIcon1((short)(0xFF & msg[offset++]));
		record.setFmlyPhoneNo1(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setFamilyIcon2((short)(0xFF & msg[offset++]));
		record.setFmlyPhoneNo2(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setFamilyIcon3((short)(0xFF & msg[offset++]));
		record.setFmlyPhoneNo3(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		
		record.setMedT1On((short)(0xFF & msg[offset++]));
		record.setMedT1Hh((short)(0xFF & msg[offset++]));
		record.setMedT1Mm((short)(0xFF & msg[offset++]));		
		record.setMedT1WeekdayFilter((short)(0xFF & msg[offset++]));
		
		setting = psrSettingMapper.selectSingleByTeamAndType(imei, "01", "01");
		setting.setsHour(String.format("%02d", record.getMedT1Hh()));
		setting.setsMin(String.format("%02d", record.getMedT1Mm()));
		setting.setsUpdatedate((new Date()));
		setting.setUpdated("N");
		setting.setIsvalid( record.getMedT1On() == 1 ? "Y" : "N" );
		tmp = String.format("%016d", Integer.valueOf(Integer.toBinaryString(record.getMedT1WeekdayFilter())));
		tmp = new StringBuilder(tmp).reverse().toString();
		setting.setT7Hex(tmp.substring(0, 1));
		setting.setT1Hex(tmp.substring(1, 2));
		setting.setT2Hex(tmp.substring(2, 3));
		setting.setT3Hex(tmp.substring(3, 4));
		setting.setT4Hex(tmp.substring(4, 5));
		setting.setT5Hex(tmp.substring(5, 6));
		setting.setT6Hex(tmp.substring(6, 7));
		psrSettingMapper.updateByPrimaryKey(setting);
		
		
		record.setMedT2On((short)(0xFF & msg[offset++]));
		record.setMedT2Hh((short)(0xFF & msg[offset++]));
		record.setMedT2Mm((short)(0xFF & msg[offset++]));		
		record.setMedT2WeekdayFilter((short)(0xFF & msg[offset++]));
		
		setting = psrSettingMapper.selectSingleByTeamAndType(imei, "02", "01");
		setting.setsHour(String.format("%02d", record.getMedT2Hh()));
		setting.setsMin(String.format("%02d", record.getMedT2Mm()));
		setting.setsUpdatedate((new Date()));
		setting.setUpdated("N");
		setting.setIsvalid( record.getMedT2On() == 1 ? "Y" : "N" );
		tmp = String.format("%016d", Integer.valueOf(Integer.toBinaryString(record.getMedT2WeekdayFilter())));
		tmp = new StringBuilder(tmp).reverse().toString();
		setting.setT7Hex(tmp.substring(0, 1));
		setting.setT1Hex(tmp.substring(1, 2));
		setting.setT2Hex(tmp.substring(2, 3));
		setting.setT3Hex(tmp.substring(3, 4));
		setting.setT4Hex(tmp.substring(4, 5));
		setting.setT5Hex(tmp.substring(5, 6));
		setting.setT6Hex(tmp.substring(6, 7));
		psrSettingMapper.updateByPrimaryKey(setting);
		
		record.setMedT3On((short)(0xFF & msg[offset++]));
		record.setMedT3Hh((short)(0xFF & msg[offset++]));
		record.setMedT3Mm((short)(0xFF & msg[offset++]));	
		record.setMedT3WeekdayFilter((short)(0xFF & msg[offset++]));
		
		setting = psrSettingMapper.selectSingleByTeamAndType(imei, "03", "01");
		setting.setsHour(String.format("%02d", record.getMedT3Hh()));
		setting.setsMin(String.format("%02d", record.getMedT3Mm()));
		setting.setsUpdatedate((new Date()));
		setting.setUpdated("N");
		setting.setIsvalid( record.getMedT3On() == 1 ? "Y" : "N" );
		tmp = String.format("%016d", Integer.valueOf(Integer.toBinaryString(record.getMedT3WeekdayFilter())));
		tmp = new StringBuilder(tmp).reverse().toString();
		setting.setT7Hex(tmp.substring(0, 1));
		setting.setT1Hex(tmp.substring(1, 2));
		setting.setT2Hex(tmp.substring(2, 3));
		setting.setT3Hex(tmp.substring(3, 4));
		setting.setT4Hex(tmp.substring(4, 5));
		setting.setT5Hex(tmp.substring(5, 6));
		setting.setT6Hex(tmp.substring(6, 7));
		psrSettingMapper.updateByPrimaryKey(setting);
		
		record.setMedT4On((short)(0xFF & msg[offset++]));
		record.setMedT4Hh((short)(0xFF & msg[offset++]));
		record.setMedT4Mm((short)(0xFF & msg[offset++]));
		record.setMedT4WeekdayFilter((short)(0xFF & msg[offset++]));
		
		setting = psrSettingMapper.selectSingleByTeamAndType(imei, "04", "01");
		setting.setsHour(String.format("%02d", record.getMedT4Hh()));
		setting.setsMin(String.format("%02d", record.getMedT4Mm()));
		setting.setsUpdatedate((new Date()));
		setting.setUpdated("N");
		setting.setIsvalid( record.getMedT4On() == 1 ? "Y" : "N" );
		tmp = String.format("%016d", Integer.valueOf(Integer.toBinaryString(record.getMedT4WeekdayFilter())));
		tmp = new StringBuilder(tmp).reverse().toString();
		setting.setT7Hex(tmp.substring(0, 1));
		setting.setT1Hex(tmp.substring(1, 2));
		setting.setT2Hex(tmp.substring(2, 3));
		setting.setT3Hex(tmp.substring(3, 4));
		setting.setT4Hex(tmp.substring(4, 5));
		setting.setT5Hex(tmp.substring(5, 6));
		setting.setT6Hex(tmp.substring(6, 7));
		psrSettingMapper.updateByPrimaryKey(setting);
		
		record.setMedT5On((short)(0xFF & msg[offset++]));
		record.setMedT5Hh((short)(0xFF & msg[offset++]));
		record.setMedT5Mm((short)(0xFF & msg[offset++]));		
		record.setMedT5WeekdayFilter((short)(0xFF & msg[offset++]));
		
		setting = psrSettingMapper.selectSingleByTeamAndType(imei, "05", "01");
		setting.setsHour(String.format("%02d", record.getMedT5Hh()));
		setting.setsMin(String.format("%02d", record.getMedT5Mm()));
		setting.setsUpdatedate((new Date()));
		setting.setUpdated("N");
		setting.setIsvalid( record.getMedT5On() == 1 ? "Y" : "N" );
		tmp = String.format("%016d", Integer.valueOf(Integer.toBinaryString(record.getMedT5WeekdayFilter())));
		tmp = new StringBuilder(tmp).reverse().toString();
		setting.setT7Hex(tmp.substring(0, 1));
		setting.setT1Hex(tmp.substring(1, 2));
		setting.setT2Hex(tmp.substring(2, 3));
		setting.setT3Hex(tmp.substring(3, 4));
		setting.setT4Hex(tmp.substring(4, 5));
		setting.setT5Hex(tmp.substring(5, 6));
		setting.setT6Hex(tmp.substring(6, 7));
		psrSettingMapper.updateByPrimaryKey(setting);
		
		record.setMedD1On((short)(0xFF & msg[offset++]));
		record.setMedD1Yy(PacketUtil.toShort(msg[(offset++)], msg[(offset++)]));		
		record.setMedD1Mm((short)(0xFF & msg[offset++]));
		record.setMedD1Dd((short)(0xFF & msg[offset++]));		
		record.setMedD1Hour((short)(0xFF & msg[offset++]));		
		record.setMedD1Minute((short)(0xFF & msg[offset++]));	
		
		setting = psrSettingMapper.selectSingleByTeamAndType(imei, "01", "02");
		setting.setsYear(String.format("%02d",record.getMedD1Yy()));
		setting.setsMon(String.format("%02d", record.getMedD1Mm()));
		setting.setsDay(String.format("%02d", record.getMedD1Dd()));
		setting.setsHour(String.format("%02d", record.getMedD1Hour()));
		setting.setsMin(String.format("%02d", record.getMedD1Minute()));
		setting.setsUpdatedate((new Date()));
		setting.setUpdated("N");
		setting.setIsvalid( record.getMedD1On() == 1 ? "Y" : "N" );
		psrSettingMapper.updateByPrimaryKey(setting);
		
		record.setMedD2On((short)(0xFF & msg[offset++]));
		record.setMedD2Yy(PacketUtil.toShort(msg[(offset++)], msg[(offset++)]));		
		record.setMedD2Mm((short)(0xFF & msg[offset++]));
		record.setMedD2Dd((short)(0xFF & msg[offset++]));		
		record.setMedD2Hour((short)(0xFF & msg[offset++]));		
		record.setMedD2Minute((short)(0xFF & msg[offset++]));
		
		setting = psrSettingMapper.selectSingleByTeamAndType(imei, "02", "02");
		setting.setsYear(String.format("%02d",record.getMedD2Yy()));
		setting.setsMon(String.format("%02d", record.getMedD2Mm()));
		setting.setsDay(String.format("%02d", record.getMedD2Dd()));
		setting.setsHour(String.format("%02d", record.getMedD2Hour()));
		setting.setsMin(String.format("%02d", record.getMedD2Minute()));
		setting.setsUpdatedate((new Date()));
		setting.setUpdated("N");
		setting.setIsvalid( record.getMedD2On() == 1 ? "Y" : "N" );
		psrSettingMapper.updateByPrimaryKey(setting);
		
		record.setWhiteListOn((short)(0xFF & msg[offset++]));
		record.setWhiteListPhone1(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone2(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone3(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone4(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone5(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone6(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone7(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone8(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone9(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone10(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone11(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone12(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone13(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone14(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone15(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone16(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone17(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone18(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone19(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;
		record.setWhiteListPhone20(this.toCellNoString("", msg, offset, 15));
		offset = offset+15;		

		record.setFallDetect((short)(0xFF & msg[offset++]));
		
		record.setFallLowLg((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallLowHg((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallLowFl((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallLowFt((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallLowSt((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallLowWt((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallLowRes1((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallLowRes2((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		
		record.setFallMidLg((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallMidHg((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallMidFl((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallMidFt((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallMidSt((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallMidWt((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallMidRes1((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallMidRes2((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		
		record.setFallHiLg((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallHiHg((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallHiFl((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallHiFt((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallHiSt((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallHiWt((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallHiRes1((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setFallHiRes2((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		
		
		record.setSetLang((short)(0xFF & msg[offset++]));
		record.setSpeakLang((short)(0xFF & msg[offset++]));

		int accountLength = 0;
		for (int i = 0; i < 15; ++i) {
			if (msg[(offset + i)] == 0) {
				break;
			}
			++accountLength;
		}

		char[] account_Buffer = new char[accountLength];
		for (int i = 0; i < accountLength; ++i) {
			account_Buffer[i] = (char) msg[(offset + i)];
		}
		record.setuAccountid(String.valueOf(account_Buffer));
		offset += 15;
		
		int titleLength = 0;
		for (int i = 0; i < 10; ++i) {
			if (msg[(offset + i)] == 0) {
				break;
			}
			++titleLength;
		}
		
		byte[] title_Buffer = new byte[titleLength];
		for (int i = 0; i < titleLength; ++i) {

			title_Buffer[i] = msg[(offset + i)];
		}
		record.setuName(new String(title_Buffer, "UTF8"));
		offset += 10;
		
		record.setuSex((short)(0xFF & msg[offset++]));
		record.setuAge((short)(0xFF & msg[offset++]));	
		record.setuBirthdateYy(PacketUtil.toShort(msg[(offset++)], msg[(offset++)]));
		record.setuBirthdateMm((short)(0xFF & msg[offset++]));
		record.setuBirthdateDd((short)(0xFF & msg[offset++]));
		record.setuUnit((short)(0xFF & msg[offset++]));
		
		record.setuHeight(new BigDecimal((short)((0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]) / 10)));		
		record.setuIdealWeight(new BigDecimal((short)((0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++] / 10))));
		record.setuWeight(new BigDecimal((short )((0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++] / 10))));
		
		record.setuStep((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setuSystolicUpperLimit((short)(0xFF & msg[offset++]));
		record.setuSystolicLowerLimit((short)(0xFF & msg[offset++]));
		record.setuDiastolicUpperLimit((short)(0xFF & msg[offset++]));
		record.setuDaistolicLowerLimit((short)(0xFF & msg[offset++]));
		
		record.setActiveG((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		record.setActiveGyro((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		
		record.setEfT1On((short)(0xFF & msg[offset++]));
		record.setEfST1Hh((short)(0xFF & msg[offset++]));
		record.setEfST1Mm((short)(0xFF & msg[offset++]));
		record.setEfET1Hh((short)(0xFF & msg[offset++]));
		record.setEfET1Mm((short)(0xFF & msg[offset++]));
		record.setEfT1WeekdayFilter((short)(0xFF & msg[offset++]));
		
		record.setEfT2On((short)(0xFF & msg[offset++]));
		record.setEfST2Hh((short)(0xFF & msg[offset++]));
		record.setEfST2Mm((short)(0xFF & msg[offset++]));
		record.setEfET2Hh((short)(0xFF & msg[offset++]));
		record.setEfET2Mm((short)(0xFF & msg[offset++]));
		record.setEfT2WeekdayFilter((short)(0xFF & msg[offset++]));
		
		record.setEfT3On((short)(0xFF & msg[offset++]));
		record.setEfST3Hh((short)(0xFF & msg[offset++]));
		record.setEfST3Mm((short)(0xFF & msg[offset++]));
		record.setEfET3Hh((short)(0xFF & msg[offset++]));
		record.setEfET3Mm((short)(0xFF & msg[offset++]));
		record.setEfT3WeekdayFilter((short)(0xFF & msg[offset++]));
		
		record.setChecksum((short)(0xFF00 & (short)(msg[offset++] << 8) | 0xFF & (short)msg[offset++]));
		
		return record;
		
	}
	/**
	 * 将二进制转换为String，用于转换电话编码
	 * @param delimiter
	 * @param array
	 * @param startIdx
	 * @param length
	 * @return
	 */
	public String toCellNoString(String delimiter, byte[] array, int startIdx, int length) {
		StringBuffer sB = new StringBuffer("");
		boolean foundDigit = false;
		int lastIdx = startIdx + length;

		for (int i = startIdx; i < lastIdx; ++i) {
			for (int j = 0; j < cellNO_tab.length; ++j) {
				if (array[i] == cellNO_tab[j]) {
					foundDigit = true;
					sB.append(cellNO_digit[j]);
					break;
				}

			}

			if (foundDigit) {
				foundDigit = false;
			} else {
				sB.append("?");
			}
		}
		return sB.toString();
	}


	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
