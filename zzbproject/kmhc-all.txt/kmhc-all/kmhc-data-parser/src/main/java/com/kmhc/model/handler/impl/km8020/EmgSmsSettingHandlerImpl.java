package com.kmhc.model.handler.impl.km8020;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.ServerActionHisMapper;
import com.kmhc.model.datacenter.dao.T9ContactInfoMapper;
import com.kmhc.model.datacenter.model.ServerActionHis;
import com.kmhc.model.datacenter.model.T9ContactInfo;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;

@MessageCommand(type = "KM8020", command = "0x543734")
public class EmgSmsSettingHandlerImpl extends AbstractParentHandlerKM8020 {

	private static final Logger log = LoggerFactory.getLogger(EmgSmsSettingHandlerImpl.class);
	private ServerActionHisMapper serverActionHisMapper = (ServerActionHisMapper) SpringBeanFacotry.getInstance().getBean("serverActionHisMapper");
	private T9ContactInfoMapper t9ContactInfoMapper = (T9ContactInfoMapper) SpringBeanFacotry.getInstance().getBean("t9ContactInfoMapper");
	
	public EmgSmsSettingHandlerImpl() {
		super(log);
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		//a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,355372020827303,S74,help! in server_action_his content
		//[V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T74]
		log.info(new String(msg));
		String protocol = "S74";
		String content[] = new String(msg).split(",");
		String uid = content[0];
		String imei = content[5];
		
		ServerActionHis record = serverActionHisMapper.selectByPrimaryKey(uid, imei, protocol);
		if( record != null){
			String command[] = record.getContent().split(",");
			String sosSms = "";
			if(command.length > 7) {
				sosSms = command[7];
				for(int i = 8; i < command.length; i++){
					sosSms += ",";
					sosSms += command[i];
				}
			}
			
			int flag = 0;
			T9ContactInfo info = null;
			info = t9ContactInfoMapper.selectByPrimaryKey(imei);
			if( info == null ){
				flag = 1;
				info = new T9ContactInfo();
			}
			info.setImei(imei);
			info.setSosSms(sosSms);
			info.setUpdatedate(new Date());
			
			int success = 0;
			try{
				if(flag == 0)success = t9ContactInfoMapper.updateByPrimaryKey(info);
				else{
					info.setCreatedate(new Date());
					success = t9ContactInfoMapper.insert(info);
				}
			}catch(Exception e){	
				log.error(e.toString());
			}
			if(success > 0){
				serverActionHisMapper.deleteByPrimaryKey(record.getUid(), record.getImei(), protocol);
				pushSettingFinish(imei,INotification.NOTIFICATION_TYPE_SETTING_EMG_CONTACT);
			}
		}
//		log.info("push fail notification to app");
		return null;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
