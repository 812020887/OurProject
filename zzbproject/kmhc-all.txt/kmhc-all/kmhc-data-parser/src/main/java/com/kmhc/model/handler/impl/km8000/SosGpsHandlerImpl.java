package com.kmhc.model.handler.impl.km8000;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.EmgIMapper;
import com.kmhc.model.datacenter.dao.EmgMMapper;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.EmgI;
import com.kmhc.model.datacenter.model.EmgM;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.util.LocUtil;

/**
 * Name: SosGpsHandlerImpl.java ProjectName: [kmhc-data-parser] Package:
 * [com.kmhc.model.handler.impl.km8000.SosGpsHandlerImpl.java] Description:
 * SOS+GPS求救协议处理
 * 
 * @since JDK1.7
 * @see
 *
 * @author: xl
 * @date: 2015年11月17日 下午4:25:10
 *
 *        Update-User: @author Update-Time: Update-Remark:
 * 
 *        Check-User: Check-Time: Check-Remark:
 * 
 *        Company: kmhc Copyright: kmhc
 */
@MessageCommand(type = "KM8000", command = "0x24")
public class SosGpsHandlerImpl extends AbstractParentHandlerKM8000 {

    private static final Logger log = LoggerFactory.getLogger(SosGpsHandlerImpl.class);
    private String type = "24";

    public SosGpsHandlerImpl() {
        super(log);
    }

    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
        byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
        writeDebugLog(msg, type);
        ReplyMessageContent result = null;
        EmgM emgm = null;
        try {
            emgm = byte2Pojo(msg);
        } catch (Exception e) {
            log.error("【type=KM8000,command=0x{}】解码失败", type);
            result = new ReplyMessageContent(imeiBytes, ACK_ERROR_KM8000);
            log.error("异常信息：", e);
        }
        try {

            // 入数据库Emg_M表
            EmgMMapper emgMMapper = (EmgMMapper) SpringBeanFacotry.getInstance().getBean("emgMMapper");
            int insert = emgMMapper.insertSelective(emgm);
            if (insert > 0) {
                result = new ReplyMessageContent(imeiBytes, process());
                push8000Gps(emgm.getImei(),"KM8000","0x24");
            }
            if (emgm.getCells().size() > 0) {
                List<EmgI> emgIList = getEmgIList(emgm.getCells(), emgm.getEmgDetailKey(), emgm.getCreateDate(),
                        emgm.getUpdateDate());
                EmgIMapper emgIMapper = (EmgIMapper) SpringBeanFacotry.getInstance().getBean("emgIMapper");
                emgIMapper.insertList(emgIList);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        sendNotification(emgm,"KM8000",null);
        return result;
    }

    private EmgM byte2Pojo(byte[] data) throws Exception {
        EmgM emgm = parseEmgBase(data, START_FRAME);
        emgm.setType(type);
        emgm.setIsvalid("Y");
        Cell cell = parseCell(data, START_FRAME + 23);
        List<Cell> cellList = parseCellList(data, START_FRAME + 34);
        emgm.setCell(cell);
        emgm.setCells(cellList);
        emgm.setCellidCount((short) cellList.size());
        List<Wifi> wifiList = parseWifiList(data, START_FRAME + 45 + cellList.size() * 11);
        setCell(emgm, cell);
        setWifiList(emgm, wifiList);
        Gps locationData = parseGps(data, START_FRAME + 35 + cellList.size() * 11);                                     //这里先用一个变量存储GPS数据，后续如果判断没有GPS数据，则会用Cell数据对此变量重新赋值
        if (locationData == null || locationData.getLat() == null || locationData.getLng() == null 
                || !"NS".contains(locationData.getDirectionLat())
                || !"WE".contains(locationData.getDirectionLng())) {                                                    //如果手表上送过来的数据包本身不包含GPS数据，则根据手表上送的Cell数据，调取位置服务商API获取经纬度信息
            LocResult locresult = LocUtil.loc(emgm.getImei(), emgm.getImsi(), cell, cellList, wifiList);                //调取位置服务商API，通过Cell数据，换取经纬度信息
            if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {              //如果位置服务商API响应状态字和类型，标识有数据则更新GPS数据
                emgm.setIsvalid("Y");
                emgm.setMcellStatus("Y");
                emgm.setWifiStatus("Y");
                LocDetailResult result = locresult.getResult();
                emgm.setHpe((double)(result.getRadius()));
                String[] lngLat = result.getLocation().split(",");
                BigDecimal lng = new BigDecimal(lngLat[0]).setScale(6, RoundingMode.HALF_EVEN);
	            BigDecimal lat = new BigDecimal(lngLat[1]).setScale(6, RoundingMode.HALF_EVEN);
	            String address = LocUtil.reverseGeocoding(lat, lng);
	            locationData = new Gps(lat, lng, "N", "E", "Y");
                locationData.setAddress(address);
            } else {
                if (locresult != null) {
                    log.info("定位失败，status:{},info:{},result.type:{}", locresult.getStatus(), locresult.getInfo(),
                            locresult.getResult() == null ? "" : locresult.getResult().getType());
                } else {
                    log.info("定位结果返回NULL");
                }
            }
        } else {
            emgm.setHpe(10.0);
            locationData = LocUtil.conver(locationData);                                                                               //坐标转换
            String address = LocUtil.reverseGeocoding(locationData.getLat(),locationData.getLng());                     //如果GPS经纬度信息存在，则调用位置服务商逆地理编码接口获取位置描述信息
            if(address != null){
                locationData.setAddress(address);
            }
        }
        if (locationData != null) {                                                                                     //这里判断locationData中如果有值则同时入库Gps经纬度字段、Cell经纬度字段、Wifi经纬度字段
            setGps(emgm, locationData);
            emgm.setLocStatus("Y");
            emgm.setMcellLat(locationData.getLat());
            emgm.setMcellLng(locationData.getLng());
            emgm.setWifiLat(locationData.getLat());
            emgm.setWifiLng(locationData.getLng());
            emgm.setMcellAddress(locationData.getAddress());
            emgm.setWifiAddress(locationData.getAddress());
        }
        return emgm;
    }

    private byte[] process() {
        return ACK_SUCCESS_KM8000;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}