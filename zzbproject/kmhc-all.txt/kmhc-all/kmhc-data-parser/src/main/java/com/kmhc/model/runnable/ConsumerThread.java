/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月24日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.runnable;

import java.io.IOException;
import java.util.concurrent.ExecutorService;

import com.kmhc.framework.rabbitmq.recover.core.ExecuteConsumer;
import com.kmhc.framework.rabbitmq.recover.core.ExecutePublisher;
import com.kmhc.framework.rabbitmq.recover.core.PublisherPool;
import com.kmhc.framework.rabbitmq.recover.declaration.IWorkerhook;
import com.kmhc.model.core.MessageDispatcher;
import com.kmhc.model.pojo.MqConnectionDeclaration;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;

/**
 * Name: ConsumerThread.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.runnable.ConsumerThread.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月24日 下午5:11:33
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class ConsumerThread{
	
	private final ExecutorService service;

	/** 
	 * @Title: ConsumerThread
	 * @Description: TODO
	 * @param @param service         
	 * @throws 
	 */ 
	public ConsumerThread(ExecutorService service) {
		this.service = service;
	}
	
	public void start( Connection consumerConnection, MqConnectionDeclaration mqDeclaration, IWorkerhook workerhook){
		for( int i = 0; i< mqDeclaration.getThreadSum(); i++ ){
			try {
				service.execute(new consumerRunnable(consumerConnection.createChannel(), workerhook, mqDeclaration));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}

class consumerRunnable implements Runnable{
	
	private final Channel channel;
	
	private  final IWorkerhook workhook;
	
	private final MqConnectionDeclaration mqDeclaration;
	
	/** 
	 * @Title: consumerRunnable
	 * @Description: TODO
	 * @param @param channel
	 * @param @param workhook
	 * @param @param mqDeclaration         
	 * @throws 
	 */ 
	public consumerRunnable(Channel channel, IWorkerhook workhook, MqConnectionDeclaration mqDeclaration) {
		super();
		this.channel = channel;
		this.workhook = workhook;
		this.mqDeclaration = mqDeclaration;
	}



	@Override
	public void run() {
		try {
			ExecuteConsumer ex = new ExecuteConsumer(channel,
					workhook , mqDeclaration.getExchangeName(), 
					mqDeclaration.getRoutingKey(), mqDeclaration.getQueueName(), mqDeclaration.getCompanyName()+"_"+Thread.currentThread());
			ex.startReceiveMessage();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
