/**
 * Copyright (C) 2016 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2016年3月9日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.util;

import com.kmhc.framework.rabbitmq.recover.core.ConnectionBuilder;
import com.kmhc.framework.rabbitmq.recover.core.ExecuteConsumer;
import com.kmhc.framework.rabbitmq.recover.core.ExecutePublisher;
import com.kmhc.framework.rabbitmq.recover.core.PublisherPool;
import com.kmhc.framework.rabbitmq.recover.declaration.IWorkerhook;
import com.kmhc.framework.rabbitmq.recover.resource.ConnectionOption;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;

/**
 * Name: Consumer.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.util.Consumer.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2016年3月9日 下午2:03:30
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class Consumer {
	
	public static void main(String[] args) {
		test();
	}
	
	public static void test() {
			try {
				ConnectionOption option = new ConnectionOption().withHostName("127.0.0.1").withPort("5672")
						.withUserName("guest").withPassowrd("guest");
				
				final Connection connection = ConnectionBuilder.createConnection(option);
				final Channel channel = connection.createChannel();
				IWorkerhook hook = new IWorkerhook() {
					
					@Override
					public void receive(byte[] body) {
						// TODO Auto-generated method stub
						System.out.println(new String(body));
					}
				};
				
				ExecuteConsumer consumer = new ExecuteConsumer(channel, hook, "kmc1", "kmc1", "kmc1", Thread.currentThread().getName());
				consumer.startReceiveMessage();
		}catch( Exception e ){
			e.printStackTrace();
		}
	}

}
