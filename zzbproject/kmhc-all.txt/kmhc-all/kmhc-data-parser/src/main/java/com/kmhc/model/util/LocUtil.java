package com.kmhc.model.util;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;

public class LocUtil {

	private static final Logger log = LoggerFactory.getLogger(LocUtil.class);

	public static LocResult SkychookLoc(String imei, Cell bts, List<Cell> nearbts, List<Wifi> wifis) {
		StringBuffer baseContent = new StringBuffer(
				"<LocationRQ xmlns=\"http://skyhookwireless.com/wps/2005\" version=\"2.15\" street-address-lookup=\"full\"> <authentication version=\"2.2\" > <key key=\"eJwdwUEKACAIBMBzjxHccsPOap-K_h40gwb9Jkc7WQvY7FIGE2eqJDXEy2PRGJN5HxAHCxw\" username=\"dont-care\"/></authentication>");
		if (wifis != null && wifis.size() > 0) {
			for (Wifi w : wifis) {
				addWifi(baseContent, w);
			}
		}
		if (bts != null) {
			addCell(baseContent, bts);
		}
		if (nearbts != null && nearbts.size() > 0) {
			for (Cell c : nearbts) {
				addCell(baseContent, c);
			}
		}
		baseContent.append("</LocationRQ>");
		log.info("imei:{},请求skyhook的url:{},请求报文：{}", imei, SystemConfigUtil.skyhookUrl, baseContent.toString());
		URLConnection connection;
		for(int k = 0; k < 5; k++){
			try {
				connection = new URL(SystemConfigUtil.skyhookUrl).openConnection();
				connection.setConnectTimeout(15000000);
				HttpURLConnection request = (HttpURLConnection) connection;
				request.setConnectTimeout(15000000);
				request.setRequestMethod("POST");
				request.setRequestProperty("Content-Type", "text/xml");
				request.setDoOutput(true);
				request.setDoInput(true);
				OutputStream out = request.getOutputStream();
//				log.info("imei:{},请求skyhook的url:{},请求报文：{}", imei, SystemConfigUtil.skyhookUrl, baseContent.toString());
				out.write(baseContent.toString().getBytes());
				out.flush();
				out.close();
				InputStream is = request.getInputStream();
				byte[] b = new byte[4096];
				StringBuffer response = new StringBuffer("");
				int temp = 0;
				while ((temp = is.read(b)) != -1) {
					response.append(new String(b, 0, temp, "UTF-8"));
				}
				is.close();
				String resp = response.toString();			
				log.info("imei:{},请求skyhook的url:{},返回报文:{}", imei, SystemConfigUtil.skyhookUrl, resp);
				if (resp.indexOf("latitude") > 0 && resp.indexOf("longitude") > 0) {
					log.debug(resp);
					String lat = resp.substring(resp.indexOf("latitude") + 9, resp.indexOf("/latitude") - 1);
					String lng = resp.substring(resp.indexOf("longitude") + 10, resp.indexOf("/longitude") - 1);
					int hpe = resp.indexOf("hpe") > 0
							? Integer.parseInt(resp.substring(resp.indexOf("hpe") + 4, resp.indexOf("/hpe") - 1)) : 500;
	
					String address = LocUtil.reverseGeocoding(new BigDecimal(lat).setScale(6, RoundingMode.HALF_EVEN), new BigDecimal(lng).setScale(6, RoundingMode.HALF_EVEN));
//					String address = "";
//					Document doc = convertStringToDocument(resp);
//					Node LRS = doc.getFirstChild();
//					NodeList rsList = LRS.getFirstChild().getChildNodes();
//					
//					for ( int i = 0; i < rsList.getLength(); ++i) {
//
//
//						if (rsList.item(i).getNodeName().equals("street-address")) {
//							NodeList addrNodeList = rsList.item(i).getChildNodes();
//
//							String address_line = "";
//							String city = "";
//							String country = "";
//							String countryCode = "";
//							for (int j = 0; j < addrNodeList.getLength(); ++j) {
//								if (addrNodeList.item(j).getNodeName().equals("address-line")) {
//									address_line = addrNodeList.item(j).getTextContent();
//								}
//								if (addrNodeList.item(j).getNodeName().equals("city")) {
//									city = addrNodeList.item(j).getTextContent();
//								}
//								if (addrNodeList.item(j).getNodeName().equals("country")) {
//									country = addrNodeList.item(j).getTextContent();
//									countryCode = addrNodeList.item(j).getAttributes().getNamedItem("code").getNodeValue();
//									if (countryCode.equals("TW")) {
//										country = "Taiwan";
//										countryCode = "886";
//									}
//								}
//							}
//							address = country + " " + countryCode + " " + city + " " + address_line;
//							break;
//						}
//					}
	
					LocResult loc = new LocResult();
					loc.setStatus(1);
					LocDetailResult result = new LocDetailResult();
					result.setLocation(lng + "," + lat);
					result.setType(1);
					result.setRadius(hpe);
					result.setDesc(address);
					loc.setResult(result);
					return loc;
				}
	
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static LocResult loc(String imei, String imsi, Cell bts, List<Cell> nearbts, List<Wifi> wifis) {
		if (SystemConfigUtil.foreign.equals("true")) {
			return SkychookLoc(imei, bts, nearbts, wifis);
		} else {
			return avloc(imei, imsi, bts, nearbts, wifis);
		}
	}

	public static LocResult avloc(String imei, String imsi, Cell bts, List<Cell> nearbts, List<Wifi> wifis) {
		LocResult loc = null;
		try {
			String param = "&imei=" + imei;
			if (imsi != null && !"".equals(imsi)) {
				param += ("&imsi=" + imsi);
			}
			if (bts != null) {
				param += ("&bts=" + bts.toString());
				int i = 0;
				if (nearbts != null && nearbts.size() > 0) {
					for (Cell cell : nearbts) {
						if (i == 0) {
							param += ("&nearbts=" + cell.toString());
						} else {
							param += ("|" + cell.toString());
						}
						i++;
					}
				}
				if (wifis != null && wifis.size() > 0) {
					int j = 0;
					for (Wifi wifi : wifis) {
						if (j == 0) {
							param += ("&mmac="
									+ new StringBuffer(wifi.getWifiMac()).insert(2, ":").insert(5, ":").insert(8, ":")
											.insert(11, ":").insert(14, ":").toString()
									+ "," + (wifi.getWifiSignal()) + ",TP-LINK");
						} else if (j == 1) {
							param += ("&macs="
									+ new StringBuffer(wifi.getWifiMac()).insert(2, ":").insert(5, ":").insert(8, ":")
											.insert(11, ":").insert(14, ":").toString()
									+ "," + (wifi.getWifiSignal()) + ",TP-LINK");
						} else {
							param += ("|"
									+ new StringBuffer(wifi.getWifiMac()).insert(2, ":").insert(5, ":").insert(8, ":")
											.insert(11, ":").insert(14, ":").toString()
									+ "," + (wifi.getWifiSignal()) + ",TP-LINK");
						}
						j++;
					}
				}
				log.info("============================");
				log.info("imei:{},请求avloc的param:{}", imei, param);
				byte[] result = HttpClientUtils.request(SystemConfigUtil.kmhcAutonaviUrl, "GET", "UTF-8", param, null,
						null, SystemConfigUtil.kmhcAutonaviConnectTimeout, SystemConfigUtil.kmhcAutonaviSocketTimeout);
				if (result != null && result.length > 0) {
					log.info("imei:{},请求avloc的返回报文:{}", imei, new String(result, "UTF-8"));

					loc = JSON.parseObject(new String(result, "UTF-8"), LocResult.class);
				}
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return loc;
	}

	/**
	 * @Title: 根据经纬度获取逆地理编码信息
	 * @Description: TODO
	 * @param lat
	 * @param lng
	 * @return String
	 */
	public static String reverseGeocoding(String lat, String lng) {
		String res = null;
		StringBuilder url = new StringBuilder(SystemConfigUtil.restapiPath).append("&location=").append(lng).append(",")
				.append(lat).append("&radius=1000");
		try {
			String resultText = HttpClientUtils.request(url.toString());
			JSONObject jsonObject = JSON.parseObject(resultText);
			if ("1".equals(jsonObject.get("status")) && jsonObject.get("regeocode") != null
					&& ((JSONObject) jsonObject.get("regeocode")).get("formatted_address") != null
					&& !((JSONObject) jsonObject.get("regeocode")).get("formatted_address").equals("")) { // 判断返回的信息中是否包含地理位置信息
				res = (String) ((JSONObject) jsonObject.get("regeocode")).get("formatted_address");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}
	
	public static String reverseGeocodByGoogle(String lat, String lng) {
		String res = null;
		StringBuilder url = new StringBuilder(SystemConfigUtil.googleapiGeocode).append("&latlng=").append(lat).append(",")
				.append(lng);
		try {
			String resultText = HttpClientUtils.request(url.toString());
			JSONObject jsonObject = JSON.parseObject(resultText);
			if(jsonObject != null && !jsonObject.isEmpty() && jsonObject.getJSONArray("results") != null)
				res = jsonObject.getJSONArray("results").getJSONObject(0).getString("formatted_address");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	/**
	 * @Title: 根据经纬度获取逆地理编码信息
	 * @Description: TODO
	 * @param lat
	 * @param lng
	 * @return String
	 */
	public static String reverseGeocoding(BigDecimal lat, BigDecimal lng) {
		if (SystemConfigUtil.foreign.equals("true")) 
			return reverseGeocodByGoogle(String.valueOf(lat), String.valueOf(lng));
		else
			return reverseGeocoding(String.valueOf(lat), String.valueOf(lng));
	}

	/**
	 * @Title: 坐标转换接口
	 * @Description: TODO
	 * @param lat
	 * @param lng
	 * @return String 转换后的经纬度，格式："lng,lat" 如："116.487582,39.991755"
	 */
	public static String conver(String lat, String lng) {
		String res = lng + "," + lat;
		if (SystemConfigUtil.foreign.equals("false")){		
			String url = SystemConfigUtil.restapiConvertPath + lng + "," + lat;
			try {
				String resultText = HttpClientUtils.request(url);
				JSONObject jsonObject = JSON.parseObject(resultText);
				if ("1".equals(jsonObject.get("status")) && jsonObject.get("locations") != null) { // 判断返回的信息中是否包含地理位置信息
					res = (String) jsonObject.get("locations");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return res;
	}

	public static Gps conver(Gps gps) {
		if (SystemConfigUtil.foreign.equals("false")){
			try {
				if (gps != null) {
					String converAfter = conver(String.valueOf(gps.getLat()), String.valueOf(gps.getLng()));
					if (converAfter != null) {
						String[] lngLat = converAfter.split(",");
						gps.setLng(new BigDecimal(lngLat[0]).setScale(10, BigDecimal.ROUND_HALF_UP));
						gps.setLat(new BigDecimal(lngLat[1]).setScale(10, BigDecimal.ROUND_HALF_UP));
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return gps;
	}

	private static void addWifi(StringBuffer sb, Wifi w) {
		sb.append("<access-point><mac>" + w.getWifiMac() + "</mac>");
		sb.append("<ssid>" + w.getWifiSsid() + "</ssid>");
		sb.append("<signal-strength>" + String.valueOf(w.getWifiSignal() -110) + "</signal-strength></access-point>");
	}

	private static void addCell(StringBuffer sb, Cell c) {
		sb.append("<cell-tower><mcc>" + c.getMcc() + "</mcc>");
		sb.append("<mnc>" + c.getMnc() + "</mnc>");
		sb.append("<lac>" + c.getLac() + "</lac>");
		sb.append("<ci>" + c.getCellid() + "</ci>");
		sb.append("<rssi>" + c.getRssi() + "</rssi><age>0</age></cell-tower>");
	}
	
	private static Document convertStringToDocument(String xmlStr) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(new StringReader(xmlStr)));
			return doc;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
