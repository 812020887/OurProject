package com.kmhc.model.handler.impl.A10;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
//import com.kmhc.model.datacenter.dao.HaJiMemberManagerMapper;
import com.kmhc.model.datacenter.model.A10DeviceStatus;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.Gps;
//import com.kmhc.model.datacenter.model.HaJiMemberManager;
import com.kmhc.model.datacenter.model.PrCellI;
import com.kmhc.model.datacenter.model.PrI;
import com.kmhc.model.datacenter.model.PrM;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.handler.impl.PushAlert;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.Publish;

public abstract class AbstractParentHandlerA10 extends AbstractHandler {

	public final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public final SimpleDateFormat yyMMddHHmmss = new SimpleDateFormat("yyMMddHHmmss");
	private Logger log;

	public AbstractParentHandlerA10(Logger log) {
		this.log = log;
	}

	protected void writeDebugLog(byte[] msg, String type) {
		String byte2hex = TripleDesHelper.byte2hex(msg, msg.length);
		log.debug("【type=A10,command=0x{}】收到数据：{}，处理中。。。", type, byte2hex);
	}

	public Logger getLog() {
		return log;
	}

	public void setLog(Logger log) {
		this.log = log;
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		return null;
	}

	protected byte[] generateResponse(String[] content) {
		// int length = content.length + 1;
		// int ret_len = length + 3;
		// byte[] response = new byte[ret_len];
		// int index = 0;
		// System.arraycopy(PID_KM8010, 0, response, index, PID_KM8010.length);
		// index += PID_KM8010.length;
		// response[index] = (byte) length;
		// index += 1;
		// response[index] = function;
		// index += 1;
		// System.arraycopy(content, 0, response, index, content.length);
		String response ="";
		for (String s : content) {
			response += "*";
			response += s;
		}
		return response.getBytes();
	}

	protected String getLengh(Integer number) {
		   NumberFormat nf = NumberFormat.getInstance();
	        //设置是否使用分组
	        nf.setGroupingUsed(false);
	        //设置最大整数位数
	        nf.setMaximumIntegerDigits(4);
	        //设置最小整数位数    
	        nf.setMinimumIntegerDigits(4);
	        //输出测试语句
	        return nf.format(number);
	}
	
	protected PrM parsePrM(String imei, String type) {
		PrM entry = new PrM();
		Date nowDate = new Date();
		entry.setImei(imei);
		entry.setBatchKey(yyMMddHHmmss.format(nowDate));
		entry.setType(type);
		entry.setCreateDate(nowDate);
		entry.setUpdateDate(nowDate);
		return entry;
	}

	
	protected List<Cell> paresLBS(String msg[]) {
		// (1)当3种定位数据都有时：
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		// WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-EDU|5c:63:bf:a4:bf:56$-27$CMCC&,

		// (2)当只有lbs定位数据时:
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,

		// (3)当上传lbs数据和gps数据时:
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,

		// (4)当上传lbs数据和wifi定位数据时:
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		// WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-EDU|5c:63:bf:a4:bf:56$-27$CMCC&,
		//7,255,460,1,9529,21809,158,9529,63555,133,9529,63554,129,9529,21405,126,9529,21242,124,9529,21151,120,9529,63556,119,0,40.7
		
		
		List<Cell> cells = new ArrayList<Cell>();
		
		int cellCount = Integer.valueOf(msg[0]);
		String mcc = msg[2];
		String mnc = msg[3];

		for (int i = 1; i <= cellCount; i++) {
			Cell cell = new Cell();
			cell.setMcc(mcc);
			cell.setMnc(mnc);
			int x = 3*(i-1)+4;
			int y = 3*(i-1)+5;
			int z = 3*(i-1)+6;
			cell.setLac((msg[x]));
			cell.setCellid(Integer.parseInt(msg[y]));
			// String arfcn = tmp[2];
			cell.setRssi(Short.parseShort(msg[z]));
			cells.add(cell);
		}
		//A10 无WiFi定位
		return cells;
	}
	
	
	
	protected PrI getPrI(Gps gps, String imei, Date updateDate) {
		PrI pri = new PrI();
		Date nowDate = new Date();
		pri.setImei(imei);
		pri.setCreateDate(nowDate);
		pri.setUpdateDate(nowDate);
		pri.setPrDate(updateDate);
		pri.setBatchKey(yyMMddHHmmss.format(nowDate));
		pri.setItemno((short) 0);
		pri.setBatchDetailKey(yyMMddHHmmss.format(nowDate) + imei + "0");
		pri.setGpsNsLat(gps.getDirectionLat());
		pri.setGpsEwLng(gps.getDirectionLng());
		pri.setGpsLat(gps.getLat());
		pri.setGpsLng(gps.getLng());
		pri.setIsvalid(gps.getIsValid());
		pri.setLocStatus(gps.getIsValid());
		pri.setMcellLat(gps.getLat());
		pri.setMcellLng(gps.getLng());
		pri.setMcellStatus(gps.getIsValid());
		pri.setWifiLat(gps.getLat());
		pri.setWifiLng(gps.getLng());
		pri.setAddress(gps.getAddress());
		pri.setHpe((double) 10);
		return pri;
	}

	protected A10DeviceStatus getA10DeviceStatus(A10DeviceStatus a10DeviceStatus, byte[] bty) {
		if((bty[3] & 0x01)==0x01) {
			   a10DeviceStatus.setLowPowerStatus(1);
		   }else {
			   a10DeviceStatus.setLowPowerStatus(0);
		   }
		   if((bty[3] & 0x02)==0x02) {
			   a10DeviceStatus.setElectricFenceStatus(1);
		   }
		   if((bty[3] & 0x04)==0x04) {
			   a10DeviceStatus.setElectricFenceStatus(0);
		   }
		   if((bty[3] & 0x08)==0x08) {
			   a10DeviceStatus.setDropStatus(1);
		   }else{
			   a10DeviceStatus.setDropStatus(0) ;
		   }
		   if((bty[3] & 0x10)==0x10) {
			   a10DeviceStatus.setMoveStatus(1);
		   }else{
			   a10DeviceStatus.setMoveStatus(0);
		   }
		   if((bty[2] & 0x40)==0x40) {
			   a10DeviceStatus.setStandbyStauts(1);
		   }else{
			   a10DeviceStatus.setStandbyStauts(0);
		   }
		   return a10DeviceStatus;
	}
	
	
	protected PrI getPrI(List<Cell> cellList, String imei, Date updateDate, int battery) {
		PrI pri = new PrI();
		Date nowDate = new Date();
		LocResult locresult = null;
		pri.setImei(imei);
		pri.setCreateDate(nowDate);
		pri.setUpdateDate(nowDate);
		pri.setPrDate(updateDate);
		pri.setBatchKey(yyMMddHHmmss.format(nowDate));
		pri.setItemno((short) 0);
		pri.setBatchDetailKey(yyMMddHHmmss.format(nowDate) + imei + "0");
		pri.setIsvalid("N");
		pri.setLocStatus("N");
		pri.setMcellStatus("N");
		Cell cell = cellList.get(0);
		pri.setMcc(cell.getMcc());
		pri.setMnc(cell.getMnc());
		pri.setLac(cell.getLac());
		pri.setCellid(cell.getCellid());
		pri.setRssi(cell.getRssi());
		if (cellList.size() > 1)
			locresult = LocUtil.loc(imei, null, cellList.get(0), cellList.subList(1, cellList.size() - 1), null);
		else
			locresult = LocUtil.loc(imei, null, cellList.get(0), null, null);
		if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {
			LocDetailResult result = locresult.getResult();
			String[] lngLat = result.getLocation().split(",");
			BigDecimal lng = new BigDecimal(lngLat[0]);
			BigDecimal lat = new BigDecimal(lngLat[1]);
			pri.setGpsNsLat("N");
			pri.setGpsEwLng("E");
			pri.setGpsLat(lat);
			pri.setGpsLng(lng);
			pri.setIsvalid("Y");
			pri.setLocStatus("Y");
			pri.setMcellLat(lat);
			pri.setMcellLng(lng);
			pri.setMcellStatus("Y");
			pri.setWifiLat(lat);
			pri.setWifiLng(lng);
			pri.setVoltage(battery);
			pri.setAddress(result.getDesc());
			pri.setHpe((double) result.getRadius());
		} else {
			if (locresult != null) {
				log.info("定位失败，status:{},info:{},result.type:{}", locresult.getStatus(), locresult.getInfo(),
						locresult.getResult() == null ? "" : locresult.getResult().getType());
			} else {
				log.info("定位结果返回NULL");
			}
		}
		return pri;
	}

	protected PrI getPrI(Gps gps, List<Cell> cellList, List<Wifi> wifis, String imei, Date updateDate, int battery) {
		PrI pri = new PrI();
		Date nowDate = new Date();
		LocResult locresult = null;
		pri.setImei(imei);
		pri.setCreateDate(nowDate);
		pri.setUpdateDate(nowDate);
		pri.setPrDate(updateDate);
		pri.setBatchKey(yyMMddHHmmss.format(nowDate));
		pri.setItemno((short) 0);
		pri.setBatchDetailKey(yyMMddHHmmss.format(nowDate) + imei + "0");
		pri.setIsvalid("N");
		pri.setLocStatus("N");
		pri.setMcellStatus("N");
		Cell cell = cellList.get(0);
		pri.setMcc(cell.getMcc());
		pri.setMnc(cell.getMnc());
		pri.setLac(cell.getLac());
		pri.setCellid(cell.getCellid());
		pri.setRssi(cell.getRssi());
		if (cellList.size() > 1)
			locresult = LocUtil.loc(imei, null, cellList.get(0), cellList.subList(1, cellList.size()), wifis);
		else
			locresult = LocUtil.loc(imei, null, cellList.get(0), null, wifis);

		if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {
			LocDetailResult result = locresult.getResult();
			String[] lngLat = result.getLocation().split(",");
			BigDecimal lng = new BigDecimal(lngLat[0]);
			BigDecimal lat = new BigDecimal(lngLat[1]);
			pri.setGpsNsLat("N");
			pri.setGpsEwLng("E");
			pri.setIsvalid("Y");
			pri.setLocStatus("Y");
			pri.setGpsLat(lat);
			pri.setGpsLng(lng);
			pri.setMcellLat(lat);
			pri.setMcellLng(lng);
			pri.setMcellStatus("Y");
			pri.setWifiLat(lat);
			pri.setWifiLng(lng);
			pri.setVoltage(battery);
			pri.setAddress(result.getDesc());
			pri.setHpe((double) result.getRadius());
		} else {
			if (locresult != null) {
				log.info("定位失败，status:{},info:{},result.type:{}", locresult.getStatus(), locresult.getInfo(),
						locresult.getResult() == null ? "" : locresult.getResult().getType());
			} else {
				log.info("定位结果返回NULL");
			}
		}
		
		if(gps != null){
			pri.setGpsNsLat(gps.getDirectionLat());
			pri.setGpsEwLng(gps.getDirectionLng());
			pri.setGpsLat(gps.getLat());
			pri.setGpsLng(gps.getLng());
			pri.setIsvalid("Y");
			pri.setLocStatus("Y");
			pri.setMcellLat(gps.getLat());
			pri.setMcellLng(gps.getLng());
			pri.setMcellStatus("Y");
			pri.setWifiLat(gps.getLat());
			pri.setWifiLng(gps.getLng());
			pri.setHpe((double) 10);
		}

		return pri;
	}

	protected List<PrCellI> getPrCellI(List<Cell> cellList, PrM prm) {
		List<PrCellI> prcelllist = new ArrayList<PrCellI>();
		Iterator<Cell> it = cellList.iterator();
		short i = 0;
		while (it.hasNext()) {

			Cell cell = it.next();
			PrCellI prcelli = new PrCellI();
			prcelli.setBatchDetailKey(prm.getBatchKey() + prm.getImei() + "0");
			prcelli.setItemno(i);
			prcelli.setIsvalid("N");
			prcelli.setLocStatus("N");
			prcelli.setMcc(cell.getMcc());
			prcelli.setMnc(cell.getMnc());
			prcelli.setCellid(cell.getCellid());
			prcelli.setRssi((short) (cell.getRssi() - 110));
			prcelli.setUpdateDate(prm.getUpdateDate());
			prcelli.setCreateDate(new Date());
			LocResult locresult = LocUtil.loc(prm.getImei(), null, cellList.get(0), null, null);
			if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {
				LocDetailResult result = locresult.getResult();
				String[] lngLat = result.getLocation().split(",");
				BigDecimal lng = new BigDecimal(lngLat[0]);
				BigDecimal lat = new BigDecimal(lngLat[1]);
				prcelli.setGpsEwLng("E");
				prcelli.setGpsNsLat("N");
				prcelli.setIsvalid("Y");
				prcelli.setLocStatus("Y");
				prcelli.setGpsLat(lat);
				prcelli.setGpsLng(lng);
			} else {
				if (locresult != null) {
					log.info("定位失败，status:{},info:{},result.type:{}", locresult.getStatus(), locresult.getInfo(),
							locresult.getResult() == null ? "" : locresult.getResult().getType());
				} else {
					log.info("定位结果返回NULL");
				}
			}
			prcelllist.add(prcelli);
			i++;
		}
		return prcelllist;
	}

	protected List<Cell> parseCellList(String cellStr) {
//		mcount$6$460$1$255#2533|75c9|124|32#2533|7798|659|27#2533|75c7|120|25#252a|1f61|115|22#2533|7838|647|16#2533|7797|651|16
		log.debug("===" + cellStr + "===");
		List<Cell> list = new ArrayList<Cell>();
		String cellInfo[] = cellStr.split("#");
		String[] mInfo = cellInfo[0].split("\\$");
		log.debug(mInfo.toString());
		log.debug(mInfo[0].toString());
		log.debug(mInfo[1].toString());
		int cellCount = Integer.valueOf(mInfo[1]);
		String mcc = mInfo[2];
		String mnc = mInfo[3];

		for (int i = 1; i <= cellCount; i++) {
			String tmp[] = cellInfo[i].split("\\|");
			Cell cell = new Cell();
			cell.setMcc(mcc);
			cell.setMnc(mnc);
			cell.setLac(Integer.toString(Integer.parseInt(tmp[0], 16)));
			cell.setCellid(Integer.parseInt(tmp[1], 16));
			// String arfcn = tmp[2];
			cell.setRssi(Short.parseShort(tmp[3]));
			list.add(cell);
		}
		return list;
	}

	protected List<Wifi> parseWifiList(String msg[]) {
		// mmac=f0:7d:68:9e:7d:18$-41$TPLink,macs=22:27:1d:20:08:d5$-55$CMCC-EDU|5c:63:bf:a4:bf:56$-27$CMCC&,
		List<Wifi> list = new ArrayList<Wifi>();
		Wifi wifi = null;
		if (msg[0].startsWith("mmac=")) {
			String mmacStr = msg[0].split("=")[1];
			String wifiDetail[] = mmacStr.split("$");
			String wifiMac = wifiDetail[0];
			String wifiSignal = wifiDetail[1];
			String wifiSsid = wifiDetail[2];
			wifi = new Wifi();
			wifi.setWifiMac(wifiMac.replace(":", ""));
			wifi.setWifiSignal(Short.parseShort(wifiSignal));
			wifi.setWifiSsid(wifiSsid);
			list.add(wifi);
		}
		if (msg.length > 1 && msg[1].startsWith("macs=")) {
			String macsStr = msg[1].split("=")[1];
			String macs[] = macsStr.split("\\|");
			for (int i = 0; i < macs.length; i++) {
				String wifiDetail[] = macs[i].split("$");
				String wifiMac = wifiDetail[0];
				String wifiSignal = wifiDetail[1];
				String wifiSsid = wifiDetail[2];
				wifi = new Wifi();
				wifi.setWifiMac(wifiMac.replace(":", ""));
				wifi.setWifiSignal(Short.parseShort(wifiSignal));
				wifi.setWifiSsid(wifiSsid);
				list.add(wifi);
			}
		}
		return list;
	}

	protected void pushSettingFinish(String imei, String type) {
		String title = "change_setting_title_key";
		String alert = new PushAlert(new Object[]{imei}, "change_setting_success_key").toString();
		String extras = String.format("type=%s|",type);
		Publish.push(imei, alert, title, INotification.ANDROID_MAKER_DEFAULT, extras);
	}
	
	/*protected void pushA10SettingFinish(String imei, String type) {
		String title = "a10_change_setting_title_key";
		String name = imei;
		HaJiMemberManagerMapper memberManagerMapper = (HaJiMemberManagerMapper) SpringBeanFacotry.getInstance().getBean("haJiMemberManagerMapper");
		HaJiMemberManager mm = memberManagerMapper.selectByImei(imei);
		if(mm!=null)
		  name=mm.getName();
		String alert = new PushAlert(new Object[]{name}, "a10_change_setting_title_key").toString();
		String extras = String.format("type=%s|",type);
		Publish.push(imei, alert, title, INotification.ANDROID_MAKER_DEFAULT, extras);
	}*/

}
