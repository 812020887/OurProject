package com.kmhc.model.handler.impl.km8000;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.EmgIMapper;
import com.kmhc.model.datacenter.dao.EmgMMapper;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.EmgI;
import com.kmhc.model.datacenter.model.EmgM;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.util.LocUtil;

/**
 * Name: SosHandlerImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8000.SosHandlerImpl.java]
 * Description: SOS求救协议
 * 
 * @since JDK1.7
 * @see
 *
 * @author: xl
 * @date: 2015年11月17日 下午4:22:37
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
@MessageCommand(type="KM8000",command="0x22")
public class SosHandlerImpl extends AbstractParentHandlerKM8000 {

    private static final Logger log = LoggerFactory.getLogger(SosHandlerImpl.class);
    private String type = "22";
    
    public SosHandlerImpl() {
        super(log);
    }
    
    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
       byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
        writeDebugLog(msg,type);
        ReplyMessageContent result = null ;
        EmgM emgm = null ;
        try {
            emgm = byte2Pojo(msg);
        } catch (ParseException e) {
            log.error("【type=KM8000,command=0x{}】解码失败",type);
            result = new ReplyMessageContent(imeiBytes,ACK_ERROR_KM8000);
            log.error("异常信息：",e);
        }
        try{
            //入数据库Emg_M表
            EmgMMapper emgMMapper = (EmgMMapper) SpringBeanFacotry.getInstance().getBean("emgMMapper");
            int insert = emgMMapper.insertSelective(emgm);
            if(insert>0){
            	 push8000Gps(emgm.getImei(),"KM8000","0x22");
                result = new ReplyMessageContent(imeiBytes,process());
            }
            if(emgm.getCells().size() >0 ){
                List<EmgI> emgIList = getEmgIList(emgm.getCells(),emgm.getEmgDetailKey(),emgm.getCreateDate(),emgm.getUpdateDate());
                EmgIMapper emgIMapper = (EmgIMapper) SpringBeanFacotry.getInstance().getBean("emgIMapper");
                emgIMapper.insertList(emgIList);
            }         
        }catch(Exception e){
            e.printStackTrace();
        }
        sendNotification(emgm,"KM8000",null);
        return result;
    }

    private EmgM byte2Pojo(byte[] data) throws ParseException{
        EmgM emgm = parseEmgBase(data,START_FRAME);
        emgm.setType(type);
        Cell cell = parseCell(data, START_FRAME+23);
        List<Cell> cellList = parseCellList(data, START_FRAME+34);
        emgm.setCell(cell);
        emgm.setCells(cellList);
        emgm.setCellidCount((short)cellList.size());
        List<Wifi> wifiList = parseWifiList(data, START_FRAME + 35 + cellList.size()*11);
        setCell(emgm, cell);
        setWifiList(emgm,wifiList);
        LocResult locresult = LocUtil.loc(emgm.getImei(), emgm.getImsi(), cell, cellList, wifiList);
        if(locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0){
            emgm.setIsvalid("Y");
            emgm.setLocStatus("Y");
            emgm.setMcellStatus("Y");
            emgm.setWifiStatus("Y");
            LocDetailResult result = locresult.getResult();
            String[] lngLat = result.getLocation().split(",");
            BigDecimal lng = new BigDecimal(lngLat[0]).setScale(6, RoundingMode.HALF_EVEN);
            BigDecimal lat = new BigDecimal(lngLat[1]).setScale(6, RoundingMode.HALF_EVEN);
            String address = LocUtil.reverseGeocoding(lat, lng);
            emgm.setGpsLng(lng);
            emgm.setGpsLat(lat);
            emgm.setAddress(address);
            emgm.setGpsNsLat("N");
            emgm.setGpsEwLng("E");
            emgm.setMcellLat(lat);
            emgm.setMcellLng(lng);
            emgm.setWifiLat(lat);
            emgm.setWifiLng(lng);
            emgm.setWifiAddress(address);
            emgm.setMcellAddress(address);
            emgm.setHpe((double)result.getRadius());
        }else{
            if(locresult != null){
                log.info("【type=KM8000,command=0x{}】定位失败，status:{},info:{},result.type:{}",type,locresult.getStatus(),locresult.getInfo(),locresult.getResult() == null?"":locresult.getResult().getType());
            }else{
                log.info("【type=KM8000,command=0x{}】定位结果返回NULL",type);
            }
        }
        return emgm;
    }
    
    private byte[] process() {
        return ACK_SUCCESS_KM8000;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
