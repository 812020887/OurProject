/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: czx
 *               Date: 2015年11月11日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8000;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.MemberSettingBloodglucoseMapper;
import com.kmhc.model.datacenter.dao.PsrBsMapper;
import com.kmhc.model.datacenter.model.MemberSettingBloodglucose;
import com.kmhc.model.datacenter.model.PsrBs;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.util.Publish;

/**
 * Name: BloodSugarHandlerImpl.java ProjectName: [kmhc-data-parser] Package:
 * [com.kmhc.model.handler.impl.BloodSugarHandlerImpl.java] Description: TODO
 * 
 * @since JDK1.7
 * @see
 *
 * @author: czx
 * @date: 2015年11月13日 下午2:11:46
 *
 *        Update-User: @author Update-Time: Update-Remark:
 * 
 *        Check-User: Check-Time: Check-Remark:
 * 
 *        Company: kmhc Copyright: kmhc
 */

@MessageCommand(type = "KM8000", command = "0x37")
public class BloodSugarHandlerImpl extends AbstractHandler {

	public static final Logger log = LoggerFactory.getLogger(BloodSugarHandlerImpl.class);

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		// TODO Auto-generated method stub
		String imei = null;
		byte[] reMsg = null;
		byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
		try {
			PsrBsMapper bSMapper = (PsrBsMapper) SpringBeanFacotry.getInstance().getBean("psrBsMapper");

			PsrBs record = constructRecord(msg);

			int success = bSMapper.selectByBsTime(record);
			if(success == 0){
				success= bSMapper.insert(record);
			}
			imei = record.getImei();
			
			push(imei, record.getGlu(), record.getBsTime(), record.getUnit(),"KM8000");
			pushBS(imei, record.getGlu(), record.getBsTime(), record.getUnit(),"KM8000");
			if (success > 0) {
				reMsg = AbstractHandler.ACK_SUCCESS_KM8000;
			} else {
				reMsg = AbstractHandler.ACK_ERROR_KM8000;
			}

		} catch (Exception e) {
			log.error("记录血糖信息出错。", e);
			reMsg = AbstractHandler.ACK_ERROR_KM8000;
		}

		ReplyMessageContent replyMessageContent = null;
		if (imei != null && reMsg != null) {
			replyMessageContent = new ReplyMessageContent(imeiBytes, reMsg);
		}

		return replyMessageContent;
	}

	/**
	 * 根据血糖信息构建入库信息
	 */
	public PsrBs constructRecord(byte[] msg) {

		int offset = 0;
		String imei = parseImeiOrImsi_KM8000(msg, offset + 0);
		String imsi = parseImeiOrImsi_KM8000(msg, offset + 8);

		PsrBs record = new PsrBs();
		record.setImei(imei);
		record.setImsi(imsi);
		record.setTypeid(37);

		Date bsTime = TripleDesHelper.byte2date(Arrays.copyOfRange(msg, offset + 16, 26));
		record.setBsTime(bsTime);

		Short unit = (short) (0xFF & msg[offset + 23]);
		record.setUnit(unit);

		Short bsCount = (short) (0xFF & msg[offset + 24]);
		record.setBsCount(bsCount);

		List<Short> glulist = new ArrayList<Short>();

		for (Short i = 0; i < bsCount; i++) {
			Short myGlu = (short) ((0xFF & msg[offset + 25 + i * 2]) << 8 | (0xFF & msg[offset + 26 + i * 2]));
			record.setGlu(myGlu);
			record.setItemno((short) (i + 1));
			glulist.add(myGlu);
		}

		return record;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
