package com.kmhc.model.handler.impl;

import java.io.Serializable;
import com.alibaba.fastjson.JSON;

@SuppressWarnings("serial")
public class PushAlert implements Serializable {
	private String loc_key;
	private Object[] loc_args;

	public PushAlert() {
	}

	public PushAlert(Object[] loc_args, String loc_key) {
		this.loc_args = loc_args;
		this.loc_key = loc_key;
	}

	public Object[] getLoc_args() {
		return loc_args;
	}

	public void setLoc_args(Object[] loc_args) {
		this.loc_args = loc_args;
	}

	public String getLoc_key() {
		return loc_key;
	}

	public void setLoc_key(String loc_key) {
		this.loc_key = loc_key;
	}

	@Override
	public String toString() {
		return JSON.toJSONString(this).replace("loc_args", "loc-args").replace("loc_key", "loc-key");
	}
}
