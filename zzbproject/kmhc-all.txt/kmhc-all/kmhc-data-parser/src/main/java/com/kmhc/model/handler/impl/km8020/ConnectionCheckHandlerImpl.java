package com.kmhc.model.handler.impl.km8020;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.T9DeviceStatusMapper;
import com.kmhc.model.datacenter.model.T9DeviceStatus;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type = "KM8020", command = "0x543200")
public class ConnectionCheckHandlerImpl extends AbstractParentHandlerKM8020 {

	private static final Logger log = LoggerFactory.getLogger(ConnectionCheckHandlerImpl.class);

	private T9DeviceStatusMapper t9DeviceStatusMapper = (T9DeviceStatusMapper) SpringBeanFacotry.getInstance().getBean("t9DeviceStatusMapper");

	public ConnectionCheckHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		log.info(new String(msg));
		String function = "S2";
		String content[] = new String(msg).split(",");
		String uid = content[0];
		String imei = content[5];
		String tzStr = "GMT+" + content[6];
		TimeZone tz = TimeZone.getTimeZone(tzStr);

		Date dt = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		sdf.setTimeZone(tz);
		log.debug(sdf.format(dt));
		String out[] = { uid, content[1], content[2], sdf.format(dt), imei, function };

		T9DeviceStatus device = t9DeviceStatusMapper.selectByImei(imei);

		if (device != null) {
			device.setUpdatetime(dt);
			t9DeviceStatusMapper.updateByPrimaryKey(device);
		}

		return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"), generateResponse(out));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
