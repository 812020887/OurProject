package com.kmhc.model.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.pojo.TimeZoneResult;

public class TimeZoneUtil {
	private static final Logger log = LoggerFactory.getLogger(TimeZoneUtil.class);
	public static TimeZoneResult time(Gps gps){
		TimeZoneResult tz = null;
		try {
			String param = "&lat=";
			if(gps.getDirectionLat().equals("S"))
				param += "-";
			param += String.valueOf(gps.getLat().doubleValue());
			param += "&lng=";
			if(gps.getDirectionLat().equals("W"))
				param += "-";
			param += String.valueOf(gps.getLng().doubleValue());
            byte[] result = HttpClientUtils.request(SystemConfigUtil.kmhcGeonamesUrl, "GET", "UTF-8", param, null, null, SystemConfigUtil.kmhcAutonaviConnectTimeout,SystemConfigUtil.kmhcAutonaviSocketTimeout);
            log.debug(new String(result,"UTF-8"));
            JSON.DEFFAULT_DATE_FORMAT = "yyyy-MM-dd HH:mm";
            log.debug("获取返回后的数据转Text:{}",JSON.parseObject(new String(result,"UTF-8"),TimeZoneResult.class).toString());
            if(result != null && result.length >0)
            	tz = JSON.parseObject(new String(result,"UTF-8"),TimeZoneResult.class);   
			//	String str = "{"sunrise":"2015-11-27 06:40","lng":114.9441519,"countryCode":"CN","gmtOffset":8,"rawOffset":8,"sunset":"2015-11-27 17:34","timezoneId":"Asia/Shanghai","dstOffset":8,"countryName":"China","time":"2015-11-26 18:37","lat":22.7592958}";
//			    String str = "{\"sunrise\":\"2015-11-27 06:40\",\"lng\":114.9441519,\"countryCode\":\"CN\",\"gmtOffset\":8,\"rawOffset\":8,\"sunset\":\"2015-11-27 17:34\",\"timezoneId\":\"Asia/Shanghai\",\"dstOffset\":8,\"countryName\":\"China\",\"time\":\"2015-11-26 18:37\",\"lat\":22.7592958}";	    
//			    tz = JSON.parseObject(str,TimeZoneResult.class);          
         } catch (Exception e) {
                e.printStackTrace();
         }	
		return tz;
	}
	
	public static void main(String[] args) {
		TimeZoneUtil.time(null);
	}

}
