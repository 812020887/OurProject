package com.kmhc.model.handler.impl.A10;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.kmhc.model.datacenter.dao.*;
import com.kmhc.model.datacenter.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.StringUtil;;

@MessageCommand(type = "A10", command = "0x5544")
public class RegularUploadHandlerImpl extends AbstractParentHandlerA10 {
	private static final Logger log = LoggerFactory.getLogger(RegularUploadHandlerImpl.class);
	private String type = "UD";

	private DeviceSettingGfenceSpMapper dsgsMapper = SpringBeanFacotry.getInstance().getBean(DeviceSettingGfenceSpMapper.class);
	// private HajiMemberElectricSettingMapper hjmesMapper =
	// SpringBeanFacotry.getInstance().getBean(HajiMemberElectricSettingMapper.class);

	private PrMMapper prMMapper = SpringBeanFacotry.getInstance().getBean(PrMMapper.class);

	private DeviceListMapper deviceListMapper = SpringBeanFacotry.getInstance().getBean(DeviceListMapper.class);
	private PrIMapper prIMapper = SpringBeanFacotry.getInstance().getBean(PrIMapper.class);
	private PrCellIMapper prCellIMapper = SpringBeanFacotry.getInstance().getBean(PrCellIMapper.class);
	private A10DeviceStatusMapper a10DeviceStatusMapper = SpringBeanFacotry.getInstance().getBean(A10DeviceStatusMapper.class);

	// private HaJiMemberManagerMapper haJiMemberManagerMapper =
	// SpringBeanFacotry.getInstance().getBean(HaJiMemberManagerMapper.class);
	// private HaJiMemberLocationMapper haJiMemberLocationMapper =
	// SpringBeanFacotry.getInstance().getBean(HaJiMemberLocationMapper.class);

	public RegularUploadHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg, type);
		// 9403094122*00CD*UD,180916,025723,A,22.570733,N,113.8626083,E,0.00,249.5,0.0,6,100,60,0,0,00000010,7,255,460,1,9529,21809,158,9529,63555,133,9529,63554,129,9529,21405,126,9529,21242,124,9529,21151,120,9529,63556,119,0,40.7
		log.info(new String(msg));
		String function = "UD";
		String content[] = new String(msg).split(",");
		String uid = content[0];
		String timeStr = content[1] + content[2];
		String sn = content[0].substring(0, content[0].indexOf("*"));
		DeviceList deviceList = deviceListMapper.selectBySn(sn);
		String imei = deviceList.getImei();
		String power = content[13];
		String tzStr = "GMT";
		int voltage = (int) Integer.parseInt(power);
		A10DeviceStatus a10DeviceStatus = new A10DeviceStatus();
		byte[] bty = TripleDesHelper.hex2byte(content[16]);

		Date dt = com.kmhc.model.util.Date.getDate(timeStr, "ddMMyyHHmmss", tzStr);
		log.debug("===={}====", sdf.format(dt));
		Gps gps = null;
		List<Cell> cells = null;
		List<Wifi> wifis = null;
		a10DeviceStatus.setLbsTime(dt);
		a10DeviceStatus.setPower(power);
		PrI pri = null;
		if (content[3].equals("A")) {
			gps = paresGps(Arrays.copyOfRange(content, 3, content.length));
			String reverseGeocoding = LocUtil.reverseGeocoding(gps.getLat(), gps.getLng());
			if (reverseGeocoding == null) {
				reverseGeocoding = "";
			}
			gps.setAddress(reverseGeocoding);
			a10DeviceStatus.setAddress(reverseGeocoding);
			a10DeviceStatus.setLatitude(gps.getLat());
			a10DeviceStatus.setLongitude(gps.getLng());
			a10DeviceStatus.setLocMode("G");
			PrM prm = parsePrM(imei, function);
			pri = getPrI(gps, imei, dt);
			pri.setLocType("GPS");
			if (prIMapper.selectByPrDate(pri) == 0) {
				if (prm != null) {
					try {
						prMMapper.insertSelective(prm);
					} catch (Exception e) {
						prMMapper.updateByPrimaryKey(prm);
					}
				}
				if (pri != null) {
					/*
					 * //判定是否开启电子围栏如果开启就推送没有就不推送 HajiMemberElectricSetting hjmec
					 * = hjmesMapper.selectUseElectricByimei(imei); if (hjmec !=
					 * null && hjmec.getStatus() == 1) {
					 * requestGFenceNotice(imei, pri.getGpsLat(),
					 * pri.getGpsLng(), pri.getHpe(), "A10"); }
					 */

					try {
						prIMapper.insertSelective(pri);
					} catch (Exception e) {
						prIMapper.updateByPrimaryKey(pri);
					}
				}
			}

		} else {
			cells = paresLBS(Arrays.copyOfRange(content, 17, content.length));
			a10DeviceStatus.setLocMode("C");
		}

		if (cells != null && cells.size() > 0) {
			PrM prm = parsePrM(imei, function);
			pri = getPrI(gps, cells, wifis, imei, dt, voltage);
			pri.setLocType("LBS");
			a10DeviceStatus.setAddress(pri.getAddress());
			a10DeviceStatus.setLatitude(pri.getGpsLat());
			a10DeviceStatus.setLongitude(pri.getGpsLng());
			List<PrCellI> prcelllist = getPrCellI(cells, prm);
			if (prIMapper.selectByPrDate(pri) == 0) {
				if (prm != null) {
					try {
						prMMapper.insertSelective(prm);
					} catch (Exception e) {
						prMMapper.updateByPrimaryKey(prm);
					}
				}

				log.debug("===" + pri.getLocStatus() + "===");
				if (pri != null && pri.getLocStatus().equals("Y")) {
					// 判定是否开启电子围栏如果开启就推送没有就不推送
					/*
					 * HajiMemberElectricSetting hjmec =
					 * hjmesMapper.selectUseElectricByimei(imei); if (hjmec !=
					 * null && hjmec.getStatus() == 1) {
					 * requestGFenceNotice(imei, pri.getGpsLat(),
					 * pri.getGpsLng(), pri.getHpe(), "A10"); }
					 */
					try {
						prIMapper.insertSelective(pri);
					} catch (Exception e) {
						prIMapper.updateByPrimaryKey(pri);
					}
				}
				for (int i = 0; prcelllist != null && i < prcelllist.size(); i++) {
					if (prcelllist.get(i).getLocStatus().equals("Y")) {
						try {
							prCellIMapper.insertSelective(prcelllist.get(i));
						} catch (Exception e) {
							prCellIMapper.updateByPrimaryKey(prcelllist.get(i));
						}
					}
				}

			}
		}

		try {
			a10DeviceStatus = getA10DeviceStatus(a10DeviceStatus, bty);
			A10DeviceStatus a10 = a10DeviceStatusMapper.selectByImei(imei);
			a10DeviceStatus.setImei(imei);
			if (a10 != null) {
				if (a10DeviceStatus.getLbsTime().getTime() >= a10.getLbsTime().getTime()) {
					a10DeviceStatus.setNo(a10.getNo());
					a10DeviceStatus.setUpdateTime(new Date());
					a10DeviceStatusMapper.updateByPrimaryKeySelective(a10DeviceStatus);
				}
			} else {
				a10DeviceStatus.setCreateTime(new Date());
				a10DeviceStatusMapper.insertSelective(a10DeviceStatus);
			}

			/*
			 * HaJiMemberManager hmm =
			 * haJiMemberManagerMapper.selectByImei(imei); if( hmm!= null &&
			 * pri.getLocStatus().equals("Y") && pri.getIsvalid().equals("Y") ){
			 * HaJiMemberLocation hml = new HaJiMemberLocation();
			 * hml.setMemberId(hmm.getId()); hml.setLbsKey(pri.getBatchKey());
			 * hml.setLbsno((int)pri.getItemno()); hml.setImei(imei);
			 * hml.setType(type); hml.setLbsDetailKey(pri.getBatchDetailKey());
			 * hml.setLbsDate(pri.getPrDate());
			 * hml.setLat(a10DeviceStatus.getLatitude());
			 * hml.setLng(a10DeviceStatus.getLongitude());
			 * hml.setAddress(a10DeviceStatus.getAddress());
			 * hml.setHpe(pri.getHpe()); if ( content[3].equals("A") )
			 * hml.setLocMethod("G"); else hml.setLocMethod("C");
			 * hml.setIsvalid("Y");
			 * haJiMemberLocationMapper.insertSelective(hml); }
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}
		// String out[] = { uid, content[1], content[2], sdf.format(new Date()),
		// imei, function };
		// [V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15
		// 10:00:00,355372020827303,S53]
		return null;

	}

	private Gps paresGps(String msg[]) {
		// (1)当3种定位数据都有时：
		// GPS,104.063469,30.551357,181.899994,0.217000,221.479996,
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		// WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-EDU|5c:63:bf:a4:bf:56$-27$CMCC&,

		// (3)当上传lbs数据和gps数据时:
		// GPS,104.063469,30.551357,181.899994,0.217000,221.479996,
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		// A,22.570733,N,113.8626083,E,0.00,249.5,0.0,6,100,60,0,0,00000010,7,255,460,1,9529,21809,158,9529,63555,133,9529,63554,129,9529,21405,126,9529,21242,124,9529,21151,120,9529,63556,119,0,40.7

		String lng = msg[3];
		String lat = msg[1];
		// String height = content[3];
		// String speed = content[4];
		// String direction = content[5];
		// String starNumber = content[6];

		Gps gps = new Gps(new BigDecimal(lat).setScale(10, BigDecimal.ROUND_HALF_UP), new BigDecimal(lng).setScale(10, BigDecimal.ROUND_HALF_UP), "N", "E", "Y");
		gps = LocUtil.conver(gps);

		return gps;
	}

	/*
	 * private Object[] paresLBS(String msg[]) { // (1)当3种定位数据都有时： //
	 * LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#
	 * 2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13, //
	 * WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-
	 * EDU|5c:63:bf:a4:bf:56$-27$CMCC&,
	 * 
	 * // (2)当只有lbs定位数据时: //
	 * LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#
	 * 2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
	 * 
	 * // (3)当上传lbs数据和gps数据时: //
	 * LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#
	 * 2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
	 * 
	 * // (4)当上传lbs数据和wifi定位数据时: //
	 * LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#
	 * 2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13, //
	 * WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-
	 * EDU|5c:63:bf:a4:bf:56$-27$CMCC&,
	 * //7,255,460,1,9529,21809,158,9529,63555,133,9529,63554,129,9529,21405,126
	 * ,9529,21242,124,9529,21151,120,9529,63556,119,0,40.7
	 * 
	 * 
	 * List<Cell> cells = new ArrayList<Cell>();
	 * 
	 * int cellCount = Integer.valueOf(msg[0]); String mcc = msg[2]; String mnc
	 * = msg[3];
	 * 
	 * for (int i = 1; i <= cellCount; i++) { Cell cell = new Cell();
	 * cell.setMcc(mcc); cell.setMnc(mnc); int x = 3*(i-1)+4; int y = 3*(i-1)+5;
	 * int z = 3*(i-1)+6; cell.setLac(Integer.toString(Integer.parseInt(msg[x],
	 * 16))); cell.setCellid(Integer.parseInt(msg[y], 16)); // String arfcn =
	 * tmp[2]; cell.setRssi(Short.parseShort(msg[z])); cells.add(cell); } //A10
	 * 无WiFi定位 List<Wifi> wifis = null; Object obj[] = { cells, wifis }; return
	 * obj; }
	 */
	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
