/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月14日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.util.DynamicLoger;
import com.kmhc.framework.util.SystemInforInformationUtil;

/**
 * Name: LogCenter.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.util.LogCenter.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月14日 下午4:32:20
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class LogCenter {
	
	public static final String fileSeparator = SystemInforInformationUtil.getFileSeparator();
	
	public static final Logger root = LoggerFactory.getLogger("ROOT");
	
	public static final Logger exception = LoggerFactory.getLogger("exception");
	
	public static final String HOME_PATH = SystemInforInformationUtil.getUserDir();
	
	public static final DynamicLoger userRquestLogger = new DynamicLoger( 8192, SystemConfigUtil.loggerFlushTime,
			HOME_PATH+fileSeparator+"mlog"+fileSeparator+"request"+fileSeparator+"user"+fileSeparator, true );
	
	public static final DynamicLoger serverResponseLogger = new DynamicLoger( 8192, SystemConfigUtil.loggerFlushTime,
			HOME_PATH+fileSeparator+"mlog"+fileSeparator+"response"+fileSeparator+"user"+fileSeparator, true );
	
	
	public static final DynamicLoger settingLogger = new DynamicLoger( 8192, SystemConfigUtil.loggerFlushTime,
		HOME_PATH+fileSeparator+"mlog"+fileSeparator+"settingLogger"+fileSeparator, true );
	
}
