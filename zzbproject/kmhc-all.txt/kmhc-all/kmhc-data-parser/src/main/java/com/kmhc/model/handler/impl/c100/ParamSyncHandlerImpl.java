package com.kmhc.model.handler.impl.c100;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.nio.charset.Charset;
import java.util.Arrays;

import javax.xml.bind.DatatypeConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.ConvertionUtil;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.C100ParamsMapper;
import com.kmhc.model.datacenter.dao.DeviceListMapper;
import com.kmhc.model.datacenter.dao.VoiceUploadRecordMapper;
import com.kmhc.model.datacenter.model.C100Params;
import com.kmhc.model.datacenter.model.DeviceList;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.SystemConfigUtil;

/**
 * @ClassName: com.kmhc.model.handler.impl.c100.ParamSyncHandlerImpl
 * @Description: 终端参数同步
 * @author xl
 * @date 2016年10月13日
 *
 */
@MessageCommand(type = "C100", command = "0x0C")
public class ParamSyncHandlerImpl extends AbstractParentHandlerC100 {

	private static final Logger log = LoggerFactory.getLogger(ParamSyncHandlerImpl.class);
	private C100ParamsMapper c100ParamsMapper = (C100ParamsMapper) SpringBeanFacotry.getInstance()
			.getBean("c100ParamsMapper");
	private VoiceUploadRecordMapper voiceUploadRecordMapper = (VoiceUploadRecordMapper) SpringBeanFacotry.getInstance()
			.getBean("voiceUploadRecordMapper");
	private DeviceListMapper deviceListMapper = (DeviceListMapper) SpringBeanFacotry.getInstance()
			.getBean("deviceListMapper");

	/**
	 * 创建一个新的实例 ParamSyncHandlerImpl.
	 *
	 * @param log
	 */

	public ParamSyncHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		int index = -5;
		byte[] snBytes = Arrays.copyOfRange(msg, index + 5, index + 14);
		int deviceTimeStamp = (int) ConvertionUtil.bigEndBytesToInt(msg, index + 14);
		int relationTimeStamp = (int) ConvertionUtil.bigEndBytesToInt(msg, index + 18);
		String snHexString = ConvertionUtil.Bytes2HexString(snBytes);
		String sn = snHexString.substring(0, snHexString.indexOf('F'));
		C100Params params = c100ParamsMapper.selectBySn(sn);
		int updateTime = (int) (params.getUpdateTime().getTime() / 1000);
		byte[] body = null;
		byte[] body8C = new byte[0];
		byte[] body8E = new byte[0];
		byte[] updateTimeBytes = ConvertionUtil.intToBigEndBytes(updateTime);
		DeviceList device = deviceListMapper.selectBySn(sn);
		short timeZoneOffset = (short) (SystemConfigUtil.timeZoneOffset == null ? 0
				: (Integer.parseInt(SystemConfigUtil.timeZoneOffset)) * 60);
		byte[] timeZoneOffsetBytes = ConvertionUtil.shortToByteArray(timeZoneOffset);
		byte mailBoxLength = (byte) voiceUploadRecordMapper.selectUndownloadFromMobileByImei(device.getImei()).size();
		if (deviceTimeStamp != updateTime) {// TODO
			Field[] fields = params.getClass().getDeclaredFields();
			Field.setAccessible(fields, true);
			String paramsStr = getParams(fields, params);
			byte[] paramBytes = paramsStr.getBytes();

			body8C = new byte[7 + paramBytes.length];
			System.arraycopy(updateTimeBytes, 0, body8C, 3, updateTimeBytes.length);
			System.arraycopy(paramBytes, 0, body8C, 7, paramBytes.length);
		} else {
			body8C = new byte[3];
		}
		body8C[0] = mailBoxLength;
		System.arraycopy(timeZoneOffsetBytes, 0, body8C, 1, timeZoneOffsetBytes.length);
		body8C = generateResponse(body8C, (byte) 0x8C);

		// log.debug("==========================================");
		// log.debug(TripleDesHelper.byte2hex(body8C, body8C.length));
		if (relationTimeStamp != updateTime) {// TODO
			body8E = getContactBytes(params, updateTimeBytes);
			if (body8E != null && body8E.length > 0) {
				body8E = generateResponse(body8E, (byte) 0x8E);
				// System.arraycopy(updateTimeBytes, 0, body8E, 6,
				// updateTimeBytes.length);
				// log.debug("==========================================");
				// log.debug(TripleDesHelper.byte2hex(body8E, body8E.length));
			} else {
				body8E = new byte[0];
			}
		}

		body = new byte[body8C.length + body8E.length];
		System.arraycopy(body8C, 0, body, 0, body8C.length);
		System.arraycopy(body8E, 0, body, body8C.length, body8E.length);

		if (body != null && body.length > 0) {
			return MessageBuilder.buildReplyMessageContent(snBytes, body);
		}
		return null;
	}

	private String getParams(Field[] fields, C100Params params) {
		StringBuffer syncParam = new StringBuffer();
		for (Field field : fields) {
			try {
				String name = field.getName();
				Object object = field.get(params);
				if ((!name.equals("id")) && (!name.equals("createTime")) && (!name.equals("updateTime"))
						&& (!name.equals("sn")) && (!name.equals("user0")) && (!name.equals("user1"))
						&& (!name.equals("user2")) && (!name.equals("user3")) && (!name.equals("user4"))
						&& (!name.equals("user5")) && (!name.equals("username0")) && (!name.equals("username1"))
						&& (!name.equals("username2")) && (!name.equals("username3")) && (!name.equals("username4"))
						&& (!name.equals("username5"))) {
					syncParam.append(";").append(name.toUpperCase()).append("=").append(object);
				}
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		return syncParam.toString().substring(1).replaceAll("true", "1").replaceAll("false", "0");
	}

	private byte[] getContactBytes(C100Params params, byte[] updateTimeBytes) {
		byte[] user0 = null;
		byte[] user1 = null;
		byte[] user2 = null;
		byte[] user3 = null;
		byte[] user4 = null;
		byte[] user5 = null;
		byte[] username0 = null;
		byte[] username1 = null;
		byte[] username2 = null;
		byte[] username3 = null;
		byte[] username4 = null;
		byte[] username5 = null;
		byte[] contact0 = null;
		byte[] contact1 = null;
		byte[] contact2 = null;
		byte[] contact3 = null;
		byte[] contact4 = null;
		byte[] contact5 = null;

		if (!params.getUser0().equals(""))
			user0 = params.getUser0().getBytes(Charset.forName("ASCII"));
		if (!params.getUser1().equals(""))
			user1 = params.getUser1().getBytes(Charset.forName("ASCII"));
		if (!params.getUser2().equals(""))
			user2 = params.getUser2().getBytes(Charset.forName("ASCII"));
		if (!params.getUser3().equals(""))
			user3 = params.getUser3().getBytes(Charset.forName("ASCII"));
		if (!params.getUser4().equals(""))
			user4 = params.getUser4().getBytes(Charset.forName("ASCII"));
		if (!params.getUser5().equals(""))
			user5 = params.getUser5().getBytes(Charset.forName("ASCII"));

		try {
			if (!params.getUsername0().equals(""))
				username0 = params.getUsername0().getBytes("UTF-16BE");
			if (!params.getUsername1().equals(""))
				username1 = params.getUsername1().getBytes("UTF-16BE");
			if (!params.getUsername2().equals(""))
				username2 = params.getUsername2().getBytes("UTF-16BE");
			if (!params.getUsername3().equals(""))
				username3 = params.getUsername3().getBytes("UTF-16BE");
			if (!params.getUsername4().equals(""))
				username4 = params.getUsername4().getBytes("UTF-16BE");
			if (!params.getUsername5().equals(""))
				username5 = params.getUsername5().getBytes("UTF-16BE");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		if (user0 != null && username0 != null && user0.length > 0 && username0.length > 0)
			contact0 = new byte[8 + user0.length + username0.length];
		if (user1 != null && username1 != null && user1.length > 0 && username1.length > 0)
			contact1 = new byte[8 + user1.length + username1.length];
		if (user2 != null && username2 != null && user2.length > 0 && username2.length > 0)
			contact2 = new byte[8 + user2.length + username2.length];
		if (user3 != null && username3 != null && user3.length > 0 && username3.length > 0)
			contact3 = new byte[8 + user3.length + username3.length];
		if (user4 != null && username4 != null && user4.length > 0 && username4.length > 0)
			contact4 = new byte[8 + user4.length + username4.length];
		if (user5 != null && username5 != null && user5.length > 0 && username5.length > 0)
			contact5 = new byte[8 + user5.length + username5.length];

		int count = 4;
		if (contact0 != null)
			count += contact0.length;
		if (contact1 != null)
			count += contact1.length;
		if (contact2 != null)
			count += contact2.length;
		if (contact3 != null)
			count += contact3.length;
		if (contact4 != null)
			count += contact4.length;
		if (contact5 != null)
			count += contact5.length;
		byte[] body = null;
		if (count > 4) {
			body = new byte[count];
			System.arraycopy(updateTimeBytes, 0, body, 0, updateTimeBytes.length);
		}

		int index = 4;
		// System.arraycopy(0, 0, contact0, 0, 8);
		if (contact0 != null) {
			contact0[0] = (byte) 3;
			System.arraycopy(ConvertionUtil.intToBigEndBytes(0), 0, contact0, 1, 4);
			contact0[5] = (byte) user0.length;
			System.arraycopy(user0, 0, contact0, 6, user0.length);
			contact0[6 + user0.length] = 0;
			contact0[7 + user0.length] = (byte) username0.length;
			System.arraycopy(username0, 0, contact0, 8 + user0.length, username0.length);

			System.arraycopy(contact0, 0, body, index, contact0.length);
			index += contact0.length;
		}

		if (contact1 != null) {
			contact1[0] = (byte) 3;
			System.arraycopy(ConvertionUtil.intToBigEndBytes(1), 0, contact1, 1, 4);
			contact1[5] = (byte) user1.length;
			System.arraycopy(user1, 0, contact1, 6, user1.length);
			contact1[6 + user1.length] = 0;
			contact1[7 + user1.length] = (byte) username1.length;
			System.arraycopy(username1, 0, contact1, 8 + user1.length, username1.length);

			System.arraycopy(contact1, 0, body, index, contact1.length);
			index += contact1.length;
		}

		if (contact2 != null) {
			contact2[0] = (byte) 3;
			System.arraycopy(ConvertionUtil.intToBigEndBytes(2), 0, contact2, 1, 4);
			contact2[5] = (byte) user2.length;
			System.arraycopy(user2, 0, contact2, 6, user2.length);
			contact2[6 + user2.length] = 0;
			contact2[7 + user2.length] = (byte) username2.length;
			System.arraycopy(username2, 0, contact2, 8 + user2.length, username2.length);

			System.arraycopy(contact2, 0, body, index, contact2.length);
			index += contact2.length;
		}

		if (contact3 != null) {
			contact3[0] = (byte) 3;
			System.arraycopy(ConvertionUtil.intToBigEndBytes(3), 0, contact3, 1, 4);
			contact3[5] = (byte) user3.length;
			System.arraycopy(user3, 0, contact3, 6, user3.length);
			contact3[6 + user3.length] = 0;
			contact3[7 + user3.length] = (byte) username3.length;
			System.arraycopy(username3, 0, contact3, 8 + user3.length, username3.length);

			System.arraycopy(contact3, 0, body, index, contact3.length);
			index += contact3.length;
		}

		if (contact4 != null) {
			contact4[0] = (byte) 3;
			System.arraycopy(ConvertionUtil.intToBigEndBytes(4), 0, contact4, 1, 4);
			contact4[5] = (byte) user4.length;
			System.arraycopy(user4, 0, contact4, 6, user4.length);
			contact4[6 + user4.length] = 0;
			contact4[7 + user4.length] = (byte) username4.length;
			System.arraycopy(username4, 0, contact4, 8 + user4.length, username4.length);

			System.arraycopy(contact4, 0, body, index, contact4.length);
			index += contact4.length;
		}

		if (contact5 != null) {
			contact5[0] = (byte) 3;
			System.arraycopy(ConvertionUtil.intToBigEndBytes(5), 0, contact5, 1, 4);
			contact5[5] = (byte) user5.length;
			System.arraycopy(user5, 0, contact5, 6, user5.length);
			contact5[6 + user5.length] = 0;
			contact5[7 + user5.length] = (byte) username5.length;
			System.arraycopy(username5, 0, contact5, 8 + user5.length, username5.length);

			System.arraycopy(contact5, 0, body, index, contact5.length);
		}
		return body;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
