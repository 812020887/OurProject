package com.kmhc.model.handler.impl.km8010;

import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrSettingMapper;
import com.kmhc.model.datacenter.model.PsrSetting;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.BooleanArrays;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type = "KM8010", command = "0x30")
public class Remind2CloudHandlerImpl extends AbstractParentHandlerKM8010 {

	private String type = "30";
	private static final Logger log = LoggerFactory.getLogger(Remind2CloudHandlerImpl.class);
	private PsrSettingMapper psrSettingMapper = (PsrSettingMapper) SpringBeanFacotry.getInstance().getBean("psrSettingMapper");
	private PsrSetting psrSetting = null;
   
	public Remind2CloudHandlerImpl() {
		super(log);
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,type);
		
		int success = 0;
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);
		ReplyMessageContent result =  MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) 48));
	   


		Object[] objs = byte2obj(msg);
		String text = null;
		if((short)objs[3] == 0x04 && ((short)objs[2] == 0x01 || (short)objs[2] == 0x02)){
			int messageLength = msg.length -23 ;
			byte MESSAGE[] = new byte[messageLength];
			System.arraycopy(msg, 23, MESSAGE, 0, messageLength);
			text = new String(MESSAGE, StandardCharsets.UTF_8);
		}
		
		
		
		switch ((short)objs[2]){
			case 1:	//modify
				psrSetting = getPsrSettingByObjs(objs);	
				if(psrSetting != null){
					psrSetting = setPsrSetting(psrSetting,objs,text);		        
					success = psrSettingMapper.updateByPrimaryKey(psrSetting);
				}
				break;
			case 2: //add
				psrSetting = new PsrSetting();
				psrSetting.setsImei((String) objs[0]);
				psrSetting = setPsrSetting(psrSetting,objs,text);
				PsrSetting tmp = psrSettingMapper.selectSingleByTeamAndType(psrSetting.getsImei(),psrSetting.getsTeam(),psrSetting.getsType());
				System.out.println("tmp:"+tmp+"====================================================================");

				if(tmp == null)
					success = psrSettingMapper.insert(psrSetting);
				else
					success = psrSettingMapper.updateByPrimaryKey(psrSetting);
				break;
			case 4: //delete
				psrSetting = getPsrSettingByObjs(objs);
				if( psrSetting != null){
					success = psrSettingMapper.deleteByPrimaryKey(psrSetting.getsId());
					refreshCustom(psrSetting.getsImei(),psrSetting.getsType());
				}
				break;
			default:
				break;
		};
		
		if(success > 0)
			result = MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_SUCCESS_KM8010,(byte) 48));
		
		return result;
	}
	
	private Object[] byte2obj( byte[] original ){
		
		int[] sections = new int[]{8,5,1,1,1};// imei,date,action,type,sequence
		String[] types = new String[]{"IMEI","Date","Short","Short","Short"};
		if(original[13] == 0x01 || original[13] == 0x02){
			sections = new int[]{8,5,1,1,1,1,5,1};// imei,date,action,type,sequence,enable_switch,remind_time,repeat
			types = new String[]{"IMEI","Date","Short","Short","Short","Short","Date","Short"};
		}
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		Object[] objs = BytesConvertionUtil.generateProperty4KM8010(original, sections, types, indexMapPolishing);
		return objs;
	}
	
	private PsrSetting getPsrSettingByObjs(Object[] objs){
		return psrSettingMapper.selectSingleByTeamAndType((String)objs[0], String.format("%02d",((short)objs[4] + 1)), String.format("%02d",((short)objs[3])));
	}
	
	private PsrSetting setPsrSetting(PsrSetting psr, Object[] objs ,String text){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH-mm");
		Date dt = (Date)objs[6];
		String dtStr = sdf.format(dt);
		String dtArr[] = dtStr.split("-");
		if((short)objs[5] != 0)psr.setIsvalid("Y");
		else psr.setIsvalid("N");
		
		psr.setsYear(dtArr[0]);
		psr.setsMon(dtArr[1]);
		psr.setsDay(dtArr[2]);
		psr.setsHour(dtArr[3]);
		psr.setsMin(dtArr[4]);
		
		BooleanArrays arrays = new BooleanArrays(16);
        for (int j = 15; j >= 0; j--) {
        	arrays.setBoolean(j, ((short)objs[7] & (1 << j)) != 0);
        }
        boolean[] repeats = arrays.getBoolean();
        if(repeats[0])psr.setT7Hex("1"); else psr.setT7Hex("0");
        if(repeats[1])psr.setT1Hex("1"); else psr.setT1Hex("0");
        if(repeats[2])psr.setT2Hex("1"); else psr.setT2Hex("0");
        if(repeats[3])psr.setT3Hex("1"); else psr.setT3Hex("0");
        if(repeats[4])psr.setT4Hex("1"); else psr.setT4Hex("0");
        if(repeats[5])psr.setT5Hex("1"); else psr.setT5Hex("0");
        if(repeats[6])psr.setT6Hex("1"); else psr.setT6Hex("0");

        psr.setsTeam(String.format("%02d",((short)objs[4] + 1)));        
        psr.setsType(String.format("%02d",(short)objs[3]));
        psr.setAttribute1(text);
        psr.setsUpdatedate(new Date());
        psr.setUpdated("N");
        
        return psr;
	}
	
	private void refreshCustom(String imei, String type){
		List<PsrSetting> psrSettings = psrSettingMapper.selectByImeiAndType(imei, type);
		for(short i = 1; i <= psrSettings.size(); i++){
			PsrSetting record = psrSettings.get(i-1);
			record.setsTeam(String.format("%02d",i));
			psrSettingMapper.updateByPrimaryKey(record);
		}
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
