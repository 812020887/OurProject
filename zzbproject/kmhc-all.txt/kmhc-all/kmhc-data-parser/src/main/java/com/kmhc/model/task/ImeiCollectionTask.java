package com.kmhc.model.task;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import com.kmhc.model.datacenter.dao.DeviceListMapper;
import com.kmhc.model.datacenter.model.DeviceList;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.runnable.ReplyMessageThread;
import com.kmhc.model.util.LogCenter;

/**
 * Name: ImeiCollectionTask.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.task.ImeiCollectionTask.java]
 * Description: 收集数据库中的Imei号,推送给通讯层做Imei处理，定时间隔时间查询增量号码  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: xl
 * @date: 2015年11月10日 下午5:06:05
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class ImeiCollectionTask {
	
	private volatile long lastImeiId = 0;
	@Autowired
//	private MemberMapper memberMapper;
	private DeviceListMapper deviceListMapper;
	private static final byte[] empty = new byte[]{};

    /** 
     * @Title: process
     * @Description: 需要定时执行的入口方法
     * @param      
     * @return void     
     * @throws 
     */ 
    public void process(){
    	LogCenter.root.info("执行任务"+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        if( lastImeiId == 0 ){
        	byte[] msg =  init();
        	if( msg.length > 0 )
        		push(msg);
        }
        else{
        	byte[] msg = collectionIncrement();
        	if( msg.length > 0 )
        		push(msg);
        }
    }
    
    
	public void response(){
        push(init());
//        LogCenter.root.info("response :"+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
    }
    
    
    /** 
     * @Title: init
     * @Description: 初始化时收集库存储数据
     * @param      
     * @return void     
     * @throws 
     */ 
    public byte[] init(){
//    	List<Member> imeiLogs = memberMapper.selectAll();
    	List<DeviceList> imeiLogs = deviceListMapper.selectAll();
    	
    	StringBuilder sb = new StringBuilder();
    	
    	for (int i = 0; i < imeiLogs.size(); i++) {
    		String key = imeiLogs.get(i).getImei();
    		if(imeiLogs.get(i).getType() == 100){
    			key = imeiLogs.get(i).getSn();
    		}else if(imeiLogs.get(i).getType() == 5000){
    			key = imeiLogs.get(i).getSn();
    		}
    		
    		if(!key.equals("")) {
				if (i < imeiLogs.size() - 1)
					sb.append(key).append(",");
				else {
					sb.append(key);
					lastImeiId = imeiLogs.get(i).getNo();
				}
			}
		}
    	
//    	if( sb.toString().length() > 0  )
//    		LogCenter.root.info("send keyCode init to Client : "+sb.toString());
    	return sb.toString().getBytes();
    	
    }
    
    /** 
     * @Title: collectionIncrement
     * @Description: 收集增量数据
     * @param      
     * @return void     
     * @throws 
     */ 
    public byte[] collectionIncrement(){
        //TODO 查询数据库增量数据操作
//    	List<Member> imeiLogs = memberMapper.selectByLastImeiCode(lastImeiId);
    	List<DeviceList> imeiLogs = deviceListMapper.selectByLastImeiCode(lastImeiId);
    	StringBuilder sb = new StringBuilder();
    	for (int i = 0; i < imeiLogs.size(); i++) {
    		String key = imeiLogs.get(i).getImei();;
    		if(imeiLogs.get(i).getType() == 100)
    			key = imeiLogs.get(i).getSn();
    		
    		if( i < imeiLogs.size() - 1 )
				sb.append(key).append(",");
			else {
				sb.append(key);
				lastImeiId = imeiLogs.get(i).getNo();
			}
		}
    	
//    	if( sb.toString().length() > 0 )
//    		LogCenter.root.info("send keyCode collectionIncrement to Client : "+sb.toString());
    	return sb.toString().getBytes();

    }
    
    /** 
     * @Title: push
     * @Description: 往外推送的统一出口
     * @param      
     * @return void     
     * @throws 
     */ 
    public static void push( byte[] reply ){
        //TODO 调用具体的推送操作
    	ReplyMessageThread.protocolTypeMapContent.get("KMHC").add(new ReplyMessageContent(reply));
    }
}
