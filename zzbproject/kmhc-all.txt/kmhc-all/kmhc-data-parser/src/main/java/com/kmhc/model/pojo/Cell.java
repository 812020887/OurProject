/*    */ package com.kmhc.model.pojo;
/*    */ 
/*    */ public class Cell
/*    */ {
/*    */   private int mcc;
/*    */   private int mnc;
/*    */   private int lac;
/*    */   private int cellid;
/*    */   private byte rssi;
/*    */ 
/*    */   public int getMcc()
/*    */   {
/* 23 */     return this.mcc;
/*    */   }
/*    */ 
/*    */   public void setMcc(int mcc) {
/* 27 */     this.mcc = mcc;
/*    */   }
/*    */ 
/*    */   public int getMnc() {
/* 31 */     return this.mnc;
/*    */   }
/*    */ 
/*    */   public void setMnc(int mnc) {
/* 35 */     this.mnc = mnc;
/*    */   }
/*    */ 
/*    */   public int getLac() {
/* 39 */     return this.lac;
/*    */   }
/*    */ 
/*    */   public void setLac(int lac) {
/* 43 */     this.lac = lac;
/*    */   }
/*    */ 
/*    */   public int getCellid() {
/* 47 */     return this.cellid;
/*    */   }
/*    */ 
/*    */   public void setCellid(int cellid) {
/* 51 */     this.cellid = cellid;
/*    */   }
/*    */ 
/*    */   public byte getRssi() {
/* 55 */     return this.rssi;
/*    */   }
/*    */ 
/*    */   public void setRssi(byte rssi) {
/* 59 */     this.rssi = rssi;
/*    */   }
/*    */ }

/* Location:           E:\doc\康美手表Server\Guider\台北蓋德_安裝光碟公版_台灣20140515\2.Gateway Program\icare2\WEB-INF\classes\
 * Qualified Name:     com.paralucent.gateway2.model.Cell
 * JD-Core Version:    0.5.3
 */