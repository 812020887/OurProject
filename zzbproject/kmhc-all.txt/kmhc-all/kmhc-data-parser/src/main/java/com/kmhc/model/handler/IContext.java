package com.kmhc.model.handler;

public interface IContext {
	public boolean handleBasicMessage(String array);
}
