/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月11日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.pojo;

/**
 * Name: MqConnectionDeclaration.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.pojo.MqConnectionDeclaration.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月11日 上午9:07:45
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class MqConnectionDeclaration {
	
	private String host;
	private String port;
	private String userName;
	private String password;
	private String exchangeName;
	private String queueName;
	private String routingKey;
	private Integer basicQos = 1;
	private Integer threadSum;
	//[0] index    [1]length
	private Integer[] functionIndex;
	
	//[0] index    [1]length
	private Integer[] contentIndex;
	
	private String companyName;
	
	
	/** 
	 * @Title: MqConnectionDeclaration
	 * @Description: TODO
	 * @param @param host
	 * @param @param port
	 * @param @param userName
	 * @param @param password
	 * @param @param exchangeName
	 * @param @param queueName
	 * @param @param routingKey         
	 * @throws 
	 */ 
	public MqConnectionDeclaration(String host, String port, String userName, String password, String exchangeName,
			String queueName, String routingKey, Integer basicQos, Integer threadSum, Integer[] functionIndex, String companyName, Integer[] contentIndex ) {
		super();
		this.host = host;
		this.port = port;
		this.userName = userName;
		this.password = password;
		this.exchangeName = exchangeName;
		this.queueName = queueName;
		this.routingKey = routingKey;
		this.basicQos = basicQos;
		this.threadSum = threadSum;
		this.functionIndex = functionIndex;
		this.companyName = companyName;
		this.contentIndex = contentIndex;
	}
	
	
	/** 
	 * @Title: MqConnectionDeclaration
	 * @Description: TODO
	 * @param          
	 * @throws 
	 */ 
	public MqConnectionDeclaration() {
		super();
		// TODO Auto-generated constructor stub
	}



	/**
	 * @return the host
	 */
	public String getHost() {
		return host;
	}
	/**
	 * @param host the host to set
	 */
	public void setHost(String host) {
		this.host = host;
	}
	/**
	 * @return the port
	 */
	public String getPort() {
		return port;
	}
	/**
	 * @param port the port to set
	 */
	public void setPort(String port) {
		this.port = port;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the exchangeName
	 */
	public String getExchangeName() {
		return exchangeName;
	}
	/**
	 * @param exchangeName the exchangeName to set
	 */
	public void setExchangeName(String exchangeName) {
		this.exchangeName = exchangeName;
	}
	/**
	 * @return the queueName
	 */
	public String getQueueName() {
		return queueName;
	}
	/**
	 * @param queueName the queueName to set
	 */
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	/**
	 * @return the routingKey
	 */
	public String getRoutingKey() {
		return routingKey;
	}
	/**
	 * @param routingKey the routingKey to set
	 */
	public void setRoutingKey(String routingKey) {
		this.routingKey = routingKey;
	}


	/**
	 * @return the basicQos
	 */
	public Integer getBasicQos() {
		return basicQos;
	}


	/**
	 * @param basicQos the basicQos to set
	 */
	public void setBasicQos(Integer basicQos) {
		this.basicQos = basicQos;
	}

	/**
	 * @return the threadSum
	 */
	public Integer getThreadSum() {
		return threadSum;
	}

	/**
	 * @param threadSum the threadSum to set
	 */
	public void setThreadSum(Integer threadSum) {
		this.threadSum = threadSum;
	}


	/**
	 * @return the functionIndex
	 */
	public Integer[] getFunctionIndex() {
		return functionIndex;
	}

	/**
	 * @param functionIndex the functionIndex to set
	 */
	public void setFunctionIndex(Integer[] functionIndex) {
		this.functionIndex = functionIndex;
	}


	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * @param companyName the companyName to set
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	/**
	 * @return the contentIndex
	 */
	public Integer[] getContentIndex() {
		return contentIndex;
	}


	/**
	 * @param contentIndex the contentIndex to set
	 */
	public void setContentIndex(Integer[] contentIndex) {
		this.contentIndex = contentIndex;
	}
	
}
