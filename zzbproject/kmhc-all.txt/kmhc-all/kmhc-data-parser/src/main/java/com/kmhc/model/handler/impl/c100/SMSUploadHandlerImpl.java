package com.kmhc.model.handler.impl.c100;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type = "C100", command = "0x0A")
public class SMSUploadHandlerImpl extends AbstractParentHandlerC100 {

	private String function = "0A";
	private static final Logger log = LoggerFactory.getLogger(SMSUploadHandlerImpl.class);
	public SMSUploadHandlerImpl() {
		super(log);
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,function);
		int index = 0 ;
		byte[] snBytes= Arrays.copyOfRange(msg, index, index + 9) ;
		
		return MessageBuilder.buildReplyMessageContent(snBytes, generateResponse((byte) 0x8A));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
