package com.kmhc.model.handler.impl.km8010;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;

import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.datacenter.model.PrM;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.EmgM;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.PrCellI;
import com.kmhc.model.datacenter.model.PrI;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.StringUtil;

public abstract class AbstractParentHandlerKM8010 extends AbstractHandler {
    public final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private  Logger log ;
    
    public AbstractParentHandlerKM8010(Logger log){
        this.log = log ;
    }
    
    protected void writeDebugLog(byte[] msg, String type) {
        String byte2hex = TripleDesHelper.byte2hex(msg, msg.length);
        log.info("【type=KM8010,command=0x{}】收到数据：{}，处理中。。。", type, byte2hex);
    }

    public Logger getLog() {
        return log;
    }

    public void setLog(Logger log) {
        this.log = log;
    }
    
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		return null;
	}
	
	protected byte[] generateResponse(byte[] content, byte function){
		int length = content.length + 1;
		int ret_len = length + 3;
		byte[] response = new byte[ret_len];
		int index = 0;
		System.arraycopy(PID_KM8010, 0, response, index, PID_KM8010.length);
		index += PID_KM8010.length;
		response[index] = (byte) length;
		index += 1;
		response[index] = function;
		index += 1;
		System.arraycopy(content, 0, response, index, content.length);
		return response;
	}
	
	protected PrM parsePrM(byte[] data,int index) throws ParseException{

//		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
//		indexMapPolishing.put(0, 1);
//		Object[] objs = BytesConvertionUtil.generateProperty4KM8010(data, new int[] { 8, 5, 1 },
//				new String[] { "String", "Date", "Short" }, indexMapPolishing);
		PrM entry = new PrM();
        Date nowDate = new Date();
        entry.setImei(parseImei_KM8010(data, index));
        entry.setBatchKey(yyMMddHHmmss.format(nowDate));
        entry.setType("10");
        entry.setCreateDate(nowDate);
//        entry.setUpdateDate((Date) objs[1]);
        entry.setUpdateDate(nowDate);
        return entry ;
    }
	
	Gps parseGps(byte[] a){
        Gps gps = null ;
        StringBuffer hexString = null;
        String EW = "E";
        String NS = "N";
        double lat = 0.0 ;
      	double lng = 0.0 ;
        
      	try{	        
			if (a[0] == 8) NS = "S";			
			if (a[5] == 8) EW = "W";
			
			hexString = new StringBuffer();	
			int a1 = a[1] & 0xFF;
			hexString.append(a1);
			hexString.append(".");
			int val1 = (a[2] & 0xFF) * 65536 + (a[3] & 0xFF) * 256 + (a[4] & 0xFF);
			hexString.append(val1);
			lat = Double.parseDouble(hexString.toString());
			
			hexString = new StringBuffer();
			int a6 = a[6] & 0xFF;
			hexString.append(a6);
			hexString.append(".");
			int val2 = (a[7] & 0xFF) * 65536 + (a[8] & 0xFF) * 256 + (a[9] & 0xFF);
			hexString.append(val2);
			lng = Double.parseDouble(hexString.toString());
			
			gps = new Gps(lat,lng,NS,EW,"Y");
        }catch(Exception e){
            log.error("解析协议GPS经纬度出错",e);
        }
        return gps;
    }
	
	protected List<Cell> parseCellList(byte[] data){
		int st = 0;
        List<Cell> list = new ArrayList<Cell>();
        Cell mcell = parseMCell(data,0);
        list.add(mcell);
        st += 8;
        int neighborCellNum = (int)data[st];
        st +=1;
        for( int i = 0; i < neighborCellNum; i++){
        	list.add(parseNCell(data,st,mcell.getMcc()));
        	st += 6;
        }
        return list;
    }
	
	protected Cell parseMCell(byte[] data,int st){
        Cell cell = null ;
        try{
            cell = new Cell();
            cell.setMcc(String.valueOf((int) ((data[st] & 0xFF) << 8 | data[(st + 1)] & 0xFF)));
    		st += 2;
    		cell.setMnc(String.valueOf((int)data[st]));
    		st += 1;
    		cell.setLac(String.valueOf((int) ((data[st] & 0xFF) << 8 | data[(st + 1)] & 0xFF)));
    		st += 2;
    		cell.setCellid((int) ((data[st] & 0xFF) << 8 | data[(st + 1)] & 0xFF));
    		st += 2;
    		cell.setRssi((short)data[st]);
        }catch(Exception e){
            log.error("解析Cell数据出错：",e);
        }
        return cell ;
    }
	
	protected Cell parseNCell(byte[] data,int st, String mcc){
        Cell cell = null ;
        try{
            cell = new Cell();
            cell.setMcc(mcc);
    		cell.setMnc(String.valueOf((int)data[st]));
    		st += 1;
    		cell.setLac(String.valueOf((int) ((data[st] & 0xFF) << 8 | data[(st + 1)] & 0xFF)));
    		st += 2;
    		cell.setCellid((int) ((data[st] & 0xFF) << 8 | data[(st + 1)] & 0xFF));
    		st += 2;
    		cell.setRssi((short)data[st]);
        }catch(Exception e){
            log.error("解析Cell数据出错：",e);
        }
        return cell ;
    }
	

	protected Cell parseCell(byte[] data, int index, String mcc) {
		int newIndex = index;
		Cell cell = new Cell();
		if (mcc == null) {
			mcc = String.valueOf(((0xFF & data[newIndex]) << 8) | (0xFF & data[newIndex + 1]));
			newIndex += 2;
		}
		cell.setMcc(mcc);
		cell.setMnc(String.valueOf(0xFF & data[newIndex]));
		cell.setLac(String.valueOf(((0xFF & data[newIndex + 1]) << 8) | (0xFF & data[newIndex + 2])));
		cell.setCellid(((0xFF & data[newIndex + 3]) << 8) | (0xFF & data[newIndex + 4]));
		cell.setRssi((short) (0xFF & data[newIndex + 5]));
		return cell;
	}
	
	protected List<Cell> parseCells(byte[] data, int index, String mcc) {
		List<Cell> list = new ArrayList<Cell>();
		int num = 0xFF & data[index];
		int indexNum = index + 1;
		for (int i = 0; i < num; i++) {
			list.add(parseCell(data, indexNum + i * 6, mcc));
		}
		return list;
	}
	
	protected List<Wifi> parseWifiList(byte[] data, int index) {
        List<Wifi> list = null;
        int wiFiNum = 0xFF & data[index];
        int wiFiIndex = index + 1;
        if (wiFiNum > 0) {
        	list = new ArrayList<Wifi>();
            for (int i = 0; i < wiFiNum; i++) {
                Wifi wifi = parseWifi(data, wiFiIndex + i * 7);
                if (wifi != null) {
                    list.add(wifi);
//                    log.debug("=================");
//                    log.debug(wifi.getWifiMac());
//                    log.debug(String.valueOf(wifi.getWifiSignal()));
//                    log.debug(wifi.getWifiSsid());
                }
            }
        }
        return list;
    }

    protected Wifi parseWifi(byte[] data, int index) {
        Wifi wifi = new Wifi();
        try {
            wifi.setWifiMac(StringUtil.toHexString(data, index, 6).toUpperCase());
            wifi.setWifiSignal((short) ((0xFF & data[index + 6]) - 110));
            wifi.setWifiSsid("UNKNOW");
        } catch (Exception e) {
            log.error("解析Wifi数据出错：", e);
        }
        return wifi;
    }

    protected void setWifiList(EmgM emgm, List<Wifi> wifi) {
        for (int i = 0; i < wifi.size() && i < 10; i++) {
            try {
                MethodHandle mac = MethodHandles.publicLookup().findVirtual(EmgM.class, "setWifiMac" + (i + 1),
                        MethodType.methodType(void.class, String.class));
                // Method mac =
                // emgmClass.getMethod("setWifiMac"+(i+1),String.class);
                MethodHandle signal = MethodHandles.publicLookup().findVirtual(EmgM.class, "setWifiSignal" + (i + 1),
                        MethodType.methodType(void.class, Short.class));
                MethodHandle channel = MethodHandles.publicLookup().findVirtual(EmgM.class, "setWifiChannel" + (i + 1),
                        MethodType.methodType(void.class, Short.class));
                MethodHandle ratio = MethodHandles.publicLookup().findVirtual(EmgM.class, "setWifiRatio" + (i + 1),
                        MethodType.methodType(void.class, Short.class));
                mac.invoke(emgm, wifi.get(i).getWifiMac());
                signal.invoke(emgm, wifi.get(i).getWifiSignal());
                channel.invoke(emgm, wifi.get(i).getWifiChannel());
                ratio.invoke(emgm, wifi.get(i).getWifiRatio());
            } catch (IllegalAccessException e) {
                e.printStackTrace();
                log.error("设置WiFi数据出错", e);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
                log.error("设置WiFi数据出错", e);
            } catch (InvocationTargetException e) {
                e.printStackTrace();
                log.error("设置WiFi数据出错", e);
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
                log.error("设置WiFi数据出错", e);
            } catch (SecurityException e) {
                e.printStackTrace();
                log.error("设置WiFi数据出错", e);
            } catch (Throwable e) {
                e.printStackTrace();
                log.error("设置WiFi数据出错", e);
            }
        }
    }
}
