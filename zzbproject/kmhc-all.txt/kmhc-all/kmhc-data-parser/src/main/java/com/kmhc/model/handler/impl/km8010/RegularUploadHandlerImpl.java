package com.kmhc.model.handler.impl.km8010;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.model.PrM;
import com.kmhc.model.datacenter.model.ProductPerSettingM;
import com.kmhc.model.datacenter.model.ProductSysSettingM;
import com.kmhc.model.datacenter.model.PsrSetting;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.StringUtil;
import com.kmhc.model.datacenter.dao.DeviceSettingGfenceSpMapper;
import com.kmhc.model.datacenter.dao.PrCellIMapper;
import com.kmhc.model.datacenter.dao.PrIMapper;
import com.kmhc.model.datacenter.dao.PrMMapper;
import com.kmhc.model.datacenter.dao.ProductPerSettingMMapper;
import com.kmhc.model.datacenter.dao.ProductSysSettingMMapper;
import com.kmhc.model.datacenter.dao.PsrSettingMapper;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.DeviceSettingGfenceSp;
import com.kmhc.model.datacenter.model.EmgM;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.PrCellI;
import com.kmhc.model.datacenter.model.PrI;;

@MessageCommand(type="KM8010",command="0x10")
public class RegularUploadHandlerImpl extends AbstractParentHandlerKM8010{
	private static final Logger log = LoggerFactory.getLogger(RegularUploadHandlerImpl.class);
    private String type = "10";
    
    private ProductSysSettingMMapper productSysSettingMMapper = (ProductSysSettingMMapper) SpringBeanFacotry.getInstance().getBean("productSysSettingMMapper");
	private ProductPerSettingMMapper productPerSettingMMapper = (ProductPerSettingMMapper) SpringBeanFacotry.getInstance().getBean("productPerSettingMMapper");
    private PsrSettingMapper psrSettingMapper = (PsrSettingMapper) SpringBeanFacotry.getInstance().getBean("psrSettingMapper");
    private DeviceSettingGfenceSpMapper dsgsMapper = (DeviceSettingGfenceSpMapper) SpringBeanFacotry.getInstance().getBean("deviceSettingGfenceSpMapper");
    
    private PrMMapper prMMapper = (PrMMapper) SpringBeanFacotry.getInstance().getBean("prMMapper");
    private PrIMapper prIMapper = (PrIMapper) SpringBeanFacotry.getInstance().getBean("prIMapper");
    private PrCellIMapper prCellIMapper = (PrCellIMapper) SpringBeanFacotry.getInstance().getBean("prCellIMapper");

	public RegularUploadHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,type);
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);
		int index = 0;

		String imei = parseImei_KM8010(msg, index);
		Date updateDate = TripleDesHelper.ParserRTC(Arrays.copyOfRange(msg, 8, 13));
		PrM prm = null;
		PrI pri = null;
		List<PrCellI> prcelllist = null;
		
		try {
			prm = parsePrM(msg , index);		
		} catch (ParseException e) {
			log.error("【type=KM8010,command=0x{}】解码失败",type);
            log.error("异常信息：",e);
		}
		index += 13;
		Byte percentage = msg[msg.length - 1];
		int battery = 4500 * percentage.intValue() / 100;
		Gps gps = null;
		Cell cell = null;
		List<Cell> cells = null;
		List<Wifi> wifis = null;
		switch((int)(msg[index])){
			case 0://GPS
				gps = parseGps(Arrays.copyOfRange(msg, index+1, msg.length - 1));
				gps = LocUtil.conver(gps);
				pri = getPrI(gps, imei, updateDate, battery);
				break;
			case 1://GSM
				cells = parseCellList(Arrays.copyOfRange(msg, index+1, msg.length - 1));
				pri = getPrI(gps, cells, wifis, imei, updateDate, battery);
				prcelllist = getPrCellI(cells, prm);
				break;
			case 4:
				index += 1;
				gps = parseGps(Arrays.copyOfRange(msg, index, index+10));
				gps = LocUtil.conver(gps);
				log.debug(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
				gps.setAddress(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
				index += 10;
				cell = parseCell(msg, index, null);
				index += 8;
				cells = parseCells(msg, index, cell.getMcc());
				cells.add(0, cell);
				pri = getPrI(gps, cells, wifis, imei, updateDate, battery);
				prcelllist = getPrCellI(cells, prm);
				break;
			case 8:
				cell = parseCell(msg, index + 1, null);
				cells = parseCells(msg, index + 9, cell.getMcc());
				wifis = parseWifiList(msg, index + 10 + cells.size()*6);
				cells.add(0, cell);
				pri = getPrI(gps, cells, wifis, imei, updateDate, battery);
				prcelllist = getPrCellI(cells, prm);
				break;
			case 0x16:
				index += 1;
				gps = parseGps(Arrays.copyOfRange(msg, index, index+10));
				gps = LocUtil.conver(gps);
				log.debug(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
				gps.setAddress(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
				index += 10;
				cell = parseCell(msg, index, null);
				index += 8;
				cells = parseCells(msg, index, cell.getMcc());
				index += ((cells.size()*6) + 1);
				wifis = parseWifiList(msg, index);							
				cells.add(0, cell);
				pri = getPrI(gps, cells, wifis, imei, updateDate, battery);
				prcelllist = getPrCellI(cells, prm);
				break;
			default:
				break;
		}
		
		int insertprmsuccess = 1;
		int insertprisuccess = 0;
		if(prm != null){
			try{
				prMMapper.insertSelective(prm);
				
			}catch(Exception e){
				insertprmsuccess = 1;
//				insertprmsuccess = prMMapper.updateByPrimaryKey(prm);
			}
		}
		if(pri != null){
			DeviceSettingGfenceSp dsg = dsgsMapper.selectByPrimaryKey(pri.getImei());
			if(dsg != null && dsg.getEnable() == 1){
				requestGFenceNotice(imei,pri.getGpsLat(),pri.getGpsLng(),pri.getHpe(),"KM8010");	
			}
			while (insertprisuccess == 0) {
				try {
					insertprisuccess = prIMapper.insertSelective(pri);
					if (insertprisuccess == 1)
						break;
				} catch (Exception e) {
 					pri.setItemno((short) (pri.getItemno() + 1));
				}
			}
		}
		for( int i = 0; prcelllist != null && i < prcelllist.size(); i++){		
			try{
				prCellIMapper.insertSelective(prcelllist.get(i));
			}catch(Exception e){
//				prCellIMapper.updateByPrimaryKey(prcelllist.get(i));
			}
		}
		
		
		
		ProductSysSettingM sysSetting = productSysSettingMMapper.selectByPrimaryKey(imei);
		ProductPerSettingM perSetting = productPerSettingMMapper.selectByPrimaryKey(imei);	
		
		byte[] content = new byte[1];
		content[0] = 5;
//		content[0] = 0;
		if( insertprmsuccess > 0 && insertprisuccess > 0 ){
//			if( sysSetting != null ){
//				sysSetting.getEchoPrT();
//				Date dt = null;
//				if(sysSetting.getUpdateDate() != null){
//					dt = new Date(sysSetting.getUpdateDate().getTime() + ((long)sysSetting.getEchoPrT()*60*1000));
//					if(prm.getUpdateDate().compareTo(dt) > 0)
//						content[0] = 1;
//				}else{
//					content[0] = 0;
//					sysSetting.setUpdateDate(new Date());
//					perSetting.setUpdateDate(new Date());
//					productSysSettingMMapper.updateByPrimaryKey(sysSetting);
//					productPerSettingMMapper.updateByPrimaryKey(perSetting);
//				}
//				List<PsrSetting> settings = psrSettingMapper.selectAllByImei(imei);
//				for(int i = 0; i < settings.size(); i++){
//					if(settings.get(i).getUpdated() == null || settings.get(i).getUpdated().equals("Y")){
//						content[0] += 4 ;
//						break;
//					}
//				}
//			}
			
			
			return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(content,(byte) 0x10));
		}
		return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) 0x10));	
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
