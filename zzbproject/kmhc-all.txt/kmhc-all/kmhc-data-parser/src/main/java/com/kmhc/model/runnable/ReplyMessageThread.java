/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月9日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.runnable;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.kmhc.framework.rabbitmq.recover.core.ExecutePublisher;
import com.kmhc.framework.rabbitmq.recover.core.PublisherPool;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.MqConnectionDeclaration;
import com.kmhc.model.util.BuildLogContent;
import com.kmhc.model.util.LogCenter;
import com.kmhc.model.util.SystemConfigUtil;
import com.rabbitmq.client.Connection;

/**
 * Name: ReplyMessageThread.java ProjectName: [kmhc-data-parser] Package:
 * [com.kmhc.model.runnable.ReplyMessageThread.java] Description: 消息回发线程
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月9日 下午3:05:19
 *
 *        Update-User: @author Update-Time: Update-Remark:
 * 
 *        Check-User: Check-Time: Check-Remark:
 * 
 *        Company: kmhc Copyright: kmhc
 */
public class ReplyMessageThread {

	private final ExecutorService service;

	public static HashMap<String, LinkedBlockingQueue<ReplyMessageContent>> protocolTypeMapContent = new HashMap<String, LinkedBlockingQueue<ReplyMessageContent>>();

	static {
		for (Map.Entry<String, String> entry : SystemConfigUtil.consumerMapReplyQueueName.entrySet()) {
			LinkedBlockingQueue<ReplyMessageContent> ReplyQueue = new LinkedBlockingQueue<ReplyMessageContent>();
			ReplyMessageThread.protocolTypeMapContent.put(entry.getValue(), ReplyQueue);
		}

	}

	/**
	 * @Title: ReplyMessageThread @Description: TODO @param @param
	 * service @throws
	 */
	public ReplyMessageThread(ExecutorService service) {
		super();
		this.service = service;
	}

	public void start(String conpanyName, Connection publisherConnection, MqConnectionDeclaration mqDeclaration) {
		for (int i = 0; i < mqDeclaration.getThreadSum(); i++) {
			try {
				ExecutePublisher publisher = new PublisherPool(publisherConnection.createChannel(),
						mqDeclaration.getExchangeName(), mqDeclaration.getRoutingKey(), mqDeclaration.getQueueName())
								.getPublisher();
				service.execute(new replyMessageRunnable(protocolTypeMapContent.get(conpanyName), publisher));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}

class replyMessageRunnable implements Runnable {

	private static final Logger log = LoggerFactory.getLogger(replyMessageRunnable.class);

	public final LinkedBlockingQueue<ReplyMessageContent> replyQueue;
	public final ExecutePublisher publisher;

	/**
	 * @Title: replyMessageRunnable @Description: TODO @param @param
	 * replyQueue @param @param publisher @throws
	 */
	public replyMessageRunnable(LinkedBlockingQueue<ReplyMessageContent> replyQueue, ExecutePublisher publisher) {
		super();
		this.replyQueue = replyQueue;
		this.publisher = publisher;
	}

	@Override
	public void run() {
		while (true) {
			ReplyMessageContent content;
			try {
				content = replyQueue.take();
				ArrayList<byte[]> contentMsg = content.getMsg();
				for (int i = 0; i < contentMsg.size(); i++) {
					if (contentMsg.get(i) != null) {
						publisher.publishMessage(content.getMsg().get(i));
						LogCenter.serverResponseLogger.log(content.getIemiCode(),
								BuildLogContent.buildServerReesponseContent(publisher.getExchange(),
										publisher.getRoutingkey(), content.getMsg().get(i), content.getProtocolName()));
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
				LogCenter.exception.error(" Exception occur when publishing message", e);
			} catch (IOException e) {
				e.printStackTrace();
				LogCenter.exception.error(" Exception occur when publishing message", e);
			}

		}

	}

}
