package com.kmhc.model.handler.impl.A10;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.kmhc.model.datacenter.dao.*;
import com.kmhc.model.datacenter.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.MessageBuilder;;

@MessageCommand(type = "A10", command = "0x414C")
public class SosGpsHandlerImpl extends AbstractParentHandlerA10 {
	private static final Logger log = LoggerFactory.getLogger(SosGpsHandlerImpl.class);
	private String type = "AL";
	private String head = "[3G";
	private String tail = "][2E 2E]";

	private EmgMMapper emgMMapper = SpringBeanFacotry.getInstance().getBean(EmgMMapper.class);
	private DeviceListMapper deviceListMapper = SpringBeanFacotry.getInstance().getBean(DeviceListMapper.class);
	private A10DeviceStatusMapper a10DeviceStatusMapper = SpringBeanFacotry.getInstance().getBean(A10DeviceStatusMapper.class);

	// private HaJiMemberManagerMapper haJiMemberManagerMapper =
	// SpringBeanFacotry.getInstance().getBean(HaJiMemberManagerMapper.class);
	// private HaJiMemberLocationMapper haJiMemberLocationMapper =
	// SpringBeanFacotry.getInstance().getBean(HaJiMemberLocationMapper.class);

	public SosGpsHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg, type);
		// 9403094122*00CD*AL,180916,025723,A,22.570733,N,113.8626083,E,0.00,249.5,0.0,6,100,60,0,0,00000010,7,255,460,1,9529,21809,158,9529,63555,133,9529,63554,129,9529,21405,126,9529,21242,124,9529,21151,120,9529,63556,119,0,40.7
		log.info(new String(msg));
		String function = "AL";
		String content[] = new String(msg).split(",");
		String timeStr = content[1] + content[2];
		String sn = content[0].substring(0, content[0].indexOf("*"));
		DeviceList deviceList = deviceListMapper.selectBySn(sn);
		String imei = deviceList.getImei();
		String tzStr = "GMT";
		String lng = content[6];
		String lat = content[4];
		String power = content[13];
		A10DeviceStatus a10DeviceStatus = new A10DeviceStatus();

		Date dt = com.kmhc.model.util.Date.getDate(timeStr, "ddMMyyHHmmss", tzStr);
		log.debug("===={}====", sdf.format(dt));
		EmgM emgm = new EmgM();
		Date nowDate = new Date();
		emgm.setImei(imei);
		emgm.setEmgDate(dt);
		emgm.setEmgKey(yyMMddHHmmss.format(new Date()));
		emgm.setEmgDetailKey(emgm.getEmgKey() + emgm.getImei());
		emgm.setCreateDate(nowDate);
		emgm.setUpdateDate(nowDate);

		a10DeviceStatus.setLbsTime(dt);
		a10DeviceStatus.setPower(power);
		Gps gps = null;
		List<Cell> cells = null;
		cells = paresLBS(Arrays.copyOfRange(content, 17, content.length));
		Cell cell = cells.get(0);
		setCell(emgm, cell);
		emgm.setCell(cell);
		emgm.setCells(cells);
		emgm.setType(function);

		if (content[3].equals("A")) {
			gps = new Gps(new BigDecimal(lat).setScale(10, BigDecimal.ROUND_HALF_UP), new BigDecimal(lng).setScale(10, BigDecimal.ROUND_HALF_UP), "N", "E", "Y");
			gps = LocUtil.conver(gps);
			String reverseGeocoding = LocUtil.reverseGeocoding(gps.getLat(), gps.getLng());
			if (reverseGeocoding == null) {
				reverseGeocoding = "";
			}
			gps.setAddress(reverseGeocoding);
			a10DeviceStatus.setAddress(reverseGeocoding);
			a10DeviceStatus.setLatitude(new BigDecimal(lat));
			a10DeviceStatus.setLongitude(new BigDecimal(lng));
			a10DeviceStatus.setLocMode("G");
			emgm = setGPSResult(emgm, gps.getLat(), gps.getLng(), reverseGeocoding);
			emgm.setLocType("GPS");

		} else {
			LocResult locresult = LocUtil.loc(emgm.getImei(), null, cell, cells, null);
			emgm.setType(function);
			emgm = setLocResult(emgm, locresult);
			emgm.setLocType("LBS");

			a10DeviceStatus.setAddress(emgm.getAddress());
			a10DeviceStatus.setLatitude(emgm.getGpsLat());
			a10DeviceStatus.setLongitude(emgm.getGpsLng());
			a10DeviceStatus.setLocMode("C");
			if (emgm.getCells() != null && emgm.getCells().size() > 0) {
				List<EmgI> emgIList = getEmgIList(emgm.getCells(), emgm.getEmgDetailKey(), emgm.getCreateDate(), emgm.getUpdateDate());
				EmgIMapper emgIMapper = (EmgIMapper) SpringBeanFacotry.getInstance().getBean("emgIMapper");
				emgIMapper.insertList(emgIList);
			}
		}
		if (emgMMapper.selectByPrimaryKey(emgm.getEmgKey(), emgm.getImei()) != null) {
			emgMMapper.updateByPrimaryKey(emgm);
		} else {
			emgMMapper.insertSelective(emgm);
		}

		/*
		 * 左边高16bit表示报警,右边低16bit表示状态. 0000 0000 0000 0000 0000 0000 0000 0000
		 * 含义如下: Bit位(0开始) 含义(1有效) 0 -低电状态,1-出围栏状态,2
		 * -进围栏状态,3-手环戴上取下状态,4-手表运行静止状态 16-SOS报警,17-低电报警,18-出围栏报警,19 - 进围栏报警,
		 * 20-手环拆除报警.
		 */
		byte[] bty = TripleDesHelper.hex2byte(content[16]);
		if ((bty[1] & 0x01) == 0x01) {
			emgm.setType("A10SOS");
			sendNotification(emgm, "A10", null);
		}
		if ((bty[1] & 0x02) == 0x02) {

		}
		if ((bty[1] & 0x04) == 0x04) {

		}
		if ((bty[1] & 0x08) == 0x08) {

		}
		if ((bty[1] & 0x10) == 0x10) {

		}

		a10DeviceStatus = getA10DeviceStatus(a10DeviceStatus, bty);
		A10DeviceStatus a10 = a10DeviceStatusMapper.selectByImei(imei);
		a10DeviceStatus.setImei(imei);
		if (a10 != null) {
			if (a10DeviceStatus.getLbsTime().getTime() >= a10.getLbsTime().getTime()) {
				a10DeviceStatus.setNo(a10.getNo());
				a10DeviceStatus.setUpdateTime(new Date());
				a10DeviceStatusMapper.updateByPrimaryKeySelective(a10DeviceStatus);
			}

		} else {
			a10DeviceStatusMapper.insertSelective(a10DeviceStatus);
		}

		/*
		 * HaJiMemberManager hmm = haJiMemberManagerMapper.selectByImei(imei);
		 * if (hmm != null && emgm.getLocStatus().equals("Y") &&
		 * emgm.getIsvalid().equals("Y")) { HaJiMemberLocation hml = new
		 * HaJiMemberLocation(); hml.setMemberId(hmm.getId());
		 * hml.setLbsKey(emgm.getEmgKey()); hml.setLbsno(0); hml.setImei(imei);
		 * hml.setType(type); hml.setLbsDetailKey(emgm.getEmgDetailKey());
		 * hml.setLbsDate(emgm.getEmgDate());
		 * hml.setLat(a10DeviceStatus.getLatitude());
		 * hml.setLng(a10DeviceStatus.getLongitude());
		 * hml.setAddress(a10DeviceStatus.getAddress());
		 * hml.setHpe(emgm.getHpe()); if (content[3].equals("A"))
		 * hml.setLocMethod("G"); else hml.setLocMethod("C");
		 * hml.setIsvalid("Y"); haJiMemberLocationMapper.insertSelective(hml); }
		 */

		// sendNotification(emgm,"A10",null);
		dt = new Date();
		String out[] = { sn, getLengh(function.length()), function, tail + head, sn, getLengh("UPLOAD".length()), "UPLOAD" + ",60" };
		// [3G*8800000015*0002*AL]
		// [V1.0.0,zu1jgjwp80veawu,1,abcd,2011-12-15
		// 10:00:00,356511170035899,S86]
		return MessageBuilder.buildReplyMessageContent(TripleDesHelper.hex2byte(sn + "0"), generateResponse(out));
	}

	private EmgM setLocResult(EmgM emgm, LocResult locresult) {
		if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {
			emgm.setIsvalid("Y");
			emgm.setLocStatus("Y");
			emgm.setMcellStatus("Y");
			emgm.setWifiStatus("Y");
			LocDetailResult result = locresult.getResult();
			String[] lngLat = result.getLocation().split(",");
			BigDecimal lng = new BigDecimal(lngLat[0].length() > 10 ? lngLat[0].substring(0, 10) : lngLat[0]);
			BigDecimal lat = new BigDecimal(lngLat[1].length() > 10 ? lngLat[1].substring(0, 10) : lngLat[1]);
			emgm.setGpsLng(lng);
			emgm.setGpsLat(lat);
			emgm.setAddress(result.getDesc());
			emgm.setGpsNsLat("N");
			emgm.setGpsEwLng("E");
			emgm.setMcellLat(lat);
			emgm.setMcellLng(lng);
			emgm.setWifiLat(lat);
			emgm.setWifiLng(lng);
			emgm.setWifiAddress(result.getDesc());
			emgm.setMcellAddress(result.getDesc());
			emgm.setHpe((double) result.getRadius());
		} else {
			if (locresult != null) {
				log.info("【type=A10,command={AL}】定位失败，status:{},info:{},result.type:{}", "AL", locresult.getStatus(), locresult.getInfo(), locresult.getResult() == null ? "" : locresult.getResult().getType());
			} else {
				log.info("【type=A10,command={AL}】定位结果返回NULL", "AL");
			}
		}
		return emgm;
	}

	private EmgM setGPSResult(EmgM emgm, BigDecimal lat, BigDecimal lng, String address) {
		emgm.setIsvalid("Y");
		emgm.setLocStatus("Y");
		emgm.setMcellStatus("Y");
		emgm.setWifiStatus("Y");
		emgm.setGpsLng(lng);
		emgm.setGpsLat(lat);
		emgm.setAddress(address);
		emgm.setGpsNsLat("N");
		emgm.setGpsEwLng("E");
		emgm.setMcellLat(lat);
		emgm.setMcellLng(lng);
		emgm.setWifiLat(lat);
		emgm.setWifiLng(lng);
		emgm.setWifiAddress(address);
		emgm.setMcellAddress(address);
		return emgm;
	}

	@Override
	public boolean handleMessage(String json) {

		return true;
	}

	/*
	 * private List<Cell> paresLBS(String msg[]) { // (1)当3种定位数据都有时： //
	 * LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#
	 * 2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13, //
	 * WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-
	 * EDU|5c:63:bf:a4:bf:56$-27$CMCC&,
	 * 
	 * // (2)当只有lbs定位数据时: //
	 * LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#
	 * 2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
	 * 
	 * // (3)当上传lbs数据和gps数据时: //
	 * LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#
	 * 2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
	 * 
	 * // (4)当上传lbs数据和wifi定位数据时: //
	 * LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#
	 * 2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13, //
	 * WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-
	 * EDU|5c:63:bf:a4:bf:56$-27$CMCC&,
	 * //7,255,460,1,9529,21809,158,9529,63555,133,9529,63554,129,9529,21405,126
	 * ,9529,21242,124,9529,21151,120,9529,63556,119,0,40.7
	 * 
	 * 
	 * List<Cell> cells = new ArrayList<Cell>();
	 * 
	 * int cellCount = Integer.valueOf(msg[0]); String mcc = msg[2]; String mnc
	 * = msg[3];
	 * 
	 * for (int i = 1; i <= cellCount; i++) { Cell cell = new Cell();
	 * cell.setMcc(mcc); cell.setMnc(mnc); int x = 3*(i-1)+4; int y = 3*(i-1)+5;
	 * int z = 3*(i-1)+6; cell.setLac((msg[x]));
	 * cell.setCellid(Integer.parseInt(msg[y])); // String arfcn = tmp[2];
	 * cell.setRssi(Short.parseShort(msg[z])); cells.add(cell); } //A10 无WiFi定位
	 * return cells; }
	 */

}
