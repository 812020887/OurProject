package com.kmhc.model.handler.impl.A10;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.datacenter.dao.A10DeviceSettingMapper;
import com.kmhc.model.datacenter.dao.A10DeviceStatusMapper;
import com.kmhc.model.datacenter.dao.DeviceListMapper;
import com.kmhc.model.datacenter.dao.ServerActionHisMapper;
import com.kmhc.model.datacenter.model.A10DeviceSetting;
import com.kmhc.model.datacenter.model.A10DeviceStatus;
import com.kmhc.model.datacenter.model.DeviceList;
import com.kmhc.model.datacenter.model.ServerActionHis;
import com.kmhc.model.handler.impl.km8020.BodySettingHandlerImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.handler.impl.PushAlert;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.Publish;

public class BaseReplyA10 extends AbstractParentHandlerA10  {

	private A10DeviceSettingMapper a10DeviceSettingMapper = SpringBeanFacotry.getInstance().getBean(A10DeviceSettingMapper.class);
	private A10DeviceStatusMapper a10DeviceStatusMapper = SpringBeanFacotry.getInstance().getBean(A10DeviceStatusMapper.class);
	private ServerActionHisMapper serverActionHisMapper = SpringBeanFacotry.getInstance().getBean(ServerActionHisMapper.class);
	private DeviceListMapper deviceListMapper = SpringBeanFacotry.getInstance().getBean(DeviceListMapper.class);
	private static final Logger log = LoggerFactory.getLogger(BaseReplyA10.class);
	private final String function;


	public BaseReplyA10(String function) {
		super(log);
		this.function = function;
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		//9403094122*00CD*UD,180916,025723,A,22.570733,N,113.8626083,E,0.00,249.5,0.0,6,100,60,0,0,00000010,7,255,460,1,9529,21809,158,9529,63555,133,9529,63554,129,9529,21405,126,9529,21242,124,9529,21151,120,9529,63556,119,0,40.7
	    log.info("======A10==={}==========",new String(msg));
		String function = this.function;
		String content[] = new String(msg).split(",");
		String sn = content[0].substring(0, content[0].indexOf("*"));
		DeviceList deviceList = deviceListMapper.selectBySn(sn);
		String imei = deviceList.getImei();
		String out[] = {sn,getLengh(function.length()), function };
		//[3G*8800000015*0002*AL]
		//[V1.0.0,zu1jgjwp80veawu,1,abcd,2011-12-15 10:00:00,356511170035899,S86]

		if(function.startsWith("SOS") || function.equals("UPLOAD")|| function.equals("STANDBY")){
			boolean insert = false;
			A10DeviceSetting deviceSetting = a10DeviceSettingMapper.selectByImei(imei);
			if(deviceSetting == null){
				deviceSetting = new A10DeviceSetting();
				deviceSetting.setImei(imei);
				insert = true;
			}

			if(function.startsWith("SOS")) {
				ServerActionHis sah = serverActionHisMapper.selectByImeiAndType(imei, "SOS");
				JSONObject json = JSONObject.parseObject(sah.getContent());
				deviceSetting.setSos1(json.getString("sos1"));
				deviceSetting.setSos2(json.getString("sos2"));
				deviceSetting.setSos3(json.getString("sos3"));
				sah.setFinished(sah.getFinished() + 1);
				if(sah.getFinished() >= 3 ){
					serverActionHisMapper.deleteByImemAndType(imei, "SOS");
				}else {
					serverActionHisMapper.updateByPrimaryKey(sah);
				}
//				if(	deviceSetting.getSos1().equals(json.getString("sos1")) &&
//					deviceSetting.getSos2().equals(json.getString("sos2")) &&
//					deviceSetting.getSos3().equals(json.getString("sos3"))){
//					serverActionHisMapper.deleteByImemAndType(imei, "SOS");
//				}

			}else if(function.equals("UPLOAD")){
				ServerActionHis sah = serverActionHisMapper.selectByImeiAndType(imei, "UPLOAD");
				JSONObject json = JSONObject.parseObject(sah.getContent());
				if (function.equals("UPLOAD")) deviceSetting.setUploadTime(json.getString("uploadTime"));
				serverActionHisMapper.deleteByImemAndType(imei, "UPLOAD");
			}else if(function.equals("STANDBY")){
				
				ServerActionHis sah = serverActionHisMapper.selectByImeiAndType(imei, "STANDBY");
				 log.info("=======ServerActionHis=={}==========",JSON.toJSONString(sah));
				if(sah!=null){
				    //JSONObject json = JSONObject.parseObject(sah.getContent());
					if (function.equals("STANDBY")) {
						A10DeviceStatus a10DeviceStatus = a10DeviceStatusMapper.selectByImei(imei);
						if(a10DeviceStatus!=null){
							a10DeviceStatus.setStandbyStauts(1);
							a10DeviceStatus.setImei(imei);
							a10DeviceStatusMapper.updateByPrimaryKeySelective(a10DeviceStatus);
						}else{
							A10DeviceStatus	aStatus =new A10DeviceStatus();
							aStatus.setCreateTime(new Date());
							aStatus.setStandbyStauts(1);
							aStatus.setImei(imei);
				            a10DeviceStatusMapper.insertSelective(aStatus);
						}
					}
					serverActionHisMapper.deleteByImemAndType(imei, "STANDBY");
					//pushA10SettingFinish(imei,INotification.NOTIFICATION_TYPE_SETTING_STANDBY);
				}

			}
			deviceSetting.setUpdateTime(new Date());
			if (insert) a10DeviceSettingMapper.insertSelective(deviceSetting);
			else a10DeviceSettingMapper.updateByPrimaryKeySelective(deviceSetting);

		}

		String[] orders = {"UPLOAD", "CENTER", "MONITOR","SOS","FACTORY","LZ","RESET","CR","STANDBY"};
		boolean flag = true;
		for(int i=0;i<orders.length;i++){
			if(function.contains(orders[i])){
				flag= false;
			}
		}
		if(flag){
			return MessageBuilder.buildReplyMessageContent(TripleDesHelper.hex2byte(sn + "0"), generateResponse(out));
		}else{
			return null;
		}

	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
