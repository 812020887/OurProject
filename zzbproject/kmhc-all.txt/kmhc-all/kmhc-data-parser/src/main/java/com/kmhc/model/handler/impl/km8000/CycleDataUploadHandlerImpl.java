/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月25日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8000;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.ConvertionUtil;
import com.kmhc.framework.util.TimeUtil;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.AreaidVMapper;
import com.kmhc.model.datacenter.dao.DeviceSettingGfenceSpMapper;
import com.kmhc.model.datacenter.dao.MemberMapper;
import com.kmhc.model.datacenter.dao.PerWeatherMapper;
import com.kmhc.model.datacenter.dao.PrIMapper;
import com.kmhc.model.datacenter.dao.ProductPerSettingMMapper;
import com.kmhc.model.datacenter.dao.ProductSysSettingMMapper;
import com.kmhc.model.datacenter.model.AreaidV;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.DeviceSettingGfenceSp;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.PerWeather;
import com.kmhc.model.datacenter.model.PrI;
import com.kmhc.model.datacenter.model.ProductPerSettingM;
import com.kmhc.model.datacenter.model.ProductSysSettingM;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.datacenter.pojo.GPS;
import com.kmhc.model.datacenter.pojo.PacketTypePRWifi;
import com.kmhc.model.datacenter.pojo.PeriodicReadingsWifi;
import com.kmhc.model.datacenter.pojo.WiFi;
import com.kmhc.model.datacenter.service.IBasicService;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.handler.impl.PushAlert;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.pojo.BufferTypeSystemSetup;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.pojo.SystemSetupBuildPackage;
import com.kmhc.model.pojo.SystemSetup_View;
import com.kmhc.model.pojo.WeatherDeclaration;
import com.kmhc.model.pojo.YahooWeatherResult;
import com.kmhc.model.runnable.WeatherAPICatchTimer;
import com.kmhc.model.util.HttpClientUtils;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.LogCenter;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.Publish;
import com.kmhc.model.util.SystemConfigUtil;
import com.kmhc.model.util.WeatherKeyEncode;
import com.kmhc.model.util.WeatherUtil;

/**
 * Name: CycleDataUploadHandlerImpl.java ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8000.CycleDataUploadHandlerImpl.java]
 * Description: TODO
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月25日 下午4:21:36
 *
 *        Update-User: @author Update-Time: Update-Remark:
 * 
 *        Check-User: Check-Time: Check-Remark:
 * 
 *        Company: kmhc Copyright: kmhc
 */
@MessageCommand(type = "KM8000", command = "0x03")
public class CycleDataUploadHandlerImpl extends AbstractHandler {

	static byte[] ACK7f_4B = {
			/* 2, 85, -86, */
			0, 11, 127, 1, 75,
			/*-86, 85, 3*/ };

	private ProductSysSettingMMapper productSysSettingMMapper = (ProductSysSettingMMapper) SpringBeanFacotry
			.getInstance().getBean("productSysSettingMMapper");
	private ProductPerSettingMMapper productPerSettingMMapper = (ProductPerSettingMMapper) SpringBeanFacotry
			.getInstance().getBean("productPerSettingMMapper");
	private IBasicService basicService = (IBasicService) SpringBeanFacotry.getInstance().getBean("basicServiceImpl");
	private PerWeatherMapper perWeatherMapper = (PerWeatherMapper) SpringBeanFacotry.getInstance()
			.getBean("perWeatherMapper");
	private MemberMapper memberMapper = (MemberMapper) SpringBeanFacotry.getInstance().getBean("memberMapper");
	private PrIMapper priMapper = (PrIMapper) SpringBeanFacotry.getInstance().getBean("prIMapper");
	private AreaidVMapper areaidVMapper = (AreaidVMapper) SpringBeanFacotry.getInstance().getBean("areaidVMapper");

    private DeviceSettingGfenceSpMapper dsgsMapper = (DeviceSettingGfenceSpMapper) SpringBeanFacotry.getInstance().getBean("deviceSettingGfenceSpMapper");

	private static final Logger log = LoggerFactory.getLogger(CycleDataUploadHandlerImpl.class);

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		byte[] imeiCode = parseImeiOrImsiBytes_KM8000(msg, 0);
		String imeiCodeStr = parseImeiOrImsi_KM8000(msg, 0);
		String imsiCodeStr = parseImeiOrImsi_KM8000(msg, 8);
		ArrayList<byte[]> replyMessages = new ArrayList<byte[]>();
		try {
			PacketTypePRWifi prWifi = new PacketTypePRWifi(msg, imeiCodeStr, imsiCodeStr);
			ProductPerSettingM perSetting = productPerSettingMMapper.selectByPrimaryKey(imeiCodeStr);
			ProductSysSettingM sysSetting = productSysSettingMMapper.selectByPrimaryKey(imeiCodeStr);
			boolean isSysSettingChange = false;
			boolean isPerSettingChange = false;

			push(prWifi.getImei(), prWifi.isLowBattery());

			if (perSetting != null)
				if (prWifi.getChecksumPER() != perSetting.getChecksum())
					isPerSettingChange = true;

			if (sysSetting != null)
				if (prWifi.getChecksumSYS() != sysSetting.getChecksumS())
					isSysSettingChange = true;

			/*---------TODO 手表设定和系统设定 后期在做---------*/

			if (isSysSettingChange) {
				BufferTypeSystemSetup setup = new BufferTypeSystemSetup(SystemSetup_View.build(sysSetting));
				replyMessages.add(setup.getByteBuffer());
			}

			if (isPerSettingChange) {
				// BufferTypeSystemSetup setup = new
				// BufferTypeSystemSetup(SystemSetup_View.build(perSetting));
				// replyMessages.add(setup.getByteBuffer());
				replyMessages.add(new SystemSetupBuildPackage().build(perSetting));
			}

			com.kmhc.model.datacenter.pojo.PersonalSetup_View perSetup = memberMapper.getMemberFamilyPhoto(imeiCodeStr);
			if (perSetup != null) {
				boolean sendStatus = true;
				if (perSetup.getImei().equals(perSetting.getImei())) {
					if (perSetup.getFamilyPic_status1() != 1)
						if (perSetup.getFamilyPic_status2() != 1)
							if (perSetup.getFamilyPic_status3() != 1)
								sendStatus = false;
					if (sendStatus)
						replyMessages.add(ACK7f_4B);
				}

			}

			/*---------TODO 手表设定和系统设定 后期在做---------*/

			ArrayList<PrI> prIs = new ArrayList<PrI>();
			for (int i = 0; i < prWifi.getPrList().size(); ++i) {// 根据协议prWifi是不可以为空的，通过这种方式获取地址信息十分垃圾而又无可奈何

				PeriodicReadingsWifi pr = (PeriodicReadingsWifi) prWifi.getPrList().get(i);

				ArrayList<Cell> cells = new ArrayList<Cell>();
				for (int j = 0; pr.getEffectiveCellID() != null && j < pr.getEffectiveCellID().size(); j++) {
					Cell cell = new Cell();
					com.kmhc.model.datacenter.pojo.Cell temp = pr.getEffectiveCellID().get(j);

					cell.setCellid(temp.getCellid());
					cell.setLac(String.valueOf(temp.getLac()));
					cell.setMcc(String.valueOf(temp.getMcc()));
					cell.setMnc(String.valueOf(temp.getMnc()));
					cell.setRssi((short) (0xFF & temp.getRssi()));

					cells.add(cell);

				}

				ArrayList<Wifi> wifis = new ArrayList<Wifi>();
				for (int j = 0; pr.getEffectiveWifi() != null && j < pr.getEffectiveWifi().size(); j++) {
					Wifi wifi = new Wifi();

					WiFi temp = pr.getEffectiveWifi().get(j);

					wifi.setWifiChannel((short) temp.getChannel());
					wifi.setWifiMac(temp.getMac());
					wifi.setWifiRatio((short) temp.getSignal_dB());
					wifi.setWifiSignal((short) temp.getSignalLevel());

					wifis.add(wifi);

				}

				Cell cell = new Cell();
				com.kmhc.model.datacenter.pojo.Cell temp = pr.getCellID();
				cell.setCellid(temp.getCellid());
				cell.setLac(String.valueOf(temp.getLac()));
				cell.setMcc(String.valueOf(temp.getMcc()));
				cell.setMnc(String.valueOf(temp.getMnc()));
				cell.setRssi(temp.getRssi());

				GPS gps = pr.getGps();

				PrI pri = new PrI();

				LocResult locresult = null;
				if (gps.getLat() == 0.0 || gps.getLng() == 0.0 || !"NS".contains(gps.getLatDispStr())
						|| !"WE".contains(gps.getLngDispStr())) {
					locresult = LocUtil.loc(prWifi.getImei(), prWifi.getImsi(), cell, cells, wifis);

					if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {

						pri.setIsvalid("Y");
						pri.setLocStatus("Y");
						pri.setMcellStatus("Y");

						LocDetailResult result = locresult.getResult();
						String[] lngLat = result.getLocation().split(",");
						BigDecimal lng = new BigDecimal(lngLat[0]).setScale(6, RoundingMode.HALF_EVEN);
						BigDecimal lat = new BigDecimal(lngLat[1]).setScale(6, RoundingMode.HALF_EVEN);
						String address = LocUtil.reverseGeocoding(lat, lng);
						pri.setGpsLng(lng);
						pri.setGpsLat(lat);
						pri.setAddress(address);
						pri.setGpsNsLat("N");
						pri.setGpsEwLng("E");
						pri.setMcellLat(lat);
						pri.setMcellLng(lng);
						pri.setWifiLat(lat);
						pri.setWifiLng(lng);
						pri.setWifiAddress(address);
						pri.setMcellAddress(address);
						pri.setHpe((double) result.getRadius());
					} else {
						if (locresult != null) {
							log.info("【type=KM8000,command=0x{}】定位失败，status:{},info:{},result.type:{}", "03",
									locresult.getStatus(), locresult.getInfo(),
									locresult.getResult() == null ? "" : locresult.getResult().getType());
						} else {
							log.info("【type=KM8000,command=0x{}】定位结果返回NULL", "03");
						}
					}

				} else {
					com.kmhc.model.datacenter.model.Gps tempGps = new com.kmhc.model.datacenter.model.Gps(gps.getLat(),
							gps.getLng(), gps.getLatDispStr(), gps.getLngDispStr(), "Y");

					pri.setIsvalid("Y");
					pri.setLocStatus("Y");
					pri.setMcellStatus("Y");

					LocUtil.conver(tempGps);
					String address = LocUtil.reverseGeocoding(tempGps.getLat(), tempGps.getLng());

					String tempLng = tempGps.getLng().toString();
					String tempLat = tempGps.getLat().toString();

					BigDecimal lng = new BigDecimal(tempLng).setScale(6, RoundingMode.HALF_EVEN);
					BigDecimal lat = new BigDecimal(tempLat).setScale(6, RoundingMode.HALF_EVEN);
					pri.setGpsLng(lng);
					pri.setGpsLat(lat);

					pri.setGpsNsLat("N");
					pri.setGpsEwLng("E");
					pri.setMcellLat(lat);
					pri.setMcellLng(lng);
					pri.setWifiLat(lat);
					pri.setWifiLng(lng);

					if (address != null) {
						pri.setAddress(address);
						pri.setWifiAddress(address);
						pri.setMcellAddress(address);
					}
					pri.setHpe(10.0);
				}

				prIs.add(pri);
				push8000Gps(imeiCodeStr,"KM8000","0x03");
//				if(pri != null){
//					DeviceSettingGfenceSp dsg = dsgsMapper.selectByPrimaryKey(pri.getImei());
//					if(dsg != null && dsg.getEnable() == 1){
//						requestGFenceNotice(pri.getImei(),pri.getGpsLat(),pri.getGpsLng(),pri.getHpe());	
//					}
//				}
			}
			boolean result = basicService.saveCycleData(prWifi, false, prIs);

			/** 更新天气,非事务方法，以后需要改进 ******************************/

			refreshWeather(prWifi.getBatchKey());

			/*************************************/

			if (result) {
				PerWeather perWeather = perWeatherMapper.selectByPrimaryKey(imeiCodeStr);
				Date currentDate = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
				String dateStr = sdf.format(currentDate);
				String dateGMT = dateStr.substring(0, 10);
				byte[] ACK7f_00 = { 0, 22, 0, 7, -35, 10, 5, 2, 35, 48, -16, 9, 50, 26, 28, 8, };
				if (perWeather != null) {

					String yy = perWeather.getReportGmtTime();
					if (yy.length() != 8) {
						yy = "12:01 AM";
					}
					String hh = yy.substring(0, 2);
					String mm = yy.substring(3, 5);
					String ampm = yy.substring(6, 8);
					int intHH = Integer.valueOf(hh).intValue();
					if (ampm.equals("PM")) {
						if (intHH <= 11) {
							intHH += 12;
							hh = Integer.toString(intHH);
						}
					}
					if (ampm.equals("AM")) {
						if (intHH == 12) {
							intHH = 0;
							hh = "00";
						}
					}
					dateStr = dateGMT + " " + hh + ":" + mm + ":00";
					int dataTimeStr = Integer.parseInt(dateStr.substring(0, 4));

					ACK7f_00[3] = (byte) (dataTimeStr >> 8 & 0xFF);
					ACK7f_00[4] = (byte) (dataTimeStr & 0xFF);
					ACK7f_00[5] = (byte) Integer.parseInt(dateStr.substring(5, 7));
					ACK7f_00[6] = (byte) Integer.parseInt(dateStr.substring(8, 10));
					ACK7f_00[7] = (byte) Integer.parseInt(dateStr.substring(11, 13));
					ACK7f_00[8] = (byte) Integer.parseInt(dateStr.substring(14, 16));
					ACK7f_00[9] = (byte) Integer.parseInt(dateStr.substring(17, 19));
					/*
					 * ACK7f_00[10] =
					 * ConvertionUtil.shortToByteArray(perWeather.getDtatmap())[
					 * 0]; ACK7f_00[11] =
					 * ConvertionUtil.shortToByteArray(perWeather.getB7())[0];
					 * ACK7f_00[12] =
					 * ConvertionUtil.shortToByteArray(perWeather.getB6())[0];
					 * ACK7f_00[13] =
					 * ConvertionUtil.shortToByteArray(perWeather.getB5L())[0];
					 * ACK7f_00[14] =
					 * ConvertionUtil.shortToByteArray(perWeather.getB5H())[0];
					 * ACK7f_00[15] =
					 * ConvertionUtil.shortToByteArray(perWeather.getB4())[0];
					 */

					ACK7f_00[10] = ConvertionUtil.shortToByteArray(perWeather.getDtatmap())[1];
					ACK7f_00[11] = ConvertionUtil.shortToByteArray(perWeather.getB7())[1];
					ACK7f_00[12] = ConvertionUtil.shortToByteArray(perWeather.getB6())[1];
					ACK7f_00[13] = ConvertionUtil.shortToByteArray(perWeather.getB5L())[1];
					ACK7f_00[14] = ConvertionUtil.shortToByteArray(perWeather.getB5H())[1];
					ACK7f_00[15] = ConvertionUtil.shortToByteArray(perWeather.getB4())[1];

				} else {
					int dataTimeStr = Integer.parseInt(dateStr.substring(0, 4));
					ACK7f_00[6] = (byte) (dataTimeStr >> 8 & 0xFF);
					ACK7f_00[7] = (byte) (dataTimeStr & 0xFF);
					ACK7f_00[8] = (byte) Integer.parseInt(dateStr.substring(5, 7));
					ACK7f_00[9] = (byte) Integer.parseInt(dateStr.substring(8, 10));
					ACK7f_00[10] = (byte) Integer.parseInt(dateStr.substring(11, 13));
					ACK7f_00[11] = (byte) Integer.parseInt(dateStr.substring(14, 16));
					ACK7f_00[12] = (byte) Integer.parseInt(dateStr.substring(17, 19));
				}
				replyMessages.add(ACK7f_00);
				return MessageBuilder.buildReplyMessageContent(imeiCode, replyMessages);
			} else {
				replyMessages.add(ACK_ERROR_KM8000);
				return MessageBuilder.buildReplyMessageContent(imeiCode, replyMessages);
			}

		} catch (Exception e) {
			LogCenter.exception.error("", e);
			replyMessages.add(ACK_ERROR_KM8000);
			return MessageBuilder.buildReplyMessageContent(imeiCode, replyMessages);
		}

	}

	/**
	 * 更新天气api
	 */
	private void refreshWeather(String batchKey) {

		SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHss");

		List<PrI> prIs = priMapper.getPsrIByBatchKey(batchKey);
		if (prIs != null) {
			for (PrI p : prIs) {
				if( p != null){
					DeviceSettingGfenceSp dsg = dsgsMapper.selectByPrimaryKey(p.getImei());
					if(dsg != null && dsg.getEnable() == 1){
						requestGFenceNotice(p.getImei(),p.getGpsLat(),p.getGpsLng(),p.getHpe(),"KM8000");	
					}
				}
				try {
					if (p.getAddress() == null || "".equals(p.getAddress()))
						continue;

					PerWeather pw = new PerWeather();
					String address = p.getAddress();
					String tempH = "";
					String tempL = "";
					String weatherCode = "";
					int tempC = 0;
					if (SystemConfigUtil.foreign.equals("false")) {
						// log.debug("===============openWeatherCN==============");
						int provIndex = address.indexOf("省");
						int cityIndex = address.indexOf("市");
						int areaIndex = address.indexOf("区");
						String district4Precision = null; // NAMECN
						String city4Precision = null; // DISTRICTCN

						/* Author PCL */
						/****
						 * BUG修復 修正某些地區地址中沒有 "省" EX:广西壮族自治区 南宁市 青秀区 英华路
						 * 靠近昊壮一品尊府居住小区4期
						 *******/
						/**** 北京市 西城区 前门西河沿街 靠近北京第一实验小学前门分校 ****/
						/**** 广东省深圳市福田区下梅林一街9号 ****/
						/* work around solution 字串解析不確定性太高了 */
						log.debug(address);
						// if( provIndex != -1 && areaIndex != -1 && cityIndex
						// != -1){
						// if( provIndex < cityIndex && provIndex < areaIndex &&
						// cityIndex < areaIndex ){
						// district4Precision = address.substring(cityIndex + 1,
						// areaIndex).trim();
						// city4Precision = address.substring(provIndex + 1,
						// cityIndex).trim();
						// }
						// }else if( areaIndex != -1 && cityIndex != -1 ){
						// if(areaIndex > cityIndex){
						// district4Precision = address.substring(0,
						// cityIndex).trim();
						// city4Precision = district4Precision;
						// }else{
						// int areaIndex2 = address.indexOf("区", areaIndex + 1
						// );
						// if( areaIndex2 != -1)
						// district4Precision = address.substring(cityIndex + 1,
						// areaIndex2).trim();
						// city4Precision = address.substring(areaIndex + 1,
						// cityIndex).trim();
						//
						// }
						// }else if ( cityIndex != -1 ){
						// district4Precision = address.substring(0,
						// cityIndex).trim();
						// city4Precision = district4Precision;
						// }

						if (areaIndex != -1) {
							if (areaIndex > cityIndex)
								district4Precision = address.substring(cityIndex + 1, areaIndex).trim();
							else {
								int areaIndex2 = address.indexOf("区", areaIndex + 1);
								district4Precision = address.substring(cityIndex + 1, areaIndex2).trim();
							}
						}

						if (cityIndex != -1) {
							if (provIndex != -1)
								city4Precision = address.substring(provIndex + 1, cityIndex).trim();
							else if (areaIndex < cityIndex)
								city4Precision = address.substring(areaIndex + 1, cityIndex).trim();
							else
								city4Precision = address.substring(0, cityIndex).trim();
						}
						/********************************************************************************/
						HashMap<String, String> words = new HashMap<String, String>();
						words.put("areaName", district4Precision);
						words.put("cityName", city4Precision);

						List<AreaidV> areaidVs = areaidVMapper.selectByAreaName(words);

						if (areaidVs.size() == 0) {
							areaidVs = areaidVMapper.selectByAreaCityName(city4Precision);
						}

						if (areaidVs != null && areaidVs.size() > 0) {
							AreaidV areaidV = areaidVs.get(0);
							String date = sf.format(new Date());
							String publicKey = WeatherAPICatchTimer.combineWeatherUrl(SystemConfigUtil.weatherKeyUrl,
									areaidV.getAreaid(), SystemConfigUtil.weatherAppid, date);
							String key = WeatherKeyEncode.standardURLEncoder(publicKey,
									SystemConfigUtil.weatherPrivateKey);
							String weatherUrl = WeatherAPICatchTimer.combineWeatherUrl(SystemConfigUtil.weatherUrl,
									areaidV.getAreaid(), SystemConfigUtil.weatherAppid.substring(0, 6), date) + "&key="
									+ key;
							String weatherDetail = HttpClientUtils.request(weatherUrl);

							try {

								JSONObject baseWeatherObj = JSONObject.parseObject(weatherDetail);
								// log.debug(baseWeatherObj.toJSONString());
								JSONObject f = baseWeatherObj.getJSONObject("f");
								JSONArray f1 = f.getJSONArray("f1");
								JSONObject weatherDate = f1.getJSONObject(0);
								tempH = weatherDate.getString("fc");
								tempL = weatherDate.getString("fd");
								weatherCode = "";

								if (!"".equals(tempH)) {
									tempC += Integer.parseInt(tempH);
									pw.setB5H(Short.valueOf(tempH));
									weatherCode = weatherDate.getString("fa");
								} 
								if (!"".equals(tempL)) {
									tempC += Integer.parseInt(tempL);
									pw.setB5L(Short.valueOf(tempL));
									weatherCode = weatherDate.getString("fb");
								}
								tempC = tempC/2;

							} catch (Exception e) {
								LogCenter.exception.error("", e);
								continue;
							}
						}
					} else {
						// log.debug("===============YahooWeatherResult==============");
						Gps gps = new Gps(new BigDecimal(p.getGpsEwLng()).setScale(6, RoundingMode.HALF_EVEN), 
								new BigDecimal(p.getGpsNsLat()).setScale(6, RoundingMode.HALF_EVEN),p.getGpsNsLat(),p.getGpsNsLat(),p.getIsvalid());
						JSONObject json = WeatherUtil.openWeatherMap(gps);
						if (json != null) {
							tempC = json.getJSONObject("main").getBigDecimal("temp").setScale(0, RoundingMode.HALF_EVEN).intValue();
							tempH= String.valueOf(json.getJSONObject("main").getBigDecimal("temp_max").setScale(0, RoundingMode.HALF_EVEN).intValue());
							tempL = String.valueOf(json.getJSONObject("main").getBigDecimal("temp_min").setScale(0, RoundingMode.HALF_EVEN).intValue());
							String icon = json.getJSONArray("weather").getJSONObject(0).getString("icon");
							weatherCode = String.valueOf(WeatherUtil.convertOpenWeather2YahooCode(json.getJSONArray("weather").getJSONObject(0).getInteger("id"), icon));
							if (!tempL.equals(""))
								pw.setB5L(Short.valueOf(tempL));
							if (!tempH.equals(""))
								pw.setB5H(Short.valueOf(tempH));
						}else {
							 YahooWeatherResult ywresult = WeatherUtil.yahoo(address);
							 if (ywresult != null && ywresult.getQuery().getResults() != null) {
								weatherCode = ywresult.getQuery().getResults().getChannel().getItem().getCondition().getCode();
								tempC = Integer.valueOf(ywresult.getQuery().getResults().getChannel().getItem().getCondition().getTemp());
								tempH = ywresult.getQuery().getResults().getChannel().getItem().getForecast().getHigh();
								tempL = ywresult.getQuery().getResults().getChannel().getItem().getForecast().getLow();
	
								if (!tempL.equals(""))
									pw.setB5L(Short.valueOf(tempL));
								if (!tempH.equals(""))
									pw.setB5H(Short.valueOf(tempH));
							}
						}
					}

					int count = perWeatherMapper.filter_Per_Weather(p.getImei());
					WeatherDeclaration weatherDeclaration = SystemConfigUtil.weatcherCodeMapDeclaration
							.get(weatherCode);

					if (weatherDeclaration != null) {
						if (tempC > 32)
							pw.setB4((short) 1);
						else if (tempC > 28)
							pw.setB4((short) 2);
						else if (tempC > 24)
							pw.setB4((short) 3);
						else if (tempC > 20)
							pw.setB4((short) 4);
						else if (tempC > 15)
							pw.setB4((short) 5);
						else if (tempC > 10)
							pw.setB4((short) 6);
						else if (tempC > 3)
							pw.setB4((short) 7);
						else
							pw.setB4((short) 8);

						// if(!tempL.equals(""))pw.setB5L(Short.valueOf(tempL));
						// if(!tempH.equals(""))pw.setB5H(Short.valueOf(tempH));

						// if(weatherDeclaration)
						pw.setB6((short) (weatherDeclaration.getRainOpp().intValue()));
						pw.setB7((short) (weatherDeclaration.getWeatherIconNum().intValue()));
						pw.setDtatmap((short) 240);
						pw.setGpsEwLng(p.getGpsEwLng());
						pw.setGpsLat(p.getGpsLat());
						pw.setGpsLng(p.getGpsLng());
						pw.setGpsNsLat(p.getGpsNsLat());
						pw.setImei(p.getImei());
						pw.setImsi("");
						pw.setReportGmtTime(TimeUtil.formatDate(p.getCreateDate()));
						if (count == 0) {
							perWeatherMapper.insert(pw);
						} else {
							perWeatherMapper.updateByPrimaryKey(pw);
						}
					}
				} catch (Exception e) {
					LogCenter.exception.error("", e);
					continue;
				}
			}
		}
	}

	/**
	 * 电池电量过低推送
	 * 
	 * @param imei
	 * @param isLowBattery
	 *            是否电量过低
	 */
	private void push(String imei, Boolean isLowBattery) {
		if (isLowBattery) {
			// new Pusher().push("13", imei);
			String extras = "";
			String alert = new PushAlert(new Object[] { imei }, "power_low_key").toString();
			String title = "power_low_title_key";
			int builder_id = INotification.ANDROID_MAKER_BATTARY;
			extras = String.format("imei=%s|", imei);
			extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_LOW);
			extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_BATTERY);
			extras += String.format("builder_id=%d|", builder_id);
			extras += "device=KM8000|";
			Publish.push(imei, alert, title, builder_id, extras);
		}
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
