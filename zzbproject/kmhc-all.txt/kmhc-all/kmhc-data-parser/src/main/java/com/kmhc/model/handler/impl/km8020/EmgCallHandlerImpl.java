package com.kmhc.model.handler.impl.km8020;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.EmgIMapper;
import com.kmhc.model.datacenter.dao.EmgMMapper;
import com.kmhc.model.datacenter.dao.T9DeviceStatusMapper;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.EmgI;
import com.kmhc.model.datacenter.model.EmgM;
import com.kmhc.model.datacenter.model.T9DeviceStatus;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type = "KM8020", command = "0x543839")
public class EmgCallHandlerImpl extends AbstractParentHandlerKM8020 {
	
	private static final Logger log = LoggerFactory.getLogger(EmgCallHandlerImpl.class);
	private T9DeviceStatusMapper t9DeviceStatusMapper = (T9DeviceStatusMapper) SpringBeanFacotry.getInstance().getBean("t9DeviceStatusMapper");
    private EmgMMapper emgMMapper = (EmgMMapper) SpringBeanFacotry.getInstance().getBean("emgMMapper");
    
	public EmgCallHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		log.info(new String(msg));
		//[V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T89,
		//mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		//|help!|,1267511609]
		
		//xtr4ijpxdpq4am6,1,abcd,2016-07-14 09:44:57,1-2,865946020953459,8,T89,
		//mcount$6$460$1$255#2533|75c7|120|39#2533|75c8|113|38#2533|75c9|124|33#2533|7836|665|27#252a|1f59|662|21#2533|7798|659|20,
		//|绱ф?姹傛晳!|,1468489497
		
		//[V1.0.0,f1h85e4q9p54r31,1,abcd,2016-07-14 09:36:38,1-2,865946020953459,8,T89,mcount$6$460$1$255#2533|75c7|120|37#2533|75c8|113|37#2533|7836|665|24#252a|1f4e|660|23#252a|1f59|662|20#2533|7798|659|18,|help!|,1468488998]


		String function = "S89";
		String content[] = new String(msg).split(",");
		String uid = content[0];
		String timeStr = content[3];
		String imei = content[5];
		String tzStr = "GMT+" + content[6];
//		int voltage = Integer.valueOf(content[8]) * 1000;  文件錯誤,無上傳電量
		String cellStr = content[8];
//		String sms = new String(content[9].getBytes(), StandardCharsets.UTF_8);
//		String timeStamp = content[10];
		
		TimeZone tz = TimeZone.getTimeZone(tzStr);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		sdf.setTimeZone(tz);
		Date dt;
		try {
			dt = sdf.parse(timeStr);
		} catch (ParseException e) {
			dt = new Date();
		}
		log.debug(sdf.format(dt));
		
		EmgM emgm = new EmgM();
		Date nowDate = new Date();
		emgm.setImei(imei);
		emgm.setEmgDate(dt);
		emgm.setEmgKey(yyMMddHHmmss.format(new Date()));
		emgm.setEmgDetailKey(emgm.getEmgKey() + emgm.getImei());
		emgm.setCreateDate(nowDate);
		emgm.setUpdateDate(nowDate);
		
		List<Cell> cells = parseCellList(cellStr);	
		Cell cell = cells.get(0);
		setCell(emgm, cell);
		emgm.setCell(cell);
		emgm.setCells(cells);
		LocResult locresult = LocUtil.loc(emgm.getImei(), null, cell, cells, null);
		emgm.setType(function);
		emgm = setLocResult(emgm, locresult);
		emgm.setLocType("LBS");
		
		if(emgMMapper.selectByPrimaryKey(emgm.getEmgKey(), emgm.getImei())!= null){
			emgMMapper.updateByPrimaryKey(emgm);
		}else{
			emgMMapper.insertSelective(emgm);
		}
		
		if (emgm.getCells() != null && emgm.getCells().size() > 0) {
			List<EmgI> emgIList = getEmgIList(emgm.getCells(), emgm.getEmgDetailKey(), emgm.getCreateDate(),
					emgm.getUpdateDate());
			EmgIMapper emgIMapper = (EmgIMapper) SpringBeanFacotry.getInstance().getBean("emgIMapper");
			emgIMapper.insertList(emgIList);
		}
		
		T9DeviceStatus device = t9DeviceStatusMapper.selectByImei(imei);

		if (device != null) {
			if(emgm != null && emgm.getIsvalid() != null && emgm.getIsvalid().equals("Y")){
				device.setLatitude(emgm.getGpsLat());
				device.setLongitude(emgm.getGpsLng());
				device.setLbstime(dt);			
			}
//			device.setVoltage(voltage);
			device.setUpdatetime(dt);
			t9DeviceStatusMapper.updateByPrimaryKey(device);
			push8000Gps(imei,"KM8020","S89");
		}
		
		sendNotification(emgm,"KM8020",null);
		
		dt = new Date();
		String out[] = { uid, content[1], content[2], sdf.format(dt), imei, function };
		//[V1.0.0,zu1jgjwp80veawu,1,abcd,2011-12-15 10:00:00,356511170035899,S86]
		return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"), generateResponse(out));
	}
	
	private EmgM setLocResult(EmgM emgm, LocResult locresult) {
		if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {
			emgm.setIsvalid("Y");
			emgm.setLocStatus("Y");
			emgm.setMcellStatus("Y");
			emgm.setWifiStatus("Y");
			LocDetailResult result = locresult.getResult();
			String[] lngLat = result.getLocation().split(",");
			BigDecimal lng = new BigDecimal(lngLat[0].length() > 10 ? lngLat[0].substring(0, 10) : lngLat[0]);
			BigDecimal lat = new BigDecimal(lngLat[1].length() > 10 ? lngLat[1].substring(0, 10) : lngLat[1]);
			emgm.setGpsLng(lng);
			emgm.setGpsLat(lat);
			emgm.setAddress(result.getDesc());
			emgm.setGpsNsLat("N");
			emgm.setGpsEwLng("E");
			emgm.setMcellLat(lat);
			emgm.setMcellLng(lng);
			emgm.setWifiLat(lat);
			emgm.setWifiLng(lng);
			emgm.setWifiAddress(result.getDesc());
			emgm.setMcellAddress(result.getDesc());
			emgm.setHpe((double) result.getRadius());
		} else {
			if (locresult != null) {
				log.info("【type=KM8020,command=0x{}】定位失败，status:{},info:{},result.type:{}", "S89", locresult.getStatus(),
						locresult.getInfo(), locresult.getResult() == null ? "" : locresult.getResult().getType());
			} else {
				log.info("【type=KM8020,command=0x{}】定位结果返回NULL", "S89");
			}
		}
		return emgm;
	}

	@Override
	public boolean handleMessage(String json) {
		//[V1.0.0,f1h85e4q9p54r31,1,abcd,2016-07-14 09:36:38,1-2,865946020953459,8,T89,mcount$6$460$1$255#2533|75c7|120|37#2533|75c8|113|37#2533|7836|665|24#252a|1f4e|660|23#252a|1f59|662|20#2533|7798|659|18,|help!|,1468488998]
		log.info(json);
		try{
			String function = "S89";
			String content[] = json.split(",");
			String imei = content[content.length-1];
			String cellStr = content[1];
			EmgM emgm = new EmgM();
			Date nowDate = new Date();
			emgm.setImei(imei);
			emgm.setEmgKey(yyMMddHHmmss.format(new Date()));
			emgm.setEmgDetailKey(emgm.getEmgKey() + emgm.getImei());
			emgm.setCreateDate(nowDate);
			emgm.setUpdateDate(nowDate);
			
			List<Cell> cells = parseCellList(cellStr);	
			Cell cell = cells.get(0);
			setCell(emgm, cell);
			emgm.setCell(cell);
			emgm.setCells(cells);
			LocResult locresult = LocUtil.loc(emgm.getImei(), null, cell, cells, null);
			emgm.setType(function);
			emgm = setLocResult(emgm, locresult);
			
			if(emgMMapper.selectByPrimaryKey(emgm.getEmgKey(), emgm.getImei())!= null){
				emgMMapper.updateByPrimaryKey(emgm);
			}else{
				emgMMapper.insertSelective(emgm);
			}
			
			if (emgm.getCells() != null && emgm.getCells().size() > 0) {
				List<EmgI> emgIList = getEmgIList(emgm.getCells(), emgm.getEmgDetailKey(), emgm.getCreateDate(),
						emgm.getUpdateDate());
				EmgIMapper emgIMapper = (EmgIMapper) SpringBeanFacotry.getInstance().getBean("emgIMapper");
				emgIMapper.insertList(emgIList);
			}
			
			T9DeviceStatus device = t9DeviceStatusMapper.selectByImei(imei);
	
			if (device != null) {
				if(emgm != null && emgm.getIsvalid() != null && emgm.getIsvalid().equals("Y")){
					device.setLatitude(emgm.getGpsLat());
					device.setLongitude(emgm.getGpsLng());	
				}
				t9DeviceStatusMapper.updateByPrimaryKey(device);
				push8000Gps(imei,"KM8020","S89");
			}
			sendNotification(emgm,"KM8020",null);
		}catch(Exception e){
			return false;
		}
		return true;
	}
}
