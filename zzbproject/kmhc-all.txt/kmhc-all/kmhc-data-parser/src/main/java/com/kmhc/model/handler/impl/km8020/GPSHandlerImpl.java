package com.kmhc.model.handler.impl.km8020;

import java.math.BigDecimal;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PrIMapper;
import com.kmhc.model.datacenter.dao.PrMMapper;
import com.kmhc.model.datacenter.dao.T9DeviceStatusMapper;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.PrI;
import com.kmhc.model.datacenter.model.PrM;
import com.kmhc.model.datacenter.model.T9DeviceStatus;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type = "KM8020", command = "0x543533")
public class GPSHandlerImpl extends AbstractParentHandlerKM8020 {
	
	private static final Logger log = LoggerFactory.getLogger(GPSHandlerImpl.class);
	private PrMMapper prMMapper = (PrMMapper) SpringBeanFacotry.getInstance().getBean("prMMapper");
    private PrIMapper prIMapper = (PrIMapper) SpringBeanFacotry.getInstance().getBean("prIMapper");
	private T9DeviceStatusMapper t9DeviceStatusMapper = (T9DeviceStatusMapper) SpringBeanFacotry.getInstance().getBean("t9DeviceStatusMapper");

	public GPSHandlerImpl() { 
		super(log);
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		
//		a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T53,
//		GPS,104.063469,30.551357,181.899994,0.217000,221.479996, 
//		1267511609
		log.info(new String(msg));
		String function = "S53";
		String content[] = new String(msg).split(",");
		String uid = content[0];
		String timeStr = content[3];
		String imei = content[5];
		String tzStr = "GMT+" + content[6];
		String lng = content[9];
		String lat = content[10];
		
		Date dt = com.kmhc.model.util.Date.getDate(timeStr,"yyyy-MM-dd HH:mm:ss",tzStr);
		log.debug(sdf.format(dt));
				
		Gps gps = new Gps(new BigDecimal(lat).setScale(10, BigDecimal.ROUND_HALF_UP), new BigDecimal(lng).setScale(10, BigDecimal.ROUND_HALF_UP), "N", "E", "Y");
		gps = LocUtil.conver(gps);
		String reverseGeocoding = LocUtil.reverseGeocoding(gps.getLat(),gps.getLng());
		if (reverseGeocoding == null) {
			reverseGeocoding = "";
		}
		gps.setAddress(reverseGeocoding);
		
		PrM prm = parsePrM(imei, function);
		PrI pri = getPrI(gps, imei, dt);
		if(prIMapper.selectByPrDate(pri) == 0){
			if(prm != null){
				try{
					prMMapper.insertSelective(prm);
				}catch(Exception e){
					prMMapper.updateByPrimaryKey(prm);
				}
			}
			if(pri != null){
				try{
					prIMapper.insertSelective(pri);
				}catch(Exception e){
					prIMapper.updateByPrimaryKey(pri);
				}
			}
			

			T9DeviceStatus device = t9DeviceStatusMapper.selectByImei(imei);

			if (device != null) {
				if(gps.getIsValid() != null && gps.getIsValid().equals("Y")){
					device.setLatitude(gps.getLat());
					device.setLongitude(gps.getLng());
					device.setLbstime(dt);
				}
				device.setUpdatetime(dt);
				t9DeviceStatusMapper.updateByPrimaryKey(device);
				push8000Gps(imei,"KM8020","S53");
			}

		}
		dt = new java.util.Date();
		String out[] = { uid, content[1], content[2], sdf.format(dt), imei, function };
		//[V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,355372020827303,S53]
		return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"), generateResponse(out));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
	
	//[V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T53,GPS,104.063469,30.551357,181.899994,0.217000,221.479996, 1267511609]

}
