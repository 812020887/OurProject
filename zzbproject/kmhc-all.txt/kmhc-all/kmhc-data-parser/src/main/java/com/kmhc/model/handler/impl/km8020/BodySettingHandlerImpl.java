package com.kmhc.model.handler.impl.km8020;

import java.math.BigDecimal;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.core.MessageHandlerRegister;
import com.kmhc.model.datacenter.dao.ProductPerSettingMMapper;
import com.kmhc.model.datacenter.dao.ServerActionHisMapper;
import com.kmhc.model.datacenter.model.ProductPerSettingM;
import com.kmhc.model.datacenter.model.ServerActionHis;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.util.LogCenter;
import com.kmhc.model.util.SystemConfigUtil;

@MessageCommand(type = "KM8020", command = "0x543737")
public class BodySettingHandlerImpl extends AbstractParentHandlerKM8020 {

	private static final Logger log = LoggerFactory.getLogger(BodySettingHandlerImpl.class);
	private ServerActionHisMapper serverActionHisMapper = (ServerActionHisMapper) SpringBeanFacotry.getInstance().getBean("serverActionHisMapper");
	private ProductPerSettingMMapper pPSM = (ProductPerSettingMMapper) SpringBeanFacotry.getInstance().getBean("productPerSettingMMapper");

	public BodySettingHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		//a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,355372020827303,S77,18,170,60,65,1 (Male-0 F-1)  in server_action_his content
		//[V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T77]
		log.info(new String(msg));
		String protocol = "S77";
		String content[] = new String(msg).split(",");
		String uid = content[0];
		String imei = content[5];
		
		ServerActionHis record = serverActionHisMapper.selectByPrimaryKey(uid, imei, protocol);
		if( record != null){
			String command[] = record.getContent().split(",");
//		if(true){
//			String command[] = ".0.0,156a233abd40013,1,abcd,2016-08-19 17:48:30,356511170035899,S77,0,170,50,65,0".split(",");
//			log.debug(command[6]);
//			log.debug(command[7]);
//			log.debug(command[8]);
//			log.debug(command[9]);
//			log.debug(command[10]);
//			log.debug(command[11]);
			
			String age = command[7];
			String height = command[8];
			String stepLength = command[9];
			String weight = command[10];
			String sex = command[11];
			
			ProductPerSettingM setting = null;
			setting = pPSM.selectByPrimaryKey(imei);
			if( setting == null ) setting = new ProductPerSettingM();
			setting.setImei(imei);
			setting.setuAge(Short.parseShort(age));
			setting.setuHeight(new BigDecimal(height));
			setting.setuWeight(new BigDecimal(weight));
			setting.setuStep(Short.parseShort(stepLength));
			setting.setuSex(Short.parseShort(sex));
			setting.setChecksum((short) 1);
			if( setting.getChecksum() != null )
					setting.setChecksum((short) ((setting.getChecksum() + 1)));
			setting.setUpdateDate(new Date());
			
			int success = 0;
			try{
				success = pPSM.updateByPrimaryKeySelective(setting);
			}catch(Exception e){
				success = 0;
			}
			if(success > 0){
//				serverActionHisMapper.deleteByPrimaryKey(record.getUid(), record.getImei(), protocol);
				pushSettingFinish(imei,INotification.NOTIFICATION_TYPE_SETTING_BODY);
				return null;
			}
		}
//		log.info("push fail notification to app");
		return null;
	}
	
	public static void main(String[] args) {
		SpringBeanFacotry.getInstance().init("spring-common.xml");
		try {
			//TODO 在初始化Spring之后才加入扫描，因为Handler中有Bean的注入。
			MessageHandlerRegister.registHandler(SystemConfigUtil.handlerPackagePath, MessageCommand.class);
			LogCenter.root.info("MessageHandlerRegister  registed");
		} catch (InstantiationException | IllegalAccessException e1) {
			e1.printStackTrace();
		}
		new BodySettingHandlerImpl().handleMessage("156a233abd40013,1,abcd,2016-08-19 17:48:30,1-2,356511170035899,8,T77".getBytes());
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
