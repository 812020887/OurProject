package com.kmhc.model.handler.impl.km8000;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.ProductSysSettingMMapper;
import com.kmhc.model.datacenter.model.ProductSysSettingM;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;

@MessageCommand(type="KM8000",command="0x40")
public class ServerIpHandlerImpl extends AbstractParentHandlerKM8000 {

    private static final Logger log = LoggerFactory.getLogger(PowerOnHandlerImpl.class);
    
    private String type = "40";
    
    public ServerIpHandlerImpl(){
        super(log);
    }
    
    
    
    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
        writeDebugLog(msg,type);
		byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
        String imei = null;
        byte[] reMsg = null;
		try {
			imei = parseImeiOrImsi_KM8000(msg, START_FRAME);

			// String hex =
			// "003d4003313230303235323235303035303832353231323030323532323530303530383235323132303032353232353030353038323532";

			ProductSysSettingMMapper pSMMapper = (ProductSysSettingMMapper) SpringBeanFacotry.getInstance()
					.getBean("productSysSettingMMapper");

			ProductSysSettingM record = pSMMapper.selectByPrimaryKey(imei);

			if (record != null) {
				reMsg = generateIpListBuf(record);
			} else {
				reMsg = AbstractHandler.ACK_ERROR_KM8000;
			}

		} catch (Exception e) {
			log.error("获取系统ip信息出错。", e);
			reMsg = AbstractHandler.ACK_ERROR_KM8000;
		}       

		ReplyMessageContent replyMessageContent = null;
		if(imei != null && reMsg != null ){
			replyMessageContent = new ReplyMessageContent(imeiBytes,reMsg);
		}
				
		return replyMessageContent;
    }
    
    
	public byte[] generateIpListBuf(ProductSysSettingM record) {
		
		byte[][] ip_buf = { 
	    	    { 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48 }, 
	    		{ 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48 }, 
	    		{ 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48 } 
	    };
	    
		byte[] byteBufferDefault = { 2, 85, -86, 0, 27, 64, 1, 50, 49, 48, 48, 54, 49, 48, 54, 52, 48, 53, 54, 48,
				53, 50, 53, 49, -86, 85, 3 };
	    
		byte[] byteBuffer1 = { 2, 85, -86, 0, 27, 64, 1, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35,
				35, 35, -86, 85, 3 };

		byte[] byteBuffer2 = { 2, 85, -86, 0, 44, 64, 2, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35,
				35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, -86, 85, 3 };

		byte[] byteBuffer3 = { 2, 85, -86, 0, 61, 64, 3, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35,
				35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35,
				35, 35, 35, 35, 35, 35, 35, 35, 35, -86, 85, 3 };
	    		   
		
		String[] ip = { record.getIp1(), record.getIp2(), record.getIp3() };
	    byte[] byteBuffer;

		int validIpCount = 0;
		for (int count = 0; count < 3; ++count) {
			int ip_sidx = 16;
			char[] ip_ch = ip[count].toCharArray();

			if (ip[count].equals("###.###.###.###:#####")) {
				break;
			}
			int offset = 0;
			++validIpCount;
			for (int i = ip_ch.length - 1; i >= 0; --i) {
				if ((ip_ch[i] != '.') && (ip_ch[i] != ':')) {
					ip_buf[count][(ip_sidx - offset)] = (byte) ip_ch[i];
					++offset;
				} else {
					if (ip_ch[i] == '.')
						ip_sidx -= 3;
					else {
						ip_sidx -= 5;
					}
					offset = 0;
				}
			}		
		}
		int j;
		if (validIpCount == 0) {
			byteBuffer = new byte[byteBufferDefault.length];
			for (j = 0; j < byteBufferDefault.length; ++j) {
				byteBuffer[j] = byteBufferDefault[j];
			}
		} else if (validIpCount == 1) {
			for (int i = 0; i < ip_buf[0].length; ++i) {
				byteBuffer1[(i + 7)] = ip_buf[0][i];
			}
			byteBuffer = new byte[byteBuffer1.length];
			for (j = 0; j < byteBuffer1.length; ++j)
				byteBuffer[j] = byteBuffer1[j];
		} else {
			int n;
			int i;
			if (validIpCount == 2) {
				for (n = 0; n < 2; ++n) {
					for (i = 0; i < ip_buf[n].length; ++i) {
						byteBuffer2[(n * 17 + i + 7)] = ip_buf[n][i];
					}
				}
				byteBuffer = new byte[byteBuffer2.length];
				for (n = 0; n < byteBuffer2.length; ++n)
					byteBuffer[n] = byteBuffer2[n];
			} else {
				for (n = 0; n < 3; ++n) {
					for (i = 0; i < ip_buf[n].length; ++i) {
						byteBuffer3[(n * 17 + i + 7)] = ip_buf[n][i];
					}
				}
				byteBuffer = new byte[byteBuffer3.length];
				for (j = 0; j < byteBuffer3.length; ++j)
					byteBuffer[j] = byteBuffer3[j];
			}
		}
		
		byte[] reByte = new byte[byteBuffer.length-6];
		for(int i = 3 ; i<byteBuffer.length-3;i++){
			reByte[i-3] = byteBuffer[i];
		}
		
		return reByte;
	}



	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
