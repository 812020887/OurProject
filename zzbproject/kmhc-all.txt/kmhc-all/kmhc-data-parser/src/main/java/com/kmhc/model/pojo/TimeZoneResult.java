package com.kmhc.model.pojo;

import java.io.Serializable;
import java.util.Date;

import com.alibaba.fastjson.annotation.JSONField;

public class TimeZoneResult implements Serializable{

	private static final long serialVersionUID = 9021079245646252545L;
	
//	@JSONField (format="yyyy-MM-dd HH:mm") 
	public Date time;
//	@JSONField (format="yyyy-MM-dd HH:mm") 
	public Date sunset;
//	@JSONField (format="yyyy-MM-dd HH:mm") 
	public Date sunrise;
	private String countryName;
	private float rawOffset;
	private float dstOffset;
	private float gmtOffset;
	private double lng;
	private double lat;
	private String countryCode;
	private String timezoneId;
//	@JSONField (format="yyyy-MM-dd HH:mm") 
	public Date getTime() {
		return time;
	}
//	@JSONField (format="yyyy-MM-dd HH:mm") 
	public void setTime(Date time) {
		this.time = time;
	}
//	@JSONField (format="yyyy-MM-dd HH:mm") 
	public Date getSunset() {
		return sunset;
	}
//	@JSONField (format="yyyy-MM-dd HH:mm") 
	public void setSunset(Date sunset) {
		this.sunset = sunset;
	}
//	@JSONField (format="yyyy-MM-dd HH:mm") 
	public Date getSunrise() {
		return sunrise;
	}
//	@JSONField (format="yyyy-MM-dd HH:mm") 
	public void setSunrise(Date sunrise) {
		this.sunrise = sunrise;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public float getRawOffset() {
		return rawOffset;
	}
	public void setRawOffset(float rawOffset) {
		this.rawOffset = rawOffset;
	}
	public float getDstOffset() {
		return dstOffset;
	}
	public void setDstOffset(float dstOffset) {
		this.dstOffset = dstOffset;
	}
	public float getGmtOffset() {
		return gmtOffset;
	}
	public void setGmtOffset(float gmtOffset) {
		this.gmtOffset = gmtOffset;
	}
	public double getLng() {
		return lng;
	}
	public void setLng(double lng) {
		this.lng = lng;
	}
	public double getLat() {
		return lat;
	}
	public void setLat(double lat) {
		this.lat = lat;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getTimezoneId() {
		return timezoneId;
	}
	public void setTimezoneId(String timezoneId) {
		this.timezoneId = timezoneId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

}
