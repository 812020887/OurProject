/**
 * 
 */
package com.kmhc.model.core;

import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.kmhc.model.pojo.Matrix;

/**
 * @author xl
 *
 */
public class Context {

    public static final ExecutorService interceptersService = Executors.newCachedThreadPool();
    public static final HashMap<Short,Matrix> MARTIXS = new HashMap<Short,Matrix>() ;
}
