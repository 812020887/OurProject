/**
 * Copyright (C) 2016 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2016年3月9日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.util;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.rabbitmq.recover.core.ConnectionBuilder;
import com.kmhc.framework.rabbitmq.recover.core.ExecutePublisher;
import com.kmhc.framework.rabbitmq.recover.core.PublisherPool;
import com.kmhc.framework.rabbitmq.recover.resource.ConnectionOption;
import com.kmhc.model.datacenter.dao.BundleIMapper;
import com.kmhc.model.datacenter.model.BundleI;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.runnable.ReplyMessageThread;
import com.rabbitmq.client.Connection;

/**
 * Name: Publish.java ProjectName: [kmhc-data-parser] Package:
 * [com.kmhc.model.util.Publish.java] Description: TODO
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2016年3月9日 下午2:01:35
 *
 *        Update-User: @author Update-Time: Update-Remark:
 * 
 *        Check-User: Check-Time: Check-Remark:
 * 
 *        Company: kmhc Copyright: kmhc
 */
public class Publish {

	private static final Logger log = LoggerFactory.getLogger(Publish.class);

	public static void main(String[] args) {
		test();
	}

	public static void test() {
		try {
			ConnectionOption option = new ConnectionOption().withHostName("127.0.0.1").withPort("5672")
					.withUserName("guest").withPassowrd("guest");

			final Connection connection = ConnectionBuilder.createConnection(option);

			ExecutePublisher publisher = new PublisherPool(connection.createChannel(), "push", "reply.push",
					"reply.push").getPublisher();
			// String imei = "865946020953459";
			// String uid = SNUtil.create15();
			// TimeZone tz = TimeZone.getTimeZone("GMT+8");
			// SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd
			// HH:mm:ss");
			// sdf.setTimeZone(tz);
			// Date dt = new Date();

			// JPUSH,YYY,false,0,13691993691|13242011451,紧急求救通知由 866545022042821
			// 触发,紧急求救通知,2,
			// type=SOS|builder_id=2|gps=false|imei=866545022042821|level=3|NS=N|EW=W|lat=255.677721|lng=120.731333|
			// hpe=179|address=江苏省苏州市吴中区阳澄湖大道|device=KM8010
			// [V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15
			// 10:00:00,355372020827303,S71,13654678948,13654673567,13654673568]
			// String msg = ".0.0," + uid + ",1,abcd," + sdf.format(dt) + "," +
			// imei + ",S71,13691993691,S71,13691993691,S71,13691993691";//11
			String msg = "JPUSH,YYY,testEnv,0,13691993691|13242011451,紧急求救通知由  866545022042821 触发,紧急求救通知,2,type=SOS|builder_id=2|gps=false|imei=866545022042821|level=3|NS=N|EW=W|lat=255.677721|lng=120.731333|hpe=179|address=江苏省苏州市吴中区阳澄湖大道|device=KM8010";
			System.out.println(msg);

			ReplyMessageContent content = new ReplyMessageContent(msg.getBytes(StandardCharsets.UTF_8));
			ArrayList<byte[]> contentMsg = content.getMsg();
			for (int i = 0; i < contentMsg.size(); i++) {
				if (contentMsg.get(i) != null) {
					publisher.publishMessage(content.getMsg().get(i));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void send(ReplyMessageContent content) {
		try {
			ArrayList<byte[]> contentMsg = content.getMsg();
			for (int i = 0; i < contentMsg.size(); i++) {
				if (contentMsg.get(i) != null) {
					ReplyMessageThread.protocolTypeMapContent.get("PUSH").add(content);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void push(String imei, String alert, String title, int builder_id, String extras) {
		String msg = SystemConfigUtil.pushMethod + ",@" + SystemConfigUtil.pushTarget + ",@"
				+ SystemConfigUtil.pushTargetEnv + ",@";
		BundleIMapper bundleIMapper = SpringBeanFacotry.getInstance().getBean(BundleIMapper.class);
		log.debug("Publish  imei {}", imei);
		List<BundleI> bundles = bundleIMapper.selectAllByImei(imei);
		String target = "";
		for (BundleI b : bundles) {
			if (b != null)
				target += (b.getAccount() + "|");
		}
		if (target != null) {
			msg = msg + "0,@" + target + ",@" + alert + ",@" + title + ",@" + String.valueOf(builder_id) + ",@"
					+ extras;
			ReplyMessageContent content = new ReplyMessageContent(msg.getBytes(StandardCharsets.UTF_8));
			Publish.send(content);
		}
	}
	
	public static void pushHL(String imei, String alert, String title, int builder_id, String extras) {
		String msg = SystemConfigUtil.pushHLMethod + ",@" + SystemConfigUtil.pushTarget + ",@"
				+ SystemConfigUtil.pushTargetEnv + ",@";
		BundleIMapper bundleIMapper = SpringBeanFacotry.getInstance().getBean(BundleIMapper.class);
		log.debug("Publish  imei {}", imei);
		List<BundleI> bundles = bundleIMapper.selectAllByImei(imei);
		String target = "";
		for (BundleI b : bundles) {
			if (b != null)
				target += (b.getAccount() + "|");
		}
		if (target != null) {
			msg = msg + "0,@" + target + ",@" + alert + ",@" + title + ",@" + String.valueOf(builder_id) + ",@"
					+ extras;
			ReplyMessageContent content = new ReplyMessageContent(msg.getBytes(StandardCharsets.UTF_8));
			Publish.send(content);
		}
	}


	public static void push(String pushStr) {
		String msg = SystemConfigUtil.pushMethod + ",@" + SystemConfigUtil.pushTarget + ",@"
				+ SystemConfigUtil.pushTargetEnv + ",@";
		msg = msg + pushStr;
		ReplyMessageContent content = new ReplyMessageContent(msg.getBytes(StandardCharsets.UTF_8));
		Publish.send(content);
	}

	public static void push8000Gps(String imei, String alert, String title, int builder_id, String extras) {
		String msg = SystemConfigUtil.push8000GPSMethod + ",@" + SystemConfigUtil.pushTarget + ",@"
				+ SystemConfigUtil.pushTargetEnv + ",@";
		
		BundleIMapper bundleIMapper = (BundleIMapper) SpringBeanFacotry.getInstance().getBean("bundleIMapper");
		log.debug("Publish  imei {}", imei);
		List<BundleI> bundles = bundleIMapper.selectAllByImei(imei);
		String target = "";
		for (BundleI b : bundles) {
			if (b != null)
				target += (b.getAccount() + "|");
		}
		if (target != null) {
			msg = msg + "0,@" + target + ",@" + alert + ",@" + title + ",@" + String.valueOf(builder_id) + ",@"
					+ extras;
			ReplyMessageContent content = new ReplyMessageContent(msg.getBytes(StandardCharsets.UTF_8));
			Publish.send(content);
		}
		
	}
}
