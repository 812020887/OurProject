package com.kmhc.model.util;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.pojo.YahooWeatherResult;

public class WeatherUtil {

	private static final Logger log = LoggerFactory.getLogger(WeatherUtil.class);

	private static final String GET_WEATHER_BY_ADDRESS_PARAM = "q=SELECT item.forecast,item.condition FROM weather.forecast(1) WHERE woeid in (SELECT woeid FROM geo.places WHERE text=\"%s\") and u=\'c\'&format=json";
	// private static final String GET_WEATHER_FROM_YAHOO_BY_LAT_LON_PARAM =
	// "q=SELECT item.forecast,item.condition FROM weather.forecast(1) WHERE
	// woeid in (SELECT woeid FROM geo.placefinder WHERE text=\"%s,%s\" and
	// gflags=\"R\") and u=\'c\'&format=json";

	public static JSONObject openWeatherMap(Gps gps) {
		JSONObject jsonObject = null;
		String lat = "";
		String lng = "";
		if (gps.getDirectionLat().equals("S"))
			lat += "-";
		if (gps.getDirectionLat().equals("W"))
			lng += "-";
		lat += String.valueOf(gps.getLat().doubleValue());
		lng += String.valueOf(gps.getLng().doubleValue());

		String url = String.format(SystemConfigUtil.kmhcOpenWeatherMapUrl, lng, lat);
		String resultText = HttpClientUtils.request(url.toString());
		jsonObject = JSON.parseObject(resultText);
		if(jsonObject.getInteger("cod") != 200) return null;
		return jsonObject;
	}
	
	public static int convertOpenWeather2YahooCode(int code, String icon) {
		if(code < 300){
			code = 4;
			if(code == 221) code = 3;
		}else if(code < 400){
			code = 4;
		}else if(code < 600){
			if(code == 500 && code == 501 && code == 521)code = 12;
			else if(code == 502 && code == 531)code = 47;
			else if(code == 503 && code == 504 && code == 522)code = 45;
			else if(code == 511)code = 10;
			else if(code == 520)code = 40;
		}else if(code < 700){
			if(code == 600 && code == 620)code = 14;
			else if(code == 601)code = 16;
			else if(code == 602)code = 15;
			else if(code == 611 && code == 612)code = 18;
			else if(code == 615 && code == 616)code = 5;
			else if(code == 621)code = 13;
			else if(code == 622)code = 46;
		}else if(code < 800){
			if(code == 701 && code == 741)code = 20;
			else if(code == 711)code = 22;
			else if(code == 721)code = 21;
			else if(code == 731 && code == 751 && code == 761 && code == 762)code = 19;
			else if(code == 771)code = 23;
			else if(code == 781)code = 0;
		}else if(code < 900){
			if(code == 800){
				if(icon.equals("01d"))code = 32;
				else if(icon.equals("01n"))code = 31;
			}else if(code == 801){
				if(icon.equals("02d"))code = 29;
				else if(icon.equals("02n"))code = 30;
			}else if(code == 802){
				code = 26;
			}else if(code == 803){
				if(icon.equals("04d"))code = 29;
				else if(icon.equals("03d"))code = 30;
			}else if(code == 804){
				code = 28;
			}
		}else{
			if(code == 900)code = 0;
			else if(code == 901)code = 1;
			else if(code == 902 && code == 961 && code == 962)code = 2;
			else if(code == 903)code = 25;
			else if(code == 904)code = 36;
			else if(code == 906)code = 17;
			else if(code == 951)code = 34;
			else if(code == 905 && code == 952 && code == 953 && code == 954 && code == 955)code = 24;
			else if(code == 956 && code == 957 && code == 958 && code == 959)code = 23;
		}
		return code;
	}

//	public static void main(String args[]) {
//		System.out.println("Test openweather");
//		Gps gps = new Gps(new BigDecimal(114.063387).setScale(6, RoundingMode.HALF_EVEN), 
//				new BigDecimal(22.544750).setScale(6, RoundingMode.HALF_EVEN),
//				"N","E","Y");
//		
//		JSONObject json = openWeatherMap(gps);
//		log.debug(json.toString());
//		log.debug(json.getJSONArray("weather").getJSONObject(0).getInteger("id").toString());
//		log.debug(json.getJSONObject("main").getBigDecimal("temp").setScale(0, RoundingMode.HALF_EVEN).toString());
//		log.debug(json.getJSONObject("main").getBigDecimal("temp_max").setScale(0, RoundingMode.HALF_EVEN).toString());
//		log.debug(json.getJSONObject("main").getBigDecimal("temp_min").setScale(0, RoundingMode.HALF_EVEN).toString());
//	}

	public static YahooWeatherResult yahoo(Gps gps) {
		// YahooWeatherResult ywresult = null;
		// try {
		String lat = "";
		String lng = "";
		if (gps.getDirectionLat().equals("S"))
			lat += "-";
		if (gps.getDirectionLat().equals("W"))
			lng += "-";
		lat += String.valueOf(gps.getLat().doubleValue());
		lng += String.valueOf(gps.getLng().doubleValue());
		String address = LocUtil.reverseGeocoding(new BigDecimal(lat).setScale(6, RoundingMode.HALF_EVEN),
				new BigDecimal(lng).setScale(6, RoundingMode.HALF_EVEN));
		// String param = String.format(GET_WEATHER_BY_ADDRESS_PARAM,
		// address).replace(" ", "%20").replace("'", "%27").replace("\"",
		// "%22");
		// byte[] result =
		// HttpClientUtils.request(SystemConfigUtil.kmhcYahooweatherUrl, "GET",
		// "UTF-8", param, null, null,
		// SystemConfigUtil.kmhcAutonaviConnectTimeout,SystemConfigUtil.kmhcAutonaviSocketTimeout);
		// log.debug(new String(result));
		// log.debug(JSON.parseObject(new
		// String(result,"UTF-8"),YahooWeatherResult.class).toString());
		// if(result != null && result.length >0)
		// ywresult = JSON.parseObject(new
		// String(result,"UTF-8"),YahooWeatherResult.class);
		// } catch (UnsupportedEncodingException e) {
		// e.printStackTrace();
		// }
		return yahoo(address);
	}

	public static YahooWeatherResult yahoo(String address) {
		YahooWeatherResult ywresult = null;
		try {
			String param = String.format(GET_WEATHER_BY_ADDRESS_PARAM, address).replace(" ", "%20").replace("'", "%27")
					.replace("\"", "%22");
			byte[] result = HttpClientUtils.request(SystemConfigUtil.kmhcYahooweatherUrl, "GET", "UTF-8", param, null,
					null, SystemConfigUtil.kmhcAutonaviConnectTimeout, SystemConfigUtil.kmhcAutonaviSocketTimeout);
			if (result != null && result.length > 0)
				// log.debug(new String(result));
				// log.debug(JSON.parseObject(new
				// String(result,"UTF-8"),YahooWeatherResult.class).toString());
				ywresult = JSON.parseObject(new String(result, "UTF-8"), YahooWeatherResult.class);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return ywresult;
	}
}
