package com.kmhc.model.handler.impl.c100;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.ConvertionUtil;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.C100DeviceStatusMapper;
import com.kmhc.model.datacenter.dao.DeviceListMapper;
import com.kmhc.model.datacenter.dao.DeviceSettingGfenceSpMapper;
import com.kmhc.model.datacenter.dao.PrCellIMapper;
import com.kmhc.model.datacenter.dao.PrIMapper;
import com.kmhc.model.datacenter.dao.PrMMapper;
import com.kmhc.model.datacenter.model.C100DeviceStatus;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.DeviceList;
import com.kmhc.model.datacenter.model.DeviceSettingGfenceSp;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.PrCellI;
import com.kmhc.model.datacenter.model.PrI;
import com.kmhc.model.datacenter.model.PrM;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.MessageBuilder;

/**
 * @ClassName: com.kmhc.model.handler.impl.c100.RealTimeTrajectoryHandlerImpl
 * @Description: 实时轨迹上报协议报文解析，本类只解析服务端关注的数据：保留字、经度、纬度、小区信息、Wifi信息列
 * @author xl
 * @date 2016年10月13日
 *
 */
@MessageCommand(type = "C100", command = "0x05")
public class RealTimeTrajectoryHandlerImpl extends AbstractParentHandlerC100 {

	private static final Logger log = LoggerFactory.getLogger(RealTimeTrajectoryHandlerImpl.class);
	public final SimpleDateFormat yyMMddHHmmss = new SimpleDateFormat("yyMMddHHmmss");
	private DeviceListMapper deviceListMapper = (DeviceListMapper) SpringBeanFacotry.getInstance()
			.getBean("deviceListMapper");
	private PrIMapper prIMapper = (PrIMapper) SpringBeanFacotry.getInstance().getBean("prIMapper");
	private C100DeviceStatusMapper c100DeviceStatusMapper = (C100DeviceStatusMapper) SpringBeanFacotry.getInstance()
			.getBean("c100DeviceStatusMapper");
	private PrMMapper prMMapper = (PrMMapper) SpringBeanFacotry.getInstance().getBean("prMMapper");
	private PrCellIMapper prCellIMapper = (PrCellIMapper) SpringBeanFacotry.getInstance().getBean("prCellIMapper");
    private DeviceSettingGfenceSpMapper dsgsMapper = (DeviceSettingGfenceSpMapper) SpringBeanFacotry.getInstance().getBean("deviceSettingGfenceSpMapper");

	private final String type = "05";

	/**
	 * 创建一个新的实例 RealTimeTrajectoryHandlerImpl.
	 *
	 * @param log
	 */

	public RealTimeTrajectoryHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		int index = 0;
		byte reserved = 0;
		byte[] snBytes = Arrays.copyOfRange(msg, index, index + 9);
		String sn = parseSn(msg, index - 5 );
		index += 9;
		DeviceList device = deviceListMapper.selectBySn(sn);
		int count = (msg.length - index) / 72;
		PrI gfencePri = null;
		for (int k = 0; k < count; k++) {
			Date deviceCurrentDate = new Date(((long) (ConvertionUtil.bigEndBytesToInt(msg, index))) * 1000);
			short signalStatus = ConvertionUtil.getShort(Arrays.copyOfRange(msg, index + 4, index + 6), false);
			boolean gpsStatus = gpsStatus(signalStatus);
			boolean wifiStatus = wifiStatus(signalStatus, reserved);
			int vpp = getVolagePrecent(signalStatus);
			int vp = vpp * VP_BASE / 10;
			List<Cell> cells = parseCells(msg, index + 16);

			C100DeviceStatus record = new C100DeviceStatus(vpp, vp, deviceCurrentDate, device.getImei());
			C100DeviceStatus old = c100DeviceStatusMapper.selectByImei(device.getImei());
			if (old != null) {
				record.setNo(old.getNo());
				c100DeviceStatusMapper.updateByPrimaryKeySelective(record);
			} else
				c100DeviceStatusMapper.insertSelective(record);

			PrI pri = null;
			List<PrCellI> prcelllist = null;
			PrM prm = new PrM();
			Date nowDate = new Date();
			prm.setImei(device.getImei());
			prm.setBatchKey(yyMMddHHmmss.format(nowDate));
			prm.setType(type);
			prm.setCreateDate(nowDate);
			prm.setUpdateDate(nowDate);
			if (gpsStatus) {
				Gps gps = parseGps(msg, index + 8);
				if (gps != null) {
					gps = LocUtil.conver(gps);
					pri = getPrI(gps, device.getImei(), deviceCurrentDate, vp);
				}
			} else if (wifiStatus) {
				List<Wifi> wifis = parseWifis(msg, index + 72);
				pri = getPrI(null, cells, wifis, device.getImei(), deviceCurrentDate, vp);
				prcelllist = getPrCellI(cells, prm);
			} else if (cells.size() > 0) {
				pri = getPrI(null, cells, null, device.getImei(), deviceCurrentDate, vp);
				prcelllist = getPrCellI(cells, prm);
			}
			if (prm != null) {
				try {
					prMMapper.insertSelective(prm);

				} catch (Exception e) {
				}
			}
			if (pri != null) {
				int insertprisuccess = 0;
				while (insertprisuccess == 0) {
					try {
						insertprisuccess = prIMapper.insertSelective(pri);
						if (insertprisuccess > 0){
							DeviceSettingGfenceSp dsg = dsgsMapper.selectByPrimaryKey(pri.getImei());
							if(dsg != null && dsg.getEnable() == 1){
								gfencePri = pri;
							}
							break;
						}
					} catch (Exception e) {
						pri.setItemno((short) (pri.getItemno() + 1));
						if(pri.getItemno() > 10) break;
					}
				}

			}
			for (int i = 0; prcelllist != null && i < prcelllist.size(); i++) {
				try {
					prCellIMapper.insertSelective(prcelllist.get(i));
				} catch (Exception e) {
				}
			}
//			index += 112;
			index += 72;
		}
		if(gfencePri != null){
			requestGFenceNotice(device.getImei(),gfencePri.getGpsLat(),gfencePri.getGpsLng(),gfencePri.getHpe(),"C100");	
		}
		return MessageBuilder.buildReplyMessageContent(snBytes, generateResponse((byte) 0x85));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
