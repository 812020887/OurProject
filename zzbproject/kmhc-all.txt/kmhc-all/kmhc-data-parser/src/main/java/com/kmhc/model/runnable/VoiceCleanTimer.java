/**  
 * All rights Reserved, Designed By KMHC   
 * @Title:  VoiceCleanTimer.java   
 * @Package com.kmhc.model.runnable   
 * @Description:    TODO
 * @author: Administrator     
 * @date:   2016年11月5日 上午11:18:07   
 * @version V1.0     
 */  
package com.kmhc.model.runnable;

import java.util.Date;
import java.util.List;
import java.util.TimerTask;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.datacenter.dao.VoiceUploadRecordMapper;
import com.kmhc.model.datacenter.model.VoiceUploadRecord;
import com.kmhc.model.util.HttpClientUtils;

/**   
 * @ClassName:  VoiceCleanTimer   
 * @Description:TODO
 * @author: Neil  
 * @date:   2016年11月5日 上午11:18:07   
 *      
 */
public class VoiceCleanTimer extends TimerTask {

	/* (non-Javadoc)
	 * @see java.util.TimerTask#run()
	 */
	
	private VoiceUploadRecordMapper voiceUploadRecordMapper = (VoiceUploadRecordMapper) SpringBeanFacotry.getInstance()
			.getBean("voiceUploadRecordMapper");
	private static final long period = 1000*60*60*24*3;  //  3天
	
	@Override
	public void run() {
		Date date = new Date();
		date = new Date(date.getTime()-period);
		List<VoiceUploadRecord> record = voiceUploadRecordMapper.selectAllOverTimeAndDownloaded(date);
		for(VoiceUploadRecord r : record){
			String url = r.getUrl().replace("download", "delete");
			HttpClientUtils.request(url);
		}
	}

}
