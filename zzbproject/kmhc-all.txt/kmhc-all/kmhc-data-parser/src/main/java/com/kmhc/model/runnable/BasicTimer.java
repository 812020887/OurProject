/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年12月1日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.runnable;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kmhc.model.task.ImeiCollectionTask;
import com.kmhc.model.util.HttpClientUtils;

/**
 * Name: BasicTimer.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.runnable.BasicTimer.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年12月1日 下午3:17:16
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class BasicTimer {
	
	private static final Timer baseTimer = new Timer();
	private static final long period = 1000*60*20;  //  20分钟
	 
	public static void startTimer(){
		//baseTimer.scheduleAtFixedRate(new WeatherAPICatchTimer(), 0l, period);
		baseTimer.scheduleAtFixedRate(new VoiceCleanTimer(), 0l, period);
	}
	

}
