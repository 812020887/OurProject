/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: czx
 *               Date: 2015年11月11日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8000;


import java.util.Arrays;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrBloodpressureMapper;
import com.kmhc.model.datacenter.model.PsrBloodpressure;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;

/**
 * Name: BloodPressureHandlerImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.BloodPressureHandlerImpl.java]
 * Description:   
 * 
 * @since JDK1.7
 * @see
 *
 * @author: czx
 * @date: 2015年11月13日 下午2:11:46
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */

@MessageCommand(type="KM8000",command="0x36")
public class BloodPressureHandlerImpl  extends AbstractHandler  {

	public static final Logger log = LoggerFactory.getLogger(BloodPressureHandlerImpl.class);
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {		
		String imei = null;
		byte[] reMsg = null;
		byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
		try{
			PsrBloodpressureMapper  bloodpressureMapper = 
					(PsrBloodpressureMapper) SpringBeanFacotry.getInstance().getBean("psrBloodpressureMapper");
						
			PsrBloodpressure record = constructRecord(msg);
			
			
			int success = bloodpressureMapper.selectByBpTime(record) ;
			if(success == 0){
				success =  bloodpressureMapper.insert(record);
			};
			
			imei = record.getImei();
			
			if(success>0){
				reMsg = AbstractHandler.ACK_SUCCESS_KM8000;
			}else{
				reMsg = AbstractHandler.ACK_ERROR_KM8000;
			}
			push(imei,record.gethPressure(),record.getlPressure(),record.getPuls(),"KM8000");                                         
			pushBP(imei,record.gethPressure(),record.getlPressure(),record.getPuls(),"KM8000",record.getBpTime()); 
		}catch(Exception e){
			log.error("记录血压信息出错。",e);
			reMsg = AbstractHandler.ACK_ERROR_KM8000;
		}
	
		ReplyMessageContent replyMessageContent = null;
		if(imei != null && reMsg != null ){
			replyMessageContent = new ReplyMessageContent(imeiBytes,reMsg);
		}
				
		return replyMessageContent;
	}
	
	/**
	 * 根据血压信息构建入库信息
	 */
	public PsrBloodpressure constructRecord(byte[] msg) {
		
		int offset = 0 ;
		String imei = parseImeiOrImsi_KM8000(msg,offset+0);
	    String imsi = parseImeiOrImsi_KM8000(msg,offset+8);
	    Date bpTime = TripleDesHelper.byte2date(Arrays.copyOfRange(msg, offset+16, 26));
	    Short hPressure = (short)(0xFF & msg[offset+23]);
	    Short lPressure = (short)(0xFF & msg[offset+24]);   
	    Short puls = (short)(0xFF & msg[offset+25]);
	    	    
	    Short model = (short)(0xFF & msg[offset+26]);
	    Short data1 = (short)(0xFF & msg[offset+27]);
	 
	    PsrBloodpressure record = new PsrBloodpressure(); 
	    
	    byte dmap1 = msg[offset+27];
	    if ((byte)(0xFFFFFF80 & dmap1) == -128) { record.setY4((short)1);  }else { record.setY4((short)0);}
	    if ((byte)(0x40 & dmap1) == 64) { record.setArr("Y"); }else { record.setArr("N");}
	    if ((byte)(0x20 & dmap1) == 32) { record.setuMode("Y"); }else { record.setuMode("N");}
	    if ((byte)(0x10 & dmap1) == 16) { record.setdMode("Y"); }else { record.setdMode("N");}
	    if ((byte)(0x8 & dmap1) == 8) { record.setRes("Y"); }else { record.setRes("N");}
	    if ((byte)(0x4 & dmap1) == 4) { record.setAm("Y"); }else { record.setAm("N");}
	    if ((byte)(0x2 & dmap1) == 2) { record.setPm("Y"); }else { record.setPm("N");}
	    if ((byte)(0x1 & dmap1) == 1) { record.setAfib("Y"); }else { record.setAfib("N");}
	  	
		
		record.setImei(imei);
		record.setImsi(imsi);
		record.setBpTime(bpTime);
		record.sethPressure(hPressure);
		record.setlPressure(lPressure);
		record.setPuls(puls);
		record.setModel(model);
		record.setData1(data1);
	    record.setTypeid(36);
		
		return record;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
