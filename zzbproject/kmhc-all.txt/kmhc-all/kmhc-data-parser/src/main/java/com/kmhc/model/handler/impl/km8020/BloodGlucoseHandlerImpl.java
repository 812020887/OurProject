/**
 * Copyright (C) 2016 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2016年7月22日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8020;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrBsMapper;
import com.kmhc.model.datacenter.model.PsrBs;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;

/**
 * Name: BloodGlucoseHandlerImpl.java ProjectName: [kmhc-data-parser] Package:
 * [com.kmhc.model.handler.impl.km8020.BloodGlucoseHandlerImpl.java]
 * Description:
 * 
 * @since JDK1.7
 * @see
 *
 * 		@author: Chris Date: 2016年7月22日 下午4:00:44
 *
 *      Update-User: @author Update-Time: Update-Remark:
 * 
 *      Check-User: Check-Time: Check-Remark:
 * 
 *      Company: kmy Copyright: kmy
 */

@MessageCommand(type = "KM8020", command = "0x543633")
public class BloodGlucoseHandlerImpl extends AbstractParentHandlerKM8020 {

	private String function = "S63";
	private static final Logger log = LoggerFactory.getLogger(BloodGlucoseHandlerImpl.class);
	private PsrBsMapper psrBsMapper = (PsrBsMapper) SpringBeanFacotry.getInstance().getBean("psrBsMapper");

	/**
	 * @Title: BloodGlucoseHandlerImpl @Description: @param @param log @throws
	 */
	public BloodGlucoseHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		log.info(new String(msg));

		// [a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T63,0,0,0,0,0,0]
		// [唯一标识,加密方式,包校验值,时间,终端类型,终端IMEI,时区,报文类型,blood_pressure,systolic_pressures,diastolic_pressures,pulse,time,timen]

		String content[] = new String(msg).split(",");
		String measureTimeStr = content[11];
		String uid = content[0];
		String imei = content[5];
		short Glu = Short.parseShort(content[9]);
		//血糖帮健康档案处理重复判定问题给时间加1秒，的暂带方案，非自身业务需求。
		measureTimeStr=measureTimeStr.substring(0, 17)+"01";
 
		String tzStr = "GMT+" + content[6];
		String timeStr = content[3];
		Date dt = com.kmhc.model.util.Date.getDate(timeStr,"yyyy-MM-dd HH:mm:ss.SSS",tzStr);
		Date measureTime = com.kmhc.model.util.Date.getDate(measureTimeStr ,"yyyy-MM-dd HH:mm:ss",tzStr);
		log.debug(sdf.format(measureTime));

		PsrBs psrBs = new PsrBs();
		psrBs.setImei(imei);
		psrBs.setImsi("");
		psrBs.setBsCount((short) 1);
		psrBs.setBsTime(measureTime);
		psrBs.setUnit((short) 2);
		psrBs.setGlu(Glu);
		psrBs.setItemno((short) 1);
		psrBs.setCreateDate(new Date());
		psrBs.setTypeid(63);

		Date now = new Date();
		Boolean flag = true;
		if((now.getTime() + (10 * 60 * 1000L))<measureTime.getTime()){
			flag = false;
		}
		if((now.getTime() - measureTime.getTime()) > (30 * 24 * 60 * 60 * 1000L)){
			flag = false;
		}

		if(psrBsMapper.selectByBsTime(psrBs) == 0 && flag){
			psrBsMapper.insert(psrBs);
			push(psrBs.getImei(), psrBs.getGlu(), psrBs.getBsTime(), psrBs.getUnit(),"KM8020");
			pushBS(psrBs.getImei(), psrBs.getGlu(), psrBs.getBsTime(), psrBs.getUnit(),"KM8020");
		}else{
			log.info("收到血糖历史数据不予保存：{}",uid+":"+content[1]+":"+content[2]+":"+sdf.format(new Date())+":"+imei+function);
		}
		push(psrBs.getImei(), psrBs.getGlu(), psrBs.getBsTime(), psrBs.getUnit(),"KM8020");
		pushBS(psrBs.getImei(), psrBs.getGlu(), psrBs.getBsTime(), psrBs.getUnit(),"KM8020");
		String out[] = { content[0], content[1], content[2], sdf.format(dt), imei, function };
		return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"), generateResponse(out));

	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
