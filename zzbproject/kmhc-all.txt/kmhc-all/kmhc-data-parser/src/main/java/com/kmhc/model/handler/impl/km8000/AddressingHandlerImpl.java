package com.kmhc.model.handler.impl.km8000;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.EmgIMapper;
import com.kmhc.model.datacenter.dao.EmgMMapper;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.EmgI;
import com.kmhc.model.datacenter.model.EmgM;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.util.LocUtil;

/**
 * Name: SosGpsHandlerImpl.java ProjectName: [kmhc-data-parser] Package:
 * [com.kmhc.model.handler.impl.km8000.SosGpsHandlerImpl.java] Description:
 * 立即寻址简讯,手表上报位置信息
 * 
 * @since JDK1.7
 * @see
 *
 * @author: xl
 * @date: 2016年4月25日 下午2:25:10
 *
 *        Update-User: @author Update-Time: Update-Remark:
 * 
 *        Check-User: Check-Time: Check-Remark:
 * 
 *        Company: kmhc Copyright: kmhc
 */
@MessageCommand(type = "KM8000", command = "0x28")
public class AddressingHandlerImpl extends AbstractParentHandlerKM8000 {

    private static final Logger log = LoggerFactory.getLogger(AddressingHandlerImpl.class);
    private String type = "28";

    public AddressingHandlerImpl() {
        super(log);
    }

    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
        byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
        writeDebugLog(msg, type);
        ReplyMessageContent result = null;
        EmgM emgm = null;
        try {
            emgm = byte2Pojo(msg);
        } catch (Exception e) {
            log.error("【type=KM8000,command=0x{}】解码失败", type);
            result = new ReplyMessageContent(imeiBytes, ACK_ERROR_KM8000);
            log.error("异常信息：", e);
        }
        try {

            // 入数据库Emg_M表
            EmgMMapper emgMMapper = (EmgMMapper) SpringBeanFacotry.getInstance().getBean("emgMMapper");
            int insert = emgMMapper.insertSelective(emgm);
            if (insert > 0) {
                result = new ReplyMessageContent(imeiBytes, process());
            }
            if (emgm.getCells().size() > 0) {
                List<EmgI> emgIList = getEmgIList(emgm.getCells(), emgm.getEmgDetailKey(), emgm.getCreateDate(),
                        emgm.getUpdateDate());
                EmgIMapper emgIMapper = (EmgIMapper) SpringBeanFacotry.getInstance().getBean("emgIMapper");
                emgIMapper.insertList(emgIList);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    private EmgM byte2Pojo(byte[] data) throws Exception {
        EmgM emgm = parseEmgBase(data, START_FRAME);
        emgm.setType(type);
        emgm.setIsvalid("Y");
        emgm.setCallerId(parseCallerId(data, START_FRAME + 23));
        Cell cell = parseCell(data, START_FRAME + 38);
        List<Cell> cellList = parseCellList(data, START_FRAME + 49);
        emgm.setCell(cell);
        emgm.setCells(cellList);
        emgm.setCellidCount((short) cellList.size());
        List<Wifi> wifiList = parseWifiList(data, START_FRAME + 60 + cellList.size() * 11);
        setCell(emgm, cell);
        setWifiList(emgm, wifiList);
        Gps locationData = parseGps(data, START_FRAME + 50 + cellList.size() * 11);                                     //这里先用一个变量存储GPS数据，后续如果判断没有GPS数据，则会用Cell数据对此变量重新赋值
        if (locationData == null || locationData.getLat() == null || locationData.getLng() == null 
                || !"NS".contains(locationData.getDirectionLat())
                || !"WE".contains(locationData.getDirectionLng())) {                                                    //如果手表上送过来的数据包本身不包含GPS数据，则根据手表上送的Cell数据，调取位置服务商API获取经纬度信息
            LocResult locresult = LocUtil.loc(emgm.getImei(), emgm.getImsi(), cell, cellList, wifiList);                //调取位置服务商API，通过Cell数据，换取经纬度信息
            if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {              //如果位置服务商API响应状态字和类型，标识有数据则更新GPS数据
                emgm.setIsvalid("Y");
                emgm.setMcellStatus("Y");
                emgm.setWifiStatus("Y");
                LocDetailResult result = locresult.getResult();
                emgm.setHpe((double)(result.getRadius()));
                String[] lngLat = result.getLocation().split(",");
                BigDecimal lng = new BigDecimal(lngLat[0].length() > 10 ? lngLat[0].substring(0, 10) : lngLat[0]);
                BigDecimal lat = new BigDecimal(lngLat[1].length() > 10 ? lngLat[1].substring(0, 10) : lngLat[1]);
                locationData = new Gps(lat, lng, "N", "E", "Y");
                locationData.setAddress(result.getDesc());
            } else {
                if (locresult != null) {
                    log.info("定位失败，status:{},info:{},result.type:{}", locresult.getStatus(), locresult.getInfo(),
                            locresult.getResult() == null ? "" : locresult.getResult().getType());
                } else {
                    log.info("定位结果返回NULL");
                }
            }
        } else {
            emgm.setHpe(10.0);
            LocUtil.conver(locationData);                                                                               //坐标转换
            String address = LocUtil.reverseGeocoding(locationData.getLat(),locationData.getLng());                     //如果GPS经纬度信息存在，则调用位置服务商逆地理编码接口获取位置描述信息
            if(address != null){
                locationData.setAddress(address);
            }
        }
        if (locationData != null) {                                                                                     //这里判断locationData中如果有值则同时入库Gps经纬度字段、Cell经纬度字段、Wifi经纬度字段
            setGps(emgm, locationData);
            emgm.setLocStatus("Y");
            emgm.setMcellLat(locationData.getLat());
            emgm.setMcellLng(locationData.getLng());
            emgm.setWifiLat(locationData.getLat());
            emgm.setWifiLng(locationData.getLng());
            emgm.setMcellAddress(locationData.getAddress());
            emgm.setWifiAddress(locationData.getAddress());
        }
        return emgm;
    }

    private String parseCallerId(byte[] data,int index){
        byte[] callerId = Arrays.copyOfRange(data, index,15);
        String callerIdStr = TripleDesHelper.byte2hex(callerId, 8);
        return callerIdStr.indexOf("#")>0?callerIdStr.substring(0, callerIdStr.indexOf("#")):callerIdStr;
    }
    
    protected List<Wifi> parseWifiList(byte[] data, int index) {
        List<Wifi> list = new ArrayList<Wifi>();
        int wiFiNum = 3;
        int wiFiIndex = index;
        if (wiFiNum > 0) {
            for (int i = 0; i < wiFiNum; i++) {
                Wifi wifi = parseWifi(data, wiFiIndex + i * 9);
                if (wifi != null) {
                    list.add(wifi);
                }
            }
        }
        return list;
    }
    
    private byte[] process() {
        return ACK_SUCCESS_KM8000;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}