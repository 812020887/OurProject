package com.kmhc.model.pojo;


public class BufferTypeSystemSetup {
	byte[][] ip_buf = { { 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48 },
			{ 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48 },
			{ 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48 } };
	private byte echoT;
	private byte echoBaseHour;
	private byte echoBaseMin;
	private byte echoBaseSec;
	private byte echoGpsT;
	private byte lineLimitOn;
	private byte lineLimit;
	private byte lineLimitMode;
	private byte lineLimitByCustomer;
	private byte lineLimitCallout_msb;
	private byte lineLimitCallout_lsb;
	private byte lineLimitCalloutFromDay;
	private byte autoReadSMS;
	private byte logo;
	private byte checksum_msb;
	private byte checksum_lsb;
	private byte test = 1;

	private byte[] byteBuffer = { /*2, 85, -86,*/ 0, 92, 16, 1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8, 35, 35, 35, 35,
			35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35,
			35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 0, 1, 2, 3, 0, 0, 0, 0, 0,
			0, 0, 1, 0, 0, 0, 0/*, -86, 85, 3*/ };

	public BufferTypeSystemSetup(SystemSetup_View ssv) {
		String[] ip = { ssv.getServer1(), ssv.getServer2(), ssv.getServer3() };
		byte[] echoTtoByte = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 32, 33, 34, 35, 36,
				37, 38, 39, 40, 41, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 80,
				81, 82, 83, 84, 85, 86, 87, 88, 89 };

		byte[] IMXItoByte = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 32, 33, 34, 35, 36,
				37, 38, 39, 40, 41, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 80,
				81, 82, 83, 84, 85, 86, 87, 88, 89, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 112, 113, 114, 115,
				116, 117, 118, 119, 120, 121, -128, -127, -126, -125, -124, -123, -122, -121, -120, -119, -112, -111,
				-110, -109, -108, -107, -106, -105, -104, -103 };

		byte[] ip_defaultBuf = { 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35 };

		for (int count = 0; count < 3; ++count) {
			int ip_sidx = 16;
			if (ip[count] == null) {
				ip[count] = "###.###.###.###:#####";
			}
			char[] ip_ch = ip[count].toCharArray();

			for (int i = 0; i < ip_ch.length; ++i) {
				System.out.print(" [" + ip_ch[i] + "]");
			}
			System.out.println();

			if (ip[count].equals("###.###.###.###:#####")) {
				this.ip_buf[count] = ip_defaultBuf;
			} else {
				int offset = 0;
				for (int i = ip_ch.length - 1; i >= 0; --i) {
					if ((ip_ch[i] != '.') && (ip_ch[i] != ':')) {
						this.ip_buf[count][(ip_sidx - offset)] = (byte) ip_ch[i];
						++offset;
					} else {
						if (ip_ch[i] == '.')
							ip_sidx -= 3;
						else {
							ip_sidx -= 5;
						}
						offset = 0;
					}
				}
			}
		}

		this.echoT = (byte) ssv.getEchoT();
		this.echoBaseHour = echoTtoByte[ssv.getEchoBaseHour()];
		this.echoBaseMin = echoTtoByte[ssv.getEchoBaseMin()];
		this.echoBaseSec = echoTtoByte[ssv.getEchoBaseSec()];

		this.echoGpsT = (byte) ssv.getEchoGpsT();

		this.lineLimitOn = (byte) ssv.getLineLimitOn();
		this.lineLimit = (byte) ssv.getLineLimit();
		this.lineLimitMode = (byte) ssv.getLineLimitMode();
		this.lineLimitByCustomer = (byte) ssv.getLineLimitByCustomer();

		int llc = ssv.getLineLimitCallout();
		this.lineLimitCallout_msb = (byte) (llc >> 8 & 0xFF);
		this.lineLimitCallout_lsb = (byte) (llc & 0xFF);

		this.lineLimitCalloutFromDay = (byte) ssv.getLineLimitCalloutFromDay();

		this.autoReadSMS = (byte) ssv.getAutoReadSMS();
		this.logo = (byte) ssv.getLogo();

		int cs_int = ssv.getChecksum();
		this.checksum_msb = (byte) (cs_int >> 8 & 0xFF);
		this.checksum_lsb = (byte) (cs_int & 0xFF);

		String imei = ssv.getImei();
		String imsi = ssv.getImsi();

		if (imsi == null) {
			imsi = "000000000000000";
		} else if (imsi.length() != 15) {
			imsi = "000000000000000";
		}

		int bbidx = 3;
		this.byteBuffer[(bbidx++)] = IMXItoByte[java.lang.Integer.parseInt(imei.substring(0, 2))];
		this.byteBuffer[(bbidx++)] = IMXItoByte[java.lang.Integer.parseInt(imei.substring(2, 4))];
		this.byteBuffer[(bbidx++)] = IMXItoByte[java.lang.Integer.parseInt(imei.substring(4, 6))];
		this.byteBuffer[(bbidx++)] = IMXItoByte[java.lang.Integer.parseInt(imei.substring(6, 8))];
		this.byteBuffer[(bbidx++)] = IMXItoByte[java.lang.Integer.parseInt(imei.substring(8, 10))];
		this.byteBuffer[(bbidx++)] = IMXItoByte[java.lang.Integer.parseInt(imei.substring(10, 12))];
		this.byteBuffer[(bbidx++)] = IMXItoByte[java.lang.Integer.parseInt(imei.substring(12, 14))];
		this.byteBuffer[(bbidx++)] = IMXItoByte[(java.lang.Integer.parseInt(imei.substring(14, 15)) * 10)];

		this.byteBuffer[(bbidx++)] = IMXItoByte[java.lang.Integer.parseInt(imsi.substring(0, 2))];
		this.byteBuffer[(bbidx++)] = IMXItoByte[java.lang.Integer.parseInt(imsi.substring(2, 4))];
		this.byteBuffer[(bbidx++)] = IMXItoByte[java.lang.Integer.parseInt(imsi.substring(4, 6))];
		this.byteBuffer[(bbidx++)] = IMXItoByte[java.lang.Integer.parseInt(imsi.substring(6, 8))];
		this.byteBuffer[(bbidx++)] = IMXItoByte[java.lang.Integer.parseInt(imsi.substring(8, 10))];
		this.byteBuffer[(bbidx++)] = IMXItoByte[java.lang.Integer.parseInt(imsi.substring(10, 12))];
		this.byteBuffer[(bbidx++)] = IMXItoByte[java.lang.Integer.parseInt(imsi.substring(12, 14))];
		this.byteBuffer[(bbidx++)] = IMXItoByte[(java.lang.Integer.parseInt(imsi.substring(14, 15)) * 10)];

		for (int i = 0; i < 3; ++i) {
			for (int j = 0; j < 17; ++j) {
				this.byteBuffer[(bbidx++)] = this.ip_buf[i][j];
			}
		}

		this.byteBuffer[(bbidx++)] = this.echoT;
		this.byteBuffer[(bbidx++)] = this.echoBaseHour;
		this.byteBuffer[(bbidx++)] = this.echoBaseMin;
		this.byteBuffer[(bbidx++)] = this.echoBaseSec;

		this.byteBuffer[(bbidx++)] = this.echoGpsT;
		this.byteBuffer[(bbidx++)] = this.lineLimitOn;
		this.byteBuffer[(bbidx++)] = this.lineLimit;
		this.byteBuffer[(bbidx++)] = this.lineLimitMode;
		this.byteBuffer[(bbidx++)] = this.lineLimitByCustomer;

		this.byteBuffer[(bbidx++)] = this.lineLimitCallout_msb;
		this.byteBuffer[(bbidx++)] = this.lineLimitCallout_lsb;
		this.byteBuffer[(bbidx++)] = this.lineLimitCalloutFromDay;
		this.byteBuffer[(bbidx++)] = this.autoReadSMS;
		this.byteBuffer[(bbidx++)] = this.logo;
		this.byteBuffer[(bbidx++)] = this.checksum_msb;
		this.byteBuffer[(bbidx++)] = this.checksum_lsb;
	}

	public byte[] getByteBuffer() {
		return this.byteBuffer;
	}

	public void setByteBuffer(byte[] byteBuffer) {
		this.byteBuffer = byteBuffer;
	}

	public byte[][] getIp_buf() {
		return this.ip_buf;
	}

	public void setIp_buf(byte[][] ip_buf) {
		this.ip_buf = ip_buf;
	}

	public byte getEchoT() {
		return this.echoT;
	}

	public void setEchoT(byte echoT) {
		this.echoT = echoT;
	}

	public byte getEchoBaseHour() {
		return this.echoBaseHour;
	}

	public void setEchoBaseHour(byte echoBaseHour) {
		this.echoBaseHour = echoBaseHour;
	}

	public byte getEchoBaseMin() {
		return this.echoBaseMin;
	}

	public void setEchoBaseMin(byte echoBaseMin) {
		this.echoBaseMin = echoBaseMin;
	}

	public byte getEchoBaseSec() {
		return this.echoBaseSec;
	}

	public void setEchoBaseSec(byte echoBaseSec) {
		this.echoBaseSec = echoBaseSec;
	}

	public byte getEchoGpsT() {
		return this.echoGpsT;
	}

	public void setEchoGpsT(byte echoGpsT) {
		this.echoGpsT = echoGpsT;
	}

	public byte getLineLimitOn() {
		return this.lineLimitOn;
	}

	public void setLineLimitOn(byte lineLimitOn) {
		this.lineLimitOn = lineLimitOn;
	}

	public byte getLineLimit() {
		return this.lineLimit;
	}

	public void setLineLimit(byte lineLimit) {
		this.lineLimit = lineLimit;
	}

	public byte getLineLimitMode() {
		return this.lineLimitMode;
	}

	public void setLineLimitMode(byte lineLimitMode) {
		this.lineLimitMode = lineLimitMode;
	}

	public byte getLineLimitByCustomer() {
		return this.lineLimitByCustomer;
	}

	public void setLineLimitByCustomer(byte lineLimitByCustomer) {
		this.lineLimitByCustomer = lineLimitByCustomer;
	}

	public byte getLineLimitCallout_msb() {
		return this.lineLimitCallout_msb;
	}

	public void setLineLimitCallout_msb(byte lineLimitCallout_msb) {
		this.lineLimitCallout_msb = lineLimitCallout_msb;
	}

	public byte getLineLimitCallout_lsb() {
		return this.lineLimitCallout_lsb;
	}

	public void setLineLimitCallout_lsb(byte lineLimitCallout_lsb) {
		this.lineLimitCallout_lsb = lineLimitCallout_lsb;
	}

	public byte getLineLimitCalloutFromDay() {
		return this.lineLimitCalloutFromDay;
	}

	public void setLineLimitCalloutFromDay(byte lineLimitCalloutFromDay) {
		this.lineLimitCalloutFromDay = lineLimitCalloutFromDay;
	}

	public byte getAutoReadSMS() {
		return this.autoReadSMS;
	}

	public void setAutoReadSMS(byte autoReadSMS) {
		this.autoReadSMS = autoReadSMS;
	}

	public byte getLogo() {
		return this.logo;
	}

	public void setLogo(byte logo) {
		this.logo = logo;
	}

	public byte getChecksum_msb() {
		return this.checksum_msb;
	}

	public void setChecksum_msb(byte checksum_msb) {
		this.checksum_msb = checksum_msb;
	}

	public byte getChecksum_lsb() {
		return this.checksum_lsb;
	}

	public void setChecksum_lsb(byte checksum_lsb) {
		this.checksum_lsb = checksum_lsb;
	}

	public byte getTest() {
		return this.test;
	}

	public void setTest(byte test) {
		this.test = test;
	}
}
