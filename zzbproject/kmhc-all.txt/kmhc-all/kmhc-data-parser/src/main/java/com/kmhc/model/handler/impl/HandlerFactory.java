package com.kmhc.model.handler.impl;

import com.kmhc.model.handler.IFactory;
import com.kmhc.model.handler.IHandler;

public class HandlerFactory implements IFactory<IHandler>{
	
	IHandler handler = null;
	
	public IHandler createClass(String className) {
		// TODO Auto-generated method stub
		try {
			handler = (IHandler) Class.forName(className).newInstance();
		} catch (Exception  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return handler;
	}
}
