package com.kmhc.model.handler.impl.km8020;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.ServerActionHisMapper;
import com.kmhc.model.datacenter.dao.T9LbsSettingMapper;
import com.kmhc.model.datacenter.model.ServerActionHis;
import com.kmhc.model.datacenter.model.T9LbsSetting;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;

@MessageCommand(type = "KM8020", command = "0x543239")
public class LBSSettingHandlerImpl extends AbstractParentHandlerKM8020 {

	private static final Logger log = LoggerFactory.getLogger(LBSSettingHandlerImpl.class);
	private ServerActionHisMapper serverActionHisMapper = (ServerActionHisMapper) SpringBeanFacotry.getInstance().getBean("serverActionHisMapper");
	private T9LbsSettingMapper t9LbsSettingMapper = (T9LbsSettingMapper) SpringBeanFacotry.getInstance().getBean("t9LbsSettingMapper");
	
	public LBSSettingHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		//a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,355372020827303,S29,10:00:05,10:58:09,60  in server_action_his content
		//[V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T29]
		log.info(new String(msg));
		String protocol = "S29";
		String content[] = new String(msg).split(",");
		String uid = content[0];
		String imei = content[5];
		
		ServerActionHis record = serverActionHisMapper.selectByPrimaryKey(uid, imei, protocol);
		if( record != null){
			String command[] = record.getContent().split(",");
			String starttime = command[7];
			String endtime = command[8];
			int span = Integer.parseInt(command[9]);
			
			int flag = 0;
			T9LbsSetting lbsSetting = null;			
			lbsSetting = t9LbsSettingMapper.selectByPrimaryKey(imei);
			if( lbsSetting == null ) {
				lbsSetting = new T9LbsSetting();
				flag = 1;
			}
			lbsSetting.setImei(imei);
			lbsSetting.setStarttime(starttime);
			lbsSetting.setEndtime(endtime);
			lbsSetting.setSpan(span);
			lbsSetting.setUpdatedate(new Date());
			
			int success = 0;
			try{
				if(flag == 0) success = t9LbsSettingMapper.updateByPrimaryKey(lbsSetting);
				else {
					lbsSetting.setCreatedate(new Date());
					success = t9LbsSettingMapper.insert(lbsSetting);
				}
			}catch(Exception e){
				log.error(e.toString());
			}
			
			if(success > 0){
				serverActionHisMapper.deleteByPrimaryKey(record.getUid(), record.getImei(), protocol);
				pushSettingFinish(imei,INotification.NOTIFICATION_TYPE_SETTING_LBS_TIME_RANGE);
				push8000Gps(imei,"KM8020","S29");
			}
		}
//		log.info("push fail notification to app");
		return null;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
