/**
 * Copyright (C) 2016 kmhc-data-parser Project
 * Author: Chris
 * Date: 2016年7月25日
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8020;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.MemberSettingHeartrateMapper;
import com.kmhc.model.datacenter.dao.ServerActionHisMapper;
import com.kmhc.model.datacenter.dao.T9DeviceStatusMapper;
import com.kmhc.model.datacenter.model.MemberSettingHeartrate;
import com.kmhc.model.datacenter.model.ServerActionHis;
import com.kmhc.model.datacenter.model.T9DeviceStatus;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;

/**
 * Name: HeartRateWarningSettingConfirm.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8020.HeartRateWarningSettingConfirm.java]
 * Description: TODO  
 *
 * @since JDK1.7
 * @see
 *
 * Author: @author: Chris
 * Date: 2016年7月25日 下午5:58:44
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 *
 * Check-User:
 * Check-Time:
 * Check-Remark:
 *
 * Company: kmy
 * Copyright: kmy
 */
//T39
@MessageCommand(type = "KM8020", command = "0x543339")
public class HeartRateWarningSettingConfirm
        extends AbstractParentHandlerKM8020 {

    private ServerActionHisMapper serverActionHisMapper = (ServerActionHisMapper) SpringBeanFacotry.getInstance().getBean("serverActionHisMapper");
    private MemberSettingHeartrateMapper memberSettingHeartrateMapper = (MemberSettingHeartrateMapper) SpringBeanFacotry.getInstance().getBean("memberSettingHeartrateMapper");
    private T9DeviceStatusMapper t9DeviceStatusMapper = (T9DeviceStatusMapper) SpringBeanFacotry.getInstance().getBean("t9DeviceStatusMapper");
    private static final Logger log = LoggerFactory.getLogger(HeartRateWarningSettingConfirm.class);


    public HeartRateWarningSettingConfirm() {
        super(log);
    }

    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {

        //[V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,355372020827303,S39,55,140,1]
        log.info(new String(msg));
        String content[] = new String(msg).split(",");
        String imei = content[5];
        String protocol = "S39";
        String uid = content[0];

        ServerActionHis sah = serverActionHisMapper.selectByPrimaryKey(uid, imei, protocol);

        if (sah != null) {
            String[] his = sah.getContent().split(",");
            MemberSettingHeartrate setting = new MemberSettingHeartrate();
            T9DeviceStatus t9 = t9DeviceStatusMapper.selectByImei(imei);
            setting.setCreateDate(new Date());
            setting.setHeartAge(0);
            setting.setHeartRateHigh(Integer.parseInt(his[8]));
            setting.setHeartRateLow(Integer.parseInt(his[7]));
            setting.setHeartRateRisk(0.0);
            setting.setImei(imei);
            setting.setUpdateDate(new Date());
            if (memberSettingHeartrateMapper.selectByPrimaryKey(imei) == null)
                memberSettingHeartrateMapper.insert(setting);
            else
                memberSettingHeartrateMapper.update(setting);

            t9.setHrAlarmStatus(Integer.parseInt(his[9]));
            t9DeviceStatusMapper.updateByPrimaryKey(t9);
            serverActionHisMapper.deleteByPrimaryKey(sah.getUid(), sah.getImei(), "S39");
            pushSettingFinish(imei, INotification.NOTIFICATION_TYPE_SETTING_HR_ALERT);
        }

        return null;
    }

    @Override
    public boolean handleMessage(String json) {
        // TODO Auto-generated method stub
        return false;
    }


}
