package com.kmhc.model.handler.impl.km8000;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.EmgM;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.datacenter.pojo.PacketTypeLocatorWifi;
import com.kmhc.model.datacenter.pojo.WiFi;
import com.kmhc.model.datacenter.service.IEmgService;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.handler.impl.PushAlert;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.LogCenter;
import com.kmhc.model.util.Publish;

@MessageCommand(type = "KM8000", command = "0x26")
public class ImmediateAddressingHandlerImpl extends AbstractHandler {

	private static final Logger log = LoggerFactory.getLogger(ImmediateAddressingHandlerImpl.class);

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {

		String imei = null;
		byte[] reMsg = null;
		byte[] imeiBytes = null;
		try {

			imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
			imei = parseImeiOrImsi_KM8000(msg, 0);
			String imsi = parseImeiOrImsi_KM8000(msg, 8);
			PacketTypeLocatorWifi ptlWifi = new PacketTypeLocatorWifi(msg, imei, imsi);

			/*
			 * if (!(ptlWifi.getMygps().getLatDispStr().equals("N"))
			 * &&!(ptlWifi.getMygps().getLatDispStr().equals("E"))){
			 * LogCenter.exception.error("上传的26报文信息有错误；"); return null; }
			 */

			EmgM emgm = getLocationInfo(ptlWifi);

			// 入数据库Emg_M表
			IEmgService emgService = (IEmgService) SpringBeanFacotry.getInstance().getBean("emgService");

			emgService.insertEmg(emgm);

			reMsg = AbstractHandler.ACK_SUCCESS_KM8000;

		} catch (Exception e) {
			LogCenter.exception.error("", e);
			reMsg = AbstractHandler.ACK_ERROR_KM8000;
		}

		ReplyMessageContent replyMessageContent = null;
		if (imei != null && reMsg != null) {
			push8000Gps(imei,"KM8000","0x26");
			replyMessageContent = new ReplyMessageContent(imeiBytes, reMsg);
		}
		// new Pusher().push("8", imei);
		// 向手机APP推送通知，APP接收到通知后更新设备位置信息
		push(imei);
	
		return replyMessageContent;
	}

	/**
	 * 获取地址信息
	 * 
	 * @throws Exception
	 */
	private EmgM getLocationInfo(PacketTypeLocatorWifi pr) throws Exception {

		ArrayList<Cell> cells = new ArrayList<Cell>();
		for (int j = 0; pr.getEffectiveCellID() != null && j < pr.getEffectiveCellID().size(); j++) {
			Cell cell = new Cell();
			com.kmhc.model.datacenter.pojo.Cell temp = pr.getEffectiveCellID().get(j);

			cell.setCellid(temp.getCellid());
			cell.setLac(String.valueOf(temp.getLac()));
			cell.setMcc(String.valueOf(temp.getMcc()));
			cell.setMnc(String.valueOf(temp.getMnc()));
			cell.setRssi((short) (0xFF & temp.getRssi()));

			cells.add(cell);

		}

		ArrayList<Wifi> wifis = new ArrayList<Wifi>();
		for (int j = 0; pr.getEffectiveWifi() != null && j < pr.getEffectiveWifi().size(); j++) {
			Wifi wifi = new Wifi();

			WiFi temp = pr.getEffectiveWifi().get(j);

			wifi.setWifiChannel((short) temp.getChannel());
			wifi.setWifiMac(temp.getMac());
			wifi.setWifiRatio((short) temp.getSignal_dB());
			wifi.setWifiSignal((short) temp.getSignalLevel());

			wifis.add(wifi);

		}

		Cell cell = new Cell();
		com.kmhc.model.datacenter.pojo.Cell temp = pr.getCellID();
		cell.setCellid(temp.getCellid());
		cell.setLac(String.valueOf(temp.getLac()));
		cell.setMcc(String.valueOf(temp.getMcc()));
		cell.setMnc(String.valueOf(temp.getMnc()));
		cell.setRssi(temp.getRssi());

		return byte2Pojo(pr, cell, cells, wifis);
	}

	private EmgM byte2Pojo(PacketTypeLocatorWifi pr, Cell cell, ArrayList<Cell> cellList, ArrayList<Wifi> wifiList)
			throws Exception {
		EmgM emgm = new EmgM();

		emgm = this.convert(pr, emgm);

		Gps locationData = new Gps(pr.getMygps().getLat(), pr.getMygps().getLng(), pr.getMygps().getLatDispStr(),
				pr.getMygps().getLngDispStr(), "Y");
		; // 这里先用一个变量存储GPS数据，后续如果判断没有GPS数据，则会用Cell数据对此变量重新赋值
		if (locationData == null || locationData.getLat() == null || locationData.getLng() == null
				|| !"NS".contains(locationData.getDirectionLat()) || !"WE".contains(locationData.getDirectionLng())) { // 如果手表上送过来的数据包本身不包含GPS数据，则根据手表上送的Cell数据，调取位置服务商API获取经纬度信息
			LocResult locresult = LocUtil.loc(emgm.getImei(), emgm.getImsi(), cell, cellList, wifiList); // 调取位置服务商API，通过Cell数据，换取经纬度信息
			if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) { // 如果位置服务商API响应状态字和类型，标识有数据则更新GPS数据
				emgm.setIsvalid("Y");
				emgm.setMcellStatus("Y");
				emgm.setWifiStatus("Y");
				LocDetailResult result = locresult.getResult();
				emgm.setHpe((double) (result.getRadius()));
				String[] lngLat = result.getLocation().split(",");
				BigDecimal lng = new BigDecimal(lngLat[0].length() > 10 ? lngLat[0].substring(0, 10) : lngLat[0]);
				BigDecimal lat = new BigDecimal(lngLat[1].length() > 10 ? lngLat[1].substring(0, 10) : lngLat[1]);
				locationData = new Gps(lat, lng, "N", "E", "Y");
				locationData.setAddress(result.getDesc());
			} else {
				if (locresult != null) {
					log.info("定位失败，status:{},info:{},result.type:{}", locresult.getStatus(), locresult.getInfo(),
							locresult.getResult() == null ? "" : locresult.getResult().getType());
				} else {
					log.info("定位结果返回NULL");
				}
			}
		} else {
			emgm.setHpe(10.0);
			LocUtil.conver(locationData); // 坐标转换
			String address = LocUtil.reverseGeocoding(locationData.getLat(), locationData.getLng()); // 如果GPS经纬度信息存在，则调用位置服务商逆地理编码接口获取位置描述信息
			if (address != null) {
				locationData.setAddress(address);
			}
		}
		if (locationData != null) { // 这里判断locationData中如果有值则同时入库Gps经纬度字段、Cell经纬度字段、Wifi经纬度字段

			String lat = locationData.getLat().toString();
			String lng = locationData.getLng().toString();

			locationData.setLat(new BigDecimal(lat.length() > 10 ? lat.substring(0, 10) : lat));
			locationData.setLng(new BigDecimal(lng.length() > 10 ? lng.substring(0, 10) : lng));

			setGps(emgm, locationData);
			emgm.setLocStatus("Y");
			emgm.setMcellLat(locationData.getLat());
			emgm.setMcellLng(locationData.getLng());
			emgm.setWifiLat(locationData.getLat());
			emgm.setWifiLng(locationData.getLng());
			emgm.setMcellAddress(locationData.getAddress());
			emgm.setWifiAddress(locationData.getAddress());
		}

		String lat = emgm.getMyGpsLat().toString();
		String lng = emgm.getMyGpsLng().toString();
		emgm.setMyGpsLat(new BigDecimal(lat.length() > 10 ? lat.substring(0, 10) : lat));
		emgm.setMyGpsLng(new BigDecimal(lng.length() > 10 ? lng.substring(0, 10) : lng));

		return emgm;
	}

	private EmgM convert(PacketTypeLocatorWifi pr, EmgM emgm) {

		emgm.setEmgKey(pr.getEmgKey());
		emgm.setImei(pr.getImei());
		emgm.setImsi(pr.getImsi());
		emgm.setType("28");
		emgm.setEmgDetailKey(pr.getEmgKey() + pr.getImei());
		emgm.setEmgDate(pr.getEventDate());

		emgm.setFwDate(null);
		emgm.setPowerOffType(0);
		emgm.setVoltage(0);

		emgm.setCallerId(pr.getCallerID());

		emgm.setCellidCount((short) pr.getCellNum());
		emgm.setMcc(String.valueOf(pr.getCellID().getMcc()));
		emgm.setMnc(String.valueOf(pr.getCellID().getMnc()));
		emgm.setLac(String.valueOf(pr.getCellID().getLac()));
		emgm.setCellid(pr.getCellID().getCellid());
		emgm.setRssi((short) pr.getCellID().getRssi());

		emgm.setGpsNsLat(pr.getGps().getLatDispStr());
		emgm.setGpsLat(new BigDecimal(pr.getGps().getLat()));
		emgm.setGpsEwLng(pr.getGps().getLngDispStr());
		emgm.setGpsLng(new BigDecimal(pr.getGps().getLng()));

		emgm.setAddress(pr.getGps().getAddress());

		emgm.setWifiLat(new BigDecimal(0));
		emgm.setWifiLng(new BigDecimal(0));
		emgm.setWifiStatus("Z");
		emgm.setWifiAddress("");

		emgm.setMyGpsNsLat(pr.getMygps().getLatDispStr());
		emgm.setMyGpsLat(new BigDecimal(pr.getMygps().getLat()));
		emgm.setMyGpsEwLng(pr.getMygps().getLngDispStr());
		emgm.setMyGpsLng(new BigDecimal(pr.getMygps().getLng()));

		if (pr.getEffectiveWifi() != null) {
			for (int j = 0; j < pr.getEffectiveWifi().size(); ++j) {
				WiFi wifi = (WiFi) pr.getEffectiveWifi().get(j);
				if ((wifi.getMac() != null) || (!(wifi.getMac().equals("000000000000")))) {
					switch (j) {
					case 0:
						emgm.setWifiMac1(wifi.getMac().toUpperCase());
						emgm.setWifiSignal1((short) wifi.getSignalLevel());
						emgm.setWifiChannel1((short) wifi.getChannel());
						emgm.setWifiRatio1((short) wifi.getSignal_dB());

						break;
					case 1:
						emgm.setWifiMac2(wifi.getMac().toUpperCase());
						emgm.setWifiSignal2((short) wifi.getSignalLevel());
						emgm.setWifiChannel2((short) wifi.getChannel());
						emgm.setWifiRatio2((short) wifi.getSignal_dB());

						break;
					case 2:
						emgm.setWifiMac3(wifi.getMac().toUpperCase());
						emgm.setWifiSignal3((short) wifi.getSignalLevel());
						emgm.setWifiChannel3((short) wifi.getChannel());
						emgm.setWifiRatio3((short) wifi.getSignal_dB());

						break;
					case 3:
						emgm.setWifiMac4(wifi.getMac().toUpperCase());
						emgm.setWifiSignal4((short) wifi.getSignalLevel());
						emgm.setWifiChannel4((short) wifi.getChannel());
						emgm.setWifiRatio4((short) wifi.getSignal_dB());

						break;
					case 4:
						emgm.setWifiMac5(wifi.getMac().toUpperCase());
						emgm.setWifiSignal5((short) wifi.getSignalLevel());
						emgm.setWifiChannel5((short) wifi.getChannel());
						emgm.setWifiRatio5((short) wifi.getSignal_dB());

						break;
					case 5:
						emgm.setWifiMac6(wifi.getMac().toUpperCase());
						emgm.setWifiSignal6((short) wifi.getSignalLevel());
						emgm.setWifiChannel6((short) wifi.getChannel());
						emgm.setWifiRatio6((short) wifi.getSignal_dB());

						break;
					case 6:
						emgm.setWifiMac7(wifi.getMac().toUpperCase());
						emgm.setWifiSignal7((short) wifi.getSignalLevel());
						emgm.setWifiChannel7((short) wifi.getChannel());
						emgm.setWifiRatio7((short) wifi.getSignal_dB());

						break;
					case 7:
						emgm.setWifiMac8(wifi.getMac().toUpperCase());
						emgm.setWifiSignal8((short) wifi.getSignalLevel());
						emgm.setWifiChannel8((short) wifi.getChannel());
						emgm.setWifiRatio8((short) wifi.getSignal_dB());

						break;
					case 8:
						emgm.setWifiMac9(wifi.getMac().toUpperCase());
						emgm.setWifiSignal9((short) wifi.getSignalLevel());
						emgm.setWifiChannel9((short) wifi.getChannel());
						emgm.setWifiRatio9((short) wifi.getSignal_dB());

						break;
					case 9:
						emgm.setWifiMac10(wifi.getMac().toUpperCase());
						emgm.setWifiSignal10((short) wifi.getSignalLevel());
						emgm.setWifiChannel10((short) wifi.getChannel());
						emgm.setWifiRatio10((short) wifi.getSignal_dB());
					}
				}

			}

		}

		emgm.setIsvalid(pr.getIsValid());
		emgm.setLocStatus(pr.getLoc_ststus());

		Date nowDate = new Date();
		emgm.setCreateDate(nowDate);
		emgm.setUpdateDate(nowDate);
		emgm.setHpe(pr.getAcc());

		ArrayList<Cell> cells = new ArrayList<Cell>();
		for (int j = 0; pr.getEffectiveCellID() != null && j < pr.getEffectiveCellID().size(); j++) {

			Cell cell = new Cell();
			com.kmhc.model.datacenter.pojo.Cell temp = pr.getEffectiveCellID().get(j);
			cell.setCellid(temp.getCellid());
			cell.setLac(String.valueOf(temp.getLac()));
			cell.setMcc(String.valueOf(temp.getMcc()));
			cell.setMnc(String.valueOf(temp.getMnc()));
			cell.setRssi((short) (0xFF & temp.getRssi()));
			cells.add(cell);
		}
		emgm.setCells(cells);

		return emgm;
	}

	public void push(String imei) {
		String alert = new PushAlert(new Object[] { imei }, "discovery_address_complete_key").toString();
		String title = "discovery_address_key";
		String extras = "";
		int builder_id = INotification.ANDROID_MAKER_DEFAULT;
		extras = String.format("imei=%s|", imei);
		extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_DEFAULT);
		extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_LOW);
		extras += String.format("builder_id=%d|", INotification.ANDROID_MAKER_DEFAULT);
		extras += "device=KM8000|";
		Publish.push(imei, alert, title, builder_id, extras);
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
