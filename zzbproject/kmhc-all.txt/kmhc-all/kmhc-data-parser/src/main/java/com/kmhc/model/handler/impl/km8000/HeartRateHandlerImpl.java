package com.kmhc.model.handler.impl.km8000;

import java.util.Arrays;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.PacketUtil;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrHeartrateMapper;
import com.kmhc.model.datacenter.model.PsrHeartrate;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.LogCenter;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type="KM8000",command="0x34") 
public class HeartRateHandlerImpl  extends AbstractHandler {

	private static PsrHeartrateMapper psrHeartrateMapper = 
			(PsrHeartrateMapper) SpringBeanFacotry.getInstance().getBean("psrHeartrateMapper");
	
	public static final Logger log = LoggerFactory.getLogger(BloodSugarHandlerImpl.class);
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {

		String imei = null;
		byte[] reMsg = null;
		byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
		try{
			
			PsrHeartrate heartRate = constructRecord(msg);

			int success = psrHeartrateMapper.selectByBpTime(heartRate);
			if(success == 0){
				success =   psrHeartrateMapper.insert(heartRate);
			};
			
			
			push(heartRate.getImei(),heartRate.getHeartRate(),"KM8000");
			pushHR(heartRate.getImei(),heartRate.getHeartRate(),"KM8000",heartRate.getBsTime());
			
			if(success>0){
				imei=heartRate.getImei();
				reMsg = AbstractHandler.ACK_SUCCESS_KM8000;
			}else{
				reMsg = AbstractHandler.ACK_ERROR_KM8000;
			}

		}catch(Exception e){
			LogCenter.exception.error("",e);
			return MessageBuilder.buildReplyMessageContent(imeiBytes, ACK_ERROR_KM8000);
		}
		
		ReplyMessageContent replyMessageContent = null;
		if(imei != null && reMsg != null ){
			replyMessageContent = new ReplyMessageContent(imeiBytes,reMsg);
		}
				
		return replyMessageContent;
	}
	
	private PsrHeartrate constructRecord(byte[] msg){
		
		PsrHeartrate heartRate = new PsrHeartrate();
		
		int offset = 0 ;
		String imei = parseImeiOrImsi_KM8000(msg,offset+0);
	    String imsi = parseImeiOrImsi_KM8000(msg,offset+8);
	    
	    Date bsTime = TripleDesHelper.byte2date(Arrays.copyOfRange(msg, offset+16, 26));
		
	    offset=offset+16+7; //imei+imsi+time = 16+7
	    
	    heartRate.setImei(imei);
	    heartRate.setImsi(imsi);
	    heartRate.setTypeid(34);
	    heartRate.setHeartRate((int) PacketUtil.toShort(msg[(offset++)], msg[(offset++)]));
	    heartRate.setBsTime(bsTime);
	    
	    return heartRate;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
