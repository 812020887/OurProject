package com.kmhc.model.handler;

public interface IFactory<T> {
	public <T extends IHandler> IHandler createClass(String className);
}