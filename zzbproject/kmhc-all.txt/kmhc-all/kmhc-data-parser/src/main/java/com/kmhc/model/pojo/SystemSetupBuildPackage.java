package com.kmhc.model.pojo;

import java.io.UnsupportedEncodingException;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.ByteBuffer;

import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.datacenter.model.ProductPerSettingM;

public class SystemSetupBuildPackage {

    public byte[] build(ProductPerSettingM m) throws UnsupportedEncodingException {
        ByteBuffer buffer = ByteBuffer.allocate(1024);

        buffer.put(new byte[] { 0, 0 }); // 预留封包长度空间
        buffer.put((byte) (0xFF & 0x11)); // 封包类别
        buffer.put(TripleDesHelper.hex2byte(m.getImei() + "0"));
        buffer.put(TripleDesHelper.hex2byte(m.getImsi() + "0"));
        buffer.put(shortToByte(m.getSosKeyDelay()));
        buffer.put(shortToByte(m.getFmlyKeyDelay()));
        buffer.put(shortToByte(m.getSosSms()));
        buffer.put(shortToByte(m.getFallSms()));
        buffer.put(shortToByte(m.getNonDistrub()));
        buffer.put(shortToByte(m.getTimezone()));

        buffer.put(stringToBytePadded(m.getSosPhoneNo1(), 15, "#"));
        buffer.put(stringToBytePadded(m.getSosPhoneNo2(), 15, "#"));
        buffer.put(stringToBytePadded(m.getSosPhoneNo3(), 15, "#"));

        buffer.put(stringToBytePadded(m.getFallPhoneNo1(), 15, "#"));
        buffer.put(stringToBytePadded(m.getFallPhoneNo2(), 15, "#"));
        buffer.put(stringToBytePadded(m.getFallPhoneNo3(), 15, "#"));

        buffer.put(shortToByte(m.getFamilyIcon1()));
        buffer.put(stringToBytePadded(m.getFmlyPhoneNo1(), 15, "#"));
        buffer.put(shortToByte(m.getFamilyIcon2()));
        buffer.put(stringToBytePadded(m.getFmlyPhoneNo2(), 15, "#"));
        buffer.put(shortToByte(m.getFamilyIcon3()));
        buffer.put(stringToBytePadded(m.getFmlyPhoneNo3(), 15, "#"));

        buffer.put(shortToByte(m.getMedT1On()));
        buffer.put(shortToByte(m.getMedT1Hh()));
        buffer.put(shortToByte(m.getMedT1Mm()));
        buffer.put(shortToByte(m.getMedT1WeekdayFilter()));

        buffer.put(shortToByte(m.getMedT2On()));
        buffer.put(shortToByte(m.getMedT2Hh()));
        buffer.put(shortToByte(m.getMedT2Mm()));
        buffer.put(shortToByte(m.getMedT2WeekdayFilter()));

        buffer.put(shortToByte(m.getMedT3On()));
        buffer.put(shortToByte(m.getMedT3Hh()));
        buffer.put(shortToByte(m.getMedT3Mm()));
        buffer.put(shortToByte(m.getMedT3WeekdayFilter()));
        
        buffer.put(shortToByte(m.getMedT4On()));
        buffer.put(shortToByte(m.getMedT4Hh()));
        buffer.put(shortToByte(m.getMedT4Mm()));
        buffer.put(shortToByte(m.getMedT4WeekdayFilter()));

        buffer.put(shortToByte(m.getMedT5On()));
        buffer.put(shortToByte(m.getMedT5Hh()));
        buffer.put(shortToByte(m.getMedT5Mm()));
        buffer.put(shortToByte(m.getMedT5WeekdayFilter()));

        buffer.put(shortToByte(m.getMedD1On()));
        buffer.put((byte) (m.getMedD1Yy() >> 8 & 0xFF));
        buffer.put(shortToByte(m.getMedD1Yy()));
        buffer.put(shortToByte(m.getMedD1Mm()));
        buffer.put(shortToByte(m.getMedD1Dd()));
        buffer.put(shortToByte(m.getMedD1Hour()));
        buffer.put(shortToByte(m.getMedD1Minute()));

        buffer.put(shortToByte(m.getMedD2On()));
        buffer.put((byte) (m.getMedD2Yy() >> 8 & 0xFF));
        buffer.put(shortToByte(m.getMedD2Yy()));
        buffer.put(shortToByte(m.getMedD2Mm()));
        buffer.put(shortToByte(m.getMedD2Dd()));
        buffer.put(shortToByte(m.getMedD2Hour()));
        buffer.put(shortToByte(m.getMedD2Minute()));

        buffer.put(shortToByte(m.getWhiteListOn()));
        batchSetPhone("getWhiteListPhone", 20, m, buffer);
        buffer.put(shortToByte(m.getFallDetect()));

        buffer.put(shortTobytes(m.getFallLowLg()));
        buffer.put(shortTobytes(m.getFallLowHg()));
        buffer.put(shortTobytes(m.getFallLowFl()));
        buffer.put(shortTobytes(m.getFallLowFt()));
        buffer.put(shortTobytes(m.getFallLowSt()));
        buffer.put(shortTobytes(m.getFallLowWt()));
        buffer.put(shortTobytes(m.getFallLowRes1()));
        buffer.put(shortTobytes(m.getFallLowRes2()));

        buffer.put(shortTobytes(m.getFallMidLg()));
        buffer.put(shortTobytes(m.getFallMidHg()));
        buffer.put(shortTobytes(m.getFallMidFl()));
        buffer.put(shortTobytes(m.getFallMidFt()));
        buffer.put(shortTobytes(m.getFallMidSt()));
        buffer.put(shortTobytes(m.getFallMidWt()));
        buffer.put(shortTobytes(m.getFallMidRes1()));
        buffer.put(shortTobytes(m.getFallMidRes2()));

        buffer.put(shortTobytes(m.getFallHiLg()));
        buffer.put(shortTobytes(m.getFallHiHg()));
        buffer.put(shortTobytes(m.getFallHiFl()));
        buffer.put(shortTobytes(m.getFallHiFt()));
        buffer.put(shortTobytes(m.getFallHiSt()));
        buffer.put(shortTobytes(m.getFallHiWt()));
        buffer.put(shortTobytes(m.getFallHiRes1()));
        buffer.put(shortTobytes(m.getFallHiRes2()));
        buffer.put(shortToByte(m.getSetLang()));
        buffer.put(shortToByte(m.getSpeakLang()));

        buffer.put(stringToBytePadded(m.getuAccountid(), 15, "0"), 0, 15);
        buffer.put(stringToBytePadded(m.getuName(), 15, "0"), 0, 10);
        buffer.put(shortToByte(m.getuSex()));
        buffer.put(shortToByte(m.getuAge()));
        buffer.put(shortTobytes(m.getuBirthdateYy()));
        buffer.put(shortToByte(m.getuBirthdateMm()));
        buffer.put(shortToByte(m.getuBirthdateDd()));
        buffer.put(shortToByte(m.getuUnit()));
        buffer.put(shortTobytes((short) (m.getuHeight().intValue() * 10)));
        buffer.put(shortTobytes((short) (m.getuIdealWeight().intValue() * 10)));
        buffer.put(shortTobytes((short) (m.getuWeight().intValue() * 10)));
        buffer.put(shortTobytes((short) m.getuStep()));
        buffer.put(shortToByte(m.getuSystolicUpperLimit()));
        buffer.put(shortToByte(m.getuSystolicLowerLimit()));
        buffer.put(shortToByte(m.getuDiastolicUpperLimit()));
        buffer.put(shortToByte(m.getuDaistolicLowerLimit()));

        buffer.put(shortTobytes(m.getActiveG()));
        buffer.put(shortTobytes(m.getActiveGyro()));

        buffer.put(shortToByte(m.getEfT1On()));
        buffer.put(shortToByte(m.getEfST1Hh()));
        buffer.put(shortToByte(m.getEfST1Mm()));
        buffer.put(shortToByte(m.getEfET1Hh()));
        buffer.put(shortToByte(m.getEfET1Mm()));
        buffer.put(shortToByte(m.getEfT1WeekdayFilter()));
        buffer.put(shortToByte(m.getEfT2On()));
        buffer.put(shortToByte(m.getEfST2Hh()));
        buffer.put(shortToByte(m.getEfST2Mm()));
        buffer.put(shortToByte(m.getEfET2Hh()));
        buffer.put(shortToByte(m.getEfET2Mm()));
        buffer.put(shortToByte(m.getEfT2WeekdayFilter()));
        buffer.put(shortToByte(m.getEfT3On()));
        buffer.put(shortToByte(m.getEfST3Hh()));
        buffer.put(shortToByte(m.getEfST3Mm()));
        buffer.put(shortToByte(m.getEfET3Hh()));
        buffer.put(shortToByte(m.getEfET3Mm()));
        buffer.put(shortToByte(m.getEfT3WeekdayFilter()));
        buffer.put(shortTobytes(m.getChecksum()));
        buffer.putShort(0, (short) (buffer.position() + 6));// 添加封包长度
        buffer.flip();
        byte[] result = new byte[buffer.limit()];
        buffer.get(result);
        return result;
    }

    public void batchSetPhone(String methodBase, int num, ProductPerSettingM object, ByteBuffer buffer) {
        for (int i = 1; i <= num; i++) {
            try {
                MethodType methodType = MethodType.methodType(String.class);
                MethodHandle method = MethodHandles.publicLookup().findVirtual(ProductPerSettingM.class,
                        methodBase + (i), methodType);
                String result = (String) method.invoke(object);
                buffer.put(stringToBytePadded(result, 15, "#"));
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }
    }

    public byte shortToByte(short s) {
        return (byte) (0xFF & s);
    }

    public byte[] shortTobytes(short s) {
        byte[] result = new byte[2];
        result[0] = (byte) (s >> 8 & 0xFF);
        result[1] = (byte) (s & 0xFF);
        return result;
    }

    /**
     * @Title: 字符串转byte[] 位数不足len以'#'补足
     * @Description: TODO
     * @param 源字符串
     * @param 规定的长度
     * @return byte[]
     * @throws UnsupportedEncodingException 
     */
    public byte[] stringToBytePadded(String str, int len, String paddStr) throws UnsupportedEncodingException {
    	if(paddStr!=null&&paddStr.length()>0&&!paddStr.equalsIgnoreCase("0")){
    		 while (len > str.length()) {
    	            str += paddStr;
    	     }
    	}else if(paddStr.equalsIgnoreCase("0")){
    		byte[] title = new byte[len];
    		byte[] info = str.getBytes("utf8");
    		for(int i=0; i<info.length;i++){
    			title[i]=info[i];
    		}
    		return title;
    	}
       
        return str.getBytes("utf8");
    }
}
