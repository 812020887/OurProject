package com.kmhc.model.handler.impl.km8020;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrBloodpressureMapper;
import com.kmhc.model.datacenter.model.PsrBloodpressure;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;


@MessageCommand(type = "KM8020", command = "0x543632")
public class BPHandlerImpl extends AbstractParentHandlerKM8020{

	private String function = "S62";
	private static final Logger log = LoggerFactory.getLogger(BPHandlerImpl.class);
	private PsrBloodpressureMapper psrBloodpressureMapper = (PsrBloodpressureMapper) SpringBeanFacotry.getInstance().getBean("psrBloodpressureMapper");
	
	public BPHandlerImpl() {
		super(log);
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		log.info(new String(msg));
		//rrhqvfdbo40bgzu,1,abcd,2017-11-24 16:47:19,1-2,865946021011026,8,T62,blood_pressure,100,61,66,2008-01-22 04:44:00,1511542039
		// 第一次時間錯誤, 無秒

		String content[] = new String(msg).split(",");
		String uid = content[0];
		String timeStr = content[3];
		String imei = content[5];
		String tzStr = "GMT+" + content[6];
		String systolic = content[9];
		String diastolic = content[10];
		String pulse = content[11];
		String measureTime = content[12];
//		String timeStamp = content[13];
		
		Date dt = com.kmhc.model.util.Date.getDate(timeStr,"yyyy-MM-dd HH:mm:ss",tzStr);
		Date mDt = com.kmhc.model.util.Date.getDate(measureTime ,"yyyy-MM-dd HH:mm:ss",tzStr);
		log.debug(sdf.format(dt));
		log.debug(sdf.format(mDt));
		
		PsrBloodpressure record = new PsrBloodpressure();
		record.setImei(imei);
		record.setImsi("");
		
		record.setBpTime(mDt);
		Date now = new Date();
		Boolean flag = true;
		if((now.getTime() + (10 * 60 * 1000L))<mDt.getTime()){
			flag = false;
		}
		if((now.getTime() - mDt.getTime()) > (30 * 24 * 60 * 60 * 1000L)){
			flag = false;
		}

		record.setlPressure(Short.parseShort(diastolic));
		record.sethPressure(Short.parseShort(systolic));
		record.setPuls(Short.parseShort(pulse));
		record.setModel((short)0);
		record.setData1((short)0);
		record.setCreateDate(new Date());
		record.setTypeid(62);
		
		if(psrBloodpressureMapper.selectByBpTime(record) == 0&&flag){
			psrBloodpressureMapper.insert(record);		
			push(record.getImei(),record.gethPressure(),record.getlPressure(),record.getPuls(),"KM8020");
			pushBP(record.getImei(),record.gethPressure(),record.getlPressure(),record.getPuls(),"KM8020",record.getBpTime());
		}else{
			log.info("收到血压历史数据不予保存：{}",uid+":"+content[1]+":"+content[2]+":"+sdf.format(new Date())+":"+imei+function);
		}
		
		//[V1.0.0,a1d83kdeio3fg3k,1,abcd,2014-08-29 09:45:15,356511170035899,S62]
		String out[] = { uid, content[1], content[2], sdf.format(new Date()), imei, function };
		return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"), generateResponse(out));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		//T62,blood_pressure,123,80,78,2017-11-24 16:49:00,1511542202
	    //{T62,blood_pressure,systolic_pressures,diastolic_pressures,pulse,time,timen, imei}
		//{T62,blood_pressure,121,80,92,2017-03-30 14:01:00,1490882502}
		//{T62,blood_pressure,100,61,66,2017-01-22 04:44:00,1511542161},
		// {T62,blood_pressure,112,68,95,2017-01-01 00:22:00,1511542171},
		// {T62,blood_pressure,97,59,73,2017-01-01 00:26:00,1511542182},
		// {T62,blood_pressure,136,73,78,2017-11-23 16:47:00,1511542192},
		// {T62,blood_pressure,123,80,78,2017-11-24 16:49:00,1511542202}
		// 血壓計上傳所有歷史數據 無秒
		try{
			log.info(json);
			String content[] = json.split(",");
			String imei = content[7];
			String systolic = content[2];
			String diastolic = content[3];
			String pulse = content[4];
			String measureTime = content[5];
			
			Date mDt = com.kmhc.model.util.Date.getDate(measureTime ,"yyyy-MM-dd HH:mm:ss","GMT+8");
			log.debug(sdf.format(mDt));
			
			PsrBloodpressure record = new PsrBloodpressure();
			record.setImei(imei);
			record.setBpTime(mDt);
			record.setlPressure(Short.parseShort(diastolic));
			record.sethPressure(Short.parseShort(systolic));
			record.setPuls(Short.parseShort(pulse));
			record.setTypeid(62);

			Date now = new Date();
			Boolean flag = true;
			if((now.getTime() + (10 * 60 * 1000L))<mDt.getTime()){
				flag = false;
			}
			if((now.getTime() - mDt.getTime()) > (30 * 24 * 60 * 60 * 1000L)){ //超過一天數據不接收
				flag = false;
			}
			
			if(psrBloodpressureMapper.selectByBpTime(record) == 0 && flag){
				psrBloodpressureMapper.insert(record);
				push(record.getImei(),record.gethPressure(),record.getlPressure(),record.getPuls(),"KM8020");
				pushBP(record.getImei(),record.gethPressure(),record.getlPressure(),record.getPuls(),"KM8020",record.getBpTime());
			}else{
				log.info("收到血压历史数据不予保存：{}",content[1]+":"+content[2]+":"+sdf.format(new Date())+":"+imei+function);
			}
		}catch(Exception e){
			log.error("psr_heartrate insert fail.....");
			return false;
		}
		return true;
	}
	
}
