package com.kmhc.model.handler.impl.c100;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type = "C100", command = "0x89")
public class RemoteHandlerImpl extends AbstractParentHandlerC100 {

	private static final Logger log = LoggerFactory.getLogger(RemoteHandlerImpl.class);
	public RemoteHandlerImpl() {
		super(log);
	}

	@Override
    public ReplyMessageContent handleMessage(byte[] msg) {
		int index = 0;
		byte[] snBytes = Arrays.copyOfRange(msg, index, index + 9);
		return null;
//		return MessageBuilder.buildReplyMessageContent(snBytes, generateResponse((byte) 0x00));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
