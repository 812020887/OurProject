package com.kmhc.model.handler.impl.km8020;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.T9DeviceStatusMapper;
import com.kmhc.model.datacenter.model.T9DeviceStatus;
import com.kmhc.model.handler.impl.PushAlert;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.Publish;

@MessageCommand(type = "KM8020", command = "0x543832")
public class LowPowerHandlerImpl extends AbstractParentHandlerKM8020 {

	private static final Logger log = LoggerFactory.getLogger(LowPowerHandlerImpl.class);
	private T9DeviceStatusMapper t9DeviceStatusMapper = (T9DeviceStatusMapper) SpringBeanFacotry.getInstance()
			.getBean("t9DeviceStatusMapper");

	public LowPowerHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		// [V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15
		// 10:00:00,1-2,355372020827303,8,T82,battery low,1267511609]
		// [V1.0.0,a1d83kdeio3fg3k,1,abcd,2014-08-29 09:45:15,356511170035899,S82]
		log.info(new String(msg));
		String function = "S82";
		String content[] = new String(msg).split(",");
		String uid = content[0];
		String imei = content[5];
		String tzStr = "GMT+" + content[6];
		String timen = content[9];
		TimeZone tz = TimeZone.getTimeZone(tzStr);

		Date dt = new Date();
		Date cdt = new Date(Long.valueOf(timen) * 1000);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		sdf.setTimeZone(tz);
		log.debug(sdf.format(dt));
		String out[] = { uid, content[1], content[2], sdf.format(dt), imei, function };

		T9DeviceStatus device = t9DeviceStatusMapper.selectByImei(imei);

		if (device != null) {
			device.setLowpowertime(cdt);
			device.setUpdatetime(dt);
			t9DeviceStatusMapper.updateByPrimaryKey(device);
		}

		String extras = "";
		String alert = new PushAlert(new Object[] { imei }, "power_low_key").toString();
		String title = "power_low_title_key";
		int builder_id = INotification.ANDROID_MAKER_BATTARY;
		extras = String.format("imei=%s|", imei);
		extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_BATTERY);
		extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_LOW);
		extras += String.format("builder_id=%d|", INotification.ANDROID_MAKER_BATTARY);
		extras += "device=KM8020|";
		Publish.push(imei, alert, title, builder_id, extras);

		return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"), generateResponse(out));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		// {T82,batterylow,timen,imei}
		log.info(json);
		try{
			String content[] = json.split(",");
			String imei = content[3];
			String timen = content[2];
	
			Date cdt = new Date(Long.valueOf(timen) * 1000);
			T9DeviceStatus device = t9DeviceStatusMapper.selectByImei(imei);
	
			if (device != null) {
				device.setLowpowertime(cdt);
				device.setUpdatetime(new Date());
				t9DeviceStatusMapper.updateByPrimaryKey(device);
			}
		}catch (Exception e) {
			return false;
		}
		return true;
	}
}
