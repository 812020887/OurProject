package com.kmhc.model.handler.impl.km8010;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.EmgIMapper;
import com.kmhc.model.datacenter.dao.EmgMMapper;
import com.kmhc.model.datacenter.dao.PrCellIMapper;
import com.kmhc.model.datacenter.dao.PrIMapper;
import com.kmhc.model.datacenter.dao.PrMMapper;
import com.kmhc.model.datacenter.dao.ProductPerSettingMMapper;
import com.kmhc.model.datacenter.dao.ProductSysSettingMMapper;
import com.kmhc.model.datacenter.dao.PsrSettingMapper;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.EmgI;
import com.kmhc.model.datacenter.model.EmgM;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.PrCellI;
import com.kmhc.model.datacenter.model.PrI;
import com.kmhc.model.datacenter.model.PrM;
import com.kmhc.model.datacenter.model.ProductPerSettingM;
import com.kmhc.model.datacenter.model.ProductSysSettingM;
import com.kmhc.model.datacenter.model.PsrSetting;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type="KM8010",command="0xB1")
public class BootUpHandlerImpl extends AbstractParentHandlerKM8010 {
//	private int index = 0;
	private static final Logger log = LoggerFactory.getLogger(BootUpHandlerImpl.class);
    private String type = "B1";
    
    private ProductSysSettingMMapper pSSMMapper = (ProductSysSettingMMapper) SpringBeanFacotry.getInstance().getBean("productSysSettingMMapper");
	private ProductPerSettingMMapper pPSMMapper = (ProductPerSettingMMapper) SpringBeanFacotry.getInstance().getBean("productPerSettingMMapper");
    private EmgMMapper emgMMapper = (EmgMMapper) SpringBeanFacotry.getInstance().getBean("emgMMapper");
    private PsrSettingMapper psrSettingMapper = (PsrSettingMapper) SpringBeanFacotry.getInstance().getBean("psrSettingMapper");
    
    private PrMMapper prMMapper = (PrMMapper) SpringBeanFacotry.getInstance().getBean("prMMapper");
    private PrIMapper prIMapper = (PrIMapper) SpringBeanFacotry.getInstance().getBean("prIMapper");
    private PrCellIMapper prCellIMapper = (PrCellIMapper) SpringBeanFacotry.getInstance().getBean("prCellIMapper");
	
	public BootUpHandlerImpl() {
		super(log);
	}
//	01013DB1 0866545022045261 1001010000 01 01CC01253375C88E 06 01253375C98F 01252A1F6187 01253375C784 01252A203B7D 012533785E7B 012533786979 64

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,type);
		int index = 0;	
		byte[] reMsg = null;
		byte[] imeiBytes = parseImeiBytes_KM8010(msg, 0);
		String imei = parseImei_KM8010(msg, index);
        Date updateDate = TripleDesHelper.ParserRTC(Arrays.copyOfRange(msg, 8, 13));
		
        PrM prm = null;
		PrI pri = null;
		EmgM emgm = null;
		List<PrCellI> prcelllist = null;
		
    	try {
            emgm = byte2Pojo(msg);
            prm = parsePrM(msg , index);		
		} catch ( Exception e) {
            log.error("【type=KM8010,command=0x{}】解码失败",type);
            log.error("异常信息：",e);
        }

		index += 13;
		Byte percentage = msg[msg.length - 1];
		int battery = 4500 * percentage.intValue() / 100;
		Gps gps = null;
		Cell cell = null;
		List<Cell> cells = null;
		List<Wifi> wifis = null;
		switch((int)(msg[index])){
		case 0://GPS
			gps = parseGps(Arrays.copyOfRange(msg, index+1, msg.length - 1));
			gps = LocUtil.conver(gps);
			pri = getPrI(gps, imei, updateDate, battery);
			break;
		case 1://GSM
			cells = parseCellList(Arrays.copyOfRange(msg, index+1, msg.length - 1));
			pri = getPrI(gps, cells, wifis, imei, updateDate, battery);
			prcelllist = getPrCellI(cells, prm);
			break;
		case 4:
			index += 1;
			gps = parseGps(Arrays.copyOfRange(msg, index, index+10));
			gps = LocUtil.conver(gps);
			log.debug(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
			gps.setAddress(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
			index += 10;
			cell = parseCell(msg, index, null);
			index += 8;
			cells = parseCells(msg, index, cell.getMcc());
			cells.add(0, cell);
			pri = getPrI(gps, cells, wifis, imei, updateDate, battery);
			prcelllist = getPrCellI(cells, prm);
			break;
		case 8:
			cell = parseCell(msg, index + 1, null);
			cells = parseCells(msg, index + 9, cell.getMcc());
			wifis = parseWifiList(msg, index + 10 + cells.size()*6);
			cells.add(0, cell);
			pri = getPrI(gps, cells, wifis, imei, updateDate, battery);
			prcelllist = getPrCellI(cells, prm);
			break;
		case 0x16:
			index += 1;
			gps = parseGps(Arrays.copyOfRange(msg, index, index+10));
			gps = LocUtil.conver(gps);
			log.debug(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
			gps.setAddress(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
			index += 10;
			cell = parseCell(msg, index, null);
			index += 8;
			cells = parseCells(msg, index, cell.getMcc());
			index += ((cells.size()*6) + 1);
			wifis = parseWifiList(msg, index);							
			pri = getPrI(gps, cells, wifis, imei, updateDate, battery);
			prcelllist = getPrCellI(cells, prm);
			break;
		default:
			break;
	}
		
		int insertprmsuccess = 0;
		int insertprisuccess = 0;
		int insertemgmsuccess = 0;
		if(emgm != null){
			emgm.setVoltage(battery);
			insertemgmsuccess = emgMMapper.insertSelective(emgm);
	        if(emgm.getCells() != null && emgm.getCells().size() >0 ){
	            List<EmgI> emgIList = getEmgIList(emgm.getCells(),emgm.getEmgDetailKey(),emgm.getCreateDate(),emgm.getUpdateDate());
	            EmgIMapper emgIMapper = (EmgIMapper) SpringBeanFacotry.getInstance().getBean("emgIMapper");
	            emgIMapper.insertList(emgIList);
	        }
		}		
		if(prm != null)
			insertprmsuccess = prMMapper.insertSelective(prm);
		if(pri != null)
			insertprisuccess = prIMapper.insertSelective(pri);
		for( int i = 0; prcelllist != null && i < prcelllist.size(); i++){
			prCellIMapper.insertSelective(prcelllist.get(i));
		}
		
		ProductSysSettingM sysSetting = pSSMMapper.selectByPrimaryKey(imei);
		ProductPerSettingM perSetting = pPSMMapper.selectByPrimaryKey(imei);	
		
		if( insertprmsuccess > 0 && insertprisuccess > 0 && insertemgmsuccess > 0 ){
			reMsg = new byte[1];
			reMsg[0] = 5;
//			if( sysSetting != null ){
//				Date dt = null;
//				if(sysSetting.getUpdateDate() != null && sysSetting.getEchoPrT() != null){
//					dt = new Date(sysSetting.getUpdateDate().getTime() + ((long)sysSetting.getEchoPrT()*60*1000));
//					if(prm.getUpdateDate().compareTo(dt) > 0)
//						reMsg[0] = 1;
//				}else{
//					reMsg[0] = 0;
//					sysSetting.setUpdateDate(new Date());
//					perSetting.setUpdateDate(new Date());
//					pSSMMapper.updateByPrimaryKey(sysSetting);
//					pPSMMapper.updateByPrimaryKey(perSetting);
//				}
//				List<PsrSetting> settings = psrSettingMapper.selectAllByImei(imei);
//				for(int i = 0; i < settings.size(); i++){
//					if(settings.get(i).getUpdated() == null || settings.get(i).getUpdated().equals("Y")){
//						reMsg[0] += 4 ;
//						break;
//					}
//				}
//			}
		}else{
			reMsg =  AbstractHandler.ACK_ERROR_KM8010;
		}	
		return MessageBuilder.buildReplyMessageContent(imeiBytes, generateResponse(reMsg,(byte) 0xB1));
	}
	
	public EmgM byte2Pojo(byte[] data) throws Exception{
		int START_FRAME = 0;
        HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
        indexMapPolishing.put(0, 1);
        Object[] objs = BytesConvertionUtil.generateProperty4KM8010(data, new int[]{8,5,1}, new String[]{"String","Date","Short"}, indexMapPolishing);
        EmgM emgm = baseEmgm(objs);
        short locationMethod = (short)objs[2];
        if(locationMethod == 0){
        	Gps gps = parseGps(Arrays.copyOfRange(data, START_FRAME+14, data.length - 1));
            setGps(emgm, gps);
        }else if(locationMethod == 1){
//            Cell cell = parseCell(data,START_FRAME+14,null);
//            List<Cell> cells = parseCells(data,START_FRAME+22,cell.getMcc());
            List<Cell> cellList = parseCellList(Arrays.copyOfRange(data, START_FRAME+14, data.length - 1));
            setCell(emgm, cellList.get(0));
            emgm.setCell(cellList.get(0));
            LocResult locresult = null;
            if(cellList.size() > 1){
            	emgm.setCells(cellList.subList(1, cellList.size()));
            	locresult = LocUtil.loc(emgm.getImei(), null, cellList.get(0), cellList.subList(1, cellList.size()-1), null);
            }else
            	locresult = LocUtil.loc(emgm.getImei(), null, cellList.get(0), null, null);
            emgm = setLocResult(emgm, locresult);
        }
        return emgm;
    }
    private EmgM setLocResult(EmgM emgm,LocResult locresult){
        if(locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0){
            emgm.setIsvalid("Y");
            emgm.setLocStatus("Y");
            emgm.setMcellStatus("Y");
            emgm.setWifiStatus("Y");
            LocDetailResult result = locresult.getResult();
            String[] lngLat = result.getLocation().split(",");
            BigDecimal lng = new BigDecimal(lngLat[0]).setScale(6, RoundingMode.HALF_EVEN);
            BigDecimal lat = new BigDecimal(lngLat[1]).setScale(6, RoundingMode.HALF_EVEN);
            String address = LocUtil.reverseGeocoding(lat, lng);
            emgm.setGpsLng(lng);
            emgm.setGpsLat(lat);
            emgm.setAddress(address);
            emgm.setGpsNsLat("N");
            emgm.setGpsEwLng("E");
            emgm.setMcellLat(lat);
            emgm.setMcellLng(lng);
            emgm.setWifiLat(lat);
            emgm.setWifiLng(lng);
            emgm.setWifiAddress(address);
            emgm.setMcellAddress(address);
            emgm.setHpe((double)result.getRadius());
        }else{
            if(locresult != null){
                log.info("【type=KM8010,command=0x{}】定位失败，status:{},info:{},result.type:{}",type,locresult.getStatus(),locresult.getInfo(),locresult.getResult() == null?"":locresult.getResult().getType());
            }else{
                log.info("【type=KM8010,command=0x{}】定位结果返回NULL",type);
            }
        }
        return emgm;
    }
    
    @SuppressWarnings("deprecation")
	private EmgM baseEmgm(Object[] objs){
        EmgM emgm = new EmgM();
        Date nowDate = new Date();
        emgm.setImei((String)objs[0]);
        emgm.setEmgDate((Date)objs[1]);
        if(((Date)objs[1]).getYear() == 2016 && ((Date)objs[1]).getMonth() == 1)
        	emgm.setEmgDate(nowDate);
        emgm.setEmgKey(yyMMddHHmmss.format(new Date()));
        emgm.setEmgDetailKey(emgm.getEmgKey()+emgm.getImei());
        emgm.setPowerOffType(0);
        emgm.setFwDate(nowDate);
        emgm.setCreateDate(nowDate);
        emgm.setUpdateDate(nowDate);
        emgm.setType("2e");
        return emgm ;
    }

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
