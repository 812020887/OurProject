package com.kmhc.model.handler.impl.c100;

import java.io.IOException;
import java.util.Arrays;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.util.ConvertionUtil;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.core.Context;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.Matrix;
import com.kmhc.model.util.MessageBuilder;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.util.ReferenceCountUtil;
/**
    * @ClassName: com.kmhc.model.handler.impl.c100.MatrixDownLoadHandlerImpl
    * @Description: 终端上传未知字模的Unicode编码，服务端回应对应字模
    * @author xl
    * @date 2016年10月13日
    *
    */
@MessageCommand(type = "C100", command = "0x13")
public class MatrixDownLoadHandlerImpl extends AbstractParentHandlerC100 {

    private static final Logger log = LoggerFactory.getLogger(MatrixDownLoadHandlerImpl.class);
    private static final String CHARMODE_PATH = "charmode.data" ;
        /**
         * 创建一个新的实例 MatrixDownLoadHandlerImpl.
         *
         * @param log
         */
        
    public MatrixDownLoadHandlerImpl() {
        super(log);
    }


    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
        int index = -5 ;
        byte[] snBytes= Arrays.copyOfRange(msg, index + 5, index + 14) ;
        initMatrix();
        byte[] charIds = Arrays.copyOfRange(msg, index + 14,msg.length-1) ;
        ByteBuf buffer = PooledByteBufAllocator.DEFAULT.buffer();
        for(int i = 0 ;i<charIds.length;i+=2){
            byte[] charId = Arrays.copyOfRange(charIds,i,i+2) ;
            Matrix matrix = Context.MARTIXS.get(ConvertionUtil.getShort(charId, false));
            if(matrix != null){
                buffer.writeBytes(matrix.struct()) ;
                log.debug("charId:"+ConvertionUtil.Bytes2HexString(charId));
            }else{
                log.error("There is no need to download the font data，charId:"+ConvertionUtil.Bytes2HexString(charId));
            }
        }
        byte[] structs = new byte[buffer.readableBytes()] ;
        buffer.readBytes(structs);
        ReferenceCountUtil.release(buffer) ;
        return MessageBuilder.buildReplyMessageContent(snBytes, generateResponse(structs,(byte) 0x93));
    }
    
    private static void initMatrix(){
        if(Context.MARTIXS.size()==0){
            byte[] bytes;
            try {          	
                bytes = IOUtils.toByteArray(Thread.currentThread().getContextClassLoader().getResourceAsStream(CHARMODE_PATH));
                log.debug(DatatypeConverter.printHexBinary(bytes));
                int readIndex = 0 ;
                while(bytes.length>readIndex+4&&bytes.length>readIndex+4+bytes[readIndex+2]*bytes[readIndex+3]/8){
                    byte[] charId = Arrays.copyOfRange(bytes, readIndex,readIndex+2);
                    byte[] revertCharId = new byte[2];
                    revertCharId[0] = charId[1];
                    revertCharId[1] = charId[0];
                    readIndex += 2 ;
                    byte width = bytes[readIndex++] ;
                    byte height = bytes[readIndex++] ;
                    int to = readIndex+width*height/8;
                    byte[] data = Arrays.copyOfRange(bytes, readIndex,to);
                    readIndex = to ;
                    Matrix matrix = new Matrix(revertCharId,width,height,data);
                    Context.MARTIXS.put(ConvertionUtil.getShort(revertCharId, false),matrix);
//                    System.out.println(ConvertionUtil.Bytes2HexString(charId));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
    }


	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
