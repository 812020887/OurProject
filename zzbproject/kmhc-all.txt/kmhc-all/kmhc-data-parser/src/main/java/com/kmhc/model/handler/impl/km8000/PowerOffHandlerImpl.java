package com.kmhc.model.handler.impl.km8000;

import java.text.ParseException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.core.Pusher;
import com.kmhc.model.datacenter.dao.EmgIMapper;
import com.kmhc.model.datacenter.dao.EmgMMapper;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.EmgI;
import com.kmhc.model.datacenter.model.EmgM;
import com.kmhc.model.handler.impl.PushAlert;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.util.Publish;

/**
 * Name: PowerOffHandlerImpl.java ProjectName: [kmhc-data-parser] Package:
 * [com.kmhc.model.handler.impl.km8000.PowerOffHandlerImpl.java] Description:
 * 关机通知协议处理
 * 
 * @since JDK1.7
 * @see
 *
 * @author: xl
 * @date: 2015年11月13日 上午10:40:40
 *
 *        Update-User: @author Update-Time: Update-Remark:
 * 
 *        Check-User: Check-Time: Check-Remark:
 * 
 *        Company: kmhc Copyright: kmhc
 */
@MessageCommand(type = "KM8000", command = "0x2F")
public class PowerOffHandlerImpl extends AbstractParentHandlerKM8000 {

	private static final Logger log = LoggerFactory.getLogger(PowerOffHandlerImpl.class);
	private String type = "2f";

	public PowerOffHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
		writeDebugLog(msg, type);
		ReplyMessageContent result = null;
		EmgM emgm = null;
		try {
			emgm = byte2Pojo(msg);
		} catch (Exception e) {
			log.error("【type=KM8000,command=0x{}】解码失败", type);
			e.printStackTrace();
			log.error("异常信息：", e);
			result = new ReplyMessageContent(imeiBytes, process());
		}
		try {
			EmgMMapper emgMMapper = (EmgMMapper) SpringBeanFacotry.getInstance().getBean("emgMMapper");
			List<Cell> cellList = parseCellList(msg, START_FRAME + 37);
			emgm.setCellidCount((short) cellList.size());
			setGps(emgm, parseGps(msg, START_FRAME + 38 + 11 * cellList.size()));
			// 入数据库Emg_M表
			int insert = emgMMapper.insertSelective(emgm);
			if (insert > 0) {
				result = new ReplyMessageContent(imeiBytes, process());
				push8000Gps(emgm.getImei(),"KM8000","0x2F");
			}
			if (cellList.size() > 0) {
				List<EmgI> emgIList = getEmgIList(cellList, emgm.getEmgDetailKey(), emgm.getCreateDate(),
						emgm.getUpdateDate());
				EmgIMapper emgIMapper = (EmgIMapper) SpringBeanFacotry.getInstance().getBean("emgIMapper");
				emgIMapper.insertList(emgIList);
			}
		} catch (Exception e) {
			result = new ReplyMessageContent(imeiBytes, ACK_ERROR_KM8000);
			log.error("【type=KM8000,command=0x{}】操作数据出现异常", type);
			log.error("异常信息：", e);
		}
		push(emgm.getImei());
		return result;
	}

	private byte[] process() {
		return ACK_SUCCESS_KM8000;
	}

	private EmgM byte2Pojo(byte[] data) throws ParseException {
		EmgM entry = parseEmgBase(data, START_FRAME);
		entry.setPowerOffType(0xFF & data[START_FRAME + 23]);
		entry.setVoltage((0xff & data[START_FRAME + 24]) | (0xff & data[START_FRAME + 25]));
		Cell cell = parseCell(data, START_FRAME + 26);
		setCell(entry, cell);
		entry.setType(type);
		entry.setIsvalid("Y");
		entry.setLocStatus("Z");
		return entry;
	}

	private void push(String imei) {
		String alert = new PushAlert(new Object[] { imei }, "power_off_key").toString();
		String title = "power_off_title_key";
		int builder_id = INotification.ANDROID_MAKER_DEFAULT;
		String extras = "";
		extras = String.format("imei=%s|", imei);
		extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_DEFAULT);
		extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_LOW);
		extras += String.format("builder_id=%d|", INotification.ANDROID_MAKER_DEFAULT);
		extras += "device=KM8000|";
		Publish.push(imei, alert, title, builder_id, extras);
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
