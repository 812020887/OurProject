package com.kmhc.model.handler.impl.km8000;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.msg.ReplyMessageContent;

/**
 * Name: FallGpsHandlerImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8000.FallGpsHandlerImpl.java]
 * Description: 跌倒+求救协议处理  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: xl
 * @date: 2015年11月17日 下午4:26:08
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
@MessageCommand(type="KM8000",command="0x25")
public class FallGpsHandlerImpl extends AbstractParentHandlerKM8000 {

    private static final Logger log = LoggerFactory.getLogger(FallGpsHandlerImpl.class);
    private String type = "25";
    
    public FallGpsHandlerImpl() {
        super(log);
    }

    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
      //这里因为报文解析和SOSGps都一样，就直接调用SOSGps的处理，后续增加推送等具体逻辑再进行分开操作
        SosGpsHandlerImpl fallHandlerImpl = new SosGpsHandlerImpl();
        fallHandlerImpl.setLog(log);
        fallHandlerImpl.setType(type);
        return fallHandlerImpl.handleMessage(msg);
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
