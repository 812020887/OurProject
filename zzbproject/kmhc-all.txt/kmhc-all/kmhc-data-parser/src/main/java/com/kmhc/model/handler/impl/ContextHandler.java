package com.kmhc.model.handler.impl;

import com.kmhc.model.handler.IContext;
import com.kmhc.model.handler.IHandler;

public class ContextHandler implements IContext {
	
	private IHandler handler;  
	
	public ContextHandler(IHandler handler){
		this.handler = handler;
	}

	@Override
	public boolean handleBasicMessage(String array) {
		// TODO Auto-generated method stub
		return handler.handleMessage(array);
	}
}
