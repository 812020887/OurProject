/**  
 * All rights Reserved, Designed By KMHC   
 * @Title:  SMSImmediateAddressHandlerImpl.java   
 * @Package com.kmhc.model.handler.impl.km8010   
 * @Description:    TODO
 * @author: Administrator     
 * @date:   2016年12月9日 上午10:12:09   
 * @version V1.0     
 */  
package com.kmhc.model.handler.impl.km8010;

import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PrCellIMapper;
import com.kmhc.model.datacenter.dao.PrIMapper;
import com.kmhc.model.datacenter.dao.PrMMapper;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.PrCellI;
import com.kmhc.model.datacenter.model.PrI;
import com.kmhc.model.datacenter.model.PrM;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.handler.impl.PushAlert;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.Publish;

/**   
 * @ClassName:  SMSImmediateAddressHandlerImpl   
 * @Description:TODO
 * @author: Administrator  
 * @date:   2016年12月9日 上午10:12:09   
 *      
 */
@MessageCommand(type="KM8010",command="0x11")
public class SMSImmediateAddressHandlerImpl extends AbstractParentHandlerKM8010 {

	/**   
	 * @Title:  SMSImmediateAddressHandlerImpl   
	 * @Description:    TODO   
	 * @param:  @param log  
	 * @throws   
	 */  
	
	private static final Logger log = LoggerFactory.getLogger(RegularUploadHandlerImpl.class);
    private String type = "11";
 
    private PrMMapper prMMapper = (PrMMapper) SpringBeanFacotry.getInstance().getBean("prMMapper");
    private PrIMapper prIMapper = (PrIMapper) SpringBeanFacotry.getInstance().getBean("prIMapper");
    private PrCellIMapper prCellIMapper = (PrCellIMapper) SpringBeanFacotry.getInstance().getBean("prCellIMapper");

	public SMSImmediateAddressHandlerImpl() {
		super(log);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,type);
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);
		int index = 0;

		String imei = parseImei_KM8010(msg, index);
		Date updateDate = TripleDesHelper.ParserRTC(Arrays.copyOfRange(msg, 8, 13));
		PrM prm = null;
		PrI pri = null;
		List<PrCellI> prcelllist = null;
		
		try {
			prm = parsePrM(msg , index);		
		} catch (ParseException e) {
			log.error("【type=KM8010,command=0x{}】解码失败",type);
            log.error("异常信息：",e);
		}
		index += 13;
		Byte percentage = msg[msg.length - 1];
		int battery = 4500 * percentage.intValue() / 100;
		Gps gps = null;
		Cell cell = null;
		List<Cell> cells = null;
		List<Wifi> wifis = null;
		switch((int)(msg[index])){
			case 0://GPS
				gps = parseGps(Arrays.copyOfRange(msg, index+1, msg.length - 1));
				gps = LocUtil.conver(gps);
				pri = getPrI(gps, imei, updateDate, battery);
				break;
			case 1://GSM
				cells = parseCellList(Arrays.copyOfRange(msg, index+1, msg.length - 1));
				pri = getPrI(gps, cells, wifis, imei, updateDate, battery);
				prcelllist = getPrCellI(cells, prm);
				break;
			case 4:
				index += 1;
				gps = parseGps(Arrays.copyOfRange(msg, index, index+10));
				gps = LocUtil.conver(gps);
//				log.debug(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
				gps.setAddress(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
				index += 10;
				cell = parseCell(msg, index, null);
				index += 8;
				cells = parseCells(msg, index, cell.getMcc());
				cells.add(0, cell);
				pri = getPrI(gps, cells, wifis, imei, updateDate, battery);
				prcelllist = getPrCellI(cells, prm);
				break;
			case 8:
				cell = parseCell(msg, index + 1, null);
				cells = parseCells(msg, index + 9, cell.getMcc());
				wifis = parseWifiList(msg, index + 10 + cells.size()*6);
				cells.add(0, cell);
				pri = getPrI(gps, cells, wifis, imei, updateDate, battery);
				prcelllist = getPrCellI(cells, prm);
				break;
			case 0x16:
				index += 1;
				gps = parseGps(Arrays.copyOfRange(msg, index, index+10));
				gps = LocUtil.conver(gps);
				log.debug(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
				gps.setAddress(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
				index += 10;
				cell = parseCell(msg, index, null);
				index += 8;
				cells = parseCells(msg, index, cell.getMcc());
				index += ((cells.size()*6) + 1);
				wifis = parseWifiList(msg, index);							
				cells.add(0, cell);
				pri = getPrI(gps, cells, wifis, imei, updateDate, battery);
				prcelllist = getPrCellI(cells, prm);
				break;
			default:
				break;
		}
		
		int insertprmsuccess = 1;
		int insertprisuccess = 0;
		if(prm != null){
			try{
				prMMapper.insertSelective(prm);
				
			}catch(Exception e){
				insertprmsuccess = 1;
			}
		}
		if(pri != null){
			while (insertprisuccess == 0) {
				try {
					insertprisuccess = prIMapper.insertSelective(pri);
					if (insertprisuccess == 1)
						break;
				} catch (Exception e) {
					pri.setItemno((short) (pri.getItemno() + 1));
				}
			}
		}
		for( int i = 0; prcelllist != null && i < prcelllist.size(); i++){		
			try{
				prCellIMapper.insertSelective(prcelllist.get(i));
			}catch(Exception e){
			}
		}
		
		if( insertprmsuccess > 0 && insertprisuccess > 0 ){
			String extras = "";
			String title = "discovery_address_key";
			String alert = new PushAlert(new Object[] { imei }, "discovery_address_start_key").toString();
			int builder_id = INotification.ANDROID_MAKER_DEFAULT;
			extras = String.format("imei=%s|", imei);
			extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_LOW);
			extras += String.format("builder_id=%d|", builder_id);
			extras += String.format("device=%s|", "KM8020");		
			extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_IMMEDIATE_ADDRESS);
			Publish.push(imei, alert, title, builder_id, extras);
			return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_SUCCESS_KM8010,(byte) 0x11));
		}
		return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) 0x11));	
	}

	/* (non-Javadoc)
	 * @see com.kmhc.model.handler.impl.AbstractHandler#handleMessage(java.lang.String)
	 */
	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
