/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月14日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.util;

import java.util.Arrays;

import com.kmhc.framework.util.ConvertionUtil;

/**
 * Name: BuildLogContent.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.util.BuildLogContent.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月14日 下午4:53:27
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class BuildLogContent {

	/** 
	 * @Title: BuildLogContent
	 * @Description: TODO
	 * @param          
	 * @throws 
	 */ 
	public BuildLogContent() {
		throw new RuntimeException("Util can not be inited!!!");
	}
	
	public static String buildDispatcherContent(String protocolName , byte[] content){
		StringBuilder sb = new StringBuilder();
		sb.append("\n <<<< recieve command from RMQ :")
		  .append("\n [ protocolName : ").append(protocolName).append(" ]")
		  .append("\n [ content : ").append(ConvertionUtil.Bytes2HexString(content)).append(" ]").append("\n");
		return sb.toString();
	}
	
	public static String buildServerReesponseContent( String exchangeName, String routingkey, byte[] content, String protocolName ){
		String contentStr = "";
		if( protocolName.equals("") )
			contentStr = new String(content);
		else
			contentStr = ConvertionUtil.Bytes2HexString(content);
		StringBuilder sb = new StringBuilder();
		sb.append("\n <<<< response command to RMQ :")
		  .append("\n [ exchange : ").append(exchangeName).append(" ]")
		  .append("\n [ routingkey : ").append(routingkey).append(" ]")
		  .append("\n [ protocolName : ").append(protocolName).append(" ]")
		  .append("\n [ content : ").append(contentStr).append(" ]").append("\n");
		
		return sb.toString();
	}
	
}
