/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月11日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8000;

import java.util.Date;
import java.util.HashMap;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrTellogMapper;
import com.kmhc.model.datacenter.model.PsrTellog;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.MessageBuilder;

/**
 * Name: CallRecordsUploadHandlerImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8000.CallRecordsUploadHandlerImpl.java]
 * Description:   
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月11日 下午7:09:44
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
@MessageCommand(type="KM8000",command="0x3F")
public class CallRecordsUploadHandlerImpl extends AbstractHandler {
	
	private final PsrTellogMapper psrTellogMapper = (PsrTellogMapper) SpringBeanFacotry.getInstance().getBean("psrTellogMapper");

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
		PsrTellog tellog = byte2Pojo(msg);
		int success = psrTellogMapper.insert(tellog);
		
		if( success > 0  ){
			push8000Gps(tellog.getImei(),"KM8000","0x3F");
			return MessageBuilder.buildReplyMessageContent(imeiBytes, ACK_SUCCESS_KM8000);
		}
		  
		return MessageBuilder.buildReplyMessageContent(imeiBytes, ACK_ERROR_KM8010);
	}
	
	public static PsrTellog byte2Pojo( byte[] original ){
		
		PsrTellog psrTellog = new PsrTellog();
		int[] sections = new int[]{8,8,1,7,7,1,20};
		String[] types= new String[]{"String","String","Short","Date","Date","Short","ASCILL"};
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		indexMapPolishing.put(1, 1);
		Object[] objs = BytesConvertionUtil.generateProperty4KM8000(original, sections, types, indexMapPolishing);
		psrTellog.setImei((String)objs[0]);
		psrTellog.setImsi((String)objs[1]);
		psrTellog.setRecordCount((Short)objs[2]);
		psrTellog.setsTime((Date)objs[3]);
		psrTellog.seteTime((Date)objs[4]);
		psrTellog.setTypeid("3f");
		psrTellog.setCallType((Short)objs[5]);
		psrTellog.setPhone((String)objs[6]);
		psrTellog.setCreateDate(new Date());
		return psrTellog;
		
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
