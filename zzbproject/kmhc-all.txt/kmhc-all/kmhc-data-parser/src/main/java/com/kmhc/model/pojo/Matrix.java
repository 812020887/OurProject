package com.kmhc.model.pojo;

import com.kmhc.framework.util.ConvertionUtil;

/**
    * @ClassName: com.kmhc.model.pojo.Matrix
    * @Description: 
    * @author xl
    * @date 2016年10月18日
    *
    */

public class Matrix {

    private byte[] charId ;
    private byte width ;
    private byte height ;
    private byte[] data ;
    private byte[] total ;
    public Matrix(byte[] charId,byte width,byte height,byte[] data){
        this.charId = charId ;
        this.width = width ;
        this.height = height ;
        this.data = data ;
    }
    public byte[] restruct(){
        byte[] total = new byte[charId.length+3+data.length] ;
        System.arraycopy(charId, 0, total,0, charId.length);
        total[charId.length] = width ;
        total[charId.length+1] = height ;
        System.arraycopy(data, 0, total,charId.length+2, data.length);
        total[total.length-1] = checkSum(total,total.length-1) ;
        this.total = total ;
        return this.total ;
    }
    public byte[] struct(){
        if(this.total == null){
            restruct() ;
        }
        return this.total ;
    } 
    public String toHexString(){
        if(this.total == null){
            restruct() ;
        }
        System.out.println(ConvertionUtil.Bytes2HexString(this.total));
        return ConvertionUtil.Bytes2HexString(this.total);
    }
    private byte checkSum(byte[] data,int endIndex){
        byte checkSum = 0 ;
        for(int i = 0 ; i<endIndex ; i++){
            checkSum += data[i] ;
        }
        return checkSum ;
    }
    public byte[] getCharId() {
        return charId;
    }
    public void setCharId(byte[] charId) {
        this.charId = charId;
    }
    public byte getWidth() {
        return width;
    }
    public void setWidth(byte width) {
        this.width = width;
    }
    public byte getHeight() {
        return height;
    }
    public void setHeight(byte height) {
        this.height = height;
    }
    public byte[] getData() {
        return data;
    }
    public void setData(byte[] data) {
        this.data = data;
    }
}
