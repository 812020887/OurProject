/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月7日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.rabbitmq.recover.core.ConnectionBuilder;
import com.kmhc.framework.rabbitmq.recover.core.ExecutePublisher;
import com.kmhc.framework.rabbitmq.recover.core.PublisherPool;
import com.kmhc.framework.rabbitmq.recover.facotry.NameThreadFacotry;
import com.kmhc.framework.rabbitmq.recover.resource.ConnectionOption;
import com.kmhc.framework.util.SystemInforInformationUtil;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.core.Intercepter;
import com.kmhc.model.core.MessageDispatcher;
import com.kmhc.model.core.MessageHandlerRegister;
import com.kmhc.model.core.JPushIntercepter;
import com.kmhc.model.core.RequestMessageDispatcher;
import com.kmhc.model.pojo.MqConnectionDeclaration;
import com.kmhc.model.runnable.BasicTimer;
import com.kmhc.model.runnable.ConsumerThread;
import com.kmhc.model.runnable.ReplyMessageThread;
import com.kmhc.model.util.DebugUtil;
import com.kmhc.model.util.LogCenter;
import com.kmhc.model.util.SystemConfigUtil;
import com.rabbitmq.client.Connection;

/**
 * Name: Main.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.Main.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月7日 下午5:31:38
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class Main {
	
	
	public static void main(String[] args) {
		LogCenter.root.info(SystemInforInformationUtil.getSystemInformation());
		initBasic();
		initMq();
		LogCenter.root.info("mq build");
//		test();
		BasicTimer.startTimer();
		LogCenter.root.info("BasicTimer start");
		
	}
	
	public static void test(){
		try {

			ConnectionOption option = new ConnectionOption().withHostName(SystemConfigUtil.host).withPort(SystemConfigUtil.port)
					.withUserName(SystemConfigUtil.userName).withPassowrd(SystemConfigUtil.password);
			final Connection connection = ConnectionBuilder.createConnection(option);

			ExecutePublisher publisher = new PublisherPool(connection.createChannel(), "ks8000", "KM8000", "KS8000").getPublisher();
			
			
			publisher.publishMessage(DebugUtil.loadSimulateData("0x3A"));
			
		}catch( Exception e ){
			e.printStackTrace();
		}
	}
	
	
	
	
	public static void initBasic(){
		//初始化Spring
		SpringBeanFacotry.getInstance().init("spring-common.xml");
//		SpringBeanFacotry.getInstance().init("spring-task.xml"); // local test
		LogCenter.root.info("Spring inited");
		try {
			//TODO 在初始化Spring之后才加入扫描，因为Handler中有Bean的注入。
			MessageHandlerRegister.registHandler(SystemConfigUtil.handlerPackagePath, MessageCommand.class);
			LogCenter.root.info("MessageHandlerRegister  registed");
		} catch (InstantiationException | IllegalAccessException e1) {
			e1.printStackTrace();
		}
	}
	
	
	public static void initMq(){
		
		try {
			ConnectionOption option = new ConnectionOption().withHostName(SystemConfigUtil.host).withPort(SystemConfigUtil.port)
					.withUserName(SystemConfigUtil.userName).withPassowrd(SystemConfigUtil.password);
			
			final Connection connection = ConnectionBuilder.createConnection(option);
			final Connection publisherConnection = ConnectionBuilder.createConnection(option);
			final Connection systemConnection = ConnectionBuilder.createConnection(option);
			final ThreadFactory consumerFactory = new NameThreadFacotry("rabbimt.consumer");
			final ThreadFactory selfReplyFactory = new NameThreadFacotry("rabbimt.selfReplyFactory");
			final ThreadFactory replyFactory = new NameThreadFacotry("rabbimt.replyFactory");
			
			//生产者
			for( Map.Entry<String, MqConnectionDeclaration> entry : SystemConfigUtil.publisherMapConnection.entrySet() ){
				final MqConnectionDeclaration mqDeclaration = entry.getValue();
				final String conpanyName = entry.getKey();
				ExecutorService publisherService = Executors.newFixedThreadPool(mqDeclaration.getThreadSum(), replyFactory);
				ReplyMessageThread replyMessageThread = new ReplyMessageThread(publisherService);
				replyMessageThread.start(conpanyName, publisherConnection, mqDeclaration);			
			}
			
			//消费者
			for( Map.Entry<String, MqConnectionDeclaration> entry : SystemConfigUtil.consumerMapConnection.entrySet() ){
				final MqConnectionDeclaration mqDeclaration = entry.getValue();
				final String conpanyName = entry.getKey();
				ExecutorService consumerService = Executors.newFixedThreadPool(mqDeclaration.getThreadSum(), consumerFactory);
				ConsumerThread consumerThread = new ConsumerThread(consumerService);
				List<Intercepter> interceptions = new ArrayList<Intercepter>();
//				interceptions.add(new Pusher());
				interceptions.add(new JPushIntercepter());
				consumerThread.start(connection, mqDeclaration, new MessageDispatcher(conpanyName, mqDeclaration.getFunctionIndex(), mqDeclaration.getContentIndex(),interceptions));
			}
			
			//系统层消费者
			for( Map.Entry<String, MqConnectionDeclaration> entry : SystemConfigUtil.systemConsumerMapConnection.entrySet() ){
				final MqConnectionDeclaration mqDeclaration = entry.getValue();
				ExecutorService consumerService = Executors.newFixedThreadPool(mqDeclaration.getThreadSum(), selfReplyFactory);
				ConsumerThread consumerThread = new ConsumerThread(consumerService);
				consumerThread.start(systemConnection, mqDeclaration,new RequestMessageDispatcher());
			}
			
			
		} catch (Exception e) {
			LogCenter.exception.error( "There are error occur when initing RMQ ...", e );
		}

	}
}
