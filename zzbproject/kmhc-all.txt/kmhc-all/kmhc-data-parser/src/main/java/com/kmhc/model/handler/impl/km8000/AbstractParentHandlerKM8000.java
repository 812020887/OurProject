package com.kmhc.model.handler.impl.km8000;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.InvocationTargetException;
import java.nio.CharBuffer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;

import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.EmgM;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.StringUtil;

public abstract class AbstractParentHandlerKM8000 extends AbstractHandler {

    public final int START_FRAME = 0;
    public final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public final SimpleDateFormat yyMMddHHmmss = new SimpleDateFormat("yyMMddHHmmss");
    private Logger log;

    public AbstractParentHandlerKM8000(Logger log) {
        this.log = log;
    }

    @Override
    public abstract ReplyMessageContent handleMessage(byte[] msg);

    protected EmgM parseEmgBase(byte[] data, int index) throws ParseException {
        EmgM entry = new EmgM();
        Date nowDate = new Date();
        entry.setImei(parseImeiOrImsi_KM8000(data, index));
        entry.setImsi(parseImeiOrImsi_KM8000(data, index + 8));
        entry.setEmgDate(sdf.parse(parseDateTime_KM8000(data, index + 16)));
        entry.setEmgKey(yyMMddHHmmss.format(nowDate));
        entry.setEmgDetailKey(entry.getEmgKey() + entry.getImei());
        entry.setCreateDate(nowDate);
        entry.setUpdateDate(nowDate);
        return entry;
    }

    protected String getCharData(byte[] data, int index, int len) {
        CharBuffer charbuf = CharBuffer.allocate(len);
        for (int i = 0; i < len; i++) {
            char c = (char) data[index + i];
            charbuf.put(c);
        }
        charbuf.flip();
        String result = charbuf.toString();
        while (result.startsWith("0") && result.length() > 1) {
            result = result.substring(1);
        }
        return result;
    }

    protected List<Cell> parseCellList(byte[] data, int index) {
        List<Cell> list = new ArrayList<Cell>();
        int cellNum = 0xFF & data[index];
        int cellIndex = index + 1;
        if (cellNum > 0) {
            for (int i = 0; i < cellNum; i++) {
                Cell cell = parseCell(data, cellIndex + i * 11);
                if (cell == null) {
                    break;
                }
                list.add(cell);
            }
        }
        return list;
    }

    protected Cell parseCell(byte[] data, int dex) {
        Cell cell = null;
        try {
            String mcc = getCharData(data, dex, 3);
            while (mcc.startsWith("0") && mcc.length() > 1) {
                mcc = mcc.substring(1);
            }
            String mnc = getCharData(data, dex + 3, 3);
            while (mnc.startsWith("0") && mnc.length() > 1) {
                mnc = mnc.substring(1);
            }
            cell = new Cell(mcc, mnc, Integer.parseInt(StringUtil.toHexString(data, dex + 6, 2), 16) + "",
                    Integer.parseInt(StringUtil.toHexString(data, dex + 8, 2), 16), (short) (0xFF & data[dex + 10]));
        } catch (Exception e) {
            log.error("解析Cell数据出错：", e);
        }
        return cell;
    }

    protected List<Wifi> parseWifiList(byte[] data, int index) {
        List<Wifi> list = new ArrayList<Wifi>();
        int wiFiNum = 0xFF & data[index];
        int wiFiIndex = index + 1;
        if (wiFiNum > 0) {
            for (int i = 0; i < wiFiNum; i++) {
                Wifi wifi = parseWifi(data, wiFiIndex + i * 9);
                if (wifi != null) {
                    list.add(wifi);
                }
            }
        }
        return list;
    }

    protected Wifi parseWifi(byte[] data, int index) {
        Wifi wifi = new Wifi();
        try {
            wifi.setWifiMac(StringUtil.toHexStringPadded(data, index, 6).toUpperCase());
            wifi.setWifiSignal((short) ( (0xFF & data[index + 6]) - 256));
            wifi.setWifiChannel((short) (0xFF & data[index + 7]));
            wifi.setWifiRatio((short) (0xFF & data[index + 8]));
        } catch (Exception e) {
            log.error("解析Wifi数据出错：", e);
        }
        return wifi;
    }

    protected void writeDebugLog(byte[] msg, String type) {
        String byte2hex = TripleDesHelper.byte2hex(msg, msg.length);
        log.debug("【type=KM8000,command=0x{}】收到数据：{}，处理中。。。", type, byte2hex);
    }

    public Logger getLog() {
        return log;
    }

    public void setLog(Logger log) {
        this.log = log;
    }
}
