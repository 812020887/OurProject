package com.kmhc.model.handler.impl.km8020;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.ServerActionHisMapper;
import com.kmhc.model.datacenter.dao.T9SilentSettingMapper;
import com.kmhc.model.datacenter.model.ServerActionHis;
import com.kmhc.model.datacenter.model.T9SilentSetting;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;

@MessageCommand(type = "KM8020", command = "0x543900")
public class SilentSettingHandlerImpl extends AbstractParentHandlerKM8020 {

    private static final Logger log = LoggerFactory.getLogger(SilentSettingHandlerImpl.class);
    private ServerActionHisMapper serverActionHisMapper = (ServerActionHisMapper) SpringBeanFacotry.getInstance().getBean("serverActionHisMapper");
    private T9SilentSettingMapper t9SilentSettingMapper = (T9SilentSettingMapper) SpringBeanFacotry.getInstance().getBean("t9SilentSettingMapper");

    public SilentSettingHandlerImpl() {
        super(log);
    }

    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
        //460001515535328,1,abcd,2011-12-1510:00:00,355372020827303,S9,8:00-12:00|1111111;14:00-16:30|1111100  in server_action_his content
        //[V1.0.0,460001515535328,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T9]
        log.info(new String(msg));
        String protocol = "S9";
        String content[] = new String(msg).split(",");
        String uid = content[0];
        String imei = content[5];

        ServerActionHis record = serverActionHisMapper.selectByPrimaryKey(uid, imei, protocol);
        if (record != null) {
            String command[] = record.getContent().split(",");
            String tmp[] = command[7].split(";");

            int flag = 0;
            T9SilentSetting silent = null;
            silent = t9SilentSettingMapper.selectByPrimaryKey(imei);
            if (silent == null) {
                silent = new T9SilentSetting();
                flag = 1;
            }
            silent.setImei(imei);
            silent.setUpdatedate(new Date());

            for (int i = 0; i < 3 && i < tmp.length; i++) {
                String timeStr = tmp[i].split("\\|")[0];
                String dayflag = tmp[i].split("\\|")[1];
                String startTime = timeStr.split("-")[0];
                String endTime = timeStr.split("-")[1];
                switch (i) {
                    case 0:
                        silent.setStarttime1(startTime);
                        silent.setEndtime1(endTime);
                        silent.setDayflag1(dayflag);
                        break;
                    case 1:
                        silent.setStarttime2(startTime);
                        silent.setEndtime2(endTime);
                        silent.setDayflag2(dayflag);
                        break;
                    case 2:
                        silent.setStarttime3(startTime);
                        silent.setEndtime3(endTime);
                        silent.setDayflag3(dayflag);
                        break;
                    default:
                        break;
                }
            }

            int success = 0;
            try {
                if (flag == 0) success = t9SilentSettingMapper.updateByPrimaryKey(silent);
                else {
                    silent.setCreatedate(new Date());
                    success = t9SilentSettingMapper.insert(silent);
                }
            } catch (Exception e) {
                log.error(e.toString());
            }
            if (success > 0) {
                serverActionHisMapper.deleteByPrimaryKey(record.getUid(), record.getImei(), protocol);
                pushSettingFinish(imei, INotification.NOTIFICATION_TYPE_SETTING_SILENT);
            }
        }
//		log.info("push fail notification to app");
        return null;
    }

    @Override
    public boolean handleMessage(String json) {
        // TODO Auto-generated method stub
        return false;
    }
}
