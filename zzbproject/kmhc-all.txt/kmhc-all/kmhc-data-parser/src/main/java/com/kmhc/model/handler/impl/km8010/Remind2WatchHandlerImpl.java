package com.kmhc.model.handler.impl.km8010;

import java.util.Date;
import java.util.HashMap;

import org.apache.commons.codec.Charsets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrSettingMapper;
import com.kmhc.model.datacenter.model.PsrSetting;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type = "KM8010", command = "0x31")
public class Remind2WatchHandlerImpl extends AbstractParentHandlerKM8010 {

	private String type = "31";
	private static final Logger log = LoggerFactory.getLogger(Remind2WatchHandlerImpl.class);
	private PsrSettingMapper psrSettingMapper = (PsrSettingMapper) SpringBeanFacotry.getInstance().getBean("psrSettingMapper");
	private PsrSetting psrSetting = null;
	
	public Remind2WatchHandlerImpl() {
		super(log);
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,type);
		
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);
		byte[] content = AbstractHandler.ACK_ERROR_KM8010;

		Object[] objs = byte2obj(msg);
		psrSetting = getPsrSettingByObjs(objs);
		if(psrSetting == null && ((short)objs[3] == 1 || (short)objs[3] == 2) && (short)objs[4] < 5){
			psrSetting = generatePsrSetting(objs,"");
		}
		
		if(psrSetting != null){
			content = generateContentByPsretting(psrSetting);
			psrSetting.setUpdated("Y");
			psrSettingMapper.updateByPrimaryKey(psrSetting);
		}
		return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(content,(byte) 0x31));
	}
	
	private Object[] byte2obj( byte[] original ){
		int[] sections = new int[]{8,5,1,1,1};// imei,date,action,type,sequence
		String[] types = new String[]{"IMEI","Date","Short","Short","Short"};
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		Object[] objs = BytesConvertionUtil.generateProperty4KM8010(original, sections, types, indexMapPolishing);
		return objs;
	}
	
	private PsrSetting getPsrSettingByObjs(Object[] objs){
		return psrSettingMapper.selectSingleByTeamAndType((String)objs[0], String.format("%02d",((short)objs[4]+1)), String.format("%02d",(short)objs[3]));
	}
	
	private PsrSetting generatePsrSetting(Object[] objs ,String text){
		PsrSetting psr = new PsrSetting();
		psr.setsImei((String) objs[0]);
		psr.setIsvalid("N");		
		psr.setsYear("2016");
		psr.setsMon("01");
		psr.setsDay("01");
		psr.setsHour("12");
		psr.setsMin("00");		
        psr.setT7Hex("0");
        psr.setT1Hex("0");
        psr.setT2Hex("0");
        psr.setT3Hex("0");
        psr.setT4Hex("0");
        psr.setT5Hex("0");
        psr.setT6Hex("0");       
        psr.setAttribute1(text);
        psr.setAttribute3(0);
        psr.setAttribute4(0);
        psr.setAttribute5(0);
        psr.setAttribute6(0);
        psr.setsTeam("0" + String.valueOf(((short)objs[4])+1));
        psr.setsType("0" + String.valueOf((short)objs[3]));
        psr.setsUpdatedate(new Date());
        psr.setUpdated("N");
        log.debug("insert setting result: " + String.valueOf(psrSettingMapper.insert(psr)));
        return psr;
	}
	
	private byte[] generateContentByPsretting(PsrSetting psr){	
		
		int year = Integer.valueOf((psr.getsYear() == null || psr.getsYear() == "" || psr.getsYear().length() < 4) ? "16" :  psr.getsYear().substring(2));
		int month = Integer.valueOf((psr.getsMon() == null || psr.getsMon() == "" ||  psr.getsMon().length() < 2) ? "01" :  psr.getsMon());
		int day = Integer.valueOf((psr.getsDay() == null || psr.getsDay() == "" ||  psr.getsDay().length() < 2) ? "01" :  psr.getsDay());
		int hour = Integer.valueOf((psr.getsHour() == null || psr.getsHour() == "" ||  psr.getsHour().length() < 2) ? "12" :  psr.getsHour());
		int min = Integer.valueOf((psr.getsMin() == null || psr.getsMin() == "" ||  psr.getsMin().length() < 2) ? "00" :  psr.getsMin());

		byte[] remindTime = new byte[5];
		remindTime[0] = (byte) year;
		remindTime[1] = (byte) month;
		remindTime[2] = (byte) day;
		remindTime[3] = (byte) hour;
		remindTime[4] = (byte) min;
		
		byte[] message = (psr.getAttribute1() == null ) ? "".getBytes(Charsets.UTF_8) :  psr.getAttribute1().getBytes(Charsets.UTF_8);
		
		int contidx = 0;
		byte[] content = new byte[message.length + 8];
		
		if(psr.getIsvalid().equals("Y")) content[contidx] = (byte)1; else content[contidx] = (byte)0;
		contidx += 1;
		
		System.arraycopy(remindTime, 0, content, contidx, remindTime.length);
		contidx += remindTime.length;
		
		int repeat = 0;
		if(psr.getT7Hex().equals("1")) repeat += 1;
		if(psr.getT1Hex().equals("1")) repeat += 2;
		if(psr.getT2Hex().equals("1")) repeat += 4;
		if(psr.getT3Hex().equals("1")) repeat += 8;
		if(psr.getT4Hex().equals("1")) repeat += 16;
		if(psr.getT5Hex().equals("1")) repeat += 32;
		if(psr.getT6Hex().equals("1")) repeat += 64;
		content[contidx] = (byte)repeat;
		contidx += 1;
		
		System.arraycopy(message, 0, content, contidx, message.length);
		contidx += message.length;
		
		content[contidx] = 0x01;
		if(psr.getsType().equals("02") && psr.getsTeam().equals("05")){
			if(psrSettingMapper.selectSingleByTeamAndType(psr.getsImei(), "01", "04") == null)
				content[contidx] = 0x00;
		}else if(psr.getsType().equals("04")){
			if(psrSettingMapper.selectSingleByTeamAndType(psr.getsImei(), String.format("%02d",(Integer.valueOf(psr.getsTeam()) + 1)), "04") == null)
				content[contidx] = 0x00;
		}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
		return content;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
