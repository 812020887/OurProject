package com.kmhc.model.util;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



/**httpClient工具类，主要是封装get和post请求
 * @author xl
 *
 */
public class HttpClientUtils {

    private static final Logger log = LoggerFactory.getLogger(HttpClientUtils.class);
    /**
     * @param url http请求地址
     * @param requestType http请求类型，POST、GET
     * @param contentType 请求内容类型，指Content Type ,例如：application/json、application/xml
     * @param content 请求内容
     * @param acceptContentType 请求内容类型，例如：application/json、application/xml
     * @param encoding 字符编码，如：GBK、UTF-8
     * @param connectTimeout 连接超时时间，指最多能容忍多久才建立连接，单位毫秒，如5000,表示5秒
     * @param socketTimeout 定义socket超时时间({@code SO_TIMEOUT})，单位毫秒，指两种情况，一种是第一个数据帧的响应时间不能超过此值，第二种情况是两个数据帧最长间隔时间不能超过此值
     * 
     * @return
     */
    public static byte[] request(String url,String requestType,String contentType,String content,String acceptContentType,String encoding,int connectTimeout,int socketTimeout){
        byte[] result = null;
        if(requestType!=null&&requestType.equalsIgnoreCase("GET")){
            result = get(url,content, acceptContentType, encoding, connectTimeout, socketTimeout);
        }else if(requestType!=null&&requestType.equalsIgnoreCase("POST")){
            result = post(url, contentType, content, acceptContentType, encoding, connectTimeout, socketTimeout);
        }
        return result;
        
    }
    
    public static String request(String url){
    	String byteArray = null;
         log.debug("调用Http GET请求,url:{}",url);
         HttpGet httpGet = new HttpGet(url);
         RequestConfig config = RequestConfig.custom()
         .setConnectTimeout(5000)
         .setSocketTimeout(5000).build();
         httpGet.setConfig(config);
         try {
             CloseableHttpClient httpclient = HttpClients.createDefault();
             CloseableHttpResponse response = httpclient.execute(httpGet);
             byteArray = EntityUtils.toString(response.getEntity());
             log.debug("获取返回后的数据转Text:{}",byteArray);
         } catch (ClientProtocolException e) {
             e.printStackTrace();
             log.error("调用Http GET请求异常：",e);
         } catch (IOException e) {
             e.printStackTrace();
             log.error("调用Http GET请求异常：",e);
         }catch(Exception e){
             e.printStackTrace();
             log.error("调用Http GET请求异常：",e);
         }
         return byteArray;
    }
    
    private static byte[] get(String url,String content,String acceptContentType,String encoding,int connectTimeout,int socketTimeout){
        byte[] byteArray = null;
        if(content!=null && !"".equals(content)){
            url = url+converSpect(content);
        }
        log.debug("调用Http GET请求,url:{}",url);
        HttpGet httpGet = new HttpGet(url);
        RequestConfig config = RequestConfig.custom()
        .setConnectTimeout(connectTimeout)
        .setSocketTimeout(socketTimeout).build();
        httpGet.setConfig(config);
        try {
            CloseableHttpClient httpclient = HttpClients.createDefault();
            CloseableHttpResponse response = httpclient.execute(httpGet);
            byteArray = EntityUtils.toByteArray(response.getEntity());
        } catch (ClientProtocolException e) {
            e.printStackTrace();
            log.error("调用Http GET请求异常：",e);
        } catch (IOException e) {
            e.printStackTrace();
            log.error("调用Http GET请求异常：",e);
        }
        return byteArray;
        
    }
    private static byte[] post(String url,String contentType,String content,String acceptContentType,String encoding,int connectTimeout,int socketTimeout){
        
        return null;
        
    }
    
   private static String converSpect(String str){
        
        return str.replace("|", "%7C").replace(":", "%3A");
    }
}
