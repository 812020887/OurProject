package com.kmhc.model.handler.impl.km8010;

import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.ProductPerSettingMMapper;
import com.kmhc.model.datacenter.dao.ProductSysSettingMMapper;
import com.kmhc.model.datacenter.model.ProductPerSettingM;
import com.kmhc.model.datacenter.model.ProductSysSettingM;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.framework.util.TripleDesHelper;

@MessageCommand(type="KM8010",command="0xA1")
public class Setting2WatchHandlerImpl extends AbstractParentHandlerKM8010 {

    private String type = "A1";
	private static final Logger log = LoggerFactory.getLogger(Setting2WatchHandlerImpl.class);

	public Setting2WatchHandlerImpl() {
		super(log);
	}

	private ProductSysSettingMMapper productSysSettingMMapper = (ProductSysSettingMMapper) SpringBeanFacotry.getInstance().getBean("productSysSettingMMapper");
	private ProductPerSettingMMapper productPerSettingMMapper = (ProductPerSettingMMapper) SpringBeanFacotry.getInstance().getBean("productPerSettingMMapper");
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,type);
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);
		Object[] objs = byte2obj(msg);
		
		ProductSysSettingM sysSetting = productSysSettingMMapper.selectByPrimaryKey(String.valueOf(objs[0]));
		ProductPerSettingM perSetting = productPerSettingMMapper.selectByPrimaryKey(String.valueOf(objs[0]));
		
		if( sysSetting != null || perSetting != null )
			return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(generateContent( sysSetting, perSetting ), (byte) 0xA1));
		
		return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) 0xA1));
	}
	
	public Object[] byte2obj( byte[] original ){
		int[] sections = new int[]{8,5};
		String[] types= new String[]{"IMEI","Date"};
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		Object[] objs = BytesConvertionUtil.generateProperty4KM8010(original, sections, types, indexMapPolishing);
		return objs;
	}
	
	public byte[] generateContent( ProductSysSettingM sysSetting, ProductPerSettingM perSetting ){
		
		byte[] result = new byte[79];

		byte[] sosNo1 = new byte[8];
		byte[] sosNo2 = new byte[8];
		byte[] sosNo3 = new byte[8];
		byte[] contact1 = new byte[8];
		byte[] contact2 = new byte[8];
		byte[] contact3 = new byte[8];
		byte[] fallNo1 = new byte[8];
		byte[] fallNo2 = new byte[8];
		byte[] fallNo3 = new byte[8];
		byte[] settings = new byte[4];
		byte[] footLength = new byte[4];
		byte[] height = new byte[2];
		byte[] weight = new byte[2];

		if( perSetting != null ){
			contact1 = TripleDesHelper.specailStringToByteArray(perSetting.getFmlyPhoneNo1().replace("#", ""));
			contact2 = TripleDesHelper.specailStringToByteArray(perSetting.getFmlyPhoneNo2().replace("#", ""));
			contact3 = TripleDesHelper.specailStringToByteArray(perSetting.getFmlyPhoneNo3().replace("#", ""));
			sosNo1 = TripleDesHelper.specailStringToByteArray(perSetting.getSosPhoneNo1().replace("#", ""));
			sosNo2 = TripleDesHelper.specailStringToByteArray(perSetting.getSosPhoneNo2().replace("#", ""));
			sosNo3 = TripleDesHelper.specailStringToByteArray(perSetting.getSosPhoneNo3().replace("#", ""));		
			fallNo1 = TripleDesHelper.specailStringToByteArray(perSetting.getFallPhoneNo1().replace("#", ""));
			fallNo2 = TripleDesHelper.specailStringToByteArray(perSetting.getFallPhoneNo2().replace("#", ""));
			fallNo3 = TripleDesHelper.specailStringToByteArray(perSetting.getFallPhoneNo3().replace("#", ""));
			footLength = TripleDesHelper.ParserInt(perSetting.getuStep());	
			height = TripleDesHelper.floatToBytes(perSetting.getuHeight().floatValue());
			weight = TripleDesHelper.floatToBytes(perSetting.getuWeight().floatValue());
		}

		settings = generateSettingResult( sysSetting, perSetting );
		
		System.arraycopy(contact1, 0, result, 0, 8);
		System.arraycopy(contact2, 0, result, 8, 8);
		System.arraycopy(contact3, 0, result, 16, 8);
		System.arraycopy(sosNo1, 0, result, 24, 8);
		System.arraycopy(sosNo2, 0, result, 32, 8);
		System.arraycopy(sosNo3, 0, result, 40, 8);
		System.arraycopy(fallNo1, 0, result, 48, 8);
		System.arraycopy(fallNo2, 0, result, 56, 8);
		System.arraycopy(fallNo3, 0, result, 64, 8);
		System.arraycopy(settings, 2, result, 72, 2);
		System.arraycopy(footLength, 3, result, 74, 1);
		System.arraycopy(height, 0, result, 75, 2);
		System.arraycopy(weight, 0, result, 77, 2);
		
		return result;
	}
	
	public byte[] generateSettingResult( ProductSysSettingM sysSetting, ProductPerSettingM perSetting ){
		int setting = 0;
		if( sysSetting != null){
			short phoneLimit = sysSetting.getPhoneLimitTime();
			short gpsTime = sysSetting.getEchoGpsT();
			short regularTime = sysSetting.getEchoPrT();
			short autoScreen = sysSetting.getAutoread();
			switch (phoneLimit){
				case 5:
					setting += 512;
					break;
				case 15:
					setting += 1024;
					break;
				case 30:
					setting += 1536;
					break;
				case 60:
					setting += 2048;
					break;
				default:
					break;
			}
			
			switch (gpsTime){
			case 5:
				setting += 64;
				break;
			case 15:
				setting += 128;
				break;
			case 30:
				setting += 192;
				break;
			case 60:
				setting += 256;
				break;
			default:
				break;
			}
			
			switch (regularTime){
			case 30:
				setting += 0;
				break;
			case 60:
				setting += 4096;
				break;
			case 90:
				setting += 8192;
				break;
			case 120:
				setting += 12288;
				break;
			default:
				break;
			}
			
			if( autoScreen != 0 ){
				setting += 32;
			}
		}
		if( perSetting != null ){
			short nonDistrub = perSetting.getNonDistrub();
			short fallDetect = perSetting.getFallDetect();
			if( fallDetect != 0 )
				setting += 1;
			if( nonDistrub != 0 )
				setting += 4;			
		}
		return TripleDesHelper.ParserInt(setting);
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
