package com.kmhc.model.core;

import java.util.Arrays;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.handler.impl.PushAlert;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.util.Publish;

public class JPushIntercepter implements Intercepter {

	private static final Logger log = LoggerFactory.getLogger(JPushIntercepter.class);
	
	@Override
	public Object exe(String protocolName, byte[] msg) {
		boolean flag = false;

		byte[] imeibyte = Arrays.copyOfRange(msg, 0, 8);
		String imei = TripleDesHelper.byte2hex(imeibyte, 8);
		String imeiConvertion = imei.substring(1, imei.length()) + "0";
		imeibyte = TripleDesHelper.hex2byte(imeiConvertion);

		String byte2hex = TripleDesHelper.byte2hex(msg, msg.length);
		log.info("【JPUSH INTERCEPTIONS,command={}, imei={}】收到数据：{}，PUSH处理中。。。", protocolName, imei, byte2hex);

		String alert = "";
		String title = "";
		String extras = "";
		int builder_id = INotification.ANDROID_MAKER_DEFAULT;

		if(protocolName.equals("0xBB")){
			imei = imei.substring(1, imei.length());
			alert = new PushAlert(new Object[] { imei }, "power_low_key").toString();
			title = "power_low_title_key";
			builder_id = INotification.ANDROID_MAKER_BATTARY;
			extras = String.format("imei=%s|",imei);
			extras += String.format("type=%s|",INotification.NOTIFICATION_TYPE_BATTERY);
			extras += String.format("level=%d|",INotification.NOTIFICATION_LEVEL_LOW);
			extras += String.format("builder_id=%d|",INotification.ANDROID_MAKER_BATTARY);
			extras += "device=KM8010|";
			flag = true;
		}else if(protocolName.equals("0xB2")){
			imei = imei.substring(1, imei.length());
			alert = new PushAlert(new Object[] { imei }, "power_off_key").toString();
			title = "power_off_title_key";
			builder_id = INotification.ANDROID_MAKER_DEFAULT;
			extras = String.format("imei=%s|",imei);
			extras += String.format("type=%s|",INotification.NOTIFICATION_TYPE_DEFAULT);
			extras += String.format("level=%d|",INotification.NOTIFICATION_LEVEL_LOW);
			extras += String.format("builder_id=%d|",INotification.ANDROID_MAKER_DEFAULT);
			extras += "device=KM8010|";
			flag = true;
		}

		if (flag) {
			Publish.push(imei, alert, title, builder_id, extras);
		}
		return msg;
	}

	public static void main(String[] args) {
		new JPushIntercepter().exe(null, null);
	}

}
