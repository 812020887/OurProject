package com.kmhc.model.handler.impl.c100;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.DeviceListMapper;
import com.kmhc.model.datacenter.dao.VoiceUploadRecordMapper;
import com.kmhc.model.datacenter.model.DeviceList;
import com.kmhc.model.datacenter.model.VoiceUploadRecord;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type = "C100", command = "0x12")
public class VoiceReadInformHandlerImpl extends AbstractParentHandlerC100 {

	private String function = "12";
	private static final Logger log = LoggerFactory.getLogger(VoiceReadInformHandlerImpl.class);
	private DeviceListMapper deviceListMapper = (DeviceListMapper) SpringBeanFacotry.getInstance().getBean("deviceListMapper");
	private VoiceUploadRecordMapper voiceUploadRecordMapper = (VoiceUploadRecordMapper) SpringBeanFacotry.getInstance().getBean("voiceUploadRecordMapper");

	public VoiceReadInformHandlerImpl() {
		super(log);
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,function);
		int index = 0 ;
		byte[] snBytes= Arrays.copyOfRange(msg, index, index + 9) ;

		int[] sections = new int[]{9,8};
		String[] types= new String[]{"SN", "LONG"};
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);	
		Object[] objs = BytesConvertionUtil.generateProperty4C100(msg, sections, types, indexMapPolishing);
		String sn = (String) objs[0];
		
		DeviceList deviceList = deviceListMapper.selectBySn(sn);
		if(deviceList != null){
			String imei = deviceList.getImei();
			Long timen = (Long) objs[1];
			VoiceUploadRecord record = voiceUploadRecordMapper.selectByPrimaryKey(imei, timen);
			if(record != null && record.getSrc()== 1 ){
				record.setState(1);
				voiceUploadRecordMapper.updateByPrimaryKey(record);
				//發送語音已讀訊息
			}
		}
		return MessageBuilder.buildReplyMessageContent(snBytes, generateResponse((byte) 0x92));		
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
