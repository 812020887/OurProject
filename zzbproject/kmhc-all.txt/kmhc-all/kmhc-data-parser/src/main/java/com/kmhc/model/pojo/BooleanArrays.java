/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月19日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.pojo;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Name: BooleanArrays.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.pojo.BooleanArrays.java]
 * Description: 线程安全的boolean数组类，可用于开关功能需求  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月19日 上午11:42:12
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class BooleanArrays {
	
	private final Integer capacity;
	private final AtomicBoolean[] booleanArrays;
	
	/** 
	 * @Title: BooleanArrays
	 * @Description: TODO
	 * @param @param capacity
	 * @param @param booleanArrays         
	 * @throws 
	 */ 
	public BooleanArrays(Integer capacity) {
		super();
		this.capacity = capacity;
		booleanArrays = new AtomicBoolean[capacity];
		for (int i = 0; i < capacity; i++) {
			booleanArrays[i] = new AtomicBoolean(false);
		}
	}
	
	public void setBoolean( int index, boolean param ){
		if ( index > capacity | index < 0 ) 
			throw new RuntimeException("the index is out of Range!!");
		booleanArrays[index].getAndSet(param);
	}
	
	public boolean[] getBoolean(){
		boolean[] result = new boolean[capacity];
		for (int i = 0; i < capacity; i++) {
			result[i] = booleanArrays[i].get();
		}
		return result;
	}

}
