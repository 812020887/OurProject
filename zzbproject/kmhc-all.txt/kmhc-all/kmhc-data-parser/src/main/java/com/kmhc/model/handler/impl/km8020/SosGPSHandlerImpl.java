package com.kmhc.model.handler.impl.km8020;

import java.math.BigDecimal;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.EmgMMapper;
import com.kmhc.model.datacenter.dao.T9DeviceStatusMapper;
import com.kmhc.model.datacenter.model.EmgM;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.T9DeviceStatus;
import com.kmhc.model.handler.impl.km8020.AbstractParentHandlerKM8020;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type = "KM8020", command = "0x543835")
public class SosGPSHandlerImpl extends AbstractParentHandlerKM8020 {

    private static final Logger log = LoggerFactory.getLogger(GPSHandlerImpl.class);
    private EmgMMapper emgMMapper = (EmgMMapper) SpringBeanFacotry.getInstance().getBean("emgMMapper");
    private T9DeviceStatusMapper t9DeviceStatusMapper = (T9DeviceStatusMapper) SpringBeanFacotry.getInstance().getBean("t9DeviceStatusMapper");

    public SosGPSHandlerImpl() {
        super(log);
    }

    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
        //[V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T85,SOS_GPS,104.063469,30.551357,181.899994,0.217000,221.479996,3,1267511609]
        // a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T85,SOS_GPS,104.063469,30.551357,181.899994,0.217000,221.479996,3,1267511609
        log.info(new String(msg));
        String function = "S85";
        String content[] = new String(msg).split(",");
        String uid = content[0];
        String timeStr = content[3];
        String imei = content[5];
        String tzStr = "GMT+" + content[6];
        String lng = content[9];
        String lat = content[10];

        Date dt = com.kmhc.model.util.Date.getDate(timeStr, "yyyy-MM-dd HH:mm:ss", tzStr);
        log.debug(sdf.format(dt));

        BigDecimal gpsLat = new BigDecimal(lat).setScale(10, BigDecimal.ROUND_HALF_UP);
        BigDecimal gpsLng = new BigDecimal(lng).setScale(10, BigDecimal.ROUND_HALF_UP);
        Gps gps = new Gps(gpsLat, gpsLng, "N", "E", "Y");
        Gps converGps = LocUtil.conver(gps);
        gps = converGps;
        EmgM emgm = new EmgM();
        Date nowDate = new Date();
        emgm.setImei(imei);
        emgm.setEmgDate(dt);
        emgm.setEmgKey(yyMMddHHmmss.format(new Date()));
        emgm.setEmgDetailKey(emgm.getEmgKey() + emgm.getImei());
        emgm.setCreateDate(nowDate);
        emgm.setUpdateDate(nowDate);
        emgm.setType(function);
        emgm.setGpsLat(gpsLat);
        emgm.setGpsLng(gpsLng);
        emgm.setIsvalid("Y");
        emgm.setLocStatus("Y");
        emgm.setGpsNsLat("N");
        emgm.setGpsEwLng("E");
        emgm.setLocType("GPS");
        String reverseGeocoding = LocUtil.reverseGeocoding(converGps.getLat(), converGps.getLng());
        if (reverseGeocoding == null) {
            reverseGeocoding = "";
        }
        emgm.setAddress(reverseGeocoding);
        if (emgMMapper.selectByPrimaryKey(emgm.getEmgKey(), emgm.getImei()) != null) {
            emgMMapper.updateByPrimaryKey(emgm);
        } else {
            emgMMapper.insertSelective(emgm);
        }
        sendNotification(emgm, "KM8020", null);

        T9DeviceStatus device = t9DeviceStatusMapper.selectByImei(imei);

        if (device != null) {
            if (gps.getIsValid().equals("Y")) {
                device.setLatitude(gps.getLat());
                device.setLongitude(gps.getLng());
                device.setLbstime(dt);
            }
            device.setUpdatetime(dt);
            t9DeviceStatusMapper.updateByPrimaryKey(device);
            push8000Gps(imei, "KM8020", "S85");
        }

        dt = new Date();
        String out[] = {uid, content[1], content[2], sdf.format(dt), imei, function};
        //[V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,355372020827303,S85]
        return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"), generateResponse(out));
    }

    @Override
    public boolean handleMessage(String json) {
        // TODO Auto-generated method stub
        //T85,SOS_GPS,longitude,latitude,height,speed,direction,StarNumber,timen,imei
        try {
            log.info(json);
            String function = "S85";
            String content[] = json.split(",");
            String lng = content[2];
            String lat = content[3];
            String imei = content[content.length - 1];

            BigDecimal gpsLat = new BigDecimal(lat).setScale(10, BigDecimal.ROUND_HALF_UP);
            BigDecimal gpsLng = new BigDecimal(lng).setScale(10, BigDecimal.ROUND_HALF_UP);
            Gps gps = new Gps(gpsLat, gpsLng, "N", "E", "Y");
            Gps converGps = LocUtil.conver(gps);
            gps = converGps;
            EmgM emgm = new EmgM();
            Date nowDate = new Date();
            emgm.setImei(imei);
            emgm.setEmgDate(new Date((Long.parseLong(content[8]) - (Long.parseLong("8") * 3600)) * 1000));
            emgm.setEmgKey(yyMMddHHmmss.format(new Date()));
            emgm.setEmgDetailKey(emgm.getEmgKey() + emgm.getImei());
            emgm.setCreateDate(nowDate);
            emgm.setUpdateDate(nowDate);
            emgm.setType(function);
            emgm.setGpsLat(gpsLat);
            emgm.setGpsLng(gpsLng);
            String reverseGeocoding = LocUtil.reverseGeocoding(converGps.getLat(), converGps.getLng());
            if (reverseGeocoding == null) {
                reverseGeocoding = "";
            }
            emgm.setAddress(reverseGeocoding);
            if (emgMMapper.selectByPrimaryKey(emgm.getEmgKey(), emgm.getImei()) != null) {
                emgMMapper.updateByPrimaryKey(emgm);
            } else {
                emgMMapper.insertSelective(emgm);
            }
            sendNotification(emgm, "KM8020", null);
            T9DeviceStatus device = t9DeviceStatusMapper.selectByImei(imei);
            if (device != null) {
                if (gps.getIsValid().equals("Y")) {
                    device.setLatitude(gps.getLat());
                    device.setLongitude(gps.getLng());
                }
                t9DeviceStatusMapper.updateByPrimaryKey(device);
                push8000Gps(imei, "KM8020", "S85");
            }
        } catch (Exception e) {
            // TODO: handle exception
            return false;
        }
        return true;
    }
}
