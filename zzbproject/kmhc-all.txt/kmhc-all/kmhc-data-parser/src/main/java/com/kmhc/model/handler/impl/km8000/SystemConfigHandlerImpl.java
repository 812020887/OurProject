/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: czx
 *               Date: 2015年11月11日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8000;





import java.io.UnsupportedEncodingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.ProductSysSettingMMapper;
import com.kmhc.model.datacenter.model.ProductSysSettingM;
import com.kmhc.model.datacenter.service.IWatchUpdateService;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.StringUtil;



/**
 * Name: SystemConfigHandlerImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.SystemConfigHandlerImpl.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: czx
 * @date: 2015年11月19日 下午2:11:46
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */

@MessageCommand(type="KM8000",command="0x10")
public class SystemConfigHandlerImpl  extends AbstractHandler  {

	public static final Logger log = LoggerFactory.getLogger(SystemConfigHandlerImpl.class);
	
	private static char[] serverIP_tab = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '#' };
	
	private static String[] serverIP_digit = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "#" };
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {		
		// TODO Auto-generated method stub
		String imei = null;
		byte[] reMsg = null;
		byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
		try{
			ProductSysSettingMMapper  pSMMapper = 
					(ProductSysSettingMMapper) SpringBeanFacotry.getInstance().getBean("productSysSettingMMapper");
						
			//ProductSysSettingM record = constructRecord(msg);
			//ProductSysSettingM record = new ProductSysSettingM();
		    imei = parseImeiOrImsi_KM8000(msg,0);
		    //record.setImei(imei);
			
		    
		    IWatchUpdateService watchUpdateService = (IWatchUpdateService) SpringBeanFacotry.getInstance().getBean("watchUpdateServiceImpl");
		    ProductSysSettingM record = pSMMapper.selectByPrimaryKey(imei);			
			
		    boolean handlerOutput = false;
		    boolean isNew = false;
		    if(record==null){
		    	record = new ProductSysSettingM();		    
		    	isNew = true;
		    }
			constructRecord(msg,record);
		    handlerOutput= watchUpdateService.updateOx10Data(record, isNew);
		    		    
			if(handlerOutput == true){
				reMsg = AbstractHandler.ACK_SUCCESS_KM8000;
			}else{
				reMsg = AbstractHandler.ACK_ERROR_KM8000;
			}
			
		}catch(Exception e){
			log.error("记录系统信息出错。",e);
			reMsg = AbstractHandler.ACK_ERROR_KM8000;
		}
	
		ReplyMessageContent replyMessageContent = null;
		if(imei != null && reMsg != null ){
			push8000Gps(imei,"KM8000","0x10");	
			replyMessageContent = new ReplyMessageContent(imeiBytes,reMsg);
		}
			
		return replyMessageContent;
	}
	
	/**
	 * 根据上传的封包入库
	 * @throws UnsupportedEncodingException 
	 */
	public ProductSysSettingM constructRecord(byte[] msg,ProductSysSettingM record) throws UnsupportedEncodingException {
		
		int offset = 0 ;
		String imei = parseImeiOrImsi_KM8000(msg,offset+0);
	    String imsi = parseImeiOrImsi_KM8000(msg,offset+8);
	 
	    record.setImei(imei);
	    record.setImsi(imsi);
	    
	    
		String ip1 = toServerIPString(msg,offset+16,17);
	    record.setIp1(ip1);
	    String ip2 = toServerIPString(msg,offset+33,17);
	    record.setIp2(ip2);
	    String ip3 = toServerIPString(msg,offset+50,17);
	    record.setIp3(ip3);
	    
	    record.setEchoPrT((short)(0xFF & msg[offset+67]));
	    record.setEchoPrH(Short.valueOf(StringUtil.toHexStringPadded(msg,offset+68,1)));
	    record.setEchoPrM(Short.valueOf(StringUtil.toHexStringPadded(msg,offset+69,1)));
	    record.setEchoPrS(Short.valueOf(StringUtil.toHexStringPadded(msg,offset+70,1)));
	    
	    record.setEchoGpsT((short)(0xFF & msg[offset+71]));
	    
	    record.setPhoneLimitOnoff((short)(0xFF & msg[offset+72]));
	    record.setPhoneLimitTime((short)(0xFF & msg[offset+73]));
	    record.setPhoneLimitMode((short)(0xFF & msg[offset+74]));
	    record.setPhoneLimitByCustomer((short)(0xFF & msg[offset+75]));
	    
	    record.setDialoutLimitTime((short)(0xFF00 & (short)(msg[offset+76] << 8) | 0xFF & (short)msg[offset+77]));
	    record.setDialoutLimitStartday((short)(0xFF & msg[offset+78]));
	  	
	    record.setAutoread((short)(0xFF & msg[offset+79]));
	    
	    record.setPoweronLogo((short)(0xFF & msg[offset+80]));
	    
	    record.setChecksumS((short)(0xFF00 & (short)(msg[offset+81] << 8) | 0xFF & (short)msg[offset+82]));
	    
		return record;
	}
	
	
	public  String toServerIPString( byte[] array, int startIdx, int length) {
		StringBuffer sB = new StringBuffer("");
		boolean foundDigit = false;
		boolean lastDigitZero = false;
		int lastIdx = startIdx + length;
		int k = 0;
		int l = 0;
		for (int i = startIdx; i < lastIdx; ++i) {
			for (int j = 0; j < serverIP_tab.length; ++j) {
				if (array[i] == serverIP_tab[j]) {
					foundDigit = true;
					if ((k == 0) && (serverIP_tab[j] == '0')) {
						++k;
						lastDigitZero = true;
						break;
					}

					if ((k == 0) && (serverIP_tab[j] != '0'))
						lastDigitZero = false;

					if (k == 2) {
						if (l == 3) {
							sB.append(serverIP_digit[j]);
							sB.append(":");
							++l;
							k = 0;
							break;
						}
						if (l == 4) {
							if (serverIP_tab[j] == '0') {
								++k;
								if (lastDigitZero)
									break;
								sB.append(serverIP_digit[j]);
								break;
							}

							++k;
							sB.append(serverIP_digit[j]);
							lastDigitZero = false;
							break;
						}

						sB.append(serverIP_digit[j]);
						sB.append(".");
						++l;
						k = 0;
						break;
					}

					if (k == 1) {
						if (serverIP_tab[j] == '0') {
							++k;
							if (lastDigitZero)
								break;
							sB.append(serverIP_digit[j]);
							break;
						}

						++k;
						sB.append(serverIP_digit[j]);
						lastDigitZero = false;
						break;
					}

					if (k == 3) {
						if (l != 4)
							break;
						if (serverIP_tab[j] == '0') {
							++k;
							if (lastDigitZero)
								break;
							sB.append(serverIP_digit[j]);
							break;
						}

						++k;
						sB.append(serverIP_digit[j]);
						lastDigitZero = false;
						break;
					}

					++k;
					sB.append(serverIP_digit[j]);

					break;
				}

			}

			if (foundDigit) {
				foundDigit = false;
			} else {
				return "###.###.###.###:#####";
			}
		}
		return sB.toString();
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
