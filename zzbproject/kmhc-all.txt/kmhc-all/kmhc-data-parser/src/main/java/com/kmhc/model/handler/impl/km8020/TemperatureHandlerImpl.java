package com.kmhc.model.handler.impl.km8020;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrBloodpressureMapper;
import com.kmhc.model.datacenter.dao.PsrTempMapper;
import com.kmhc.model.datacenter.model.PsrBloodpressure;
import com.kmhc.model.datacenter.model.PsrTemp;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.Date;


@MessageCommand(type = "KM8020", command = "0x543631")
public class TemperatureHandlerImpl extends AbstractParentHandlerKM8020{

	private String function = "S61";
	private static final Logger log = LoggerFactory.getLogger(TemperatureHandlerImpl.class);
	private PsrTempMapper psrTempMapper = (PsrTempMapper) SpringBeanFacotry.getInstance().getBean("psrTempMapper");

	public TemperatureHandlerImpl() {
		super(log);
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		log.info(new String(msg));
		//rrhqvfdbo40bgzu,1,abcd,2017-11-24 16:47:19,1-2,865946021011026,8,T61,temperature_type,0,0,36.5,2008-01-22 04:44:00,1511542039
		// 第一次時間錯誤, 無秒

		String content[] = new String(msg).split(",");
		String uid = content[0];
		String timeStr = content[3];
		String imei = content[5];
		String tzStr = "GMT+" + content[6];
		Short tempType = Short.valueOf(content[9]);
		Short tempUnit = Short.valueOf(content[10]);
		BigDecimal temperature = new BigDecimal(content[11]);//.valueOf(Double.valueOf(content[11]));
		String measureTime = content[12];
//		String timeStamp = content[13];
		
		Date dt = com.kmhc.model.util.Date.getDate(timeStr,"yyyy-MM-dd HH:mm:ss",tzStr);
		Date mDt = com.kmhc.model.util.Date.getDate(measureTime ,"yyyy-MM-dd HH:mm:ss",tzStr);
		log.debug(sdf.format(dt));
		log.debug(sdf.format(mDt));

		PsrTemp record = new PsrTemp();
		record.setImei(imei);
		record.setImsi("");
		
		record.setTempTime(mDt);
		Date now = new Date();
		Boolean flag = true;
		if((now.getTime() + (10 * 60 * 1000L))<mDt.getTime()){
			flag = false;
		}
		if((now.getTime() - mDt.getTime()) > (30 * 24 * 60 * 60 * 1000L)){
			flag = false;
		}

		record.setTempType(tempType);
		record.setTempUnit(tempUnit);
		record.setTemp(temperature);
		record.setCreateDate(new Date());
		record.setTypeid("T61");
		
		if(psrTempMapper.selectByTempTime(record) == 0 && flag){
			psrTempMapper.insert(record);
			push(record.getImei(),record.getTemp().doubleValue(),"KM8020");
			pushTemp(record.getImei(),record.getTemp().doubleValue(),"KM8020",record.getTempTime());
		}else{
			log.info("收到体温历史数据不予保存：{}",uid+":"+content[1]+":"+content[2]+":"+sdf.format(new Date())+":"+imei+function);
		}
		
		//[V1.0.0,a1d83kdeio3fg3k,1,abcd,2014-08-29 09:45:15,356511170035899,S61]
		String out[] = { uid, content[1], content[2], sdf.format(new Date()), imei, function };
		return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"), generateResponse(out));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		//T61,temperature_type,0,0,36.5,2017-11-24 16:49:00,1511542202
	    //{T61,temperature_type,device_type,temp_unit,temperature,time,timen, imei}
		try{
			log.info(json);
			String content[] = json.split(",");
			String imei = content[7];
//			String systolic = content[2];
//			String diastolic = content[3];
//			String pulse = content[4];
			Short tempType = Short.valueOf(content[2]);
			Short tempUnit = Short.valueOf(content[3]);
			BigDecimal temperature = new BigDecimal(content[4]);//.valueOf(Double.valueOf(content[11]));
			String measureTime = content[5];
			
			Date mDt = com.kmhc.model.util.Date.getDate(measureTime ,"yyyy-MM-dd HH:mm:ss","GMT+8");
			log.debug(sdf.format(mDt));

			PsrTemp record = new PsrTemp();
			record.setImei(imei);
			record.setTempTime(mDt);
			record.setTempType(tempType);
			record.setTempUnit(tempUnit);
			record.setTemp(temperature);
			record.setTypeid("T61");

			Date now = new Date();
			Boolean flag = true;
			if((now.getTime() + (10 * 60 * 1000L))<mDt.getTime()){
				flag = false;
			}
			if((now.getTime() - mDt.getTime()) > (30 * 24 * 60 * 60 * 1000L)){ //超過一天數據不接收
				flag = false;
			}

			if(psrTempMapper.selectByTempTime(record) == 0 && flag){
				psrTempMapper.insert(record);
				push(record.getImei(),record.getTemp().doubleValue(),"KM8020");
				pushTemp(record.getImei(),record.getTemp().doubleValue(),"KM8020",record.getTempTime());
			}else{
				log.info("收到体温历史数据不予保存：{}",content[1]+":"+content[2]+":"+sdf.format(new Date())+":"+imei+function);
			}
		}catch(Exception e){
			log.error("psr_temp insert fail.....");
			return false;
		}
		return true;
	}
	
}
