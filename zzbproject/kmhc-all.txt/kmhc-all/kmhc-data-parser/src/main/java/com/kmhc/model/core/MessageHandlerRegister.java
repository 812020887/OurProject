/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月7日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.core;

import java.util.HashMap;
import java.util.List;

import com.kmhc.framework.util.ClassScanUtil;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.handler.IHandler;
import com.kmhc.model.util.LogCenter;

/**
 * Name: MessageHandlerRegister.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.core.MessageHandlerRegister.java]
 * Description: 方法执行类注册机  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月7日 上午11:41:44
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class MessageHandlerRegister {
	
	public static volatile HashMap<String,HashMap<String, IHandler>> protocolNameMapHandler = new HashMap<String, HashMap<String, IHandler>>();	
	
	public static void registHandler( String pathName, Class<MessageCommand> annotationName ) throws InstantiationException, IllegalAccessException{
		List<Class<?>> classes = ClassScanUtil.scan(pathName);
		
		for( Class<?> clazz : classes  ){
			LogCenter.root.debug("{}",clazz.getClass().getName());
			if( clazz.isAnnotationPresent(annotationName) ){
				String commond = ((MessageCommand)clazz.getAnnotation(annotationName)).command();
				String type = ((MessageCommand)clazz.getAnnotation(annotationName)).type();
				HashMap<String, IHandler> handlers =  protocolNameMapHandler.get(type);
				LogCenter.root.debug("protocolNameMapHandler type={} commond={}",type,commond);
				if( handlers == null ){
					handlers = new HashMap<String, IHandler>();
					protocolNameMapHandler.put(type, handlers);
				}
				handlers.put(commond, (IHandler) clazz.newInstance());
			}
		}
	}
	
	public static IHandler getHandler( String type , String protocol ){
		try {
			return protocolNameMapHandler.get(type).get(protocol);
		} catch (Exception e) {
			LogCenter.exception.error("unknow handler with type = " + type + " , protocol = "+protocol);
		}
		return null;
	}
	

}
