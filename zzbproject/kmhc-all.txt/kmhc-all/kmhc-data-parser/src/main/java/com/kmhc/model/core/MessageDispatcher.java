/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月7日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.core;

import java.util.Arrays;
import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.rabbitmq.recover.declaration.IWorkerhook;
import com.kmhc.framework.util.ConvertionUtil;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.datacenter.dao.A10DeviceSettingMapper;
import com.kmhc.model.datacenter.dao.DeviceListMapper;
import com.kmhc.model.datacenter.dao.ServerActionHisMapper;
import com.kmhc.model.datacenter.model.DeviceList;
import com.kmhc.model.handler.IHandler;
import com.kmhc.model.handler.impl.A10.BaseReplyA10;
import com.kmhc.model.handler.impl.km8000.TestD4;
import com.kmhc.model.handler.impl.km8010.BaseTest;
import com.kmhc.model.handler.impl.km8020.BaseReply8020;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.runnable.ReplyMessageThread;
import com.kmhc.model.util.BuildLogContent;
import com.kmhc.model.util.LogCenter;
import com.kmhc.model.util.SystemConfigUtil;


/**
 * Name: MessageDispatcher.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.core.MessageDispatcher.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月7日 下午2:20:21 
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class MessageDispatcher implements IWorkerhook {
	
	private static final Logger log = LoggerFactory.getLogger(MessageDispatcher.class);
	private ServerActionHisMapper serverActionHisMapper = (ServerActionHisMapper) SpringBeanFacotry.getInstance().getBean("serverActionHisMapper");
	private DeviceListMapper deviceListMapper = (DeviceListMapper) SpringBeanFacotry.getInstance().getBean("deviceListMapper");
	private A10DeviceSettingMapper a10DeviceSettingMapper = (A10DeviceSettingMapper) SpringBeanFacotry.getInstance().getBean("a10DeviceSettingMapper");
	       
	private final String protocolType ;
	private final Integer[] functionIndex;
	private final Integer[] contentIndex;
	private final List<Intercepter> intercepters ;
	
	
	public void dispatcher( byte[] msg ){
		try {			
			if( msg.length > 0 ){
				
				byte[] content = getContentMsg(msg);
				
				String protocolName = getProtocolName(msg);
				doIntercept(protocolName,content); //这里添加拦截程序的入口
//				log.debug("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
//				log.debug("name: " +protocolName + "  type: " + protocolType);
				IHandler handler = MessageHandlerRegister.getHandler(protocolType, protocolName);
							 				
				if( handler != null ){
					MessageContent msgContent = new MessageContent(content, protocolName);
					ReplyMessageContent replyContent = handler.handleBasicMessage( msgContent );
					if( replyContent != null ){
						
						replyContent.setProtocolName(protocolName);
						String ReplyprotocolType = SystemConfigUtil.consumerMapReplyQueueName.get(protocolType);
						ReplyMessageThread.protocolTypeMapContent.get(ReplyprotocolType).put(replyContent);
						LogCenter.userRquestLogger.log(replyContent.getIemiCode(), BuildLogContent.buildDispatcherContent(protocolName, content));
					}
				} else {
					/*----------------------------TODO DEAD CODE FOR TEST------------------------------------------------*/
					
					if(protocolType.equals("KM8010")){
						byte protocol = Arrays.copyOfRange(msg, 3, 4)[0];
						ReplyMessageContent testContent = new BaseTest(protocol).handleMessage(content);
						String ReplyprotocolType =  SystemConfigUtil.consumerMapReplyQueueName.get(protocolType);
						ReplyMessageThread.protocolTypeMapContent.get(ReplyprotocolType).put(testContent);
					}else if(protocolType.equals("KM8020")){
						byte[] protocol = Arrays.copyOfRange(msg, 70, 73);
//						MessageContent msgContent = new MessageContent(content, protocolName);
						ReplyMessageContent testContent = new BaseReply8020(protocol).handleMessage(content);
						if( testContent != null ){
							testContent.setProtocolName(protocolName);
							String ReplyprotocolType =  SystemConfigUtil.consumerMapReplyQueueName.get(protocolType);
							ReplyMessageThread.protocolTypeMapContent.get(ReplyprotocolType).put(testContent);
						}
					}else if(protocolType.equals("A10")){
						log.info(new String(msg));
						String function = null;
						String contentStr= new String(msg).substring(17);
						if(contentStr.contains(",")){
							function=contentStr.substring(0, contentStr.indexOf(","));
						}else{
							function=contentStr;
						}
						ReplyMessageContent testContent = new BaseReplyA10(function).handleMessage(content);
						if( testContent != null ){
							testContent.setProtocolName(protocolName);
							String ReplyprotocolType =  SystemConfigUtil.consumerMapReplyQueueName.get(protocolType);
							ReplyMessageThread.protocolTypeMapContent.get(ReplyprotocolType).put(testContent);
						}
						
					}  else{
						ReplyMessageContent testContent = new TestD4().handleMessage(content);
						String ReplyprotocolType =  SystemConfigUtil.consumerMapReplyQueueName.get(protocolType);
						ReplyMessageThread.protocolTypeMapContent.get(ReplyprotocolType).put(testContent);
					}
					/*----------------------------TODO DEAD CODE FOR TEST------------------------------------------------*/
					LogCenter.userRquestLogger.log(ConvertionUtil.bcd2Str(Arrays.copyOfRange(content, 0, 8)), " Recieve msg from RMQ : but handler is empty with protocol:"+ protocolName);
				}
			} else{
				LogCenter.exception.error("Recieve msg from RMQ : but Message is empty with protocolType:"+ protocolType);
			}
		} catch (Exception e) {
			e.printStackTrace();
			LogCenter.exception.error("",e);

		}
	}
	
	private String getImei(byte[] msg) {
		String con[] = new String(msg).split("\\*");
		String sn = con[1];
		DeviceList deviceList = deviceListMapper.selectBySn(sn);
		String imei = deviceList.getImei();
		return imei;
	}
	
	
    /**这里执行拦截器的操作,简单的循环顺序执行拦截程序，并没有通过链式数据结构方式处理
     * @param protocolName  
     * @param msg
     */
    private Object doIntercept(String protocolName, byte[] msg) {
        if(intercepters!=null && intercepters.size()>0){
            for(Intercepter inte:intercepters){
                inte.exe(protocolName,msg);
            }
        }
        return msg;
    }

    /** 
	 * @Title: MessageDispatcher
	 * @Description: TODO
	 * @param @param protocolType         
	 * @throws 
	 */ 
	public MessageDispatcher(String protocolType, Integer[] functionIndex, Integer[] contentIndex) {
		this(protocolType,functionIndex,contentIndex,null) ;
	}
        public MessageDispatcher(String protocolType, Integer[] functionIndex, Integer[] contentIndex,List<Intercepter> interceptions) {
                this.protocolType = protocolType;
                this.functionIndex = functionIndex;
                this.contentIndex = contentIndex;
                this.intercepters = interceptions ;
        }

	@Override
	public void receive(byte[] body) {
		dispatcher(body);
	}
	
	public byte[] getContentMsg( byte[] msg ){
		Integer limitIndex = contentIndex[1] == -1 ? msg.length : contentIndex[1];
		return Arrays.copyOfRange(msg, contentIndex[0], limitIndex);
	}
	
	public String getProtocolName(byte[] msg){
		byte[] orgnialProtocol = null;
		if(functionIndex[0] >=0 ){
			//A10特殊处理
			if(functionIndex[1]==1010){
				String contentStr= new String(msg).substring(17);
				if(contentStr.contains(",")){
					orgnialProtocol=contentStr.substring(0, contentStr.indexOf(",")).getBytes();
				}else{
					orgnialProtocol=contentStr.getBytes();
				}
			}else{
				orgnialProtocol = Arrays.copyOfRange(msg, functionIndex[0], functionIndex[0]+functionIndex[1]);
			}
		}//特殊符合km8020
		else if( functionIndex[0] == -1 && functionIndex[1] == -1 ) {
		    String[] content = new String(msg).split(",");
		    return String.format("%s%s","0x", ConvertionUtil.Bytes2HexString(content[8].getBytes()));
		}else{
			orgnialProtocol = Arrays.copyOfRange(msg, msg.length + functionIndex[0], msg.length + functionIndex[0]+functionIndex[1]);
		}		
		return "0x"+ConvertionUtil.Bytes2HexString(orgnialProtocol);	
	}	
}
