package com.kmhc.model.handler.impl.km8010;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type="KM8010",command="0xC1")
public class EnableSilentCallHandlerImpl extends AbstractParentHandlerKM8010 {

	private String type = "C1";
	private static final Logger log = LoggerFactory.getLogger(EnableSilentCallHandlerImpl.class);
	
	public EnableSilentCallHandlerImpl() {
		super(log);
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,type);
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);
//		String imei = parseImei_KM8010(msg, 0);
		
		byte[] content = ACK_SUCCESS_KM8010;
		return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(content,(byte) 0xC1));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
