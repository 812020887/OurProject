/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月11日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8000;

import java.util.Date;
import java.util.HashMap;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrStepMapper;
import com.kmhc.model.datacenter.model.PsrStep;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.MessageBuilder;

/**
 * Name: StepCounterHandler.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.StepCounterHandler.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月11日 下午3:10:26
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */

@MessageCommand(type="KM8000",command="0x35")
public class StepCounterHandlerImpl extends AbstractHandler {

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
		PsrStepMapper stepMapper = (PsrStepMapper) SpringBeanFacotry.getInstance().getBean("psrStepMapper");
		PsrStep step  = byte2Pojo(msg);
		
		int success = stepMapper.selectByETime(step);
		if(success == 0){
			success = stepMapper.insert(step);
			pushSTP(step.getImei(), step.getSteps(), step.getCal(), step.getDistance(), "KM8010",step.geteTime());
		}
		
		if( success > 0  ){
			return MessageBuilder.buildReplyMessageContent(imeiBytes, ACK_SUCCESS_KM8000);
		}else { 
			return MessageBuilder.buildReplyMessageContent(imeiBytes, ACK_ERROR_KM8000);
	    }
		}
	
	
	public static PsrStep byte2Pojo( byte[] original ){
		
		int[] sections = new int[]{8,8,7,7,2,2,4,4,4};
		String[] types= new String[]{"String","String","Date","Date","Integer","Integer","Integer","Integer","Integer"};
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		indexMapPolishing.put(1, 1);
		Object[] objs = BytesConvertionUtil.generateProperty4KM8000(original, sections, types, indexMapPolishing);
		
		PsrStep step = new PsrStep();
		step.setImei(String.valueOf(objs[0]));
		step.setImsi(String.valueOf(objs[1]));
		step.setsTime((Date)objs[2]);
		step.seteTime((Date)objs[3]);
		step.setWeight((Integer)objs[4]);
		step.setStepLong((Integer)objs[5]);
		step.setSteps((Integer)objs[6]);
		step.setDistance((Integer)objs[7]);
		step.setCal((Integer)objs[8]);
		step.setTypeid("35");
		return step;
	}


	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	
	
	

}
