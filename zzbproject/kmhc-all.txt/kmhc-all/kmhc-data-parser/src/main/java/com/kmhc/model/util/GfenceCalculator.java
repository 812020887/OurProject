package com.kmhc.model.util;

import org.gavaghan.geodesy.Ellipsoid;
import org.gavaghan.geodesy.GeodeticCalculator;
import org.gavaghan.geodesy.GeodeticMeasurement;
import org.gavaghan.geodesy.GlobalPosition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.datacenter.dao.DeviceSettingGfenceSpMapper;
import com.kmhc.model.datacenter.model.DeviceSettingGfenceSp;

public class GfenceCalculator {
	
	private static final Logger log = LoggerFactory.getLogger(GfenceCalculator.class);

	
	private GlobalPosition base;
	private GlobalPosition current;
	private DeviceSettingGfenceSp dsg;
	
	private DeviceSettingGfenceSpMapper dsgMapper = (DeviceSettingGfenceSpMapper) SpringBeanFacotry.getInstance().getBean("deviceSettingGfenceSpMapper");
	
	public GfenceCalculator(String imei, Double currentLat, Double currentlng) {
		dsg = dsgMapper.selectByPrimaryKey(imei);
		this.base = null;
		this.current = new GlobalPosition(currentLat, currentlng, 0.0);
		if(dsg != null)
			this.base = new GlobalPosition(dsg.getLatitude().doubleValue(), dsg.getLongitude().doubleValue(), 0.0);
	}

	private double threeDimensionalCalculation() {
		// instantiate the calculator
		GeodeticCalculator geoCalc = new GeodeticCalculator();
		// select a reference elllipsoid
		Ellipsoid reference = Ellipsoid.WGS84;
		GeodeticMeasurement geoMeasurement = geoCalc.calculateGeodeticMeasurement(reference, base, current);

		return geoMeasurement.getPointToPointDistance();
	}
	
	public boolean inside(){
		if(dsg != null && dsg.getRadius() > threeDimensionalCalculation()){
			return true;
		}
		return false;
	}
	
public static void main(String[] args) {
//	GfenceCalculator a = new GfenceCalculator("865946021155310",31.255956,120.734218);
//	System.out.println(a.inside());
	GlobalPosition b = new GlobalPosition(31.273113,120.744377, 0.0);
	GlobalPosition c = new GlobalPosition(31.255799,120.733924, 0.0);
	
	GeodeticCalculator geoCalc = new GeodeticCalculator();
	// select a reference elllipsoid
	Ellipsoid reference = Ellipsoid.WGS84;
	GeodeticMeasurement geoMeasurement = geoCalc.calculateGeodeticMeasurement(reference, b, c);

	System.out.println(geoCalc.calculateGeodeticMeasurement(reference, b, c).getPointToPointDistance());
	
}
}
