/**
  * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月14日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8010;

import java.util.Date;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrBloodpressureMapper;
import com.kmhc.model.datacenter.model.PsrBloodpressure;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.LogCenter;
import com.kmhc.model.util.MessageBuilder;


/**
 * Name: BloodPressureHandlerImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8010.BloodPressureHandlerImpl.java]
 * Description:  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月14日 下午2:44:20
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
@MessageCommand(type="KM8010",command="0x88")
public class BloodPressureHandlerImpl extends AbstractParentHandlerKM8010 {
	
	private String type = "88";
	private static final Logger log = LoggerFactory.getLogger(BloodPressureHandlerImpl.class);
	
	public BloodPressureHandlerImpl() {
		super(log);
	}


	private PsrBloodpressureMapper psrBloodpressureMapper = (PsrBloodpressureMapper) SpringBeanFacotry.getInstance().getBean("psrBloodpressureMapper");

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,type);
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);
		try {
			PsrBloodpressure bloodpressure = byte2Pojo(msg);
			int success = psrBloodpressureMapper.selectByBpTime(bloodpressure) ;
			if(success == 0){
				success =  psrBloodpressureMapper.insert(bloodpressure);
			};
			
			push(bloodpressure.getImei(),bloodpressure.gethPressure(),bloodpressure.getlPressure(),bloodpressure.getPuls(),"KM8010");
			pushBP(bloodpressure.getImei(),bloodpressure.gethPressure(),bloodpressure.getlPressure(),bloodpressure.getPuls(),"KM8010",bloodpressure.getBpTime()); 
			if( success > 0  )
				return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_SUCCESS_KM8010,(byte) 0x88));
			
			return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) 0x88));
		} catch (Exception e) {
			LogCenter.exception.error("",e);
			return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) 0x88));
		}
	}
	
	private PsrBloodpressure byte2Pojo( byte[] original ){
		PsrBloodpressure record = new PsrBloodpressure();
		int[] sections = new int[]{8,5,1,1,1};
		String[] types= new String[]{"IMEI","Date","Short","Short","Short"};
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		Object[] objs = BytesConvertionUtil.generateProperty4KM8010(original, sections, types, indexMapPolishing);
		
		record.setImei((String)objs[0]);
		record.setImsi("");
		record.setBpTime((Date)objs[1]);
		record.setlPressure((Short)objs[3]);
		record.sethPressure((Short)objs[2]);
		record.setPuls((Short)objs[4]);
		record.setModel((short)0);
		record.setData1((short)0);
		record.setCreateDate(new Date());
		record.setTypeid(88);
		return record;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
