 package com.kmhc.model.handler.impl.km8020;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.DeviceSettingGfenceSpMapper;
import com.kmhc.model.datacenter.dao.PrCellIMapper;
import com.kmhc.model.datacenter.dao.PrIMapper;
import com.kmhc.model.datacenter.dao.PrMMapper;
import com.kmhc.model.datacenter.dao.T9DeviceStatusMapper;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.DeviceSettingGfenceSp;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.PrCellI;
import com.kmhc.model.datacenter.model.PrI;
import com.kmhc.model.datacenter.model.PrM;
import com.kmhc.model.datacenter.model.T9DeviceStatus;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type = "KM8020", command = "0x543934")
public class MutiLBSHandlerImpl extends AbstractParentHandlerKM8020 {

	private static final Logger log = LoggerFactory.getLogger(MutiLBSHandlerImpl.class);
	private PrMMapper prMMapper = (PrMMapper) SpringBeanFacotry.getInstance().getBean("prMMapper");
	private PrIMapper prIMapper = (PrIMapper) SpringBeanFacotry.getInstance().getBean("prIMapper");
	private PrCellIMapper prCellIMapper = (PrCellIMapper) SpringBeanFacotry.getInstance().getBean("prCellIMapper");
	private T9DeviceStatusMapper t9DeviceStatusMapper = (T9DeviceStatusMapper) SpringBeanFacotry.getInstance()
			.getBean("t9DeviceStatusMapper");
	private DeviceSettingGfenceSpMapper dsgsMapper = (DeviceSettingGfenceSpMapper) SpringBeanFacotry.getInstance()
			.getBean("deviceSettingGfenceSpMapper");

	public MutiLBSHandlerImpl() {
		super(log);
	}

	@SuppressWarnings("unchecked")
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {

		// (1)当3种定位数据都有时：
		// zu1jgjwp80veawu,1,abcd,2011-12-15 10:00:00,1-2,
		// 356511170035899,8,T94,4.10,
		// GPS,104.063469,30.551357,181.899994,0.217000,221.479996,
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		// WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-EDU|5c:63:bf:a4:bf:56$-27$CMCC&,
		// 1267511609
		//
		// (2)当只有lbs定位数据时:
		// zu1jgjwp80veawu,1,abcd,2011-12-15 10:00:00,1-2,
		// 356511170035899,8,T94,4.10,
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		// 1267511609
		//
		//
		// (3)当上传lbs数据和gps数据时:
		// zu1jgjwp80veawu,1,abcd,2011-12-15 10:00:00,1-2,
		// 356511170035899,8,T94,4.10,
		// GPS,104.063469,30.551357,181.899994,0.217000,221.479996,
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		// 1267511609
		//
		// (4)当上传lbs数据和wifi定位数据时:
		// zu1jgjwp80veawu,1,abcd,2011-12-15 10:00:00,1-2,
		// 356511170035899,8,T94,4.10,
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		// WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-EDU|5c:63:bf:a4:bf:56$-27$CMCC&,
		// 1267511609

		// av4mwbb8y1ut6gu,1,abcd,2016-08-11
		// 05:54:32,1-2,356511170035899,8,T94,3.76,GPS,120.745811,31.272255,28.200001,0.916000,0.000000,11.000000,LBS,mcount$0$0$0$0,1470894872

		log.info(new String(msg));
		String function = "S94";
		String content[] = new String(msg).split(",");
		String uid = content[0];
		String timeStr = content[3];
		String imei = content[5];
		String tzStr = "GMT+" + content[6];
		int voltage = (int) (Float.valueOf(content[8]) * 1000);
		// String lng = content[9];
		// String lat = content[10];

		Date dt = com.kmhc.model.util.Date.getDate(timeStr,"yyyy-MM-dd HH:mm:ss",tzStr);
		log.debug(sdf.format(dt));

		Gps gps = null;
		List<Cell> cells = null;
		List<Wifi> wifis = null;
		for (int i = 0; i < content.length; i++) {
			if (content[i].equals("GPS")) {
				gps = paresGps(Arrays.copyOfRange(content, i, content.length));
			}
			if (content[i].equals("LBS")) {
				Object[] obj = paresLBS(Arrays.copyOfRange(content, i, content.length));
				cells = (List<Cell>) obj[0];
				wifis = (List<Wifi>) obj[1];
				break;
			}
		}
		if (cells.size() > 0) {
			PrM prm = parsePrM(imei, function);
			PrI pri = getPrI(gps, cells, wifis, imei, dt, voltage);
			List<PrCellI> prcelllist = getPrCellI(cells, prm);
			if(prIMapper.selectByPrDate(pri) == 0){
			
				if (prm != null) {
					try {
						prMMapper.insertSelective(prm);
					} catch (Exception e) {
						prMMapper.updateByPrimaryKey(prm);
					}
				}
	
				log.debug("===" + pri.getLocStatus() + "===");
				if (pri != null && pri.getLocStatus().equals("Y")) {
					DeviceSettingGfenceSp dsg = dsgsMapper.selectByPrimaryKey(pri.getImei());
					if (dsg != null && dsg.getEnable() == 1) {
						requestGFenceNotice(imei, pri.getGpsLat(), pri.getGpsLng(), pri.getHpe(),"KM8020");
					}
					try {
						prIMapper.insertSelective(pri);
					} catch (Exception e) {
						prIMapper.updateByPrimaryKey(pri);
					}
				}
				for (int i = 0; prcelllist != null && i < prcelllist.size(); i++) {
					if (prcelllist.get(i).getLocStatus().equals("Y")) {
						try {
							prCellIMapper.insertSelective(prcelllist.get(i));
						} catch (Exception e) {
							prCellIMapper.updateByPrimaryKey(prcelllist.get(i));
						}
					}
				}
	
				T9DeviceStatus device = t9DeviceStatusMapper.selectByImei(imei);
				if (device != null) {
					if (pri != null && pri.getIsvalid().equals("Y")) {
						device.setLatitude(pri.getGpsLat());
						device.setLongitude(pri.getGpsLng());
						device.setLbstime(dt);
					}
					device.setVoltage(voltage);
					device.setUpdatetime(dt);
					t9DeviceStatusMapper.updateByPrimaryKey(device);
					push8000Gps(imei,"KM8020","S94");
				}
			}
		}
		String out[] = { uid, content[1], content[2], sdf.format(new Date()), imei, function };
		// [V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15
		// 10:00:00,355372020827303,S53]
		return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"), generateResponse(out));

	}

	private Gps paresGps(String msg[]) {
		// (1)当3种定位数据都有时：
		// GPS,104.063469,30.551357,181.899994,0.217000,221.479996,
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		// WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-EDU|5c:63:bf:a4:bf:56$-27$CMCC&,

		// (3)当上传lbs数据和gps数据时:
		// GPS,104.063469,30.551357,181.899994,0.217000,221.479996,
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,

		String lng = msg[1];
		String lat = msg[2];
		// String height = content[3];
		// String speed = content[4];
		// String direction = content[5];
		// String starNumber = content[6];

		Gps gps = new Gps(new BigDecimal(lat).setScale(10, BigDecimal.ROUND_HALF_UP),
				new BigDecimal(lng).setScale(10, BigDecimal.ROUND_HALF_UP), "N", "E", "Y");
		gps = LocUtil.conver(gps);

		return gps;
	}

	private Object[] paresLBS(String msg[]) {
		// (1)当3种定位数据都有时：
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		// WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-EDU|5c:63:bf:a4:bf:56$-27$CMCC&,

		// (2)当只有lbs定位数据时:
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,

		// (3)当上传lbs数据和gps数据时:
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,

		// (4)当上传lbs数据和wifi定位数据时:
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		// WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-EDU|5c:63:bf:a4:bf:56$-27$CMCC&,

		List<Cell> cells = parseCellList(msg[1]);
		List<Wifi> wifis = null;
		if (msg.length > 2 && msg[2].equals("WIFI")) {
			wifis = parseWifiList(Arrays.copyOfRange(msg, 3, 4));
		}

		Object obj[] = { cells, wifis };

		return obj;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		//T94,voltage,GPS,longitude,latitude,height,speed,direction,LBS,mcount$num$mcc$mnc$response#lac1|cellid1|arfcn1|rxlev1#lac2|cellid2|arfcn2|rxlev2#lac3|cellid3|arfcn3|rxlev3#lac4|cellid4|arfcn4|rxlev4#lac5|cellid5|arfcn5|rxlev5#lac6|cellid6|arfcn6|rxlev6,timen
		//T94,4.16,LBS,mcount$6$460$1$255#2533|7621|118|40#2533|75c9|124|29#2533|75c7|120|22#2533|785f|640|21#2533|7860|662|20#252a|203b|111|20,1486647420,865946021011026

		try{
			log.info(json);
			String function = "S94";
			String content[] = json.split(",");
			String imei = content[content.length-1];
			int voltage = (int) (Float.valueOf(content[1]) * 1000);

			Date dt = new Date((Long.parseLong(content[4]) - (Long.parseLong("8")*3600))*1000);

			Gps gps = null;
			List<Cell> cells = null;
			List<Wifi> wifis = null;
			for (int i = 0; i < content.length; i++) {
				if (content[i].equals("GPS")) {
					gps = paresGps(Arrays.copyOfRange(content, i, content.length-1));
				}
				if (content[i].equals("LBS")) {
					Object[] obj = paresLBS(Arrays.copyOfRange(content, i, content.length-1));
					cells = (List<Cell>) obj[0];
					wifis = (List<Wifi>) obj[1];
					break;
				}
			}
			if (cells.size() > 0) {
				PrM prm = parsePrM(imei, function);
				PrI pri = getPrI(gps, cells, wifis, imei, dt, voltage);
				List<PrCellI> prcelllist = getPrCellI(cells, prm);
				if(prIMapper.selectByPrDate(pri) == 0){
				
					if (prm != null) {
						try {
							prMMapper.insertSelective(prm);
						} catch (Exception e) {
							prMMapper.updateByPrimaryKey(prm);
						}
					}
		
					log.debug("===" + pri.getLocStatus() + "===");
					if (pri != null && pri.getLocStatus().equals("Y")) {
						DeviceSettingGfenceSp dsg = dsgsMapper.selectByPrimaryKey(pri.getImei());
						if (dsg != null && dsg.getEnable() == 1) {
							requestGFenceNotice(imei, pri.getGpsLat(), pri.getGpsLng(), pri.getHpe(),"KM8020");
						}
						
						int success = 0;
						for( int i = 0; success == 0 ;i++ ){
							try {
								success = prIMapper.insertSelective(pri);
								pri.setItemno((short) (pri.getItemno() + 1));
							} catch (Exception e) {
	//							prIMapper.updateByPrimaryKey(pri);
							}
						}
					}
					for (int i = 0; prcelllist != null && i < prcelllist.size(); i++) {
						if (prcelllist.get(i).getLocStatus().equals("Y")) {
							try {
								prCellIMapper.insertSelective(prcelllist.get(i));
							} catch (Exception e) {
								prCellIMapper.updateByPrimaryKey(prcelllist.get(i));
							}
						}
					}
		
					T9DeviceStatus device = t9DeviceStatusMapper.selectByImei(imei);
					if (device != null) {
						if (pri != null && pri.getIsvalid().equals("Y")) {
							device.setLatitude(pri.getGpsLat());
							device.setLongitude(pri.getGpsLng());
							device.setLbstime(null);
						}
						device.setVoltage(voltage);
						device.setUpdatetime(null);
						t9DeviceStatusMapper.updateByPrimaryKey(device);
						push8000Gps(imei,"KM8020","S94");
					}
				}
			}
		}catch (Exception e) {
			log.debug(e.toString());
			return false;
		}
		return true;
	}
}
