package com.kmhc.model.handler.impl.km8010;

import java.math.BigDecimal;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.ProductPerSettingMMapper;
import com.kmhc.model.datacenter.dao.ProductSysSettingMMapper;
import com.kmhc.model.datacenter.model.ProductPerSettingM;
import com.kmhc.model.datacenter.model.ProductSysSettingM;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.SystemConfigUtil;

@MessageCommand(type="KM8010",command="0xB0")
public class RequestIpHandlerImpl extends AbstractParentHandlerKM8010 {

//	private int index = 0;
	private String type = "B0";
	
	private static final Logger log = LoggerFactory.getLogger(RequestIpHandlerImpl.class);
	
	private ProductSysSettingMMapper pSMMapper = (ProductSysSettingMMapper) SpringBeanFacotry.getInstance().getBean("productSysSettingMMapper");
	private ProductPerSettingMMapper pPSMMapper = (ProductPerSettingMMapper) SpringBeanFacotry.getInstance().getBean("productPerSettingMMapper");

	public RequestIpHandlerImpl() {
		super(log);
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		//01013DB108665450220452611001010D320101CC01253375C9940601253375C89301253376218D01253375C784012533785F8201252F3E3E7E012533785E7D5A
		//        08665450220452611001010D320101CC01253375C9940601253375C89301253376218D01253375C784012533785F8201252F3E3E7E012533785E7D5A
		writeDebugLog(msg,type);
		
		int index = 0;
		byte[] reMsg = null;
		byte[] imeiBytes = parseImeiBytes_KM8010(msg, 0);
		try {		
			String imei = parseImei_KM8010(msg, index);
			ProductSysSettingM record = pSMMapper.selectByPrimaryKey(imei);
			ProductPerSettingM perSetting = pPSMMapper.selectByPrimaryKey(imei);

			if(perSetting == null){
				perSetting = initPerSettingM(imei);
				pPSMMapper.insert(perSetting);
			}
			
			if (record != null) {
				reMsg = generateIpListBuf(record);			
				log.debug(TripleDesHelper.byte2hex(reMsg, reMsg.length));
			} else {
				reMsg = AbstractHandler.ACK_ERROR_KM8010;
				record = new ProductSysSettingM();
				record.setImei(imei);
				record.setImsi("");
				record.setIp1("120.025.225.005:6000");
				record.setIp2("120.025.225.005:6000");
				record.setIp3("120.025.225.005:6000");
				record.setEchoPrT((short) 60);
				record.setEchoPrH((short) 0);
				record.setEchoPrM((short) 0);
				record.setEchoPrS((short) 0);
				record.setEchoGpsT((short) 60);
				record.setPhoneLimitOnoff((short) 0);
				record.setPhoneLimitTime((short) 0);
				record.setPhoneLimitMode((short) 0);
				record.setPhoneLimitByCustomer((short) 0);
				record.setDialoutLimitStartday((short) 0);
				record.setAutoread((short) 0);
				record.setChecksumS((short) 0);
				record.setCreateDate(new Date());
				record.setUpdateDate(new Date());
				int success = pSMMapper.insert(record);
				
				if( success > 0  ){
					reMsg = generateIpListBuf(record);			
					log.debug(TripleDesHelper.byte2hex(reMsg, reMsg.length));
				}else
					reMsg = AbstractHandler.ACK_ERROR_KM8010;
			}

		} catch (Exception e) {
			log.error("获取系统ip信息出错。", e);
			reMsg = AbstractHandler.ACK_ERROR_KM8010;
		}      
		return MessageBuilder.buildReplyMessageContent(imeiBytes, generateResponse(reMsg,(byte) 0xB0));
	}
	
	public byte[] generateIpListBuf(ProductSysSettingM record) {    		   
		
		String[] ip = { record.getIp1(), record.getIp2(), record.getIp3() };
		byte[] reByte = new byte[6];

		for (int count = 0; count < 3; count++) {

			if (ip[count].equals("###.###.###.###:#####")) {
				continue;
			}
			String[] tmp = ip[count].split(":");
			short port = Short.valueOf(tmp[1]);
			String[] ipList = tmp[0].split("\\.");
			for(int i = 0; i < 4; i++){		
				int tmpIp = Integer.valueOf(ipList[i]);
				reByte[i] = (byte)(tmpIp);
			}
			reByte[4] = (byte) (port >>> 8);
			reByte[5] = (byte) port;
			break;
		}	
		return reByte;
	}
	
	private ProductPerSettingM initPerSettingM(String imei){
		ProductPerSettingM perSetting = new ProductPerSettingM();
		perSetting.setImei(imei);
		perSetting.setImsi("");
		perSetting.setFmlyPhoneNo1("");
		perSetting.setFmlyPhoneNo2("");
		perSetting.setFmlyPhoneNo3("");
		
		perSetting.setSosPhoneNo1("");
		perSetting.setSosPhoneNo2("");
		perSetting.setSosPhoneNo3("");
		perSetting.setNonDistrub((short) 0);
		perSetting.setFallDetect((short) 0);
		perSetting.setCreateDate(new Date());
		perSetting.setUpdateDate(new Date());
		
		perSetting.setuStep((short)35);
		perSetting.setuHeight(new BigDecimal(168));
		perSetting.setuWeight(new BigDecimal(65));
		
		perSetting.setSosKeyDelay((short)0);
		perSetting.setFmlyKeyDelay((short)0);
		perSetting.setSosSms((short)0);
		perSetting.setFallSms((short)0);
		perSetting.setNonDistrub((short)0);
		perSetting.setTimezone((short)0);
		
		perSetting.setSosPhoneNo1("112");
		perSetting.setSosPhoneNo2("");
		perSetting.setSosPhoneNo3("");
//		
		perSetting.setFallPhoneNo1("");
		perSetting.setFallPhoneNo2("");
		perSetting.setFallPhoneNo3("");
//		
		perSetting.setFamilyIcon1((short)0);
		perSetting.setFamilyIcon2((short)0);
		perSetting.setFamilyIcon3((short)0);
//		
		perSetting.setFmlyPhoneNo1("");
		perSetting.setFmlyPhoneNo2("");
		perSetting.setFmlyPhoneNo3("");
//		
		perSetting.setMedT1On((short)0);
		perSetting.setMedT1Hh((short)0);
		perSetting.setMedT1Mm((short)0);
		perSetting.setMedT1WeekdayFilter((short)0);
//		
		perSetting.setMedT2On((short)0);
		perSetting.setMedT2Hh((short)0);
		perSetting.setMedT2Mm((short)0);
		perSetting.setMedT2WeekdayFilter((short)0);
//		
		perSetting.setMedT3On((short)0);
		perSetting.setMedT3Hh((short)0);
		perSetting.setMedT3Mm((short)0);
		perSetting.setMedT3WeekdayFilter((short)0);
//		
		perSetting.setMedT4On((short)0);
		perSetting.setMedT4Hh((short)0);
		perSetting.setMedT4Mm((short)0);
		perSetting.setMedT4WeekdayFilter((short)0);
//
		perSetting.setMedT5On((short)0);
		perSetting.setMedT5Hh((short)0);
		perSetting.setMedT5Mm((short)0);
		perSetting.setMedT5WeekdayFilter((short)0);
		
		perSetting.setMedD1On((short)0);
		perSetting.setMedD1Yy((short)0);
		perSetting.setMedD1Mm((short)0);
		perSetting.setMedD1Dd((short)0);
		perSetting.setMedD1Hour((short)0);
		perSetting.setMedD1Minute((short)0);
		
		perSetting.setMedD2On((short)0);
		perSetting.setMedD2Yy((short)0);
		perSetting.setMedD2Mm((short)0);
		perSetting.setMedD2Dd((short)0);
		perSetting.setMedD2Hour((short)0);
		perSetting.setMedD2Minute((short)0);
//
		perSetting.setWhiteListOn((short)0);
		perSetting.setWhiteListPhone1("");
		perSetting.setWhiteListPhone2("");
		perSetting.setWhiteListPhone3("");
		perSetting.setWhiteListPhone4("");
		perSetting.setWhiteListPhone5("");
		perSetting.setWhiteListPhone6("");
		perSetting.setWhiteListPhone7("");
		perSetting.setWhiteListPhone8("");
		perSetting.setWhiteListPhone9("");
		perSetting.setWhiteListPhone10("");
		perSetting.setWhiteListPhone11("");
		perSetting.setWhiteListPhone12("");
		perSetting.setWhiteListPhone13("");
		perSetting.setWhiteListPhone14("");
		perSetting.setWhiteListPhone15("");
		perSetting.setWhiteListPhone16("");
		perSetting.setWhiteListPhone17("");
		perSetting.setWhiteListPhone18("");
		perSetting.setWhiteListPhone19("");
		perSetting.setWhiteListPhone20("");

		perSetting.setFallDetect((short)0);
		
		perSetting.setFallLowLg((short)0);
		perSetting.setFallLowHg((short)0);
		perSetting.setFallLowFl((short)0);
		perSetting.setFallLowFt((short)0);
		perSetting.setFallLowSt((short)0);
		perSetting.setFallLowWt((short)0);
		perSetting.setFallLowRes1((short)0);
		perSetting.setFallLowRes2((short)0);
		
		perSetting.setFallMidLg((short)0);
		perSetting.setFallMidHg((short)0);
		perSetting.setFallMidFl((short)0);
		perSetting.setFallMidFt((short)0);
		perSetting.setFallMidSt((short)0);
		perSetting.setFallMidWt((short)0);
		perSetting.setFallMidRes1((short)0);
		perSetting.setFallMidRes2((short)0);
		
		perSetting.setFallHiLg((short)0);
		perSetting.setFallHiHg((short)0);
		perSetting.setFallHiFl((short)0);
		perSetting.setFallHiFt((short)0);
		perSetting.setFallHiSt((short)0);
		perSetting.setFallHiWt((short)0);
		perSetting.setFallHiRes1((short)0);
		perSetting.setFallHiRes2((short)0);
		
		perSetting.setSetLang((short)0);
		perSetting.setSpeakLang((short)0);
		
		perSetting.setuAccountid("");
		perSetting.setuName("");
//		perSetting.setuSex("");
//		perSetting.setuAge("");
//		perSetting.setuBirthdateYy(uBirthdateYy);
//		perSetting.setuBirthdateMm(uBirthdateMm);
//		perSetting.setuBirthdateDd(uBirthdateDd);
//		
//		perSetting.setuUnit(uUnit);
//		
//		perSetting.setuHeight(uHeight);
//		perSetting.setuWeight(uWeight);
//		perSetting.setuIdealWeight(uIdealWeight);
		perSetting.setuStep((short)12);
		
		perSetting.setuSystolicLowerLimit((short)12);
		perSetting.setuSystolicUpperLimit((short)12);
		perSetting.setuDaistolicLowerLimit((short)12);
		perSetting.setuDiastolicUpperLimit((short)12);

		perSetting.setActiveG((short)12);
		perSetting.setActiveGyro((short)12);
		perSetting.setChecksum((short)12);
		perSetting.setCreateDate(new Date());
		perSetting.setUpdateDate(new Date());
		
		perSetting.setEfT1On((short)12);		
		perSetting.setEfST1Hh((short)12);
		perSetting.setEfST1Mm((short)12);
		perSetting.setEfET1Hh((short)12);
		perSetting.setEfET1Mm((short)12);
		perSetting.setEfT1WeekdayFilter((short)12);
		
		perSetting.setEfT2On((short)12);		
		perSetting.setEfST2Hh((short)12);
		perSetting.setEfST2Mm((short)12);
		perSetting.setEfET2Hh((short)12);
		perSetting.setEfET2Mm((short)12);
		perSetting.setEfT2WeekdayFilter((short)12);
		
		perSetting.setEfT3On((short)12);		
		perSetting.setEfST3Hh((short)12);
		perSetting.setEfST3Mm((short)12);
		perSetting.setEfET3Hh((short)12);
		perSetting.setEfET3Mm((short)12);
		perSetting.setEfT3WeekdayFilter((short)12);
		
		perSetting.setDistanceUnit(12);
		perSetting.setStepTotal(12);
		perSetting.setHeatTotal(12);
		
		return perSetting;	
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
