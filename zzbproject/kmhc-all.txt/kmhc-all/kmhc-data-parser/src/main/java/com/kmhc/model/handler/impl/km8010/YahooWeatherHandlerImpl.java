package com.kmhc.model.handler.impl.km8010;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.pojo.YahooWeatherResult;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.WeatherUtil;

@MessageCommand(type = "KM8010", command = "0x20")
public class YahooWeatherHandlerImpl extends AbstractParentHandlerKM8010 {

	private static final Logger log = LoggerFactory.getLogger(YahooWeatherHandlerImpl.class);

	public YahooWeatherHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);
		
		int index = 0;
		Gps gps = null;

		String imei = parseImei_KM8010(msg, index);
		index += 8;
		LocResult locresult = null;
		Cell cell = null;
		List<Cell> cells = null;
		List<Wifi> wifis = null;
		
		switch (msg[index]) {
		case 0x00:// GPS
			gps = parseGps(Arrays.copyOfRange(msg, index + 1, msg.length));
			gps = LocUtil.conver(gps);
			break;
		case 0x01:// GSM
			List<Cell> cellList = parseCellList(Arrays.copyOfRange(msg, index + 1, msg.length));
			if (cellList.size() > 1)
				locresult = LocUtil.loc(imei, null, cellList.get(0), cellList.subList(1, cellList.size() - 1), null);
			else if (cellList.size() == 1)
				locresult = LocUtil.loc(imei, null, cellList.get(0), null, null);
			if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {
				LocDetailResult result = locresult.getResult();
				String[] lngLat = result.getLocation().split(",");
				BigDecimal lng = new BigDecimal(lngLat[0]).setScale(6, RoundingMode.HALF_EVEN);
				BigDecimal lat = new BigDecimal(lngLat[1]).setScale(6, RoundingMode.HALF_EVEN);
				gps = new Gps(lat, lng, "N", "E", "Y");
			} else {
				if (locresult != null) {
					log.info("定位失败，status:{},info:{},result.type:{}", locresult.getStatus(), locresult.getInfo(),
							locresult.getResult() == null ? "" : locresult.getResult().getType());
				} else {
					log.info("定位结果返回NULL");
				}
			}
			break;
		case 4:// GPS + GSM
			gps = parseGps(Arrays.copyOfRange(msg, index + 1, index + 11));
			break;
		case 0x08:
			cell = parseCell(msg, index + 1, null);
			cells = parseCells(msg, index + 9, cell.getMcc());
			wifis = parseWifiList(msg, index + 10 + cells.size() * 6);
			if (cells.size() > 0)
				locresult = LocUtil.loc(imei, null, cell, cells, wifis);
			else
				locresult = LocUtil.loc(imei, null, cell, null, wifis);
			if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {
				LocDetailResult result = locresult.getResult();
				String[] lngLat = result.getLocation().split(",");
				BigDecimal lng = new BigDecimal(lngLat[0]).setScale(6, RoundingMode.HALF_EVEN);
				BigDecimal lat = new BigDecimal(lngLat[1]).setScale(6, RoundingMode.HALF_EVEN);
				// String address = LocUtil.reverseGeocoding(lat, lng);
				gps = new Gps(lat, lng, "N", "E", "Y");
			} else {
				if (locresult != null) {
					log.info("定位失败，status:{},info:{},result.type:{}", locresult.getStatus(), locresult.getInfo(),
							locresult.getResult() == null ? "" : locresult.getResult().getType());
				} else {
					log.info("定位结果返回NULL");
				}
			}
			break;
		case 0x16:
			index += 1;
			gps = parseGps(Arrays.copyOfRange(msg, index, index + 10));
			gps = LocUtil.conver(gps);
			index += 10;
			cell = parseCell(msg, index, null);
			index += 8;
			cells = parseCells(msg, index, cell.getMcc());
			index += (cells.size() * 6 + 1);
			wifis = parseWifiList(msg, index);
			if (cells.size() > 0)
				locresult = LocUtil.loc(imei, null, cell, cells, wifis);
			else
				locresult = LocUtil.loc(imei, null, cell, null, wifis);
			if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {
				LocDetailResult result = locresult.getResult();
				String[] lngLat = result.getLocation().split(",");
				BigDecimal lng = new BigDecimal(lngLat[0]).setScale(6, RoundingMode.HALF_EVEN);
				BigDecimal lat = new BigDecimal(lngLat[1]).setScale(6, RoundingMode.HALF_EVEN);
				// String address = LocUtil.reverseGeocoding(lat, lng);
				gps = new Gps(lat, lng, "N", "E", "Y");
			} else {
				if (locresult != null) {
					log.info("定位失败，status:{},info:{},result.type:{}", locresult.getStatus(), locresult.getInfo(),
							locresult.getResult() == null ? "" : locresult.getResult().getType());
				} else {
					log.info("定位结果返回NULL");
				}
			}
			break;
		default:
			break;
		}
		if (gps != null) {
			JSONObject json = WeatherUtil.openWeatherMap(gps);
			if (json != null) {
				log.debug(json.getJSONArray("weather").getJSONObject(0).getInteger("id").toString());
				log.debug(json.getJSONObject("main").getBigDecimal("temp").setScale(0, RoundingMode.HALF_EVEN).toString());
				log.debug(json.getJSONObject("main").getBigDecimal("temp_max").setScale(0, RoundingMode.HALF_EVEN).toString());
				log.debug(json.getJSONObject("main").getBigDecimal("temp_min").setScale(0, RoundingMode.HALF_EVEN).toString());
				int code = json.getJSONArray("weather").getJSONObject(0).getInteger("id");
				int currentTemp = json.getJSONObject("main").getBigDecimal("temp").setScale(0, RoundingMode.HALF_EVEN).intValue();
				int maxTemp = json.getJSONObject("main").getBigDecimal("temp_max").setScale(0, RoundingMode.HALF_EVEN).intValue();
				int minTemp = json.getJSONObject("main").getBigDecimal("temp_min").setScale(0, RoundingMode.HALF_EVEN).intValue();
				String icon = json.getJSONArray("weather").getJSONObject(0).getString("icon");
				if (currentTemp < 0) {
					currentTemp = 255 + currentTemp + 1;
				}
				if (maxTemp < 0) {
					maxTemp = 255 + maxTemp + 1;
				}
				if (minTemp < 0) {
					minTemp = 255 + minTemp + 1;
				}
				code = WeatherUtil.convertOpenWeather2YahooCode(code, icon);
				byte[] content = new byte[4];
				content[0] = (byte) code;
				content[1] = (byte) currentTemp;
				content[2] = (byte) maxTemp;
				content[3] = (byte) minTemp;
				return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(content, (byte) 0x20));
			}else{
				YahooWeatherResult ywresult = WeatherUtil.yahoo(gps);
				if (ywresult != null && ywresult.getQuery() != null && ywresult.getQuery().getResults() != null) {
					int code = Integer.valueOf(ywresult.getQuery().getResults().getChannel().getItem().getCondition().getCode());
					int currentTemp = Integer.valueOf(ywresult.getQuery().getResults().getChannel().getItem().getCondition().getTemp());
					int maxTemp = Integer.valueOf(ywresult.getQuery().getResults().getChannel().getItem().getForecast().getHigh());
					int minTemp = Integer.valueOf(ywresult.getQuery().getResults().getChannel().getItem().getForecast().getLow());
	
					if (currentTemp < 0) {
						currentTemp = 255 + currentTemp + 1;
					}
					if (maxTemp < 0) {
						maxTemp = 255 + maxTemp + 1;
					}
					if (minTemp < 0) {
						minTemp = 255 + minTemp + 1;
					}
	
					log.debug(ywresult.getQuery().getResults().getChannel().getItem().getCondition().getCode());
					log.debug(ywresult.getQuery().getResults().getChannel().getItem().getCondition().getTemp());
					log.debug(ywresult.getQuery().getResults().getChannel().getItem().getForecast().getHigh());
					log.debug(ywresult.getQuery().getResults().getChannel().getItem().getForecast().getLow());
	
					byte[] content = new byte[4];
					content[0] = (byte) code;
					content[1] = (byte) currentTemp;
					content[2] = (byte) maxTemp;
					content[3] = (byte) minTemp;
					return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(content, (byte) 0x20));
				} 
			}
		}
//		try {
//			TimeUnit.MILLISECONDS.sleep(9500);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010, (byte) 0x20));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
