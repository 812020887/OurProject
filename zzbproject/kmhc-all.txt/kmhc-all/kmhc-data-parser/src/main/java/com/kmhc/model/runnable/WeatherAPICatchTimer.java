/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年12月1日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.runnable;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimerTask;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TimeUtil;
import com.kmhc.model.datacenter.dao.AreaidVMapper;
import com.kmhc.model.datacenter.dao.PerWeatherMapper;
import com.kmhc.model.datacenter.dao.PrIMapper;
import com.kmhc.model.datacenter.model.AreaidV;
import com.kmhc.model.datacenter.model.PerWeather;
import com.kmhc.model.datacenter.model.PrI;
import com.kmhc.model.pojo.WeatherDeclaration;
import com.kmhc.model.util.HttpClientUtils;
import com.kmhc.model.util.LogCenter;
import com.kmhc.model.util.SystemConfigUtil;
import com.kmhc.model.util.WeatherKeyEncode;

/**
 * Name: WeatherAPICatchTimer.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.runnable.WeatherAPICatchTimer.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年12月1日 上午11:01:25
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class WeatherAPICatchTimer extends TimerTask {
	private static final PrIMapper priMapper = (PrIMapper) SpringBeanFacotry.getInstance().getBean("prIMapper");
	private static final AreaidVMapper areaidVMapper = (AreaidVMapper) SpringBeanFacotry.getInstance().getBean("areaidVMapper");
	private static final PerWeatherMapper perWeatherMapper = (PerWeatherMapper) SpringBeanFacotry.getInstance().getBean("perWeatherMapper");
	public static final SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHss");
	
	
	
	@Override
	public void run() {
		List<PrI> prIs =  priMapper.getPsrTop200();
		if( prIs != null ){
			for( PrI p : prIs ){
				
				try {
					
					if( p.getAddress() == null || "".equals(p.getAddress()) )
						continue;
					
//					String lat = String.valueOf(p.getGpsLat());
//					String lng = String.valueOf(p.getGpsLng());
//					String locationUrl = WeatherAPICatchTimer.combineUrl(lat, lng);
//					
//					String locationDeclaration = HttpClientUtils.request(locationUrl);
//					JSONObject jsonObject = JSON.parseObject(locationDeclaration);
//					String district = ((JSONObject)((JSONObject)jsonObject.get("regeocode")).get("addressComponent")).get("district").toString();
//					String city = ((JSONObject)((JSONObject)jsonObject.get("regeocode")).get("addressComponent")).get("city").toString();
//					String district4Precision = district.equals("[]")? null : district;
//					String city4Precision = city.equals("[]")? null:city;
//					if( district.endsWith("区") )
//						district4Precision = district.substring(0, district.length()-1 );
//					
//					if( city.endsWith("市"))
//						city4Precision = city.substring(0, district.length()-1 );
					String address = p.getAddress();
					int provIndex = address.indexOf("省");
					int cityIndex = address.indexOf("市");
					int areaIndex = address.indexOf("区");
					String district4Precision = null;
					String city4Precision = null;
					
					if( areaIndex != -1 ){
						district4Precision = address.substring(cityIndex+1,areaIndex).trim();
					}
					
					if( cityIndex != -1 ){
						city4Precision = address.substring(provIndex+1,cityIndex).trim();
					}
					
					HashMap<String, String> words = new HashMap<String, String>();
					words.put("areaName", district4Precision);
					words.put("cityName", city4Precision);
					List<AreaidV> areaidVs = areaidVMapper.selectByAreaName(words);
					
					if( areaidVs.size() == 0 ){
						areaidVs = areaidVMapper.selectByAreaCityName(city4Precision);
					}
					
					if( areaidVs != null && areaidVs.size() > 0 ){
						AreaidV areaidV = areaidVs.get(0);
						String date = sf.format(new Date());
						String publicKey = WeatherAPICatchTimer.combineWeatherUrl(SystemConfigUtil.weatherKeyUrl, areaidV.getAreaid(),SystemConfigUtil.weatherAppid,date);
						String key = WeatherKeyEncode.standardURLEncoder( publicKey , SystemConfigUtil.weatherPrivateKey);
						String weatherUrl = WeatherAPICatchTimer.combineWeatherUrl(SystemConfigUtil.weatherUrl, areaidV.getAreaid(),SystemConfigUtil.weatherAppid.substring(0,6),date)+"&key="+key;
						String weatherDetail = HttpClientUtils.request(weatherUrl);
						
						if(weatherDetail!=null||!weatherDetail.equals("")){
							int count = perWeatherMapper.filter_Per_Weather(p.getImei());
							try {
								int tempC = 0;
								PerWeather pw = new PerWeather();
								JSONObject baseWeatherObj = JSONObject.parseObject(weatherDetail);
								JSONObject f = baseWeatherObj.getJSONObject("f");
								JSONArray f1 = f.getJSONArray("f1");
								JSONObject weatherDate =  f1.getJSONObject(0);
								String tempH = weatherDate.getString("fc");
								String tempL = weatherDate.getString("fd");
								String weatherCode = "";
								
								
								if( !"".equals(tempH) ){
									tempC = Integer.parseInt(tempH);
									pw.setB5H(Short.valueOf(tempH));
									weatherCode = weatherDate.getString("fa");
								}else{
									if( !"".equals(tempL) ){
										tempC = Integer.parseInt(tempL);
										weatherCode = weatherDate.getString("fb");
									}
								}
								
								
								WeatherDeclaration weatherDeclaration = SystemConfigUtil.weatcherCodeMapDeclaration.get(weatherCode);
								
								
								if (tempC > 32) 
									pw.setB4((short)1);
								else if (tempC > 28) 
									pw.setB4((short)2);
								else if (tempC > 24) 
									pw.setB4((short)3);
								else if (tempC > 20) 
									pw.setB4((short)4);
								else if (tempC > 15) 
									pw.setB4((short)5);
								else if (tempC > 10) 
									pw.setB4((short)6);
								else if (tempC > 3)
									pw.setB4((short)7);
								else 
									pw.setB4((short)8);
								
								pw.setB5L(Short.valueOf(tempL));
									
								pw.setB6((short)(weatherDeclaration.getRainOpp().intValue()));
								pw.setB7((short)(weatherDeclaration.getWeatherIconNum().intValue()));
								pw.setDtatmap((short)240);
								pw.setGpsEwLng(p.getGpsEwLng());
								pw.setGpsLat(p.getGpsLat());
								pw.setGpsLng(p.getGpsLng());
								pw.setGpsNsLat(p.getGpsNsLat());
								pw.setImei(p.getImei());
								pw.setImsi("");
								pw.setReportGmtTime(TimeUtil.formatDate(p.getCreateDate()));
								if( count == 0 ){
									perWeatherMapper.insert(pw);
								}else{
									perWeatherMapper.updateByPrimaryKey(pw);
								}
					
							} catch (Exception e) {
								LogCenter.exception.error("",e);
								continue;
							}
						}
						
						
					}
				} catch (Exception e) {
					LogCenter.exception.error("",e);
					continue;
				}
			}
		}
	}
	
	public static String combineUrl(String lat, String lng){
		StringBuilder sb = new StringBuilder(SystemConfigUtil.restapiPath).append("&location=")
				.append(lng).append(",").append(lat).append("&radius=1000");
		return sb.toString();
	}
	
	public static String combineWeatherUrl( String baseUrl , String distinctCode, String weatherAppid, String date ){
		
		StringBuilder sb = new StringBuilder(baseUrl).append("&date=")
				.append(date).append("&areaid=").append(distinctCode).append("&appid=").append(weatherAppid);
		System.out.println(sb.toString());
		return sb.toString();
	}
	
}
