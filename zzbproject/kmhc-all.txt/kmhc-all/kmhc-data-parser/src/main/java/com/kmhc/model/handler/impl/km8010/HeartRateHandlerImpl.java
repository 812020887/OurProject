package com.kmhc.model.handler.impl.km8010;

import java.util.Date;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrHeartrateMapper;
import com.kmhc.model.datacenter.model.PsrHeartrate;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.LogCenter;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type="KM8010",command="0x87")
public class HeartRateHandlerImpl extends AbstractParentHandlerKM8010 {
	
	private String type = "87";
	private static final Logger log = LoggerFactory.getLogger(HeartRateHandlerImpl.class);
	private PsrHeartrateMapper psrHRMapper = (PsrHeartrateMapper) SpringBeanFacotry.getInstance().getBean("psrHeartrateMapper");

	public HeartRateHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,type);
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);
		try {
			PsrHeartrate heartRate = byte2Pojo(msg);
			
			int success = psrHRMapper.selectByBpTime(heartRate);
			if(success == 0){
				success =   psrHRMapper.insert(heartRate);
			};
			
			
			push(heartRate.getImei(),heartRate.getHeartRate(),"KM8010");
			pushHR(heartRate.getImei(),heartRate.getHeartRate(),"KM8010",heartRate.getBsTime());
			if( success > 0  )
				return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_SUCCESS_KM8010,(byte) 0x87));
			
			return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) 0x87));
		} catch (Exception e) {
			LogCenter.exception.error("",e);
			return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) 0x87));
		}
	}
	
	
	private PsrHeartrate byte2Pojo( byte[] original ){
		PsrHeartrate record = new PsrHeartrate();
		int[] sections = new int[]{8,5,5,1};
		String[] types= new String[]{"IMEI","Date","Date","Short"};
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		Object[] objs = BytesConvertionUtil.generateProperty4KM8010(original, sections, types, indexMapPolishing);
		record.setImei((String)objs[0]);
		record.setImsi("");
		record.setBsTime((Date)objs[2]);
		record.setHeartRate((int)((Short)objs[3]));
		record.setCreateDate(new Date());
		record.setTypeid(87);
		return record;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
