/**
 * 
 */
package com.kmhc.model.core;

/**
 * @author xl
 *
 */
public interface Intercepter{

    Object exe(String protocolName, byte[] msg);
}
