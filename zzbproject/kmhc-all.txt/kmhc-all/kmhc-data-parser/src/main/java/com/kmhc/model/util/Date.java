package com.kmhc.model.util;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

public class Date {
	
	public static java.util.Date getDate(String date,String format,String ID){
		SimpleDateFormat sdf = new SimpleDateFormat(format); 
		sdf.setTimeZone(TimeZone.getTimeZone(ID));
		try {
			return sdf.parse(date);
		} catch (ParseException e) {
			return new java.util.Date();
		}
	}
	public static void main(String[] args) {
		System.out.println(Date.getDate("2011-12-15 10:00:00","yyy-MM-dd","GMT+8"));
	}
}
