package com.kmhc.model.handler.impl.km8000;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.msg.ReplyMessageContent;

@MessageCommand(type="KM8000",command="0x7f")
public class UpdateNoticeHandlerImpl extends AbstractParentHandlerKM8000{

    private static final Logger log = LoggerFactory.getLogger(PowerOnHandlerImpl.class);
    
    private byte[] ACK_7F_00 = {0, 10, 127, 0};
    public UpdateNoticeHandlerImpl() {
        super(log);
    }

    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
        byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
        return new ReplyMessageContent(imeiBytes,ACK_7F_00);
    }

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
