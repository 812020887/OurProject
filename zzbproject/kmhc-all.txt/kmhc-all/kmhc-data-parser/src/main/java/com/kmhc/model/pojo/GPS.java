/*    */ package com.kmhc.model.pojo;
/*    */ 
/*    */ public class GPS
/*    */ {
/*    */   private String latDispStr;
/*    */   private double lat;
/*    */   private String lngDispStr;
/*    */   private double lng;
/* 17 */   private String address = "";
/*    */ 
/*    */   public String getLatDispStr()
/*    */   {
/* 25 */     return this.latDispStr;
/*    */   }
/*    */ 
/*    */   public void setLatDispStr(String latDispStr) {
/* 29 */     this.latDispStr = latDispStr;
/*    */   }
/*    */ 
/*    */   public double getLat() {
/* 33 */     return this.lat;
/*    */   }
/*    */ 
/*    */   public void setLat(double lat) {
/* 37 */     this.lat = lat;
/*    */   }
/*    */ 
/*    */   public String getLngDispStr() {
/* 41 */     return this.lngDispStr;
/*    */   }
/*    */ 
/*    */   public void setLngDispStr(String lngDispStr) {
/* 45 */     this.lngDispStr = lngDispStr;
/*    */   }
/*    */ 
/*    */   public double getLng() {
/* 49 */     return this.lng;
/*    */   }
/*    */ 
/*    */   public void setLng(double lng) {
/* 53 */     this.lng = lng;
/*    */   }
/*    */ 
/*    */   public String getAddress() {
/* 57 */     return this.address;
/*    */   }
/*    */ 
/*    */   public void setAddress(String address) {
/* 61 */     this.address = address;
/*    */   }
/*    */ }

/* Location:           E:\doc\康美手表Server\Guider\台北蓋德_安裝光碟公版_台灣20140515\2.Gateway Program\icare2\WEB-INF\classes\
 * Qualified Name:     com.paralucent.gateway2.model.GPS
 * JD-Core Version:    0.5.3
 */