/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年12月1日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.pojo;

import java.io.Serializable;

/**
 * Name: WeatherDeclaration.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.pojo.WeatherDeclaration.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年12月1日 下午2:48:59
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class WeatherDeclaration implements Serializable {

	/** 
	 * @Fields serialVersionUID : TODO
	 */ 
	private static final long serialVersionUID = -2587359157090306398L;

	private Integer weatherIconNum;
	
	private String weatherCode;
	
	private String waetherDescription;
	
	private Integer rainOpp;
	
	/** 
	 * @Title: WeatherDeclaration
	 * @Description: TODO
	 * @param @param weatherIconNum
	 * @param @param weatherCode
	 * @param @param waetherDescription
	 * @param @param rainOpp         
	 * @throws 
	 */ 
	public WeatherDeclaration(Integer weatherIconNum, String weatherCode, String waetherDescription, Integer rainOpp) {
		super();
		this.weatherIconNum = weatherIconNum;
		this.weatherCode = weatherCode;
		this.waetherDescription = waetherDescription;
		this.rainOpp = rainOpp;
	}

	public Integer getWeatherIconNum() {
		return weatherIconNum;
	}

	public void setWeatherIconNum(Integer weatherIconNum) {
		this.weatherIconNum = weatherIconNum;
	}

	public String getWeatherCode() {
		return weatherCode;
	}

	public void setWeatherCode(String weatherCode) {
		this.weatherCode = weatherCode;
	}

	public String getWaetherDescription() {
		return waetherDescription;
	}

	public void setWaetherDescription(String waetherDescription) {
		this.waetherDescription = waetherDescription;
	}

	public Integer getRainOpp() {
		return rainOpp;
	}

	public void setRainOpp(Integer rainOpp) {
		this.rainOpp = rainOpp;
	}

}
