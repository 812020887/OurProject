/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月14日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.core;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.rabbitmq.recover.declaration.IWorkerhook;
import com.kmhc.model.task.ImeiCollectionTask;

/**
 * Name: RequestMessageDispatcher.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.core.RequestMessageDispatcher.java]
 * Description: 处理会话层的主动请求  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月14日 上午10:54:45
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class RequestMessageDispatcher implements IWorkerhook {
	
	
	
	public void dispatch( String command ){
		if( command.equals("kmhc.imei.getAll") ){
			ImeiCollectionTask task = ((ImeiCollectionTask)SpringBeanFacotry.getInstance().getBean("imeiCollectiontask"));
			task.response();
		}
	}

	@Override
	public void receive(byte[] body) {
		dispatch(new String(body));
	}

}
