package com.kmhc.model.handler.impl.km8020;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrHeartrateMapper;
import com.kmhc.model.datacenter.model.PsrHeartrate;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;

/**
 * 
 * Name: HRHandlerImpl.java ProjectName: [kmhc-data-parser] Package:
 * [com.kmhc.model.handler.impl.km8020.HRHandlerImpl.java] Description: T28
 * 心率数据上传
 * 
 * @since JDK1.7
 * @see
 *
 * 		@author: Chris Date: 2016年7月22日 下午2:41:15
 *
 *      Update-User: @author Update-Time: Update-Remark:
 * 
 *      Check-User: Check-Time: Check-Remark:
 * 
 *      Company: kmy Copyright: kmy
 */

// T28
@MessageCommand(type = "KM8020", command = "0x543238")
public class HRHandlerImpl extends AbstractParentHandlerKM8020 {

	private String function = "S28";
	private static final Logger log = LoggerFactory.getLogger(HRHandlerImpl.class);
	private PsrHeartrateMapper psrHRMapper = (PsrHeartrateMapper) SpringBeanFacotry.getInstance()
			.getBean("psrHeartrateMapper");

	public HRHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		log.info(new String(msg));
		// [a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T28,mt_pulse,78,1267511609]
		String content[] = new String(msg).split(",");
		String uid = content[0];
		String timeStr = content[3];
		String imei = content[5];
		String tzStr = "GMT+" + content[6];
		String pulse = content[9];
		String timeStamp = content[10];

		TimeZone tz = TimeZone.getTimeZone(tzStr);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		sdf.setTimeZone(tz);
		Date dt = null;
		try {
			dt = sdf.parse(timeStr);
		} catch (ParseException e) {
			dt = new Date((Long.parseLong(timeStamp) - (Long.parseLong(content[6])*3600))*1000);
		}
		log.debug(sdf.format(dt));

		PsrHeartrate record = new PsrHeartrate();
		record.setImei(imei);
		record.setImsi("");
		record.setBsTime(dt);
		record.setHeartRate(Integer.parseInt(pulse));
		record.setCreateDate(new Date());
		record.setTypeid(28);

		if (record.getHeartRate() > 1 && psrHRMapper.selectByBpTime(record) == 0) {
			psrHRMapper.insert(record);
			push(record.getImei(), record.getHeartRate(), "KM8020");
			pushHR(record.getImei(), record.getHeartRate(), "KM8020",record.getBsTime());
		}

		// [V1.0.0,a1d83kdeio3fg3k,1,abcd,2014-08-29 09:45:15,356511170035899,S28]
		dt = new Date();
		String out[] = { uid, content[1], content[2], sdf.format(dt), imei, function };
		return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"), generateResponse(out));
	}

	@Override
	public boolean handleMessage(String json) {
		// {T28,mt_pulse,88,1267511609,imei}
		try{
			log.info(json);
			String content[] = json.split(",");
		
			PsrHeartrate record = new PsrHeartrate();
			record.setBsTime(new Date((Long.parseLong(content[3]) - (Long.parseLong("8")*3600))*1000));
			record.setImei(content[4]);
			record.setHeartRate(Integer.parseInt(content[2]));
			record.setTypeid(28);
	
			if (record.getHeartRate() > 1) {
				psrHRMapper.insert(record);
				push(record.getImei(), record.getHeartRate(), "KM8020");
				pushHR(record.getImei(), record.getHeartRate(), "KM8020",record.getBsTime());
			}
		}catch (Exception e) {
			return false;
		}
		return true;
	}

}
