/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月14日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8010;

import java.util.Date;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrOxyMapper;
import com.kmhc.model.datacenter.model.PsrOxy;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.LogCenter;
import com.kmhc.model.util.MessageBuilder;


/**
 * Name: BloodOxyHandlerImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8010.BloodOxyHandlerImpl.java]
 * Description:  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Neil
 * @date: 2015年11月14日 下午3:31:48
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */

@MessageCommand(type="KM8010",command="0x86")
public class BloodOxyHandlerImpl extends AbstractParentHandlerKM8010 {
	
	private String type = "86";
	private static final Logger log = LoggerFactory.getLogger(BloodOxyHandlerImpl.class);
	
	public BloodOxyHandlerImpl() {
		super(log);
	}

	private PsrOxyMapper psrOxyMapper = (PsrOxyMapper) SpringBeanFacotry.getInstance().getBean("psrOxyMapper");

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,type);
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);

		try {
			PsrOxy psrOxy = byte2pojo(msg);
			
			int success = psrOxyMapper.selectByOXYTime(psrOxy);
			if(success == 0){
				success = psrOxyMapper.insert(psrOxy);
			}
			push(psrOxy.getImei(),psrOxy.getSpo2(),"KM8010");
			pushBO(psrOxy.getImei(),psrOxy.getSpo2(),"KM8010",psrOxy.getOxyTime());
			if( success > 0  ){			
				return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_SUCCESS_KM8010,(byte) 0x86));
			}
			return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) 0x86));
		} catch (Exception e) {
			LogCenter.exception.error("",e);
			return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) 0x86));
		}
	}
	
	private PsrOxy byte2pojo(byte[] original){
		PsrOxy psrOxy = new PsrOxy();
		
		int[] sections = new int[]{8,5,1,1};
		String[] types= new String[]{"IMEI","Date","Short","Short"};
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		Object[] objs = BytesConvertionUtil.generateProperty4KM8010(original, sections, types, indexMapPolishing);
		
		psrOxy.setImei((String)objs[0]);
		psrOxy.setImsi("");
		psrOxy.setOxyCount((short)1);
		psrOxy.setOxyTime((Date)objs[1]);
		psrOxy.setPuls((short)objs[2]);	
		psrOxy.setSpo2((short)objs[3]);
		psrOxy.setItemno((short)1);
		psrOxy.setCreateDate(new Date());
		psrOxy.setTypeid(86);
		return psrOxy;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
