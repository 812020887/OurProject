/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月11日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.util;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import com.kmhc.framework.util.CollectionUtil;
import com.kmhc.framework.util.ConvertionUtil;
import com.kmhc.framework.util.PacketUtil;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.pojo.BooleanArrays;

/**
 * Name: BytesConvertionUtil.java ProjectName: [kmhc-data-parser] Package:
 * [com.kmhc.model.util.BytesConvertionUtil.java] Description: TODO
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月11日 下午7:35:52
 *
 *        Update-User: @author Update-Time: Update-Remark:
 * 
 *        Check-User: Check-Time: Check-Remark:
 * 
 *        Company: kmhc Copyright: kmhc
 */
public class BytesConvertionUtil {

	/**
	 * @Title: BytesConvertionUtil @Description: TODO @param @throws
	 */
	public BytesConvertionUtil() {
		throw new RuntimeException("util class can't be init!");
	}

	/**
	 * 
	 * @Title: generateProperty @Description: 根据条件从byte中提取数据 @param @param
	 *         original 原数组 @param @param sections 字节数组长度 @param @param types
	 *         属性类型 @param @param indexMapPolishing
	 *         补位还原，只针对在字节尾部补位的还原，去掉个尾部个数 @param @return @return
	 *         Object[] @throws
	 */
	public static Object[] generateProperty4KM8000(byte[] original, int[] sections, String[] types,
			HashMap<Integer, Integer> indexMapPolishing) {
		Object[] objs = new Object[types.length];
		int initialIndex = 0;
		for (int i = 0; i < sections.length; i++) {
			int polishing = 0;
			Object obj;
			int section = sections[i];
			int lastIndex = section + initialIndex;
			String type = types[i];
			byte[] orignalProperty = Arrays.copyOfRange(original, initialIndex, lastIndex);
			initialIndex += section;

			if (indexMapPolishing.containsKey(i))
				polishing = indexMapPolishing.get(i);

			switch (type) {
			case "String":
				String strTemp = ConvertionUtil.bcd2Str(orignalProperty);
				;
				if (polishing > 0)
					strTemp = strTemp.substring(0, strTemp.length() - polishing);
				obj = strTemp;
				break;

			case "Integer":
				if (orignalProperty.length < 4) {
					byte[] b = new byte[] { 0 };
					for (int j = orignalProperty.length; j < 4; j++) {
						orignalProperty = CollectionUtil.concatAll(b, orignalProperty);
					}
				}
				Integer interTemp = new Integer(ConvertionUtil.bigEndBytesToInt(orignalProperty, 0));
				obj = interTemp;
				break;

			case "Date":
				obj = TripleDesHelper.byte2date(orignalProperty);
				break;

			case "BigDecimal&Temperature":
				double temp = (PacketUtil.unsignedInt(PacketUtil.toShort(orignalProperty[(0)], orignalProperty[(1)]))
						/ 100.0D);
				obj = new BigDecimal(temp).setScale(2, BigDecimal.ROUND_HALF_UP);
				break;

			case "Short":
				if (orignalProperty.length < 2) {
					byte[] b = new byte[] { 0 };
					for (int j = orignalProperty.length; j < 2; j++) {
						orignalProperty = CollectionUtil.concatAll(b, orignalProperty);
					}
				}
				Short shortTemp = ConvertionUtil.getShort(orignalProperty, false);
				obj = shortTemp;

				break;

			case "ASCILL":
				obj = PacketUtil.toCellNoString("", orignalProperty, 0, 20);
				break;
			default:
				throw new RuntimeException("property unknow!!!");
			}
			objs[i] = obj;
		}

		return objs;
	}

	public static Object[] generateProperty4KM8010(byte[] original, int[] sections, String[] types,
			HashMap<Integer, Integer> indexMapPolishing) {
		Object[] objs = new Object[types.length];
		int initialIndex = 0;
		for (int i = 0; i < sections.length; i++) {
			// int polishing = 0;
			Object obj;
			int section = sections[i];
			int lastIndex = section + initialIndex;
			String type = types[i];
			byte[] orignalProperty = Arrays.copyOfRange(original, initialIndex, lastIndex);
			initialIndex += section;

			switch (type) {
			case "IMEI":
				String imei = ConvertionUtil.bcd2Str(orignalProperty);
				obj = imei.substring(1, imei.length());
				break;
			case "String":
				String strTemp = ConvertionUtil.bcd2Str(orignalProperty);
				obj = strTemp;
				break;
			case "Integer":
				if (orignalProperty.length < 4) {
					byte[] b = new byte[] { 0 };
					for (int j = orignalProperty.length; j < 4; j++) {
						orignalProperty = CollectionUtil.concatAll(b, orignalProperty);
					}
				}
				Integer interTemp = new Integer(ConvertionUtil.bigEndBytesToInt(orignalProperty, 0));
				obj = interTemp;
				break;

			case "Date":
				obj = TripleDesHelper.ParserRTC(orignalProperty);
				break;

			case "BigDecimal&Temperature":
				double temp = (PacketUtil.unsignedInt(PacketUtil.toShort(orignalProperty[(0)], orignalProperty[(1)]))
						/ 100.0D);
				obj = new BigDecimal(temp).setScale(2, BigDecimal.ROUND_HALF_UP);
				break;

			case "Short":
				if (orignalProperty.length < 2) {
					byte[] b = new byte[] { 0 };
					for (int j = orignalProperty.length; j < 2; j++) {
						orignalProperty = CollectionUtil.concatAll(b, orignalProperty);
					}
				}
				Short shortTemp = ConvertionUtil.getShort(orignalProperty, false);
				obj = shortTemp;
				break;

			case "SETTING":
				if (orignalProperty.length < 2) {
					byte[] b = new byte[] { 0 };
					for (int j = orignalProperty.length; j < 2; j++) {
						orignalProperty = CollectionUtil.concatAll(b, orignalProperty);
					}
				}
				Short settings = ConvertionUtil.getShort(orignalProperty, false);
				BooleanArrays arrays = new BooleanArrays(16);
				for (int j = 15; j >= 0; j--) {
					arrays.setBoolean(j, (settings & (1 << j)) != 0);
				}
				obj = arrays;
				break;

			case "ASCILL":
				obj = PacketUtil.toCellNoString("", orignalProperty, 0, 20);
				break;

			case "HEIGHT&WEIGHT":
				obj = new BigDecimal(TripleDesHelper.ParserHeightWeight(orignalProperty)).setScale(2,
						BigDecimal.ROUND_UP);
				break;

			case "PHONENO":
				obj = TripleDesHelper.ParserPhoneNumber(orignalProperty);
				break;

			case "IGNORE":
				obj = null;
				break;
			default:
				throw new RuntimeException("property unknow!!!");
			}
			objs[i] = obj;
		}
		return objs;
	}

	public static Object[] generateProperty4C100(byte[] original, int[] sections, String[] types,
			HashMap<Integer, Integer> indexMapPolishing) {
		Object[] objs = new Object[types.length];
		int initialIndex = 0;
		for (int i = 0; i < sections.length; i++) {
			// int polishing = 0;
			Object obj;
			int section = sections[i];
			int lastIndex = section + initialIndex;
			String type = types[i];
			byte[] orignalProperty = Arrays.copyOfRange(original, initialIndex, lastIndex);
			initialIndex += section;

			switch (type) {
			case "SN":
				String sn = ConvertionUtil.bcd2Str(orignalProperty);
				sn = sn.substring(0, 9);
				obj = sn;
				break;

			case "TIMESTAMP_SECOND":
				Integer timeStamp = (new Integer(ConvertionUtil.bigEndBytesToInt(orignalProperty, 0))) * 1000;
				Date dt = new Date(timeStamp);
				obj = dt;
				break;

			case "IMESI":
				String imesi = ConvertionUtil.bcd2Str(orignalProperty);
				sn = imesi.substring(0, 15);
				obj = imesi;
				break;

			case "TZ":
				int tz = 0;
				// String timeZone = "GMT+8";
				BooleanArrays arrays = new BooleanArrays(8);
				for (int j = 0; j < 8; j++) {
					arrays.setBoolean(j, ((short) (orignalProperty[0] & 0xFF) & (1 << j)) != 0);
				}
				boolean[] ident = arrays.getBoolean();
				if (ident[7]) {
					for (int k = 0; k < 5; k++) {
						if (ident[k])
							tz += 1 << i;
					}
					tz = tz / 8;
					// timeZone = String.format("GMT+%d", tz);
					// if(ident[6]) timeZone = String.format("GMT-%d", tz);
					if (ident[6])
						tz = -1 * tz;
				}
				obj = tz;
				break;

			case "STRING":
				String asciiStr = "";
				try {
					asciiStr = new String(orignalProperty, "UTF-8");
				} catch (UnsupportedEncodingException e) {
				}
				obj = asciiStr;
				break;
			case "LONG":
				Long s = ConvertionUtil.bytesToLong(orignalProperty);
				obj = s;
				break;

			// case "String":
			// String strTemp = ConvertionUtil.bcd2Str(orignalProperty);
			// if( polishing > 0 )
			// strTemp = strTemp.substring(0, strTemp.length()-polishing);
			// obj = strTemp;
			// break;
			//
			// case "Integer":
			// if( orignalProperty.length < 4 ){
			// byte[] b = new byte[]{0};
			// for( int j = orignalProperty.length ; j < 4 ; j ++ ){
			// orignalProperty = CollectionUtil.concatAll(b, orignalProperty);
			// }
			// }
			// Integer interTemp = new Integer(
			// ConvertionUtil.bigEndBytesToInt(orignalProperty, 0) );
			// obj = interTemp;
			// break;
			//
			// case "Date":
			// obj = TripleDesHelper.byte2date(orignalProperty);
			// break;
			//
			// case "BigDecimal&Temperature":
			// double temp =
			// (PacketUtil.unsignedInt(PacketUtil.toShort(orignalProperty[(0)],
			// orignalProperty[(1)])) / 100.0D);
			// obj = new BigDecimal(temp).setScale(2, BigDecimal.ROUND_HALF_UP);
			// break;

			case "SHORT":
				if (orignalProperty.length < 2) {
					byte[] b = new byte[] { 0 };
					for (int j = orignalProperty.length; j < 2; j++) {
						orignalProperty = CollectionUtil.concatAll(b, orignalProperty);
					}
				}
				Short shortTemp = ConvertionUtil.getShort(orignalProperty, false);
				obj = shortTemp;
				break;

			// case "ASCILL":
			// obj = PacketUtil.toCellNoString("", orignalProperty, 0, 20);
			// break;

			case "IGNORE":
				obj = null;
				break;
			default:
				throw new RuntimeException("property unknow!!!");
			}
			objs[i] = obj;
		}
		return objs;
	}

	/**
	 * 
	 * @Title: polishingPhoneNo @Description: 整合魔禾，统一15为不足后面补# @param @param
	 *         makeupLength @param @param phoneNo @param @return @return
	 *         String @throws
	 */
	// public static String polishingPhoneNo(int makeupLength, String phoneNo){
	// int makeupIndex = makeupLength - phoneNo.length();
	// for (int i = 0; i < makeupIndex; i++) {
	// StringBuilder sb = new StringBuilder(phoneNo).append("#");
	// return sb.toString();
	// }
	// return phoneNo;
	// }

}
