package com.kmhc.model.handler.impl.km8000;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.DeviceSettingGfenceSpMapper;
import com.kmhc.model.datacenter.dao.EfIMapper;
import com.kmhc.model.datacenter.model.DeviceSettingGfenceSp;
import com.kmhc.model.datacenter.model.EfI;
import com.kmhc.model.datacenter.model.EfM;
import com.kmhc.model.datacenter.pojo.PacketTypeEFWifi;
import com.kmhc.model.datacenter.pojo.PeriodicReadingsWifi;
import com.kmhc.model.datacenter.service.ISysRangeService;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;

/**
 * Name: GDSynTimeHandlerImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.SysRangeHandlerImpl.java]
 * Description:   
 * 
 * @since JDK1.7
 * @see
 *
 * @author: czx
 * @date: 2015年11月25日 下午2:11:46
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
@MessageCommand(type="KM8000",command="0x27")
public class SysRangeHandlerImpl extends AbstractHandler   {

	private static final Logger log = LoggerFactory.getLogger(SysRangeHandlerImpl.class);
	private EfIMapper efIMapper = (EfIMapper) SpringBeanFacotry.getInstance().getBean("efIMapper");
    private DeviceSettingGfenceSpMapper dsgsMapper = (DeviceSettingGfenceSpMapper) SpringBeanFacotry.getInstance().getBean("deviceSettingGfenceSpMapper");

	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		String imei = null;
		byte[] reMsg = null;
		byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
		try {
			
			//constructMsg(msg);
			imei = parseImeiOrImsi_KM8000(msg,0);
		    String imsi = parseImeiOrImsi_KM8000(msg,8);
		    
		    ISysRangeService sysRangeService = (ISysRangeService) SpringBeanFacotry.getInstance().getBean("sysRangeService");
			
		    PacketTypeEFWifi pkt = new PacketTypeEFWifi(msg,imei,imsi);
		    
		    sysRangeService.insertPkt27(pkt, false);
		    EfM efm = sysRangeService.getEfMRecord();
		    EfI efi = efIMapper.selectByPrimaryKey(efm.getBatchKey(), efm.getImei(), (short) 0);
		    DeviceSettingGfenceSp dsg = dsgsMapper.selectByPrimaryKey(efi.getImei());
		    if(dsg != null && dsg.getEnable() == 1){
				requestGFenceNotice(imei,efi.getGpsLat(),efi.getGpsLng(),efi.getHpe(),"KM8000");	
			}
		    reMsg = AbstractHandler.ACK_SUCCESS_KM8000;
		    push8000Gps(imei,"KM8000","0x27");	
		} catch (Exception e) {
			log.error("同步区间出错.", e);
			reMsg = AbstractHandler.ACK_ERROR_KM8000;			
		}	
		
		ReplyMessageContent replyMessageContent = null;
		if(imei != null && reMsg != null  ){
			replyMessageContent = new ReplyMessageContent(imeiBytes, reMsg);
		}
		
		return replyMessageContent;
	}
	
	/**
	 * 暂时不会使用该函数
	 * @param msg
	 */
	public void constructMsg(byte[] msg){
		
		int offset = 0 ;
		String imei = parseImeiOrImsi_KM8000(msg,offset+0);
	    String imsi = parseImeiOrImsi_KM8000(msg,offset+8);
	    
/*	    Date date = TripleDesHelper.byte2date(Arrays.copyOfRange(msg, offset+16, 26));
	    
	    Short ev = (short)(0xFF00 & (short)(msg[offset+23] << 8) | 0xFF & (short)msg[offset+24]);
	    
	    String cellID = new String(msg,offset+25,11);
	    
	    byte dataMap1 = msg[offset+36];
	    byte dataMap2 = msg[offset+37];*/
	    
	    short pr_ver = (short)(0xFF & msg[offset+16]);
	    
	    short checksumSYS = (short)(0xFF00 & (short)(msg[offset+17] << 8) | 0xFF & (short)msg[offset+18]);
	    
	    short checksumPER = (short)(0xFF00 & (short)(msg[offset+19] << 8) | 0xFF & (short)msg[offset+20]);
	    
	    short prCount = (short)(0xFF & msg[offset+21]);
	    
	    
	    offset=	offset+22;	
		for (int i = 0; i < prCount; ++i) {
			
			byte[] rss = { -86 };
			byte dmap1 = msg[(offset + 20)];
			byte dmap2 = msg[(offset + 21)];
	
			boolean[] dmArray = new boolean[8];
			int prLength = 22;
			if ((byte) (0xFFFFFF80 & dmap1) == -128) {
				dmArray[1] = true;
				prLength += 3;
				
			}
			if ((byte) (0x40 & dmap1) == 64) {
				dmArray[2] = true;
				prLength += 3;
				
			}
			if ((byte) (0x20 & dmap1) == 32) {
				dmArray[3] = true;
				prLength += 10;
				
			}

			if ((byte) (0x10 & dmap1) == 16) {
				dmArray[4] = true;
				int cellCount = msg[(offset + prLength)];
				prLength += 11 * cellCount + 1;
				
			}

			if ((byte) (0x8 & dmap1) == 8) {
				dmArray[5] = true;
				int wifiCount = msg[(offset + prLength)];
				prLength += 9 * wifiCount + 1;
				
			}

			if ((byte) (0x4 & dmap1) == 4) {
				dmArray[6] = true;
				prLength += 4;
				
			}
			if ((byte) (0x2 & dmap1) == 2) {
				dmArray[7] = true;
				prLength += 4;
				
			}
			
	         PeriodicReadingsWifi pr = new PeriodicReadingsWifi(msg, offset, prLength, dmArray);
			 offset += prLength;
			 
			      
		     //prList.add(pr);
		}
	    
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}
