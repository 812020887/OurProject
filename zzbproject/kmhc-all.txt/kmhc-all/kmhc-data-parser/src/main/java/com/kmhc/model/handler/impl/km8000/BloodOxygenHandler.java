/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月13日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8000;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.PacketUtil;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrOxyMapper;
import com.kmhc.model.datacenter.model.PsrOxy;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.LogCenter;
import com.kmhc.model.util.MessageBuilder;

/**
 * Name: BloodOxygenHandler.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8000.BloodOxygenHandler.java]
 * Description:   
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月13日 上午11:21:03
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
@MessageCommand(type="KM8000",command="0x38") 
public class BloodOxygenHandler extends AbstractHandler {
	
	private PsrOxyMapper psrOxyMapper = (PsrOxyMapper) SpringBeanFacotry.getInstance().getBean("psrOxyMapper");
	private static final Logger log = LoggerFactory.getLogger(BloodOxygenHandler.class);

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
		try {
			PsrOxy oxy = byte2Pojo(msg);
			
			int success = psrOxyMapper.selectByOXYTime(oxy);
			if(success == 0){
				success = psrOxyMapper.insert(oxy);
			}
			
			push(oxy.getImei(),oxy.getSpo2(),"KM8000");
			pushBO(oxy.getImei(),oxy.getSpo2(),"KM8000",oxy.getOxyTime());
			if( success > 0  ){				
				return MessageBuilder.buildReplyMessageContent(imeiBytes, ACK_SUCCESS_KM8000);
			}
			
			return MessageBuilder.buildReplyMessageContent(imeiBytes, ACK_ERROR_KM8000);
		} catch (Exception e) {
			e.printStackTrace();
			LogCenter.exception.error("",e);
			return MessageBuilder.buildReplyMessageContent(imeiBytes, ACK_ERROR_KM8000);
		}
	}
	
	public static PsrOxy byte2Pojo( byte[] msg ){

		PsrOxy psrOxy = new PsrOxy();
		int[] sections = new int[]{8,8,7,1};
		String[] types= new String[]{"String","String","Date","Short"};
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		indexMapPolishing.put(1, 1);
		
		byte[] prefix = Arrays.copyOf(msg, 23);
		byte[] suffix = Arrays.copyOfRange(msg, 23,msg.length);
		
		short plus = 0;
		short spo2 = 0;
		
		int length = (int)PacketUtil.toShort((byte)0, suffix[0]);
		
		for( int i = 1; i < length*2; i=i+2  ){
			byte temp = 0;
			plus += PacketUtil.toShort(temp, suffix[i]);
			spo2 += PacketUtil.toShort(temp, suffix[i+1]);
		}
		
		int average = length;
		plus = (short) (plus / average);
		spo2 = (short) (spo2 / average);
		
		Object[] objs = BytesConvertionUtil.generateProperty4KM8000(prefix, sections, types, indexMapPolishing);
		
		psrOxy.setImei((String)objs[0]);
		psrOxy.setImsi((String)objs[1]);
		psrOxy.setOxyTime((Date)objs[2]);
		psrOxy.setOxyCount((Short)objs[3]);
		psrOxy.setPuls(plus);
		psrOxy.setSpo2(spo2);
		psrOxy.setTypeid(38);
		return psrOxy;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
