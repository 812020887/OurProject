package com.kmhc.model.handler.impl.c100;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.ConvertionUtil;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.DeviceListMapper;
import com.kmhc.model.datacenter.dao.VoiceUploadRecordMapper;
import com.kmhc.model.datacenter.model.DeviceList;
import com.kmhc.model.datacenter.model.VoiceUploadRecord;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.HttpClientUtils;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.SystemConfigUtil;

@MessageCommand(type = "C100", command = "0x0E")
public class VoiceDownloadRequestHandlerImpl extends AbstractParentHandlerC100 {

	private String function = "0E";
	private static final Logger log = LoggerFactory.getLogger(VoiceDownloadRequestHandlerImpl.class);
	private DeviceListMapper deviceListMapper = (DeviceListMapper) SpringBeanFacotry.getInstance()
			.getBean("deviceListMapper");
	private VoiceUploadRecordMapper voiceUploadRecordMapper = (VoiceUploadRecordMapper) SpringBeanFacotry.getInstance()
			.getBean("voiceUploadRecordMapper");

	public VoiceDownloadRequestHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg, function);
		int index = 0;
		byte[] snBytes = Arrays.copyOfRange(msg, index, index + 9);

		int[] sections = new int[] { 9 };
		String[] types = new String[] { "SN" };
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		Object[] objs = BytesConvertionUtil.generateProperty4C100(msg, sections, types, indexMapPolishing);
		String sn = (String) objs[0];
		byte[] body = new byte[11];

		DeviceList deviceList = deviceListMapper.selectBySn(sn);
		if (deviceList != null) {
			String imei = deviceList.getImei();
			List<VoiceUploadRecord> list = voiceUploadRecordMapper.selectFromMobileByImei(imei);
			if (list != null && list.size() > 0) {
				VoiceUploadRecord record = null;
				int number = 0;
				for (VoiceUploadRecord r : list) {
					if (r.getState() == 0) {
						number = r.getRownumber();
						record = r;
						break;
					}
				}
				if (record != null) {
					String filePath = SystemConfigUtil.storageRoot + SystemConfigUtil.storageAudio + "\\"
							+ record.getImei() + "\\" + record.getImei() + "_" + record.getTimen() + ".amr";
					File file = new File(filePath);
					byte[] result = null;
					if (!file.exists()) {
						result = HttpClientUtils.request(record.getUrl(), "GET", "UTF-8", null, null, null,
								SystemConfigUtil.kmhcAutonaviConnectTimeout,
								SystemConfigUtil.kmhcAutonaviSocketTimeout);
					} else {
						result = new byte[(int) file.length()];
						try {
							FileInputStream inFile = new FileInputStream(file);
							inFile.read(result);
							inFile.close();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					if (result != null) {
						body = new byte[11 + result.length];
						body[0] = (byte) (number & 0xFF);
						body[1] = (byte) (record.getDuration() & 0xFF00);
						body[2] = (byte) (record.getDuration() & 0xFF);
						System.arraycopy(ConvertionUtil.longToBytes(record.getTimen()), 0, body, 3, 8);
						System.arraycopy(result, 0, body, 11, result.length);
					}
				}
			}
		}
		if(body.length > 11)return MessageBuilder.buildReplyMessageContent(snBytes, generateResponse(body, (byte) 0x0F));
		else return null;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
