/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月14日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8010;

import java.util.Date;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrStepMapper;
import com.kmhc.model.datacenter.model.PsrStep;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.LogCenter;
import com.kmhc.model.util.MessageBuilder;

/**
 * Name: StepCounterHandlerImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8010.StepCounterHandlerImpl.java]
 * Description:   
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月14日 下午2:06:20
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */

@MessageCommand(type="KM8010",command="0x8B")
public class StepCounterHandlerImpl extends AbstractParentHandlerKM8010 {
	
	private static final Logger log = LoggerFactory.getLogger(StepCounterHandlerImpl.class);

	public StepCounterHandlerImpl() {
		super(log);
	}

	private PsrStepMapper psrStepMapper = (PsrStepMapper) SpringBeanFacotry.getInstance().getBean("psrStepMapper");

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);

		try {
			PsrStep step = byte2Pojo(msg);
			
			int success = psrStepMapper.selectByETime(step);
			if(success == 0){
				success = psrStepMapper.insert(step);
				pushSTP(step.getImei(), step.getSteps(), step.getCal(), step.getDistance(), "KM8010",step.geteTime());
			}
			
			if ( success > 0 ) 
				return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_SUCCESS_KM8010,(byte) -117));
			
			return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) -117));
		} catch (Exception e) {
			LogCenter.exception.error("",e);
			return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) -117));
		}
	}
	
	public PsrStep byte2Pojo( byte[] original ){
		
		int[] sections = new int[]{8,5,5,4,4,4};
		String[] types= new String[]{"IMEI","Date","Date","Integer","Integer","Integer"};
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		Object[] objs = BytesConvertionUtil.generateProperty4KM8010(original, sections, types, indexMapPolishing);
		
		PsrStep step = new PsrStep();
		step.setImei(String.valueOf(objs[0]));
		step.setImsi("");
		step.setsTime((Date)objs[1]);
		step.seteTime((Date)objs[2]);
		step.setWeight(0);
		step.setStepLong(0);
		step.setSteps((Integer)objs[3]);
		step.setDistance((Integer)objs[4]);
		step.setCal((Integer)objs[5]);
		step.setTypeid("35");
		return step;
		
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
