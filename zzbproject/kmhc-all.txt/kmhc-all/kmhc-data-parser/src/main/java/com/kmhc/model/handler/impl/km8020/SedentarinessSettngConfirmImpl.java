/**
 * Copyright (C) 2016 kmhc-data-parser Project
 * Author: Chris
 * Date: 2016年7月22日
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8020;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.ServerActionHisMapper;
import com.kmhc.model.datacenter.dao.T9SitSettingMapper;
import com.kmhc.model.datacenter.model.ServerActionHis;
import com.kmhc.model.datacenter.model.T9SitSetting;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;

/**
 * Name: SedentarinessSettngConfirmImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8020.SedentarinessSettngConfirmImpl.java]
 * Description:   
 *
 * @since JDK1.7
 * @see
 *
 * Author: @author: Chris
 * Date: 2016年7月22日 下午6:15:35
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 *
 * Check-User:
 * Check-Time:
 * Check-Remark:
 *
 * Company: kmy
 * Copyright: kmy
 */

//T87
@MessageCommand(type = "KM8020", command = "0x543837")
public class SedentarinessSettngConfirmImpl
        extends AbstractParentHandlerKM8020 {

    private static final Logger log = LoggerFactory.getLogger(SedentarinessSettngConfirmImpl.class);
    private ServerActionHisMapper serverActionHisMapper = (ServerActionHisMapper) SpringBeanFacotry.getInstance().getBean("serverActionHisMapper");
    private T9SitSettingMapper t9SitSettingMapper = (T9SitSettingMapper) SpringBeanFacotry.getInstance().getBean("t9SitSettingMapper");


    public SedentarinessSettngConfirmImpl() {
        super(log);
    }


    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {


        log.info(new String(msg));
        //[V1.0.0,a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,355372020827303,S87,10:00:05,10:58:09,1]
        String content[] = new String(msg).split(",");
        String imei = content[5];
        String protocol = "S87";
        String uid = content[0];

        ServerActionHis sah = serverActionHisMapper.selectByPrimaryKey(uid, imei, protocol);

        if (sah != null) {
            String[] his = sah.getContent().split(",");
            T9SitSetting setting = new T9SitSetting();
            setting.setCreatedate(new Date());
            setting.setEndtime(his[8]);
            setting.setImei(imei);
            setting.setStarttime(his[7]);
            setting.setStatus(Integer.parseInt(his[9]));
            setting.setUpdatedate(new Date());

            if (t9SitSettingMapper.selectByPrimaryKey(imei) == null)
                t9SitSettingMapper.insert(setting);
            else
                t9SitSettingMapper.update(setting);

            serverActionHisMapper.deleteByPrimaryKey(sah.getUid(), sah.getImei(), sah.getProtocol());
            pushSettingFinish(imei, INotification.NOTIFICATION_TYPE_SETTING_SEDENTARY);
        }


        return null;
    }


    @Override
    public boolean handleMessage(String json) {
        // TODO Auto-generated method stub
        return false;
    }


}
