package com.kmhc.model.pojo;

import java.io.Serializable;

public class LocResult implements Serializable{

    private static final long serialVersionUID = 6039607814089372072L;
    private int status ;
    private String info ;
    private LocDetailResult result ;
    
    public int getStatus() {
        return status;
    }
    public void setStatus(int status) {
        this.status = status;
    }
    public String getInfo() {
        return info;
    }
    public void setInfo(String info) {
        this.info = info;
    }
    public LocDetailResult getResult() {
        return result;
    }
    public void setResult(LocDetailResult result) {
        this.result = result;
    }
    
    
}
