/**
 * Copyright (C) 2016 kmhc-data-parser Project
 * Author: Chris
 * Date: 2016年7月25日
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8020;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.T9SleepMapper;
import com.kmhc.model.datacenter.model.T9Sleep;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;

/**
 * Name: SleepQualityDataUploadIml.java ProjectName: [kmhc-data-parser] Package:
 * [com.kmhc.model.handler.impl.km8020.SleepQualityDataUploadIml.java]
 * Description: TODO
 *
 * @since JDK1.7
 * @see
 *
 * 		@author: Chris Date: 2016年7月25日 下午6:28:49
 *
 *      Update-User: @author Update-Time: Update-Remark:
 *
 *      Check-User: Check-Time: Check-Remark:
 *
 *      Company: kmy Copyright: kmy
 */

// T91
@MessageCommand(type = "KM8020", command = "0x543931")
public class SleepQualityDataUploadIml extends AbstractParentHandlerKM8020 {

    private T9SleepMapper t9SleepMapper = (T9SleepMapper) SpringBeanFacotry.getInstance().getBean("t9SleepMapper");
    private static final Logger log = LoggerFactory.getLogger(SleepQualityDataUploadIml.class);

    public SleepQualityDataUploadIml() {
        super(log);
    }

    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {

        log.info(new String(msg));

        String contents[] = new String(msg).split(",");
        String imei = contents[5];
        String time = contents[3];
        String[] content = Arrays.copyOfRange(contents, 8, contents.length);
        T9Sleep t9Sleep = new T9Sleep();

        String[] group = content[9].split("\\|");
        String groupTemp = group[0];
        String highTemp = group[1];

        t9Sleep.setDuration(content[3]);
        t9Sleep.setEndTime(content[2]);
        t9Sleep.setGcount(groupTemp);
        t9Sleep.setHcount(highTemp);
        t9Sleep.setHeartPercent(Integer.parseInt(content[5]));
        t9Sleep.setImei(imei);
        t9Sleep.setMaxHeart(Integer.parseInt(content[7]));
        t9Sleep.setMeanHeart(Integer.parseInt(content[8]));
        t9Sleep.setMinHeart(Integer.parseInt(content[6]));
        t9Sleep.setQuietPercent(Integer.parseInt(content[4]));
        t9Sleep.setSleepinfo(content[0]);
        t9Sleep.setStartTime(content[1]);
        t9Sleep.setTimen(new Date(Long.parseLong(content[10].trim()) * 1000));

        if (t9SleepMapper.selectBySETime(t9Sleep) == 0)
            t9SleepMapper.insert(t9Sleep);

        String out[] = {contents[0], contents[1], contents[2], time, imei, "S91"};
        return MessageBuilder.buildReplyMessageContentKM8020(TripleDesHelper.hex2byte(imei + "0"),
                generateResponse(out));

    }

    @Override
    public boolean handleMessage(String json) {
        // TODO Auto-generated method stub
        // {T91,sleep_info,start_ime,end_time,duration,quiet_percent,heart_percent,min_heart,max_heart,mean_heart,gcount1;gcount2;gcountN|hcount1;gcount2;gcountN,timen}
        // [T91,sleep
        // info,01:30,08:55,07:25,89,59,61,86,70,111111;111111211111;111111111112;111111111211;111111111111;111111112212;121211111111;11111111112|222212;112221222212;111211111111;112121010201;112211122111;111122212211;121111111111;22111221122,1441762200]
        log.info(json);
        try {
            String content[] = json.split(",");
            T9Sleep t9Sleep = new T9Sleep();
            String[] group = content[10].split("\\|");
            String groupTemp = group[0];
            String highTemp = group[1];

            t9Sleep.setDuration(content[4]);
            t9Sleep.setEndTime(content[3]);
            t9Sleep.setGcount(groupTemp);
            t9Sleep.setHcount(highTemp);
            t9Sleep.setHeartPercent(Integer.parseInt(content[6]));
            t9Sleep.setImei(content[content.length - 1]);
            t9Sleep.setMaxHeart(Integer.parseInt(content[8]));
            t9Sleep.setMeanHeart(Integer.parseInt(content[9]));
            t9Sleep.setMinHeart(Integer.parseInt(content[7]));
            t9Sleep.setQuietPercent(Integer.parseInt(content[5]));
            t9Sleep.setSleepinfo(content[1]);
            t9Sleep.setStartTime(content[2]);
            t9Sleep.setTimen(new Timestamp(Long.parseLong(content[11].trim()) * 1000));
            t9SleepMapper.insert(t9Sleep);
        } catch (Exception e) {
            return false;
        }
        return true;
    }
}
