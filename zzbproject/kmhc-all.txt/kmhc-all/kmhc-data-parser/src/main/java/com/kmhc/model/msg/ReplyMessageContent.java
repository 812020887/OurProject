/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月7日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.msg;

import java.io.Serializable;
import java.util.ArrayList;

import com.kmhc.framework.util.CollectionUtil;
import com.kmhc.framework.util.ConvertionUtil;
import com.kmhc.framework.util.TripleDesHelper;
//import com.sun.corba.se.impl.protocol.giopmsgheaders.ReplyMessage;


/**
 * Name: ReplyMessageContent.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.msg.ReplyMessageContent.java]
 * Description: 数据回发消息类  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月7日 下午3:40:36
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class ReplyMessageContent implements Serializable {

	/** 
	 * @Fields serialVersionUID : TODO
	 */ 
	private static final long serialVersionUID = 2855586150231809614L;
	
	
	private final ArrayList<byte[]> msg;
	
	private final String iemiCodeStr;
	
	private String protocolName = "";

	/** 
	 * @Title: ReplyMessageContent
	 * @Description: TODO
	 * @param @param msg
	 * @param @param iemiCode         
	 * @throws 
	 */ 
	public ReplyMessageContent(byte[] iemiCode , ArrayList<byte[]> msgs ) {
		ArrayList<byte[]> msgTemp = new ArrayList<>(msgs.size());
		for( byte[] m : msgs ){
			msgTemp.add( CollectionUtil.concatAll(iemiCode, m) );
		}
		this.msg = msgTemp;
		this.iemiCodeStr = ConvertionUtil.bcd2Str(iemiCode);
	}
	
	
	public ReplyMessageContent( byte[] iemiCode, byte[] msgSingle  ){
		msg = new ArrayList<>(1);
		msg.add(CollectionUtil.concatAll(iemiCode, msgSingle));
		this.iemiCodeStr = ConvertionUtil.bcd2Str(iemiCode);	
	}
	
	public ReplyMessageContent( byte[] iemiCode, byte[] msgSingle, String type ){
		msg = new ArrayList<>(1);
		msg.add(CollectionUtil.concatAll(iemiCode, msgSingle));
		this.iemiCodeStr = TripleDesHelper.byte2hex(iemiCode,iemiCode.length);	
	}
	
	public ReplyMessageContent( byte[] iemiCode, byte[]... rest ){
		msg = new ArrayList<>(rest.length);
		for( byte[] array : rest ){
			msg.add(CollectionUtil.concatAll(iemiCode, array));
		}
		this.iemiCodeStr = ConvertionUtil.bcd2Str(iemiCode);
	}
	
	public ReplyMessageContent(byte[] content){
		msg = new ArrayList<>(1);
		msg.add(content);
		this.iemiCodeStr = "initData";
	}

	/**
	 * @return the msg
	 */
	public ArrayList<byte[]> getMsg() {
		return msg;
	}

	/**
	 * @return the iemiCode
	 */
	public String getIemiCode() {
		return iemiCodeStr;
	}


	/**
	 * @return the protocolName
	 */
	public String getProtocolName() {
		return protocolName;
	}

	/**
	 * @param protocolName the protocolName to set
	 */
	public void setProtocolName(String protocolName) {
		this.protocolName = protocolName;
	}
	
}
