/**
 * Copyright (C) 2016 kmhc-data-parser Project
 * Author: Chris
 * Date: 2016年7月22日
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8020;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrSettingMapper;
import com.kmhc.model.datacenter.dao.ServerActionHisMapper;
import com.kmhc.model.datacenter.model.ServerActionHis;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;

/**
 * Name: DeleteAllWarnConfirmImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8020.DeleteAllWarnConfirmImpl.java]
 * Description: TODO  
 *
 * @since JDK1.7
 * @see
 *
 * Author: @author: Chris
 * Date: 2016年7月22日 下午6:14:02
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 *
 * Check-User:
 * Check-Time:
 * Check-Remark:
 *
 * Company: kmy
 * Copyright: kmy
 */

@MessageCommand(type = "KM8020", command = "0x543933")
public class DeleteAllWarnSettingConfirmImpl extends AbstractParentHandlerKM8020 {


    private ServerActionHisMapper serverActionHisMapper = (ServerActionHisMapper) SpringBeanFacotry.getInstance().getBean("serverActionHisMapper");
    private PsrSettingMapper psrSettingMapper = (PsrSettingMapper) SpringBeanFacotry.getInstance().getBean("psrSettingMapper");
    private static final Logger log = LoggerFactory.getLogger(DeleteAllWarnSettingConfirmImpl.class);

    /**
     * @Title: DeleteAllWarnSettingConfirmImpl
     * @Description: TODO
     * @param @param log         
     * @throws
     */
    public DeleteAllWarnSettingConfirmImpl() {
        super(log);
    }

    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
        log.info(new String(msg));
        String content[] = new String(msg).split(",");
        String imei = content[5];
        String uid = content[0];
        String protocol = "S93";

        ServerActionHis sah = serverActionHisMapper.selectByPrimaryKey(uid, imei, protocol);


        if (sah != null) {
            psrSettingMapper.deleteAllByImei(imei);
            serverActionHisMapper.deleteByPrimaryKey(sah.getUid(), sah.getImei(), protocol);
            pushSettingFinish(imei, INotification.NOTIFICATION_TYPE_SETTING_REMIND);
        }
        return null;
    }

    @Override
    public boolean handleMessage(String json) {
        // TODO Auto-generated method stub
        return false;
    }


}
