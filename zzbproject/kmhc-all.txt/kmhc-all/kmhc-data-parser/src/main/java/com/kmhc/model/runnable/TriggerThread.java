/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月7日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.runnable;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;

import com.kmhc.model.msg.MessageContent;

/**
 * Name: TriggerThread.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.trigger.TriggerThread.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月7日 下午3:30:50
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class TriggerThread implements Runnable {
	
	private final ExecutorService service;
	public static LinkedBlockingQueue<MessageContent> triggerQueue = new LinkedBlockingQueue<MessageContent>();
	
	/** 
	 * @Title: TriggerThread
	 * @Description: TODO
	 * @param @param service         
	 * @throws 
	 */ 
	public TriggerThread(ExecutorService service) {
		super();
		this.service = service;
	}

	private void start(){
		service.execute(this);
	}

	@Override
	public void run() {
		while( true ){
			try {
				MessageContent content = triggerQueue.take();
				
				//TODO 第三方操作
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		
	}
			

}
