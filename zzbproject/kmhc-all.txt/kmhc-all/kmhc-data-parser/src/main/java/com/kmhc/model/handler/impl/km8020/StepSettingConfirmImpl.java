/**
 * Copyright (C) 2016 kmhc-data-parser Project
 * Author: Chris
 * Date: 2016年7月22日
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8020;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.ServerActionHisMapper;
import com.kmhc.model.datacenter.dao.T9StepSettingMapper;
import com.kmhc.model.datacenter.model.ServerActionHis;
import com.kmhc.model.datacenter.model.T9StepSetting;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;

/**
 * Name: StepSettingConfirmImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8020.StepSettingConfirmImpl.java]
 * Description: TODO  
 *
 * @since JDK1.7
 * @see
 *
 * Author: @author: Chris
 * Date: 2016年7月22日 下午6:08:19
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 *
 * Check-User:
 * Check-Time:
 * Check-Remark:
 *
 * Company: kmy
 * Copyright: kmy
 */

//T78
@MessageCommand(type = "KM8020", command = "0x543738")
public class StepSettingConfirmImpl extends AbstractParentHandlerKM8020 {

    private static final Logger log = LoggerFactory.getLogger(StepSettingConfirmImpl.class);
    private ServerActionHisMapper serverActionHisMapper = (ServerActionHisMapper) SpringBeanFacotry.getInstance().getBean("serverActionHisMapper");
    private T9StepSettingMapper t9StepSettingMapper = (T9StepSettingMapper) SpringBeanFacotry.getInstance().getBean("t9StepSettingMapper");


    /**
     * @Title: StepSettingConfirmImpl
     * @Description: TODO
     * @param @param log         
     * @throws
     */
    public StepSettingConfirmImpl() {
        super(log);
    }

    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
        log.info(new String(msg));
        //[a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,355372020827303,S78,10:00:05,10:58:09,60]
        String content[] = new String(msg).split(",");
        String imei = content[5];
        String protocol = "S78";
        String uid = content[0];

        ServerActionHis sah = serverActionHisMapper.selectByPrimaryKey(uid, imei, protocol);
        if (sah != null) {
            String[] his = sah.getContent().split(",");
            T9StepSetting setting = new T9StepSetting();
            setting.setCreatedate(new Date());
            setting.setEndtime(his[8]);
            setting.setImei(imei);
            setting.setSpan(Integer.parseInt(his[9]));
            setting.setStarttime(his[7]);
            setting.setUpdatedate(new Date());
            if (t9StepSettingMapper.selectByPrimaryKey(imei) == null)
                t9StepSettingMapper.insert(setting);
            else
                t9StepSettingMapper.update(setting);
            serverActionHisMapper.deleteByPrimaryKey(sah.getUid(), sah.getImei(), "S78");
            pushSettingFinish(imei, INotification.NOTIFICATION_TYPE_SETTING_STEP);
        }
        return null;
    }

    @Override
    public boolean handleMessage(String json) {
        // TODO Auto-generated method stub
        return false;
    }


}
