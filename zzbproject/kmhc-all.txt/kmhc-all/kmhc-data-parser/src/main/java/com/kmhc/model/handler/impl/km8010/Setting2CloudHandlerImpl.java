package com.kmhc.model.handler.impl.km8010;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.ProductPerSettingMMapper;
import com.kmhc.model.datacenter.dao.ProductSysSettingMMapper;
import com.kmhc.model.datacenter.model.ProductPerSettingM;
import com.kmhc.model.datacenter.model.ProductSysSettingM;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.pojo.BooleanArrays;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type="KM8010",command="0xA0")
public class Setting2CloudHandlerImpl extends AbstractParentHandlerKM8010 {
	
	private String type = "A0";
	private static final Logger log = LoggerFactory.getLogger(Setting2CloudHandlerImpl.class);
	private ProductSysSettingMMapper productSysSettingMMapper = (ProductSysSettingMMapper) SpringBeanFacotry.getInstance().getBean("productSysSettingMMapper");
	private ProductPerSettingMMapper productPerSettingMMapper = (ProductPerSettingMMapper) SpringBeanFacotry.getInstance().getBean("productPerSettingMMapper");
	
	public Setting2CloudHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,type);
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);

		Object[] objs = byte2obj(msg);
		int successSys = 0;
		int successPer = 0;
		
		ProductSysSettingM sysSetting = productSysSettingMMapper.selectByPrimaryKey(String.valueOf(objs[0]));
		ProductPerSettingM perSetting = productPerSettingMMapper.selectByPrimaryKey(String.valueOf(objs[0]));
		
		if( sysSetting == null)
			successSys = productSysSettingMMapper.insert(object2SysPojo( objs, sysSetting ));
		else
			successSys = productSysSettingMMapper.updateByPrimaryKey(object2SysPojo( objs, sysSetting ));
		
		if( perSetting == null )
			successPer = productPerSettingMMapper.insert(object2PerPojo( objs, perSetting ));
		else
			successPer = productPerSettingMMapper.updateByPrimaryKey(object2PerPojo( objs, perSetting ));
		
		if( successSys > 0 && successPer > 0 )
			return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_SUCCESS_KM8010,(byte) 0xA0));
		
		return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) 0xA0));
	}
	
	
	public Object[] byte2obj( byte[] original ){
		int[] sections = new int[]{8,5,8,8,8,8,8,8,8,8,8,2,1,2,2};
		String[] types= new String[]{"IMEI","Date","PHONENO","PHONENO","PHONENO","PHONENO","PHONENO","PHONENO","PHONENO","PHONENO",
									 "PHONENO","SETTING","Short","HEIGHT&WEIGHT","HEIGHT&WEIGHT"};
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		Object[] objs = BytesConvertionUtil.generateProperty4KM8010(original, sections, types, indexMapPolishing);
		return objs;
	}
	
	public ProductSysSettingM object2SysPojo( Object[] objs, ProductSysSettingM sysSetting ){		
		if(sysSetting == null){
			sysSetting = new ProductSysSettingM();
			sysSetting.setCreateDate((Date)objs[1]);
		}
		
		sysSetting.setImei(String.valueOf(objs[0]));
		sysSetting.setImsi("");
		sysSetting.setUpdateDate((Date)objs[1]);
		
//		boolean[] settings = (boolean[])objs[8];
		boolean[] settings = ((BooleanArrays)objs[11]).getBoolean();
		short duration = 0;
		short switchonoff = 0;
		
		if( settings[9] || settings[10] || settings[11] ){
			switchonoff = 1;
			if( !settings[9] && !settings[10] && settings[11] )
				duration = 60;
			else if( settings[9] && settings[10] && !settings[11] )
				duration = 30;
			else if( !settings[9] && settings[10] && !settings[11] )
				duration = 15;
			else if( settings[9] && !settings[10] && !settings[11] )
				duration = 5;
			
		}
		sysSetting.setPhoneLimitOnoff(switchonoff);
		sysSetting.setPhoneLimitTime(duration);

		duration = 30;
		if ( settings[12] && settings[13] )
			duration = 120;
		else if ( !settings[12] && settings[13] )
			duration = 90;
		else if ( settings[12] && !settings[13] )
			duration = 60;
		sysSetting.setEchoPrT(duration);
		
		duration = 0;
		if( settings[6] || settings[7] || settings[8] ){
			if( !settings[6] && !settings[7] && settings[8] )
				duration = 60;
			else if( settings[6] && settings[7] && !settings[8] )
				duration = 30;
			else if( !settings[6] && settings[7] && !settings[8] )
				duration = 15;
			else if( settings[6] && !settings[7] && !settings[8] )
				duration = 5;
		}
		sysSetting.setEchoGpsT(duration);
		
		switchonoff = 0;
		if(settings[5])
			switchonoff = 1;
		sysSetting.setAutoread(switchonoff);	
		return sysSetting;	
	}
	
	public ProductPerSettingM object2PerPojo( Object[] objs , ProductPerSettingM perSetting ){		
		if( perSetting == null ){
			perSetting = new ProductPerSettingM();
			perSetting.setCreateDate((Date)objs[1]);
		}
		
		perSetting.setImei(String.valueOf(objs[0]));
		perSetting.setImsi("");	
		perSetting.setUpdateDate((Date)objs[1]);
		
		perSetting.setFmlyPhoneNo1((String)objs[2]);
		perSetting.setFmlyPhoneNo2((String)objs[3]);
		perSetting.setFmlyPhoneNo3((String)objs[4]);
		
		perSetting.setSosPhoneNo1((String)objs[5]);
		perSetting.setSosPhoneNo2((String)objs[6]);
		perSetting.setSosPhoneNo3((String)objs[7]);
		
		perSetting.setFallPhoneNo1((String)objs[8]);
		perSetting.setFallPhoneNo2((String)objs[9]);
		perSetting.setFallPhoneNo3((String)objs[10]);
		
//		boolean[] settings = (boolean[])objs[8];
		boolean[] settings = ((BooleanArrays)objs[11]).getBoolean();
		short switchonoff = 0;
		
		if( settings[2] )
			switchonoff = 1;
		perSetting.setNonDistrub(switchonoff);
		
		switchonoff = 0;
		if( settings[0] )
			switchonoff = 1;
		perSetting.setFallDetect(switchonoff);
		
		perSetting.setuStep((short)objs[12]);
		perSetting.setuHeight((BigDecimal)objs[13]);
		perSetting.setuWeight((BigDecimal)objs[14]);
		
		/*-------------------TODO 假数据------------*/
		
		perSetting.setSosKeyDelay((short)0);
		perSetting.setFmlyKeyDelay((short)0);
		perSetting.setSosSms((short)0);
		perSetting.setFallSms((short)0);
//		perSetting.setNonDistrub((short)0);
		perSetting.setTimezone((short)0);
		
		perSetting.setFamilyIcon1((short)0);
		perSetting.setFamilyIcon2((short)0);
		perSetting.setFamilyIcon3((short)0);
		
		perSetting.setMedT1On((short)0);
		perSetting.setMedT1Hh((short)0);
		perSetting.setMedT1Mm((short)0);
		perSetting.setMedT1WeekdayFilter((short)0);
//		
		perSetting.setMedT2On((short)0);
		perSetting.setMedT2Hh((short)0);
		perSetting.setMedT2Mm((short)0);
		perSetting.setMedT2WeekdayFilter((short)0);
//		
		perSetting.setMedT3On((short)0);
		perSetting.setMedT3Hh((short)0);
		perSetting.setMedT3Mm((short)0);
		perSetting.setMedT3WeekdayFilter((short)0);
//		
		perSetting.setMedT4On((short)0);
		perSetting.setMedT4Hh((short)0);
		perSetting.setMedT4Mm((short)0);
		perSetting.setMedT4WeekdayFilter((short)0);
//
		perSetting.setMedT5On((short)0);
		perSetting.setMedT5Hh((short)0);
		perSetting.setMedT5Mm((short)0);
		perSetting.setMedT5WeekdayFilter((short)0);
		
		perSetting.setMedD1On((short)0);
		perSetting.setMedD1Yy((short)0);
		perSetting.setMedD1Mm((short)0);
		perSetting.setMedD1Dd((short)0);
		perSetting.setMedD1Hour((short)0);
		perSetting.setMedD1Minute((short)0);
		
		perSetting.setMedD2On((short)0);
		perSetting.setMedD2Yy((short)0);
		perSetting.setMedD2Mm((short)0);
		perSetting.setMedD2Dd((short)0);
		perSetting.setMedD2Hour((short)0);
		perSetting.setMedD2Minute((short)0);
//
		perSetting.setWhiteListOn((short)0);
		perSetting.setWhiteListPhone1("###############");
		perSetting.setWhiteListPhone2("###############");
		perSetting.setWhiteListPhone3("###############");
		perSetting.setWhiteListPhone4("###############");
		perSetting.setWhiteListPhone5("###############");
		perSetting.setWhiteListPhone6("###############");
		perSetting.setWhiteListPhone7("###############");
		perSetting.setWhiteListPhone8("###############");
		perSetting.setWhiteListPhone9("###############");
		perSetting.setWhiteListPhone10("###############");
		perSetting.setWhiteListPhone11("###############");
		perSetting.setWhiteListPhone12("###############");
		perSetting.setWhiteListPhone13("###############");
		perSetting.setWhiteListPhone14("###############");
		perSetting.setWhiteListPhone15("###############");
		perSetting.setWhiteListPhone16("###############");
		perSetting.setWhiteListPhone17("###############");
		perSetting.setWhiteListPhone18("###############");
		perSetting.setWhiteListPhone19("###############");
		perSetting.setWhiteListPhone20("###############");
		
		perSetting.setFallLowLg((short)0);
		perSetting.setFallLowHg((short)0);
		perSetting.setFallLowFl((short)0);
		perSetting.setFallLowFt((short)0);
		perSetting.setFallLowSt((short)0);
		perSetting.setFallLowWt((short)0);
		perSetting.setFallLowRes1((short)0);
		perSetting.setFallLowRes2((short)0);
		
		perSetting.setFallMidLg((short)0);
		perSetting.setFallMidHg((short)0);
		perSetting.setFallMidFl((short)0);
		perSetting.setFallMidFt((short)0);
		perSetting.setFallMidSt((short)0);
		perSetting.setFallMidWt((short)0);
		perSetting.setFallMidRes1((short)0);
		perSetting.setFallMidRes2((short)0);
		
		perSetting.setFallHiLg((short)0);
		perSetting.setFallHiHg((short)0);
		perSetting.setFallHiFl((short)0);
		perSetting.setFallHiFt((short)0);
		perSetting.setFallHiSt((short)0);
		perSetting.setFallHiWt((short)0);
		perSetting.setFallHiRes1((short)0);
		perSetting.setFallHiRes2((short)0);
		
		perSetting.setSetLang((short)0);
		perSetting.setSpeakLang((short)0);
		
		perSetting.setuSystolicLowerLimit((short)0);
		perSetting.setuSystolicUpperLimit((short)0);
		perSetting.setuDaistolicLowerLimit((short)0);
		perSetting.setuDiastolicUpperLimit((short)0);

		perSetting.setActiveG((short)0);
		perSetting.setActiveGyro((short)0);
		perSetting.setChecksum((short)0);
		
		perSetting.setEfT1On((short)0);		
		perSetting.setEfST1Hh((short)0);
		perSetting.setEfST1Mm((short)0);
		perSetting.setEfET1Hh((short)0);
		perSetting.setEfET1Mm((short)0);
		perSetting.setEfT1WeekdayFilter((short)0);
		
		perSetting.setEfT2On((short)0);		
		perSetting.setEfST2Hh((short)0);
		perSetting.setEfST2Mm((short)0);
		perSetting.setEfET2Hh((short)0);
		perSetting.setEfET2Mm((short)0);
		perSetting.setEfT2WeekdayFilter((short)0);
		
		perSetting.setEfT3On((short)0);		
		perSetting.setEfST3Hh((short)0);
		perSetting.setEfST3Mm((short)0);
		perSetting.setEfET3Hh((short)0);
		perSetting.setEfET3Mm((short)0);
		perSetting.setEfT3WeekdayFilter((short)0);
		
		perSetting.setDistanceUnit(0);
		perSetting.setStepTotal(0);
		perSetting.setHeatTotal(0);
		
		return perSetting;	
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
