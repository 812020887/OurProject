package com.kmhc.model.handler.impl.c100;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.DeviceListMapper;
import com.kmhc.model.datacenter.dao.VoiceUploadRecordMapper;
import com.kmhc.model.datacenter.model.DeviceList;
import com.kmhc.model.datacenter.model.VoiceUploadRecord;
import com.kmhc.model.handler.impl.PushAlert;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.Publish;
import com.kmhc.model.util.SystemConfigUtil;

@MessageCommand(type = "C100", command = "0x91")
public class VoiceRecordRequestHandlerImpl extends AbstractParentHandlerC100 {

	private String function = "91";
	private static final Logger log = LoggerFactory.getLogger(VoiceRecordRequestHandlerImpl.class);
	private DeviceListMapper deviceListMapper = (DeviceListMapper) SpringBeanFacotry.getInstance()
			.getBean("deviceListMapper");
	private VoiceUploadRecordMapper voiceUploadRecordMapper = (VoiceUploadRecordMapper) SpringBeanFacotry.getInstance()
			.getBean("voiceUploadRecordMapper");

	public VoiceRecordRequestHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg, function);
		int index = 0;
		byte[] snBytes = Arrays.copyOfRange(msg, index, index + 9);

		int[] sections = new int[] { 9, 2 };
		String[] types = new String[] { "SN", "SHORT" };
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		Object[] objs = BytesConvertionUtil.generateProperty4C100(msg, sections, types, indexMapPolishing);
		String sn = (String) objs[0];
		short duration = (short) objs[1];

		Date dt = new Date();

		DeviceList deviceList = deviceListMapper.selectBySn(sn);
		byte[] amr = Arrays.copyOfRange(msg, 11, msg.length - 4);
		if (deviceList != null) {
			String filePath = SystemConfigUtil.storageRoot + SystemConfigUtil.storageAudio + "\\" + deviceList.getImei()
					+ "\\" + deviceList.getImei() + "_" + dt.getTime() + ".amr";
			File file = new File(filePath);
			file.getParentFile().mkdirs();
			try {
				if (!file.exists()) {
					file.createNewFile();
				}
				FileOutputStream outFile = new FileOutputStream(file);
				outFile.write(amr);
				outFile.close();

				String url = SystemConfigUtil.localServiceUrl + "voice/download/" + deviceList.getImei() + "/"
						+ dt.getTime();
				VoiceUploadRecord vur = new VoiceUploadRecord(deviceList.getImei(), dt.getTime(), (int) duration, url,
						0, 0, "");
				int result = voiceUploadRecordMapper.insert(vur);
				if (result > 0) {
					// 新的錄音來自imei 下午12:30
					push(deviceList.getImei(), url);
					return MessageBuilder.buildReplyMessageContent(snBytes, generateResponse((byte) 0x8D));
				}
			} catch (FileNotFoundException e) {
				log.error("Image not found" + e);
			} catch (IOException ioe) {
				log.error("Exception while reading the Image " + ioe);
			}
		}
		return null;
	}

	private void push(String imei, String url) {
		String alert = new PushAlert(null, "record_msg_key").toString();
		String title = "record_msg_title_key";
		int builder_id = INotification.ANDROID_MAKER_DEFAULT;
		String extras = "";
		extras = String.format("imei=%s|", imei);
		extras += String.format("type=%s|", INotification.NOTIFICATION_TYPE_RECORD);
		extras += String.format("level=%d|", INotification.NOTIFICATION_LEVEL_LOW);
		extras += String.format("builder_id=%d|", INotification.ANDROID_MAKER_DEFAULT);
		extras += String.format("url=%s|", url);
		extras += "device=C100|";
		Publish.push(imei, alert, title, builder_id, extras);
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
