package com.kmhc.model.handler.impl.c100;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.ConvertionUtil;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.DeviceListMapper;
import com.kmhc.model.datacenter.dao.EmgIMapper;
import com.kmhc.model.datacenter.dao.EmgMMapper;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.DeviceList;
import com.kmhc.model.datacenter.model.EmgI;
import com.kmhc.model.datacenter.model.EmgM;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.handler.impl.PushAlert;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.Publish;

/**
    * @ClassName: com.kmhc.model.handler.impl.c100.AlarmCommandHandlerImpl
    * @Description: 
    * @author xl
    * @date 2016年10月13日
    *
    */
@MessageCommand(type = "C100", command = "0x06")
public class AlarmCommandHandlerImpl extends AbstractParentHandlerC100 {
    
    private static final Logger log = LoggerFactory.getLogger(AlarmCommandHandlerImpl.class);
    private final String type = "06" ;
    private DeviceListMapper deviceListMapper = (DeviceListMapper) SpringBeanFacotry.getInstance().getBean("deviceListMapper");
    
    public AlarmCommandHandlerImpl() {
        super(log);
    }

    @Override
    public ReplyMessageContent handleMessage(byte[] msg) {
        int index = -5;
        ReplyMessageContent result = null;
        EmgM emgm = null;
        byte[] snBytes= Arrays.copyOfRange(msg,index+ 5,index+14) ;
        try {
            emgm = byte2Pojo(index,msg);
            // 入数据库Emg_M表
            EmgMMapper emgMMapper = (EmgMMapper) SpringBeanFacotry.getInstance().getBean("emgMMapper");
            emgMMapper.insertSelective(emgm);
            if (emgm.getCells().size() > 0) {
                List<EmgI> emgIList = getEmgIList(emgm.getCells(), emgm.getEmgDetailKey(), emgm.getCreateDate(),
                        emgm.getUpdateDate());
                EmgIMapper emgIMapper = (EmgIMapper) SpringBeanFacotry.getInstance().getBean("emgIMapper");
                emgIMapper.insertList(emgIList);
            }
        } catch (Exception e) {
            log.error("【type=C100,command=0x{}】解码失败", type);
            log.error("异常信息：", e);
        }
//        sendNotification(emgm,"C100",null);
        String alert = "";
		String title = "";
		String extras = "";
		alert = new PushAlert(new Object[] { emgm.getImei() }, "power_low_key").toString();
		title = "power_low_title_key";
		int builder_id = INotification.ANDROID_MAKER_BATTARY;
		extras = String.format("imei=%s|",emgm.getImei());
		extras += String.format("type=%s|",INotification.NOTIFICATION_TYPE_BATTERY);
		extras += String.format("level=%d|",INotification.NOTIFICATION_LEVEL_LOW);
		extras += String.format("builder_id=%d|",INotification.ANDROID_MAKER_BATTARY);
		extras += "device=C100|";		
		Publish.push(emgm.getImei(), alert, title, builder_id, extras);
        
        result = MessageBuilder.buildReplyMessageContent(snBytes, generateResponse(new byte[]{Byte.parseByte(emgm.getType())},(byte) 0x86)) ;
        return result ;
    }

    private EmgM byte2Pojo(int index ,byte[] data){
        byte reserved = 0 ;
        String sn = parseSn(data,index) ;
        DeviceList deviceList = deviceListMapper.selectBySn(sn) ;
        Date deviceCurrentDate =   new Date((long)ConvertionUtil.bigEndBytesToInt(data, index+14)*1000) ;
        short signalStatus = ConvertionUtil.getShort(Arrays.copyOfRange(data, index+18, index+20), false) ;
        boolean gpsStatus = gpsStatus(signalStatus) ;
        boolean wifiStatus = wifiStatus(signalStatus,reserved) ;
        List<Cell> cells = parseCells(data,index+30);
        int alarmType = (int)data[index+86] ;
        
        EmgM entry = new EmgM();
        Date nowDate = new Date();
        entry.setImei(deviceList.getImei());
        entry.setEmgDate(deviceCurrentDate);
        entry.setEmgKey(yyMMddHHmmss.format(nowDate));
        entry.setEmgDetailKey(entry.getEmgKey() + entry.getImei());
        entry.setCreateDate(nowDate);
        entry.setUpdateDate(nowDate);
        entry.setType(String.valueOf(alarmType));
        entry.setIsvalid("Y");
        if(cells.size()>0){
            entry.setCell(cells.get(0));
            entry.setCells(cells.subList(1,cells.size()));
            entry.setCellidCount((short) (cells.size()-1));
        }
        setCell(entry, cells.get(0));
        List<Wifi> wifis = null ;
        if(wifiStatus){
            wifis = parseWifis(data, index+87);
            setWifiList(entry, wifis);
        }
        Gps locationData = null ;
        if(gpsStatus){
            locationData = parseGps(data, index+22);                                     //这里先用一个变量存储GPS数据，后续如果判断没有GPS数据，则会用Cell数据对此变量重新赋值
        }
        if (locationData == null || locationData.getLat() == null || locationData.getLng() == null 
                || !"NS".contains(locationData.getDirectionLat())
                || !"WE".contains(locationData.getDirectionLng())) {                                                    //如果手表上送过来的数据包本身不包含GPS数据，则根据手表上送的Cell数据，调取位置服务商API获取经纬度信息
            LocResult locresult = LocUtil.loc(entry.getImei(), entry.getImsi(), entry.getCell(), entry.getCells(), wifis);                //调取位置服务商API，通过Cell数据，换取经纬度信息
            if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {              //如果位置服务商API响应状态字和类型，标识有数据则更新GPS数据
                entry.setIsvalid("Y");
                entry.setMcellStatus("Y");
                entry.setWifiStatus("Y");
                LocDetailResult result = locresult.getResult();
                entry.setHpe((double)(result.getRadius()));
                String[] lngLat = result.getLocation().split(",");
                BigDecimal lng = new BigDecimal(lngLat[0]).setScale(6, RoundingMode.HALF_EVEN);
                    BigDecimal lat = new BigDecimal(lngLat[1]).setScale(6, RoundingMode.HALF_EVEN);
                    String address = LocUtil.reverseGeocoding(lat, lng);
                    locationData = new Gps(lat, lng, "N", "E", "Y");
                locationData.setAddress(address);
            } else {
                if (locresult != null) {
                    log.info("定位失败，status:{},info:{},result.type:{}", locresult.getStatus(), locresult.getInfo(),
                            locresult.getResult() == null ? "" : locresult.getResult().getType());
                } else {
                    log.info("定位结果返回NULL");
                }
            }
        } else {
            entry.setHpe(10.0);
            locationData = LocUtil.conver(locationData);                                                                               //坐标转换
            String address = LocUtil.reverseGeocoding(locationData.getLat(),locationData.getLng());                     //如果GPS经纬度信息存在，则调用位置服务商逆地理编码接口获取位置描述信息
            if(address != null){
                locationData.setAddress(address);
            }
        }
        if (locationData != null) {                                                                                     //这里判断locationData中如果有值则同时入库Gps经纬度字段、Cell经纬度字段、Wifi经纬度字段
            setGps(entry, locationData);
            entry.setLocStatus("Y");
            entry.setMcellLat(locationData.getLat());
            entry.setMcellLng(locationData.getLng());
            entry.setWifiLat(locationData.getLat());
            entry.setWifiLng(locationData.getLng());
            entry.setMcellAddress(locationData.getAddress());
            entry.setWifiAddress(locationData.getAddress());
        }
        return entry;
    }

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return true;
	}
}
