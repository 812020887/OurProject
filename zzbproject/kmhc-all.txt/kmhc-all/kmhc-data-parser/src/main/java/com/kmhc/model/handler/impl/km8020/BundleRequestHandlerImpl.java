package com.kmhc.model.handler.impl.km8020;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.BundleIMapper;
import com.kmhc.model.datacenter.model.BundleI;
import com.kmhc.model.handler.impl.PushAlert;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;
import com.kmhc.model.util.Publish;


@MessageCommand(type="KM8020",command="0x54302C")
public class BundleRequestHandlerImpl extends AbstractParentHandlerKM8020 {
	
	private static final Logger log = LoggerFactory.getLogger(BundleRequestHandlerImpl.class);
	private BundleIMapper bundleIMapper = (BundleIMapper) SpringBeanFacotry.getInstance().getBean("bundleIMapper");

	public BundleRequestHandlerImpl() {
		super(log);
	}
	
	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		log.info(new String(msg));
		String content[] = new String(msg).split(",");
		String imei = content[5];
		String comfirm = content[8];
		String account = content[9].split("\\|")[1];
		
//		log.debug("=======" + comfirm + "===========");
//		log.debug("=======" + account + "===========");

		String extras = "";
		int builder_id = INotification.ANDROID_MAKER_DEFAULT;
		String alert = null;
		String	title = "bind_notification_title_key";
		extras = String.format("imei=%s|",imei);
		extras += String.format("type=%s|",INotification.NOTIFICATION_TYPE_BU);
		extras += String.format("level=%d|",INotification.NOTIFICATION_LEVEL_LOW);
		extras += String.format("builder_id=%d|",builder_id);
		extras += String.format("device=%s|","KM8020");

		BundleI bundleI = bundleIMapper.selectByPrimaryKey(account, imei);
		if(comfirm.equals("1") && bundleI != null){
			bundleI.setAccept(1);
			bundleIMapper.updateByPrimaryKey(bundleI);
			alert = new PushAlert(new Object[]{imei}, "bind_accept_key").toString();
			extras += String.format("accpet=%d|",1);	
		}else{
			bundleIMapper.deleteByPrimaryKey(account, imei);
			alert = new PushAlert(new Object[]{imei}, "bind_refuse_key").toString();
			extras += String.format("accpet=%d|",0);
		}
		
		Publish.push(imei, alert, title, builder_id, extras);
		return null;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}

}
