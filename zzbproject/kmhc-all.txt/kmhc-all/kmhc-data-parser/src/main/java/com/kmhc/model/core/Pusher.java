/**
 * 
 */
package com.kmhc.model.core;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.util.HttpClientUtils;
import com.kmhc.model.util.SystemConfigUtil;

/**
 * 推送实现类，这个推送功能，是发往anglecare项目发布的接口服务那里，在anglecare项目里有具体的推送实现，
 * 本类使用简单的线程池来处理发送网络IO，这样是为了避免阻塞解析主线程
 * 
 * @author xl
 *
 */
public class Pusher implements Intercepter {

	private static final Logger log = LoggerFactory.getLogger(Pusher.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.kmhc.model.core.Interception#intercept(java.lang.String, byte[])
	 */
	@Override
	public Object exe(String protocolName, byte[] msg) {
		boolean flag = false;
		byte[] imeibyte = Arrays.copyOfRange(msg, 0, 8);
		String imei = TripleDesHelper.byte2hex(imeibyte, 8);
		imei = imei.substring(0, imei.length() - 1);

		String byte2hex = TripleDesHelper.byte2hex(msg, msg.length);
		log.info("【PUSH INTERCEPTIONS,command={}】收到数据：{}，PUSH处理中。。。", protocolName, byte2hex);

		String type = "";
		
		
		if(protocolName.equals("0x22")){
			type = "3";
			flag = true;
		}else if(protocolName.equals("0x23")){
			type = "5";
			flag = true;
		}else if(protocolName.equals("0x24")){
			type = "4";
			flag = true;
		}else if(protocolName.equals("0x25")){
			type = "6";
			flag = true;
		}else if(protocolName.equals("0x95")){
			if (msg[msg.length - 1] == 0x01) {
				switch (msg[13]) {
				case 0x01:
				case 0x08:
					type = "3";
					flag = true;
					break;
				case 0x00:
				case 0x16:
					type = "4";
					flag = true;
					break;
				default:
					flag = false;
				}
			} else if (msg[msg.length - 1] == 0x08) {
				switch (msg[13]) {
				case 0x01:
				case 0x08:
					type = "5";
					flag = true;
					break;
				case 0x00:
				case 0x16:
					type = "6";
					flag = true;
					break;
				default:
					flag = false;
				}
			}
		}else{
			flag = false;
		}
		if (flag) {
			push(type, imei);
			log.debug("【iemi:{}】紧急求救触发推送消息,type={}", imei, type);
		}
		return msg;
	}

	public Object push(final String url) {
		Context.interceptersService.execute(new Runnable() {
			@Override
			public void run() {
				HttpClientUtils.request(url);
			}

		});
		return null;
	}

	public Object push(String type, String imei) {
		String url = SystemConfigUtil.pushUrl;
		return push(url + "&imei=" + imei + "&type=" + type);
	}

	public static void main(String[] args) {
		new Pusher().exe(null, null);
	}
}
