package com.kmhc.model.handler.impl.km8010;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.CheckRIMapper;
import com.kmhc.model.datacenter.dao.CheckRMMapper;
import com.kmhc.model.datacenter.dao.EmgIMapper;
import com.kmhc.model.datacenter.dao.EmgMMapper;
import com.kmhc.model.datacenter.model.Cell;
import com.kmhc.model.datacenter.model.CheckRI;
import com.kmhc.model.datacenter.model.CheckRM;
import com.kmhc.model.datacenter.model.EmgI;
import com.kmhc.model.datacenter.model.EmgM;
import com.kmhc.model.datacenter.model.Gps;
import com.kmhc.model.datacenter.model.Wifi;
import com.kmhc.model.msg.ReplyMessageContent;

import com.kmhc.model.pojo.LocDetailResult;
import com.kmhc.model.pojo.LocResult;
import com.kmhc.model.util.BytesConvertionUtil;
import com.kmhc.model.util.LocUtil;
import com.kmhc.model.util.MessageBuilder;
import com.kmhc.model.util.StringUtil;


/**
 * Name: SosGpsHandlerImpl.java ProjectName: [kmhc-data-parser] Package:
 * [com.kmhc.model.handler.impl.km8010.SosGpsHandlerImpl.java] Description:
 * 解析处理紧急求救协议
 * 
 * @since JDK1.7
 * @see
 *
 * @author: xl
 * @date: 2015年11月19日 上午11:21:44
 *
 *        Update-User: @author Update-Time: Update-Remark:
 * 
 *        Check-User: Check-Time: Check-Remark:
 * 
 *        Company: kmhc Copyright: kmhc
 */
@MessageCommand(type = "KM8010", command = "0x95")
public class SosGpsHandlerImpl extends AbstractParentHandlerKM8010 {
	
	private static final Logger log = LoggerFactory.getLogger(SosGpsHandlerImpl.class);
	private String type = "95";
	public final SimpleDateFormat yyMMddHHmmss = new SimpleDateFormat("yyMMddHHmmss");

	private CheckRM checkRM = null;
	private CheckRI checkRI = null;

	public SosGpsHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg, type);

		ReplyMessageContent result = null; 
		int START_FRAME = 0;
		String phone = null;
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);
		String imei = StringUtil.toHexStringPadded(msg, START_FRAME, 8).substring(1);
		if (msg[msg.length - 9] == 0x01 || msg[msg.length - 9] == 0x08) {

			EmgM emgm = null;
			try {
				emgm = byte2Pojo(msg);
				// 入数据库Emg_M表
				HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
				indexMapPolishing.put(0, 1);
				Object[] objs = BytesConvertionUtil.generateProperty4KM8010(msg, new int[] { 8, 5, 1 , msg.length - 22, 8},
						new String[] { "IMEI", "Date", "Short", "IGNORE", "PHONENO" }, indexMapPolishing);
				phone = (String) objs[4];
				log.debug("--------------------------------");
				log.debug("===="+phone+"====");
				
				int op = 0;
				EmgMMapper emgMMapper = (EmgMMapper) SpringBeanFacotry.getInstance().getBean("emgMMapper");
				if(emgMMapper.selectByPrimaryKey(emgm.getEmgKey(), emgm.getImei())!= null){
					op = emgMMapper.updateByPrimaryKey(emgm);
				}else{
					op = emgMMapper.insertSelective(emgm);
				}
				if (op > 0) {
					result =  MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_SUCCESS_KM8010,(byte) -107));
					
				}
				
				if (emgm.getCells() != null && emgm.getCells().size() > 0) {
					List<EmgI> emgIList = getEmgIList(emgm.getCells(), emgm.getEmgDetailKey(), emgm.getCreateDate(),
							emgm.getUpdateDate());
					EmgIMapper emgIMapper = (EmgIMapper) SpringBeanFacotry.getInstance().getBean("emgIMapper");
					emgIMapper.insertList(emgIList);
				}
				
				sendNotification(emgm,"KM8010", phone);
				
			} catch (Exception e) {
				log.error("异常信息：", e);
     			result = MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) -107));
			}
		} else if (msg[msg.length - 1] == 0x02 || msg[msg.length - 1] == 0x04){
			CheckRMMapper checkRMMapper = (CheckRMMapper) SpringBeanFacotry.getInstance().getBean("checkRMMapper");
			CheckRIMapper checkRIMapper = (CheckRIMapper) SpringBeanFacotry.getInstance().getBean("checkRIMapper");
			checkRM = checkRMMapper.selectByPrimaryKey(imei);
			int successRMMop = 0;
			int successRIMop = 0;
			if (checkRM == null)
				checkRM = baseCheckRM(imei);

			if (checkRM.getBatchDetailKey() == null || checkRM.getBatchDetailKey().equals("")) {
				checkRM.setBatchDetailKey(yyMMddHHmmss.format(new Date()));
				checkRI = baseCheckRI(imei, checkRM);
			} else {
				checkRI = checkRIMapper.selectByPrimaryKey(checkRM.getBatchDetailKey(), imei);
			}

			try {
				if(checkByte2Pojo(msg)){
					if (checkRMMapper.selectByPrimaryKey(imei) != null)
						successRMMop = checkRMMapper.updateByPrimaryKey(checkRM);
					else
						successRMMop = checkRMMapper.insert(checkRM);
	
					if (checkRIMapper.selectByPrimaryKey(checkRI.getBatchDetailKey(), imei) != null)
						successRIMop = checkRIMapper.updateByPrimaryKey(checkRI);
					else
						successRIMop = checkRIMapper.insert(checkRI);
	
					log.debug(checkRI.getBatchDetailKey());
					if (successRMMop > 0 && successRIMop > 0)
						result =  MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_SUCCESS_KM8010,(byte) -107));
					else
						result = MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) -107));
					
				}else{
					result = MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) -107));
				}
			} catch (Exception e) {
				log.error("【type=KM8010,command=0x{}】解码失败", type);
				log.error("异常信息：", e);
				result = MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) -107));
			} finally {
				checkRM = null;
				checkRI = null;
			}

		}else {
			result = MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(ACK_ERROR_KM8010,(byte) -107));
		}
		return result;
	}

	public boolean checkByte2Pojo(byte[] data) throws Exception {
		int index = 0;
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		Object[] objs = BytesConvertionUtil.generateProperty4KM8010(data, new int[] { 8, 5, 1 , data.length - 22, 8},
				new String[] { "IMEI", "Date", "Short", "IGNORE", "PHONENO" }, indexMapPolishing);

		short locationMethod = (short) objs[2];
		Gps gps = null;
		LocResult locresult = null;
		String imei = (String) objs[0];
		if (locationMethod == 0) {
			gps = parseGps(data, index + 14);
			gps = LocUtil.conver(gps);
			gps.setAddress(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
		} else if (locationMethod == 4) {
		   gps = parseGps(data, index + 14);
			gps = LocUtil.conver(gps);
			gps.setAddress(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
			Cell cell = parseCell(data, index + 24, null);
			List<Cell> cells = parseCells(data, index + 32, cell.getMcc());
			 locresult = LocUtil.loc(imei, null, cell, cells, null);
		}else if (locationMethod == 1) {
			Cell cell = parseCell(data, index + 14, null);
			List<Cell> cells = parseCells(data, index + 22, cell.getMcc());
		    locresult = LocUtil.loc(imei, null, cell, cells, null);
		} else if (locationMethod == 8) { //目前沒GPS
			Cell cell = parseCell(data, index + 14, null);
			List<Cell> cells = parseCells(data, index + 22, cell.getMcc());
			List<Wifi> wifis = parseWifiList(data, index + 23 + cells.size()*6);
			 locresult = LocUtil.loc(imei, null, cell, cells, wifis);
		}else if (locationMethod == 0x16) {
		    gps = parseGps(data, index + 14);
			gps = LocUtil.conver(gps);
			gps.setAddress(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
			log.debug(gps.getAddress());
			Cell cell = parseCell(data, index + 24, null);
			List<Cell> cells = parseCells(data, index + 32, cell.getMcc());
			List<Wifi> wifis = parseWifiList(data, index + 33 + cells.size()*6);
		    locresult = LocUtil.loc(imei, null, cell, cells, wifis);
//			if(gps.getAddress() != null && !gps.getAddress().equals(""))emgm = setGps(emgm, gps);
		}
		
		if (checkRM.getOnLineStatus() == 0 && data[data.length - 1] == 0x02) {
			checkRI.setCheckInDate((Date) objs[1]);
			setInLocation(checkRI, gps);
			setInLocResult(checkRI, locresult);
			checkRM.setOnLineStatus(1);
			checkRM.setUpdateDate(new Date());
			return true;
		} else if(checkRM.getOnLineStatus() == 1 && data[data.length - 1] == 0x04){
			checkRI.setCheckOutDate((Date) objs[1]);
			checkRI.setVal(
					(int)((checkRI.getCheckOutDate().getTime() - checkRI.getCheckInDate().getTime()) / 60000) );
			setOutLocation(checkRI, gps);
			setOutLocResult(checkRI, locresult);
			checkRM.setCurrentVal(checkRM.getCurrentVal() + checkRI.getVal());
			checkRM.setOnLineStatus(0);
			checkRM.setBatchDetailKey(null);
			checkRM.setUpdateDate(new Date());
			return true;
		}
		return false;
	}

	public EmgM byte2Pojo(byte[] data) throws Exception {
		int index = 0;
		HashMap<Integer, Integer> indexMapPolishing = new HashMap<Integer, Integer>();
		indexMapPolishing.put(0, 1);
		Object[] objs = BytesConvertionUtil.generateProperty4KM8010(data, new int[] { 8, 5, 1 , data.length - 22, 8},
				new String[] { "IMEI", "Date", "Short", "IGNORE", "PHONENO" }, indexMapPolishing);
		EmgM emgm = baseEmgm(objs);
		short locationMethod = (short) objs[2];
		if (locationMethod == 0) {
			Gps gps = parseGps(data, index + 14);
			gps = LocUtil.conver(gps);
			gps.setAddress(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
			emgm = setGps(emgm, gps);
			log.debug("===" + (data[data.length - 9] == 0x01 ? "24" : "25") + "==="); //sos,fall
			emgm.setType(data[data.length - 9] == 0x01 ? "24" : "25");
		} else if (locationMethod == 4) {
			Gps gps = parseGps(data, index + 14);
			gps = LocUtil.conver(gps);
			gps.setAddress(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
			emgm = setGps(emgm, gps);
			Cell cell = parseCell(data, index + 24, null);
			List<Cell> cells = parseCells(data, index + 32, cell.getMcc());
			emgm = setCell(emgm, cell);
			emgm.setCell(cell);
			emgm.setCells(cells);
			LocResult locresult = LocUtil.loc(emgm.getImei(), null, cell, cells, null);
			log.debug("===" + (data[data.length - 9] == 0x01 ? "22" : "23") + "===");//sos,fall
			emgm.setType(data[data.length - 9] == 0x01 ? "22" : "23");
			emgm = setLocResult(emgm, locresult);
		}else if (locationMethod == 1) {
			Cell cell = parseCell(data, index + 14, null);
			List<Cell> cells = parseCells(data, index + 22, cell.getMcc());
			emgm = setCell(emgm, cell);
			emgm.setCell(cell);
			emgm.setCells(cells);
			LocResult locresult = LocUtil.loc(emgm.getImei(), null, cell, cells, null);
			log.debug("===" + (data[data.length - 9] == 0x01 ? "22" : "23") + "===");//sos,fall
			emgm.setType(data[data.length - 9] == 0x01 ? "22" : "23");
			emgm = setLocResult(emgm, locresult);
		} else if (locationMethod == 8) { //目前沒GPS
			Cell cell = parseCell(data, index + 14, null);
			List<Cell> cells = parseCells(data, index + 22, cell.getMcc());
			List<Wifi> wifis = parseWifiList(data, index + 23 + cells.size()*6);
			emgm = setCell(emgm, cell);
			setWifiList(emgm,wifis);
			emgm.setCell(cell);
			emgm.setCells(cells);
			LocResult locresult = LocUtil.loc(emgm.getImei(), null, cell, cells, wifis);
			log.debug("===" + (data[data.length - 9] == 0x01 ? "22" : "23") + "===");//sos,fall
			emgm.setType(data[data.length - 9] == 0x01 ? "22" : "23");
			emgm = setLocResult(emgm, locresult);
		}else if (locationMethod == 0x16) {
			Gps gps = parseGps(data, index + 14);
			gps = LocUtil.conver(gps);
			log.debug(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
			gps.setAddress(LocUtil.reverseGeocoding(gps.getLat(), gps.getLng()));
			emgm = setGps(emgm, gps);
			Cell cell = parseCell(data, index + 24, null);
			List<Cell> cells = parseCells(data, index + 32, cell.getMcc());
			List<Wifi> wifis = parseWifiList(data, index + 33 + cells.size()*6);
			emgm = setCell(emgm, cell);
			setWifiList(emgm,wifis);
			emgm.setCell(cell);
			emgm.setCells(cells);
			LocResult locresult = LocUtil.loc(emgm.getImei(), null, cell, cells, wifis);
			log.debug("===" + (data[data.length - 9] == 0x01 ? "24" : "25") + "==="); //sos,fall
			emgm.setType(data[data.length - 9] == 0x01 ? "24" : "25");
			emgm = setLocResult(emgm, locresult);
		}
		return emgm;
	}

	private CheckRI setInLocResult(CheckRI checkRI, LocResult locresult) {
		if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {
			LocDetailResult result = locresult.getResult();
			String[] lngLat = result.getLocation().split(",");
			BigDecimal lng = new BigDecimal(lngLat[0]).setScale(6, RoundingMode.HALF_EVEN);
            BigDecimal lat = new BigDecimal(lngLat[1]).setScale(6, RoundingMode.HALF_EVEN);
            String address = LocUtil.reverseGeocoding(lat, lng);
			checkRI.setInGpsLat(lat);
			checkRI.setInGpsLng(lng);
			checkRI.setInGpsEwLng("E");
			checkRI.setInGpsNsLat("N");
			checkRI.setInAddress(address);
			checkRI.setInHpe((double)result.getRadius());
			checkRI.setInIsvalid("Y");
			checkRI.setInLocStatus("Y");
			checkRI.setUpdateDate(new Date());
		} else {
			checkRI.setInIsvalid("N");
			checkRI.setInLocStatus("N");
			if (locresult != null) {
				log.info("【type=KM8010,command=0x{}】定位失败，status:{},info:{},result.type:{}", type, locresult.getStatus(),
						locresult.getInfo(), locresult.getResult() == null ? "" : locresult.getResult().getType());
			} else {
				log.info("【type=KM8010,command=0x{}】定位结果返回NULL", type);
			}
		}
		return checkRI;
	}

	private CheckRI setOutLocResult(CheckRI checkRI, LocResult locresult) {
		if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {
			LocDetailResult result = locresult.getResult();
			String[] lngLat = result.getLocation().split(",");
			BigDecimal lng = new BigDecimal(lngLat[0]).setScale(6, RoundingMode.HALF_EVEN);
            BigDecimal lat = new BigDecimal(lngLat[1]).setScale(6, RoundingMode.HALF_EVEN);
            String address = LocUtil.reverseGeocoding(lat, lng);
            checkRI.setOutGpsLat(lat);
			checkRI.setOutGpsLng(lng);
			checkRI.setOutGpsEwLng("E");
			checkRI.setOutGpsNsLat("N");
			checkRI.setOutAddress(address);
			checkRI.setOutHpe((double)result.getRadius());
			checkRI.setOutIsvalid("Y");
			checkRI.setOutLocStatus("Y");
			checkRI.setUpdateDate(new Date());
		} else {
			if (locresult != null) {
				log.info("【type=KM8010,command=0x{}】定位失败，status:{},info:{},result.type:{}", type, locresult.getStatus(),
						locresult.getInfo(), locresult.getResult() == null ? "" : locresult.getResult().getType());
			} else {
				log.info("【type=KM8010,command=0x{}】定位结果返回NULL", type);
			}
		}
		return checkRI;
	}

	private EmgM setLocResult(EmgM emgm, LocResult locresult) {
		if (locresult != null && locresult.getStatus() == 1 && locresult.getResult().getType() != 0) {
			emgm.setIsvalid("Y");
			emgm.setLocStatus("Y");
			emgm.setMcellStatus("Y");
			emgm.setWifiStatus("Y");
			LocDetailResult result = locresult.getResult();
			String[] lngLat = result.getLocation().split(",");
			BigDecimal lng = new BigDecimal(lngLat[0]).setScale(6, RoundingMode.HALF_EVEN);
            BigDecimal lat = new BigDecimal(lngLat[1]).setScale(6, RoundingMode.HALF_EVEN);
            String address = LocUtil.reverseGeocoding(lat, lng);
            emgm.setGpsLng(lng);
			emgm.setGpsLat(lat);
			emgm.setAddress(address);
			emgm.setGpsNsLat("N");
			emgm.setGpsEwLng("E");
			emgm.setMcellLat(lat);
			emgm.setMcellLng(lng);
			emgm.setWifiLat(lat);
			emgm.setWifiLng(lng);
			emgm.setWifiAddress(address);
			emgm.setMcellAddress(address);
			emgm.setHpe((double) result.getRadius());
		} else {
			if (locresult != null) {
				log.info("【type=KM8010,command=0x{}】定位失败，status:{},info:{},result.type:{}", type, locresult.getStatus(),
						locresult.getInfo(), locresult.getResult() == null ? "" : locresult.getResult().getType());
			} else {
				log.info("【type=KM8010,command=0x{}】定位结果返回NULL", type);
			}
		}
		return emgm;
	}

	private CheckRI setInLocation(CheckRI checkRI, Gps gps) {
		if (gps != null) {
			checkRI.setInGpsLat(gps.getLat());
			checkRI.setInGpsLng(gps.getLng());
			checkRI.setInGpsEwLng(gps.getDirectionLng());
			checkRI.setInGpsNsLat(gps.getDirectionLat());
			checkRI.setInIsvalid(gps.getIsValid());
			checkRI.setInAddress(gps.getAddress());
			checkRI.setInHpe(10.0);
			checkRI.setInLocStatus("Y");
			checkRI.setUpdateDate(new Date());
		}
		return checkRI;
	}

	private CheckRI setOutLocation(CheckRI checkRI, Gps gps) {
		if (gps != null) {
			checkRI.setOutGpsLat(gps.getLat());
			checkRI.setOutGpsLng(gps.getLng());
			checkRI.setOutGpsEwLng(gps.getDirectionLng());
			checkRI.setOutGpsNsLat(gps.getDirectionLat());
			checkRI.setOutIsvalid(gps.getIsValid());
			checkRI.setOutAddress(gps.getAddress());
			checkRI.setOutHpe(10.0);
			checkRI.setOutLocStatus("Y");
			checkRI.setUpdateDate(new Date());
		}
		return checkRI;
	}

	private CheckRM baseCheckRM(String imei) {
		CheckRM checkRM = new CheckRM();
		Date nowDate = new Date();
		checkRM.setImei(imei);
		checkRM.setImsi("");
		checkRM.setCurrentVal(0);
		checkRM.setOnLineStatus(0);
		checkRM.setCreateDate(nowDate);
		checkRM.setUpdateDate(nowDate);
		return checkRM;
	}

	private CheckRI baseCheckRI(String imei, CheckRM checkRM) {
		CheckRI checkRI = new CheckRI();
		Date nowDate = new Date();
		checkRI.setImei(imei);
		checkRI.setBatchDetailKey(checkRM.getBatchDetailKey());
		checkRI.setVal(0);
		checkRI.setCreateDate(nowDate);
		checkRI.setUpdateDate(nowDate);
		return checkRI;
	}

	private EmgM baseEmgm(Object[] objs) {
		EmgM emgm = new EmgM();
		Date nowDate = new Date();
		emgm.setImei((String) objs[0]);
		emgm.setEmgDate((Date) objs[1]);
		emgm.setEmgKey(yyMMddHHmmss.format(new Date()));
		emgm.setEmgDetailKey(emgm.getEmgKey() + emgm.getImei());
		emgm.setCreateDate(nowDate);
		emgm.setUpdateDate(nowDate);
		return emgm;
	}

	protected void writeDebugLog(byte[] msg, String type) {
		String byte2hex = TripleDesHelper.byte2hex(msg, msg.length);
		log.debug("【type=KM8010,command=0x{}】收到数据：{}，处理中。。。", type, byte2hex);
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
