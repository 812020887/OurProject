/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: czx
 *               Date: 2015年11月11日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8000;


import java.util.ArrayList;
import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.handler.impl.AbstractHandler;
import com.kmhc.model.msg.ReplyMessageContent;

/**
 * Name: GDSynTimeHandlerImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.GDSynTimeHandlerImpl.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: czx
 * @date: 2015年11月11日 下午2:11:46
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */

@MessageCommand(type="KM8000",command="0x7A")
public class SynTimeHandlerImpl  extends AbstractHandler  {
	
	public static final Logger log = LoggerFactory.getLogger(SynTimeHandlerImpl.class);
		 

	@Override 
	public ReplyMessageContent handleMessage(byte[] msg) {
		byte[] imeiBytes = parseImeiOrImsiBytes_KM8000(msg, 0);
		String imei = null;
		ArrayList<byte[]> remsgs = new ArrayList<byte[]>();
		try {
			imei = parseImeiOrImsi_KM8000(msg, 0);

			// String imsi = parseImeiOrImsi_KM8000(msg,11);

			Calendar cal = getCalendar();
			byte[] reMsg = constructReMsg(cal);
			remsgs.add(reMsg);
			remsgs.add(AbstractHandler.ACK_SUCCESS_KM8000);
		
		} catch (Exception e) {
			log.error("同步时间出错.", e);
			byte[] reMsg = AbstractHandler.ACK_ERROR_KM8000;
			remsgs.add(reMsg);
		}	
		
		ReplyMessageContent replyMessageContent = null;
		if(imei != null && remsgs.size() > 0 ){
			replyMessageContent = new ReplyMessageContent(imeiBytes,remsgs);
		}
		
		return replyMessageContent;
	}
	
	/**
	 * 获取标准的日期时间
	 * @return
	 */
	public Calendar getCalendar() {
		// 取得本地时间
		Calendar cal = java.util.Calendar.getInstance();
		// 取得时间偏移量
		int zoneOffset = cal.get(java.util.Calendar.ZONE_OFFSET);
		// 取得夏令时差
		int dstOffset = cal.get(java.util.Calendar.DST_OFFSET);
		// 从本地时间里扣除这些差量，即可以取得UTC时间
		cal.add(java.util.Calendar.MILLISECOND, -(zoneOffset + dstOffset));
		
		//KM8000原来的计算方式
	    //Date currentDate = new Date();
		//SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		//sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		//String dateStr = sdf.format(currentDate);
		
		return cal;
	}
	
	/**
	 * 根据时间生成返回的消息
	 * @param cal 协调世界时(UTC) 
	 * @return
	 */
	public byte[] constructReMsg(Calendar cal){

	    byte[] reMsg = new byte[10];
	    int offset = 0;  
    
	    reMsg[offset+0]= Integer.valueOf("00", 16).byteValue(); 
	    reMsg[offset+1]= Integer.valueOf("10", 16).byteValue(); 
	    reMsg[offset+2]= Integer.valueOf("7a", 16).byteValue();
	    
	    //计算时间
	    String year = Integer.toHexString( cal.get(Calendar.YEAR) ); 
	    String head=year.substring(0,year.length()-2);
	    String rear=year.substring(year.length()-2,year.length());
	    reMsg[offset+3]= Integer.valueOf(head, 16).byteValue();
	    reMsg[offset+4]= Integer.valueOf(rear, 16).byteValue();
	    
	    String month = Integer.toHexString(cal.get(Calendar.MONTH)+1);
	    reMsg[offset+5]= Integer.valueOf(month, 16).byteValue();
	    
	    String day = Integer.toHexString(cal.get(Calendar.DAY_OF_MONTH));
	    reMsg[offset+6]= Integer.valueOf(day, 16).byteValue();
	    
	    String hour = Integer.toHexString(cal.get(Calendar.HOUR_OF_DAY));
	    reMsg[offset+7]= Integer.valueOf(hour, 16).byteValue();
	    
	    String minute = Integer.toHexString(cal.get(Calendar.MINUTE));
	    reMsg[offset+8]= Integer.valueOf(minute, 16).byteValue();
	    
	    String second = Integer.toHexString(cal.get(Calendar.SECOND));
	    reMsg[offset+9]= Integer.valueOf(second, 16).byteValue();
	    
	    return reMsg;
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
