/*    */ package com.kmhc.model.pojo;
/*    */ 
/*    */ public class WiFi
/*    */ {
/* 11 */   private String mac = "000000000000";
/* 12 */   private int signalLevel = 0;
/* 13 */   private int channel = 0;
/* 14 */   private int signal_dB = 0;
/*    */ 
/*    */   public String getMac()
/*    */   {
/* 22 */     return this.mac; }
/*    */ 
/*    */   public void setMac(String mac) {
/* 25 */     this.mac = mac; }
/*    */ 
/*    */   public int getSignalLevel() {
/* 28 */     return this.signalLevel; }
/*    */ 
/*    */   public void setSignalLevel(int signalLevel) {
/* 31 */     this.signalLevel = signalLevel; }
/*    */ 
/*    */   public int getChannel() {
/* 34 */     return this.channel; }
/*    */ 
/*    */   public void setChannel(int channel) {
/* 37 */     this.channel = channel; }
/*    */ 
/*    */   public int getSignal_dB() {
/* 40 */     return this.signal_dB; }
/*    */ 
/*    */   public void setSignal_dB(int signal_dB) {
/* 43 */     this.signal_dB = signal_dB;
/*    */   }
/*    */ }

/* Location:           E:\doc\康美手表Server\Guider\台北蓋德_安裝光碟公版_台灣20140515\2.Gateway Program\icare2\WEB-INF\classes\
 * Qualified Name:     com.paralucent.gateway2.model.WiFi
 * JD-Core Version:    0.5.3
 */