package com.kmhc.model.handler.impl.km8010;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.codec.Charsets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.DebitMMapper;
import com.kmhc.model.datacenter.model.DebitM;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.MessageBuilder;

@MessageCommand(type="KM8010",command="0xF0")
public class DebitHandlerImpl extends AbstractParentHandlerKM8010 {

	private String type = "F0";
	private static final Logger log = LoggerFactory.getLogger(DebitHandlerImpl.class);
	private DebitMMapper debitMMapper = (DebitMMapper) SpringBeanFacotry.getInstance().getBean("debitMMapper");
	
	public DebitHandlerImpl() {
		super(log);
	}

	@Override
	public ReplyMessageContent handleMessage(byte[] msg) {
		writeDebugLog(msg,type);
		byte[] imeibytes = parseImeiBytes_KM8010(msg, 0);
		String imei = parseImei_KM8010(msg, 0);
		DebitM debitM = debitMMapper.selectByPrimaryKey(imei);
		
		byte[] content = ACK_ERROR_KM8010;
		String nameStr = "";
		int val = 0;
		Date updateDate = new Date();
		if(debitM != null){
			if(debitM.getName() != null)nameStr = debitM.getName();
			if(debitM.getCurrentVal() != null)val = debitM.getCurrentVal();
			updateDate = debitM.getUpdateDate();
		}
		
		byte[] name = nameStr.getBytes(Charsets.UTF_8);
		byte[] date = new byte[5];
		byte[] val1 = TripleDesHelper.ParserInt(val);
		byte[] val2 = TripleDesHelper.ParserInt(0);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd-HH-mm");
		sdf.setTimeZone(TimeZone.getTimeZone("GMT+8"));
		String tmp[] = sdf.format(updateDate).split("-");
		
		int year = Integer.valueOf(tmp[0]);
		int month = Integer.valueOf(tmp[1]);
		int day = Integer.valueOf(tmp[2]);
		int hour = Integer.valueOf(tmp[3]);
		int min = Integer.valueOf(tmp[4]);

		date[0] = (byte) year;
		date[1] = (byte) month;
		date[2] = (byte) day;
		date[3] = (byte) hour;
		date[4] = (byte) min;
		

		int contidx = 0;
		int ret_len = name.length + date.length + val1.length + val2.length;
		content = new byte[ret_len];

		System.arraycopy(name, 0, content, contidx, name.length);
		contidx += name.length;
		
		System.arraycopy(date, 0, content, contidx, date.length);
		contidx += date.length;

		System.arraycopy(val1, 0, content, contidx, val1.length);
		contidx += val1.length;

		System.arraycopy(val2, 0, content, contidx, val2.length);
		contidx += val2.length;
		
		return MessageBuilder.buildReplyMessageContent(imeibytes, generateResponse(content,(byte) 0xF0));
	}

	@Override
	public boolean handleMessage(String json) {
		// TODO Auto-generated method stub
		return false;
	}
}
