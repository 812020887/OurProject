/**
 * Copyright (C) 2016 kmhc-data-parser Project
 * Author: Chris
 * Date: 2016年7月22日
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8020;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.datacenter.dao.PsrSettingMapper;
import com.kmhc.model.datacenter.dao.ServerActionHisMapper;
import com.kmhc.model.datacenter.model.PsrSetting;
import com.kmhc.model.datacenter.model.ServerActionHis;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.notification.INotification;

/**
 * Name: WarnSettingConfirmImpl.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8020.WarnSettingConfirmImpl.java]
 * Description: TODO  
 *
 * @since JDK1.7
 * @see
 *
 * Author: @author: Chris
 * Date: 2016年7月22日 下午4:52:15
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 *
 * Check-User:
 * Check-Time:
 * Check-Remark:
 *
 * Company: kmy
 * Copyright: kmy
 */

//T95
@MessageCommand(type = "KM8020", command = "0x543935")
public class WarnSettingConfirmImpl2 extends AbstractParentHandlerKM8020 {

    private ServerActionHisMapper serverActionHisMapper = (ServerActionHisMapper) SpringBeanFacotry.getInstance().getBean("serverActionHisMapper");
    private PsrSettingMapper psrSettingMapper = (PsrSettingMapper) SpringBeanFacotry.getInstance().getBean("psrSettingMapper");
    private static final Logger log = LoggerFactory.getLogger(WarnSettingConfirmImpl2.class);


    /**
     * @Title: WarnSettingConfirmImpl
     * @Description: TODO
     * @param @param log         
     * @throws
     */
    public WarnSettingConfirmImpl2() {
        super(log);
    }

    @Override
    @Transactional
    public ReplyMessageContent handleMessage(byte[] msg) {
        log.info(new String(msg));
        //[a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00, 355372020827303, S83,0,|have a walk|,201112151830]

        String content[] = new String(msg).split(",");
        String imei = content[5];
        String uid = content[0];
        String protocol = "S95";
        String tzStr = "GMT+" + content[6];
        TimeZone tz = TimeZone.getTimeZone(tzStr);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        sdf.setTimeZone(tz);
        String yyyyMMdd = sdf.format(new Date());
        ServerActionHis sah = serverActionHisMapper.selectByPrimaryKey(uid, imei, protocol);

        if (sah != null) {
            log.debug("=======================================");
            log.debug(sah.getContent());
            //.0.0,157048f9fb3000a,1,abcd,2016-09-07 20:11:43,865946021009624,S95,0000,0,|試試類型0|,01|20160930123000
            //0001,0,|試試類型0|,01|20160930123000
            String[] contents = sah.getContent().split(",");

            String[] settingContent = Arrays.copyOfRange(contents, 7, contents.length);
            PsrSetting setting = new PsrSetting();

            if (settingContent[1].equals("0")) {
                String[] settingTime = settingContent[3].split("\\|");
                setting.setsYear(settingTime[1].substring(0, 4));
                setting.setsMon(settingTime[1].substring(4, 6));
                setting.setsDay(settingTime[1].substring(6, 8));
                setting.setsHour(settingTime[1].substring(8, 10));
                setting.setsMin(settingTime[1].substring(10, 12));

            } else if (settingContent[1].equals("1")) {
                String[] settingTime = settingContent[3].split("\\|");
                setting.setsYear(yyyyMMdd.substring(0, 4));
                setting.setsMon(yyyyMMdd.substring(4, 6));
                setting.setsDay(yyyyMMdd.substring(6, 8));
                setting.setsHour(settingTime[1].substring(0, 2));
                setting.setsMin(settingTime[1].substring(2, 4));
            } else {
                String[] settingTime = settingContent[3].split("\\|");
                setting.setsYear(yyyyMMdd.substring(0, 4));
                setting.setsMon(yyyyMMdd.substring(4, 6));
                setting.setsDay(yyyyMMdd.substring(6, 8));
                setting.setsHour(settingTime[2].substring(0, 2));
                setting.setsMin(settingTime[2].substring(2, 4));
            }

            if (settingContent[1].equals("1")) {
                setting.setT1Hex("1");
                setting.setT2Hex("1");
                setting.setT3Hex("1");
                setting.setT4Hex("1");
                setting.setT5Hex("1");
                setting.setT6Hex("1");
                setting.setT7Hex("1");
            } else if (settingContent[1].equals("0")) {
                setting.setT1Hex("0");
                setting.setT2Hex("0");
                setting.setT3Hex("0");
                setting.setT4Hex("0");
                setting.setT5Hex("0");
                setting.setT6Hex("0");
                setting.setT7Hex("0");
            } else {

                String[] settingTime = settingContent[3].split("\\|");
                int weekSetting = Integer.parseInt(settingTime[1]);
                String weekSettingStr = Integer.toBinaryString(weekSetting);
                weekSettingStr = "0000000".substring(0, 7 - weekSettingStr.length()) + weekSettingStr;
                setting.setT6Hex(weekSettingStr.substring(0, 1));
                setting.setT5Hex(weekSettingStr.substring(1, 2));
                setting.setT4Hex(weekSettingStr.substring(2, 3));
                setting.setT3Hex(weekSettingStr.substring(3, 4));
                setting.setT2Hex(weekSettingStr.substring(4, 5));
                setting.setT1Hex(weekSettingStr.substring(5, 6));
                setting.setT7Hex(weekSettingStr.substring(6, 7));

            }
            String team = settingContent[0].substring(0, 2);
            String type = settingContent[0].substring(2, 4);
            setting.setsType(type);
            setting.setsTeam(team);
            setting.setAttribute1(settingContent[2].substring(1, settingContent[2].length() - 1));

            setting.setIsvalid("Y");
            setting.setsImei(imei);
            setting.setsUpdatedate(new Date());

            PsrSetting pset = psrSettingMapper.selectSingleByTeamAndType(imei, team, type);
            if (pset != null) {
                setting.setsId(pset.getsId());
                psrSettingMapper.updateByPrimaryKey(setting);
            } else {
                psrSettingMapper.insert(setting);
            }

            serverActionHisMapper.deleteByPrimaryKey(sah.getUid(), sah.getImei(), protocol);
            pushSettingFinish(imei, INotification.NOTIFICATION_TYPE_SETTING_REMIND);
        }

        return null;
    }

    @Override
    public boolean handleMessage(String json) {
        return false;
    }


}
