package com.kmhc.model.pojo;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.kmhc.framework.util.PacketUtil;
/*     */ 
/*     */ public class PacketTypePRWifi
/*     */ {
/*     */   private String batchKey;
/*     */   private String imei;
/*     */   private String imsi;
/*  15 */   private String pr_ver = "00";
/*  16 */   private int checksumSYS = 0;
/*  17 */   private int checksumPER = 0;
/*  18 */   private int prCount = 0;
/*  19 */   private List<PeriodicReadingsWifi> prList = new ArrayList<PeriodicReadingsWifi>();
/*     */ 
/*  21 */   private boolean isLowBattery = false;
/*  22 */   private PeriodicReadingsWifi lowBatteryPR = null;
/*     */ 
/*     */   public PacketTypePRWifi(byte[] dataBuffer, String imeiCode, String imsi)
/*     */   {
/*  30 */     if (this.prCount == 0) {
/*  32 */       this.imei = imeiCode;
/*  33 */       this.imsi = imsi;
/*  34 */       int offset = 16;
/*  35 */       this.pr_ver = Integer.toString(PacketUtil.unsignedShort(dataBuffer[offset]));
/*  36 */       this.checksumSYS = PacketUtil.toShort(dataBuffer[(offset + 1)], dataBuffer[(offset + 2)]);
/*  37 */       this.checksumPER = PacketUtil.toShort(dataBuffer[(offset + 3)], dataBuffer[(offset + 4)]);
/*  38 */       this.prCount = PacketUtil.unsignedShort(dataBuffer[(offset + 5)]);
/*  39 */       System.out.println("====> Process PR packet =[" + this.imei + " : " + this.imsi + ":ver " + this.pr_ver + ":sys " + this.checksumSYS + ":per " + this.checksumPER + ":count " + this.prCount + "]");
/*     */ 
/*  41 */       Date currentDate = new Date();
/*  42 */       SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmss");
/*  43 */       String batchKey = sdf.format(currentDate);
/*     */ 
/*  45 */       this.batchKey = batchKey;
/*     */ 
/*  47 */       offset += 6;
/*  48 */       for (int i = 0; i < this.prCount; ++i)
/*     */       {
/*  50 */         byte[] rss = { -86 };
/*  51 */         byte dmap1 = dataBuffer[(offset + 20)];
/*  52 */         byte dmap2 = dataBuffer[(offset + 21)];
/*     */ 
/*  54 */         System.out.println("====> Process PR 0x03 packet offset=[" + offset + "][" + dmap1 + " : " + dmap2 + "] rss Hex=0x" + PacketUtil.toHexString("", rss, rss.length) + " int [" + rss[0] + "]");
/*  55 */         boolean[] dmArray = new boolean[8];
/*  56 */         int prLength = 22;
/*  57 */         if ((byte)(0xFFFFFF80 & dmap1) == -128) { dmArray[1] = true; prLength += 3; System.out.println("====> Temp 溫度"); }
/*  58 */         if ((byte)(0x40 & dmap1) == 64) { dmArray[2] = true; prLength += 3; System.out.println("====> Pa 氣壓"); }
/*  59 */         if ((byte)(0x20 & dmap1) == 32) { dmArray[3] = true; prLength += 10; System.out.println("====> GPS");
/*     */         }
/*     */ 
/*  62 */         if ((byte)(0x10 & dmap1) == 16) {
/*  63 */           dmArray[4] = true;
/*  64 */           int cellCount = dataBuffer[(offset + prLength)];
/*  65 */           prLength += 11 * cellCount + 1;
/*  66 */           System.out.println("====> Cell, count=" + cellCount);
/*     */         }
/*     */ 
/*  70 */         if ((byte)(0x8 & dmap1) == 8) {
/*  71 */           dmArray[5] = true;
/*  72 */           int wifiCount = dataBuffer[(offset + prLength)];
/*  73 */           prLength += 9 * wifiCount + 1;
/*  74 */           System.out.println("====> WIFI, count=" + wifiCount);
/*     */         }
/*     */ 
/*  77 */         if ((byte)(0x4 & dmap1) == 4) { dmArray[6] = true; prLength += 4; System.out.println("====> G Sensor"); }
/*  78 */         if ((byte)(0x2 & dmap1) == 2) { dmArray[7] = true; prLength += 4; System.out.println("====> GYRO Sensor");
/*     */         }
/*  80 */         PeriodicReadingsWifi pr = new PeriodicReadingsWifi(dataBuffer, offset, prLength, dmArray);
/*  81 */         offset += prLength;
/*     */ 
/*  83 */         System.out.println("===> PR[" + i + "] date:[" + pr.getDateString() + "][" + pr.getTemp() + " C][" + pr.getmVol() + " mV][" + pr.getPa() + " Pa]");
/*  84 */         System.out.println("===> PR[" + i + "] GPS:[" + pr.getGps().getLatDispStr() + "->" + pr.getGps().getLat() + " , " + pr.getGps().getLngDispStr() + "->" + pr.getGps().getLng() + "][" + pr.getTemp() + " C][" + pr.getmVol() + " mV][" + pr.getPa() + " Pa]");
/*  85 */         this.prList.add(pr);
/*  86 */         if ((pr.getmVol() < 3650) && 
/*  87 */           (!(this.isLowBattery))) {
/*  88 */           this.isLowBattery = true;
/*  89 */           this.lowBatteryPR = pr;
/*  90 */           this.lowBatteryPR.setImei(this.imei);
/*  91 */           this.lowBatteryPR.setImsi(this.imsi);
/*     */         }
/*     */ 
/*  94 */         if (pr.getEffectiveCellID() != null) {
/*  95 */           for (Cell cid : pr.getEffectiveCellID()) {
/*  96 */             System.out.println("===> PR[" + i + "] cid:[mcc:" + cid.getMcc() + " mnc:" + cid.getMnc() + " lac:" + cid.getLac() + " cid:" + cid.getCellid() + " rssi:" + cid.getRssi() + "]");
/*     */           }
/*     */         }
/*  99 */         if (pr.getEffectiveWifi() != null)
/* 100 */           for (WiFi wifi : pr.getEffectiveWifi())
/* 101 */             System.out.println("===> PR[" + i + "] wifi:[" + wifi.getMac() + "]");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getBatchKey()
/*     */   {
/* 109 */     return this.batchKey;
/*     */   }
/*     */   public String getImei() {
/* 117 */     return this.imei;
/*     */   }
/*     */ 
/*     */   public String getImsi() {
/* 121 */     return this.imsi;
/*     */   }
/*     */ 
/*     */   public String getPr_ver() {
/* 125 */     return this.pr_ver;
/*     */   }
/*     */ 
/*     */   public int getChecksumSYS()
/*     */   {
/* 131 */     return this.checksumSYS;
/*     */   }
/*     */ 
/*     */   public int getChecksumPER() {
/* 135 */     return this.checksumPER;
/*     */   }
/*     */ 
/*     */   public int getPrCount() {
/* 139 */     return this.prCount;
/*     */   }
/*     */ 
/*     */   public List<PeriodicReadingsWifi> getPrList() {
/* 143 */     return this.prList;
/*     */   }
/*     */ 
/*     */   public boolean isLowBattery() {
/* 147 */     return this.isLowBattery;
/*     */   }
/*     */ 
/*     */   public void setLowBattery(boolean isLowBattery) {
/* 151 */     this.isLowBattery = isLowBattery;
/*     */   }
/*     */ 
/*     */   public PeriodicReadingsWifi getLowBatteryPR() {
/* 155 */     return this.lowBatteryPR;
/*     */   }
/*     */ 
/*     */   public void setLowBatteryPR(PeriodicReadingsWifi lowBatteryPR) {
/* 159 */     this.lowBatteryPR = lowBatteryPR;
/*     */   }
/*     */ }

/* Location:           E:\doc\康美手表Server\Guider\台北蓋德_安裝光碟公版_台灣20140515\2.Gateway Program\icare2\WEB-INF\classes\
 * Qualified Name:     com.paralucent.gateway2.model.PacketTypePRWifi
 * JD-Core Version:    0.5.3
 */