package com.kmhc.model.util;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.kmhc.model.pojo.LocResult;
import static org.junit.Assert.assertEquals ;

public class HttpClientUtilsTest {

    @Test
    public void testLocGet() {
        String url = "http://apilocate.amap.com/position?key=caffe6f361c4c3e3fee3b988b65c2944&cdma=0" ;
        String param = "&imei=352151022010156&imsi=460012512203041&bts=460,1,17429,3816,-69&nearbts=460,1,17429,3811,-71|460,1,17429,3813,-81|460,1,17429,3812,-87|460,1,17429,3802,-91|460,1,17429,12792,-91|460,1,17429,13101,-95|460,1,17429,3817,-69|460,1,17429,3816,-65|460,1,17429,3811,-71|460,1,17429,3812,-73|460,1,17429,3813,-73|460,1,17429,13101,-83|460,1,17429,3817,-67|460,1,17429,3816,-67|460,1,17429,3812,-71|460,1,17429,3813,-73|460,1,17429,3811,-77|460,1,17429,13101,-81|460,1,17429,1811,-89&mmac=df:0b:0e:16:13:35,-85,TP-LINK&macs=36:30:30:30:31:44,-71,TP-LINK|16:38:00:ff:ff:ff,397,TP-LINK|ff:ff:ff:ff:05:34,-5,TP-LINK|30:31:44:15:0e:e8,-65,TP-LINK|30:30:30:31:44:15,-85,TP-LINK&accesstype=0";
        byte[] result = HttpClientUtils.request(url, "GET", "UTF-8", param, null, null, 2000, 3000);
        String str = new String(result);
        LocResult locResult = JSON.parseObject(str,LocResult.class);
        System.out.println(locResult.getResult().getDesc());
        assertEquals(550, locResult.getResult().getRadius());
    }
}
