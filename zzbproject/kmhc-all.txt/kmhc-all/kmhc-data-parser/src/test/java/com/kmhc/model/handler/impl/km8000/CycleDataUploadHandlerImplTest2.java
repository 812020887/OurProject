package com.kmhc.model.handler.impl.km8000;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class CycleDataUploadHandlerImplTest2 {

    @Before
    public void befor() throws InterruptedException {
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }

    @Test
    public void testParseData() throws InterruptedException {
        String commandSeq = "86419802750374404600161126167710000031004d0307df0b030f26381020343630303031451fa393ff3800801f2a6550807872117204343630303031451fa3941d343630303031451fa39515343630303031451fbece0f343630303031451f5971090820dce652b470c906008c210a7db736b606006ce8732350c6b306009c216a6d2e5aae0100b075d5806241ae01009c216ae67bb8ac0b0000180a27ec0aaa010006180a27ec0aa9010007df0b030f3a381020343630303031451fa391263800801f2a6550807872117206343630303031451fa38f22343630303031451fa39320343630303031451fa3941e343630303031451fbf041a343630303031451fbd8018343630303031451fa395180820dce652b470c906008c210a7db736b70600b075d5806241ae01006ce8732350c6ae0600c061182b5ae2aa060006180a27ec0aa90100001a1e4c7a20a90600001a1e4c7a21a8060007df0b03101239101c343630303031451fa393243800801f2a6550807872117206343630303031451fa39126343630303031451fa38f25343630303031451fa3901d343630303031451fa3941c343630303031451fbf041b343630303031451fbecb190820dce652b470c706008c210a7db736b206006ce8732350c6ae0600b075d5806241ad01009c216a6d2e5aaa01009c216ae67bb8a90b00c061182b5ae2a7060040169fc9b7d8a20600";
        CycleDataUploadHandlerImpl fallHandlerImpl = new CycleDataUploadHandlerImpl();
        ReplyMessageContent result = fallHandlerImpl
                .handleBasicMessage(new MessageContent(TripleDesHelper.hex2byte(commandSeq), "KM8000"));
        byte[] bs = result.getMsg().get(0);
        System.out.println(TripleDesHelper.byte2hex(bs, bs.length));
        assertEquals("8641980275037440", result.getIemiCode());
    }
}
