package com.kmhc.model.handler.impl.km8000;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class PowerOffHandlerImplTest {

    @Before
    public void befor() throws InterruptedException{
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }
    @Test
    public void testParseData() throws InterruptedException{
        String commandSeq = "3521510220101230460016102618330007df0b06130221010f57343630303031451fa38f2404343630303031451fa3932b343630303031451fa39021343630303031451fa39121343630303031451fbf0413801f299328807871da0c";
        PowerOffHandlerImpl powerOnHandlerImpl = new PowerOffHandlerImpl();
        ReplyMessageContent result = powerOnHandlerImpl.handleBasicMessage(new MessageContent(TripleDesHelper.hex2byte(commandSeq), "KM8000"));
        assertEquals("352151022010123",result.getIemiCode());
    }
}
