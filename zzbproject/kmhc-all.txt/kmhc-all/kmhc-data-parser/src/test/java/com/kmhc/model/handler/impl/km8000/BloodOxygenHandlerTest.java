/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月14日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8000;

import static org.junit.Assert.*;

import java.io.UnsupportedEncodingException;

import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.core.MessageHandlerRegister;
import com.kmhc.model.msg.ReplyMessageContent;

/**
 * Name: BloodOxygenHandlerTest.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8000.BloodOxygenHandlerTest.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月14日 上午11:33:47
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class BloodOxygenHandlerTest {

	@Test
	public void test() throws UnsupportedEncodingException {
		SpringBeanFacotry.getInstance().init("spring-common.xml");
		//
		try {
			MessageHandlerRegister.registHandler("com.kmhc.model.handler", MessageCommand.class);
		} catch (InstantiationException | IllegalAccessException e1) {
			e1.printStackTrace();
		}

		// 构建一个将要传输的报文
		//String hex = "B9FA3139343900000000";
		 String hex = "3886123201112570000000000000000007e0010c0b1e1103535352525151";
		             //3886123201112570000000000000000007e0010c121e1303535352525151
		
					  
					  

		byte[] msg = new byte[hex.length() / 2];

		for (int i = 0; i < hex.length() / 2; i++) {

			char a = hex.charAt(2 * i);
			char b = hex.charAt(2 * i + 1);

			byte f = Integer.valueOf(String.valueOf(a), 16).byteValue();
			byte r = Integer.valueOf(String.valueOf(b), 16).byteValue();

			msg[i] = (byte) ((f << 4) | r);
		}
		

		
		ReplyMessageContent replyMessageContent = new BloodOxygenHandler().handleMessage(msg);
		
	}
	

}
