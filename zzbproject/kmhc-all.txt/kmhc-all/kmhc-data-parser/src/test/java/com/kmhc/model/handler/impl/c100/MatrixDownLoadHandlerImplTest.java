package com.kmhc.model.handler.impl.c100;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

/**
    * @ClassName: com.kmhc.model.handler.impl.c100.MatrixDownLoadHandlerImplTest
    * @Description: 
    * @author xl
    * @date 2016年10月20日
    *
    */

public class MatrixDownLoadHandlerImplTest {

    @Before
    public void befor() throws InterruptedException{
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }
    @Test
    public void testParseData() throws InterruptedException{
        String commandSeq = "0027130600500250109FFFFFFFFF80015E08006C006D0031591A6D4B8BD590E80047006900678D";
        MatrixDownLoadHandlerImpl matrixDownLoadHandlerImpl = new MatrixDownLoadHandlerImpl();
        ReplyMessageContent result = matrixDownLoadHandlerImpl.handleBasicMessage(new MessageContent(TripleDesHelper.hex2byte(commandSeq), "C100"));
        assertEquals("500250109FFFFFFFFF",result.getIemiCode());
        System.out.println(TripleDesHelper.byte2hex(result.getMsg().get(0),result.getMsg().get(0).length));
    }
}
