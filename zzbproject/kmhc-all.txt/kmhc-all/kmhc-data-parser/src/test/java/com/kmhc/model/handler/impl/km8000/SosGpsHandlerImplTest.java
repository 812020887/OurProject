package com.kmhc.model.handler.impl.km8000;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class SosGpsHandlerImplTest {
    @Before
    public void befor() throws InterruptedException{
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }
    @Test
    public void testParseData() throws InterruptedException{
        String commandSeq = "3521510250199640460005270154809007df0b110e151a34363030303027930f791c0634363030303027930ef71834363030303027930ef81534363030303027930f701234363030303027930f850f34363030303027930f150f34363030303027930f740c80165dbc1e807204579f0606696c22a80bc206000a696c22a80bc206000e696c22a80bc20600a456023e1599ab0500b0d59d430ce1aa0b00b85510d2a87ca20a00";
        SosGpsHandlerImpl fallHandlerImpl = new SosGpsHandlerImpl();
        ReplyMessageContent result = fallHandlerImpl.handleBasicMessage(new MessageContent(TripleDesHelper.hex2byte(commandSeq), "KM8000"));
        assertEquals("861232010689104",result.getIemiCode());
    }
}
