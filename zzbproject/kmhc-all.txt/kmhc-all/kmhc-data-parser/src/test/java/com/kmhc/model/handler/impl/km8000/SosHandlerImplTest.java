package com.kmhc.model.handler.impl.km8000;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class SosHandlerImplTest {

    @Before
    public void befor() throws InterruptedException{
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }
    @Test
    public void testParseData() throws InterruptedException{
        String commandSeq = "3521510250199640460005270154809007DF0B100B040134363030303027930F79310634363030303027930F151D34363030303027930EF81D34363030303027930F701634363030303027930EF7143436303030302794113C0A34363030303027930EED090706696C22AA3FCA0B000A696C22AA3FCA0B000E696C22AA3FCA0B0000F14032057BB2060064098026F7EBB20600F0B4293078C6AD0100B0D59D3BC668AB0600";
        SosHandlerImpl sosHandlerImpl = new SosHandlerImpl();
        ReplyMessageContent result = sosHandlerImpl.handleBasicMessage(new MessageContent(TripleDesHelper.hex2byte(commandSeq), "KM8000"));
        assertEquals("352151025019964",result.getIemiCode());
    }
}
