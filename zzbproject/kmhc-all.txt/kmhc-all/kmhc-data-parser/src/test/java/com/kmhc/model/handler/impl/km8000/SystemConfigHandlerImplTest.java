package com.kmhc.model.handler.impl.km8000;

import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.datacenter.dao.ProductSysSettingMMapper;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.StringUtil;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SystemConfigHandlerImplTest {

	
	@Test
	public void SystemConfigHandlerImpl_first() {
		SpringBeanFacotry.getInstance().init("spring-common.xml");

		String hex = "8612320111170970"+"4600781089444220"+
		             "3132303032353038343131343038323532"+
				     "3132303032353038343131343038323532"+
				     "3132303032353038343131343038323532"+
				       "01000000"
				     + "00"
				     + "010a000a"
				     + "000000"
				     + "00"
				     + "00"
				     + "0031";

		        
		// imei 8612320111170970
		// imsi 4600781089444220
		// ip1 3132303032353038343131343038323532
		// ip2 3132303032353038343131343038323532
		// ip3 3132303032353038343131343038323532
		// 回报频率  01
		// 基准时      00
		// 基准分      00
		// 基准秒      00
		// GPS上传周期  00
		// 通话限时  010a000a
		// 拨出限时  000000
		// 自动阅读新短信  00
		// 开机logo 00
		// Checksum 0031
		byte[] msg = new byte[hex.length() / 2];

		for (int i = 0; i < hex.length() / 2; i++) {

			char a = hex.charAt(2 * i);
			char b = hex.charAt(2 * i + 1);

			byte f = Integer.valueOf(String.valueOf(a), 16).byteValue();
			byte r = Integer.valueOf(String.valueOf(b), 16).byteValue();

			msg[i] = (byte) ((f << 4) | r);
		}

		ReplyMessageContent replyMessageContent = new SystemConfigHandlerImpl().handleMessage(msg);
		
        assertEquals("861232011117097",replyMessageContent.getIemiCode());
		
		//判断返回的包体是否正确
		assertEquals("000900",StringUtil.toHexStringPadded(replyMessageContent.getMsg().get(0),0,replyMessageContent.getMsg().get(0).length));
		
		
	}
	
	@Test
	public void SystemConfigHandlerImpl_second() {
		SpringBeanFacotry.getInstance().init("spring-common.xml");

		String hex = "8612320111170970"+"4600781089444220"+
		             "3132303032353038343131343038323532"+
				     "3132303032353038343131343038323532"+
				     "3132303032353038343131343038323532"+
				       "01000000"
				     + "00"
				     + "010a000a"
				     + "000000"
				     + "00"
				     + "00"
				     + "0031";

		        
		// imei 8612320111170970
		// imsi 4600781089444220
		// ip1 3132303032353038343131343038323532
		// ip2 3132303032353038343131343038323532
		// ip3 3132303032353038343131343038323532
		// 回报频率  01
		// 基准时      00
		// 基准分      00
		// 基准秒      00
		// GPS上传周期  00
		// 通话限时  010a000a
		// 拨出限时  000000
		// 自动阅读新短信  00
		// 开机logo 00
		// Checksum 0031
		byte[] msg = new byte[hex.length() / 2];

		for (int i = 0; i < hex.length() / 2; i++) {

			char a = hex.charAt(2 * i);
			char b = hex.charAt(2 * i + 1);

			byte f = Integer.valueOf(String.valueOf(a), 16).byteValue();
			byte r = Integer.valueOf(String.valueOf(b), 16).byteValue();

			msg[i] = (byte) ((f << 4) | r);
		}
		
		
		ProductSysSettingMMapper  pSMMapper = 
				(ProductSysSettingMMapper) SpringBeanFacotry.getInstance().getBean("productSysSettingMMapper");
		
		pSMMapper.deleteByPrimaryKey("861232011117097");
		

		ReplyMessageContent replyMessageContent = new SystemConfigHandlerImpl().handleMessage(msg);
		
        assertEquals("861232011117097",replyMessageContent.getIemiCode());
		
		//判断返回的包体是否正确
		assertEquals("000900",StringUtil.toHexStringPadded(replyMessageContent.getMsg().get(0),0,replyMessageContent.getMsg().get(0).length));
		
		
	}
}
