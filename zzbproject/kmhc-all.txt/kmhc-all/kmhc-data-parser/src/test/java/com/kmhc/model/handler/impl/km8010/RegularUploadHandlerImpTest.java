package com.kmhc.model.handler.impl.km8010;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class RegularUploadHandlerImpTest {
	
	@Before
    public void befor() throws InterruptedException{
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }
    @Test
    public void testParseData() throws InterruptedException{
        
        String commandSeq = "08696150002158360F06190D010101D25C084A08429B025C084ACE35915C084A0AE28E4C";
        RegularUploadHandlerImpl regularUploadHandlerImp = new RegularUploadHandlerImpl();
        ReplyMessageContent result = regularUploadHandlerImp.handleBasicMessage(new MessageContent(TripleDesHelper.hex2byte(commandSeq), "KM8010"));
        assertEquals("869615000215836",result.getIemiCode());
    }
}
