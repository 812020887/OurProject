package com.kmhc.model.handler.impl.km8020;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import com.kmhc.model.handler.impl.AbstractTest;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class BPHandlerImplTest extends AbstractTest {

	@Test
    public void normalTest(){
        String commandSeq = "a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T62, blood_pressure,94,72,85,2011-12-15 08:00:00,1267511609";
        BPHandlerImpl bp = new BPHandlerImpl();
        ReplyMessageContent result = bp.handleBasicMessage(new MessageContent(commandSeq.getBytes(), "KM8020"));
        assertEquals("355372020827303",result.getIemiCode());
    }
}
