package com.kmhc.model.handler.impl.c100;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

/**
    * @ClassName: com.kmhc.model.handler.impl.c100.RealTimeTrajectoryHandlerImplTest
    * @Description: 
    * @author xl
    * @date 2016年10月15日
    *
    */

public class RealTimeTrajectoryHandlerImplTest {

    @Before
    public void befor() throws InterruptedException{
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }
    @Test
    public void testParseData() throws InterruptedException{
        String commandSeq = "0057050600500250109FFFFFFFFF57DDE81E06900000000000000000000001CC00012534E3291201CC00012534E29E0E01CC00012534E4880D01CC00012534E48A0901CC00012541115E0E01CC00012541A1760F800068";
        RealTimeTrajectoryHandlerImpl realTimeTrajectoryHandlerImpl = new RealTimeTrajectoryHandlerImpl();
        ReplyMessageContent result = realTimeTrajectoryHandlerImpl.handleBasicMessage(new MessageContent(TripleDesHelper.hex2byte(commandSeq), "C100"));
        assertEquals("500250109FFFFFFFFF",result.getIemiCode());
        System.out.println(TripleDesHelper.byte2hex(result.getMsg().get(0),result.getMsg().get(0).length));
    }
}
