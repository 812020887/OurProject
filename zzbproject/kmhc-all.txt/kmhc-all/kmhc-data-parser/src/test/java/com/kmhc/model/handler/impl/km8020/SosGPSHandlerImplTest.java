package com.kmhc.model.handler.impl.km8020;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.kmhc.model.handler.impl.AbstractTest;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

/**
    * @ClassName: com.kmhc.model.handler.impl.km8020.SosGPSHandlerImplTest
    * @Description: T85/S85协议解析SosGPSHandlerImpl类的测试用例
    * @author xl
    * @date 2016年9月1日
    *
    */

public class SosGPSHandlerImplTest extends AbstractTest{
  
	@Test
    public void normalTest(){
        String commandSeq = "a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T85,SOS_GPS,104.063469,30.551357,181.899994,0.217000,221.479996,3,1267511609";
        SosGPSHandlerImpl fallHandlerImpl = new SosGPSHandlerImpl();
        ReplyMessageContent result = fallHandlerImpl.handleBasicMessage(new MessageContent(commandSeq.getBytes(), "KM8020"));
        assertEquals("3553720208273030",result.getIemiCode());
    }
}
