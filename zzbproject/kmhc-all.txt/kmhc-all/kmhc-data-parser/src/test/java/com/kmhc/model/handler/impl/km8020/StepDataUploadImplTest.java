package com.kmhc.model.handler.impl.km8020;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.kmhc.model.handler.impl.AbstractTest;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

/**
    * @ClassName: com.kmhc.model.handler.impl.km8020.SosGPSHandlerImplTest
    * @Description: T85/S85协议解析SosGPSHandlerImpl类的测试用例
    * @author xl
    * @date 2016年9月1日
    *
    */

public class StepDataUploadImplTest extends AbstractTest{
    

    @Test
    public void normalTest(){
        String commandSeq = "a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T30,pedo,4057,2231,120.21,1267511609";
        StepDataUploadImpl stepDataUpload = new StepDataUploadImpl();
        ReplyMessageContent result = stepDataUpload.handleBasicMessage(new MessageContent(commandSeq.getBytes(), "KM8020"));
        assertEquals("3553720208273030",result.getIemiCode());
    }
}
