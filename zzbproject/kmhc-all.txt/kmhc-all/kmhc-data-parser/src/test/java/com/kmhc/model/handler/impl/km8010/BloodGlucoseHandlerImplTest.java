/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月17日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8010;

import static org.junit.Assert.*;

import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.core.MessageDispatcher;
import com.kmhc.model.core.MessageHandlerRegister;

/**
 * Name: BloodGlucoseHandlerImplTest.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8010.BloodGlucoseHandlerImplTest.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月17日 上午11:05:22
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class BloodGlucoseHandlerImplTest {

	@Test
	public void test() {
		
		SpringBeanFacotry.getInstance().init("spring-common.xml");
		
		try {
			MessageHandlerRegister.registHandler("com.kmhc.model.handler", MessageCommand.class);
		} catch (InstantiationException | IllegalAccessException e1) {
			e1.printStackTrace();
		}
		
		//构建一个将要传输的报文
		String hex = "0000|00|89|0352151022010107|0e0b180f28|1a|57";
		
		byte[] msg =new byte[hex.length()/2];
		hex = hex.replace("|", "");
		

		
		for(int i =0 ; i<hex.length()/2;i++){
			
			char a = hex.charAt(2*i);
			char b = hex.charAt(2*i+1);
			
			byte f = Integer.valueOf(String.valueOf(a), 16).byteValue();
			byte r = Integer.valueOf(String.valueOf(b), 16).byteValue();
			
			msg[i] =  (byte) ((f<<4)|r);
		}
		Integer[] function = new Integer[]{3,1};
		Integer[] content = new Integer[]{3,-1};
		new MessageDispatcher("KM8010",function,content).dispatcher(msg);
	}

}
