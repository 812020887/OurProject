package com.kmhc.model.handler.impl.km8020;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import com.kmhc.model.handler.impl.AbstractTest;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class LBSHandlerImplTest extends AbstractTest {
	
	@Test
    public void normalTest(){
		String commandSeq = "zu1jgjwp80veawu,1,abcd,2011-12-15 10:00:00,1-2,356511170035899,8,T86,4.10,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,1267511609";
        LBSHandlerImpl lb = new LBSHandlerImpl();
        ReplyMessageContent result = lb.handleBasicMessage(new MessageContent(commandSeq.getBytes(), "KM8020"));
        assertEquals("2,356511170035899,8",result.getIemiCode());
    }
}
