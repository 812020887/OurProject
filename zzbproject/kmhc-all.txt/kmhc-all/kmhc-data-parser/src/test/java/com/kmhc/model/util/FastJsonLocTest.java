package com.kmhc.model.util;

import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.kmhc.model.pojo.LocResult;

import static org.junit.Assert.assertEquals;

public class FastJsonLocTest {

    @Test
    public void testJsonToObject() throws IOException {
         String resource = "json/locresult.json";
         InputStream is =
         Thread.currentThread().getContextClassLoader().getResourceAsStream(resource);
         String text = IOUtils.toString(is);
         is.close();
         LocResult locResult = JSON.parseObject(text,LocResult.class);
         assertEquals(1,locResult.getStatus());

       /* Properties p = new Properties();
        InputStream in = SystemConfigUtil.class.getClassLoader().getResourceAsStream("SystemConfig.properties");
        p.load(in);

        String s = p.getProperty("weather.declaration");
        String[] s2 = s.split("\\|");
        for (String a : s2) {
            System.out.println(a);
        }*/
    }
}
