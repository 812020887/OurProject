/**
 * Copyright (C) 2015 kmhc-data-parser Project
 *               Author: Chris
 *               Date: 2015年11月26日
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kmhc.model.handler.impl.km8000;

import static org.junit.Assert.*;

import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.core.MessageDispatcher;
import com.kmhc.model.core.MessageHandlerRegister;

/**
 * Name: CycleDataUploadHandlerImplTest.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.handler.impl.km8000.CycleDataUploadHandlerImplTest.java]
 * Description: TODO  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: Chris
 * @date: 2015年11月26日 下午3:03:26
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class CycleDataUploadHandlerImplTest {

	@Test
	public void test() {
		SpringBeanFacotry.getInstance().init("spring-common.xml");
		//
		try {
			MessageHandlerRegister.registHandler("com.kmhc.model.handler", MessageCommand.class);
		} catch (InstantiationException | IllegalAccessException e1) {
			e1.printStackTrace();
		}

		// 构建一个将要传输的报文
		String hex = "00b9038612320111255950460012094213143000002500610107df0c070b1d3b0f61343630303031253377961738008016654c92807201c1d106343630303031252a1f6125343630303031252a1f4b1c3436303030312533782e16343630303031253375c916343630303031253375c7153436303030312533785f12060e696c22a7dfbd060006696c22aa27bd01000a696c22aa27bd0100882593110d5fac0600b0d59d3bb52ca80b006cc2174e6521a70600";

		byte[] msg = new byte[hex.length() / 2];

		for (int i = 0; i < hex.length() / 2; i++) {

			char a = hex.charAt(2 * i);
			char b = hex.charAt(2 * i + 1);

			byte f = Integer.valueOf(String.valueOf(a), 16).byteValue();
			byte r = Integer.valueOf(String.valueOf(b), 16).byteValue();

			msg[i] = (byte) ((f << 4) | r);
		}
		Integer[] a = new  Integer[]{2,1};
		Integer[] b = new  Integer[]{3,-1};
		new MessageDispatcher("KM8000", a, b).dispatcher(msg);;
	}

}
