package com.kmhc.model.handler.impl.km8000;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class FallGpsHandlerImplTest {

    @Before
    public void befor() throws InterruptedException{
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }
    @Test
    public void testParseData() throws InterruptedException{
        String commandSeq = "8641980275037440460016112616771007df0b110c1026343630303031451fa3902c06343630303031451fa38f27343630303031451fa39126343630303031451fa39321343630303031451fa3941f343630303031451f7cee1e343630303031451fbecb1c801f2a655080787211720520dce652b470c201006ce8732350c6b806009c216ae67bb8ae0b0052bd5f53ac25a40600b075d5805cfe9f0b00";
        FallGpsHandlerImpl fallHandlerImpl = new FallGpsHandlerImpl();
        ReplyMessageContent result = fallHandlerImpl.handleBasicMessage(new MessageContent(TripleDesHelper.hex2byte(commandSeq), "KM8000"));
        assertEquals("861232011117568",result.getIemiCode());
    }
}
