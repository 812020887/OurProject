package com.kmhc.model.handler.impl.km8000;

import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;
import static org.junit.Assert.assertEquals;

import org.junit.Before;



public class PowerOnHandlerImplTest {

    @Before
    public void befor() throws InterruptedException{
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }
    @Test
    public void testParseData() throws InterruptedException{
        
        String commandSeq = "3521510250199640460005270154809007dd010100002207df0a160e0e0020131014100110010f9734363030303027930f792c0434363030303027930ef81b34363030303027930f701834363030303027930ef71734363030303027930eed13";
        PowerOnHandlerImpl powerOnHandlerImpl = new PowerOnHandlerImpl();
        ReplyMessageContent result = powerOnHandlerImpl.handleBasicMessage(new MessageContent(TripleDesHelper.hex2byte(commandSeq), "KM8000"));
        assertEquals("352151025019964",result.getIemiCode());
    }
}
