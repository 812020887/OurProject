package com.kmhc.model.handler.impl.km8010;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.command.MessageCommand;
import com.kmhc.model.core.MessageDispatcher;
import com.kmhc.model.core.MessageHandlerRegister;
import com.kmhc.model.handler.impl.km8010.AutoTimeAlignmentHandlerImpl;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class AutoTimeAlignmentHandlerImplTest {
	
	@Before
    public void befor() throws InterruptedException{
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }
//    @Test
//    public void testParseData() throws InterruptedException{
//        String commandSeq = "01013CA208665450220452610F0C1F11230101CC01253375C98B0601253375C88A012533762184012533785F83012533785E8201252F3E3E8101253375517C";
//        AutoTimeAlignmentHandlerImpl autoTimeAlignmentHandler = new AutoTimeAlignmentHandlerImpl();
//        ReplyMessageContent result = autoTimeAlignmentHandler.handleBasicMessage(new MessageContent(TripleDesHelper.hex2byte(commandSeq), "KM8010"));
//        assertEquals("866545022045261",result.getIemiCode());
//    }
    
    @Test
	public void test() {		//
		try {
			MessageHandlerRegister.registHandler("com.kmhc.model.handler", MessageCommand.class);
		} catch (InstantiationException | IllegalAccessException e1) {
			e1.printStackTrace();
		}

		// 构建一个将要传输的报文
		String hex = "00b9038612320111255950460012094213143000002500610107df0c070b1d3b0f61343630303031253377961738008016654c92807201c1d106343630303031252a1f6125343630303031252a1f4b1c3436303030312533782e16343630303031253375c916343630303031253375c7153436303030312533785f12060e696c22a7dfbd060006696c22aa27bd01000a696c22aa27bd0100882593110d5fac0600b0d59d3bb52ca80b006cc2174e6521a70600";

		byte[] msg = new byte[hex.length() / 2];

		for (int i = 0; i < hex.length() / 2; i++) {

			char a = hex.charAt(2 * i);
			char b = hex.charAt(2 * i + 1);

			byte f = Integer.valueOf(String.valueOf(a), 16).byteValue();
			byte r = Integer.valueOf(String.valueOf(b), 16).byteValue();

			msg[i] = (byte) ((f << 4) | r);
		}
		Integer[] a = new  Integer[]{2,1};
		Integer[] b = new  Integer[]{3,-1};
		new MessageDispatcher("KM8000", a, b).dispatcher(msg);
    }

}
