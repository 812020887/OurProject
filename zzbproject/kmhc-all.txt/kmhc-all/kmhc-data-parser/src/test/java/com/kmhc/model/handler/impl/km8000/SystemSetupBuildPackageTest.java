package com.kmhc.model.handler.impl.km8000;

import com.kmhc.model.pojo.SystemSetupBuildPackage;
import static org.junit.Assert.assertEquals;

import java.nio.ByteBuffer;

import org.junit.Test;

public class SystemSetupBuildPackageTest {

    @Test
    public void testStringToBytePadded(){
        //assertEquals(15,new SystemSetupBuildPackage().stringToBytePadded("12", 15,"#").length);
    }
    
    @Test
    public void testShortTobytes(){
        new SystemSetupBuildPackage().shortTobytes((short) 1987);
    }
    
    @Test
    public void testByteBuffer(){
        ByteBuffer buffer = ByteBuffer.allocate(1024);
        buffer.put(new byte[]{0,2,3,4});
        assertEquals(4,buffer.position());
        buffer.put(0,(byte)9);
        assertEquals(4,buffer.position());
        assertEquals(9,buffer.get(0));
    }
}
