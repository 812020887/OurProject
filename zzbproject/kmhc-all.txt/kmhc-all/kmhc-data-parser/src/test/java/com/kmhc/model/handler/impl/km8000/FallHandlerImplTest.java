package com.kmhc.model.handler.impl.km8000;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class FallHandlerImplTest {

    @Before
    public void befor() throws InterruptedException{
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }
    @Test
    public void testParseData() throws InterruptedException{
        String commandSeq = "3521510220101230460016102618330007df0b10123b04343630303031451fa394380007e4d332bc2762b10100808917651740a4010000265af87294a3070014e6e4bdd2eea20600882593fde02aa001008c210a3c0f54a006003400a3167988a00700";
        FallHandlerImpl fallHandlerImpl = new FallHandlerImpl();
        ReplyMessageContent result = fallHandlerImpl.handleBasicMessage(new MessageContent(TripleDesHelper.hex2byte(commandSeq), "KM8000"));
        assertEquals("861232011117568",result.getIemiCode());
    }
}
