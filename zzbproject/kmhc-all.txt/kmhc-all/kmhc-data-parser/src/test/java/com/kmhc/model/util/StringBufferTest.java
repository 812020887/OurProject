package com.kmhc.model.util;

import org.junit.Test;
import static org.junit.Assert.assertEquals ;

public class StringBufferTest {

    @Test
    public void testInsert(){
        assertEquals("A6:96:C2:2A:A2:07",new StringBuffer("A696C22AA207").insert(2,":").insert(5, ":").insert(8, ":").insert(11,":").insert(14,":").toString());
    }
}
