package com.kmhc.model.handler.impl.km8000;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.StringUtil;

public class ImmediateAddressingHandlerImplTest {

	
	@Test
	public void ImmediateAddressingHandlerImpl() {
		SpringBeanFacotry.getInstance().init("spring-common.xml");

		String hex = "8612320111255790460013169052614007df0b060a342f313337373638303537333723232323343630303031441809091302343630303031331887290b3436303030313318872a09001f4f15d30077952280026ce873ab55deac0100081079954d3ea00b00";

		byte[] msg = new byte[hex.length() / 2];

		for (int i = 0; i < hex.length() / 2; i++) {

			char a = hex.charAt(2 * i);
			char b = hex.charAt(2 * i + 1);

			byte f = Integer.valueOf(String.valueOf(a), 16).byteValue();
			byte r = Integer.valueOf(String.valueOf(b), 16).byteValue();

			msg[i] = (byte) ((f << 4) | r);
		}

		ReplyMessageContent replyMessageContent = new ImmediateAddressingHandlerImpl().handleMessage(msg);
		
      
		assertEquals("000900",StringUtil.toHexStringPadded(replyMessageContent.getMsg().get(0),0,replyMessageContent.getMsg().get(0).length));
		
	}
}
