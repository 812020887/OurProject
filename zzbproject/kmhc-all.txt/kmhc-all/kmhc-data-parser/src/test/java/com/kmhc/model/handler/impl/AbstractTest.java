package com.kmhc.model.handler.impl;

import org.junit.Before;
import com.kmhc.framework.core.SpringBeanFacotry;

/**
    * @ClassName: com.kmhc.model.handler.impl.AbstractTest
    * @Description: 一个测试父类，暂时没想好抽象什么方法，只是想复用配置文件加载
    * @author xl
    * @date 2016年9月1日
    *
    */
public class AbstractTest {

    @Before
    public void before(){
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }
}
