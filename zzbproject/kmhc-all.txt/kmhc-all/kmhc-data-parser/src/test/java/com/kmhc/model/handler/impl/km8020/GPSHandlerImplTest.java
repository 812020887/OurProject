package com.kmhc.model.handler.impl.km8020;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import com.kmhc.model.handler.impl.AbstractTest;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class GPSHandlerImplTest extends AbstractTest {
	
	@Test
    public void normalTest(){
        String commandSeq = "a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T53,GPS,104.063469,30.551357,181.899994,0.217000,221.479996, 1267511609";
        GPSHandlerImpl gps = new GPSHandlerImpl();
        ReplyMessageContent result = gps.handleBasicMessage(new MessageContent(commandSeq.getBytes(), "KM8020"));
        assertEquals("355372020827303",result.getIemiCode());
    }
}
