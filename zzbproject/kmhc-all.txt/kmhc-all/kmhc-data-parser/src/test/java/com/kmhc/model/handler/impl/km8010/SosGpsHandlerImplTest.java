package com.kmhc.model.handler.impl.km8010;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.handler.impl.km8010.SosGpsHandlerImpl;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class SosGpsHandlerImplTest {

    @Before
    public void befor() throws InterruptedException{
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }
    @Test
    public void testParseData() throws InterruptedException{
        String commandSeq = "08665450220450710E0C1F10170101CC01253375C9870501253375C87F01253376217D01253375C77D012533782E7301253377967101";
        SosGpsHandlerImpl fallHandlerImpl = new SosGpsHandlerImpl();
        ReplyMessageContent result = fallHandlerImpl.handleBasicMessage(new MessageContent(TripleDesHelper.hex2byte(commandSeq), "KM8010"));
        assertEquals("866545022045071",result.getIemiCode());
    }
}
