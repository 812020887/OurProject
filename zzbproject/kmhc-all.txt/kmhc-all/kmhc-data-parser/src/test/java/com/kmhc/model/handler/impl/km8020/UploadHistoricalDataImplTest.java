package com.kmhc.model.handler.impl.km8020;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class UploadHistoricalDataImplTest {
	
	@Before
    public void befor() throws InterruptedException{
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }

	@Test
    public void normalTest(){
		String commandSeq = "67ymcms6avii5eq,1,abcd,2016-11-09 16:20:34,1-2,865946021011091,8,T10,"+
    			"{T30,pedo,0,0,0.00,1388534483},"+
    			"{T94,4.02,LBS,mcount$4$460$0$255#2793|11ef|553|43#2793|f85|562|13#2793|eef|570|7#2793|dea|56|6,1388534539},"+
    			"{T28,mt_pulse,0,1388534700},"+
    			"{T30,pedo,4,2,0.15,1389832088},"+
    			"{T94,4.14,LBS,mcount$1$460$1$255#2533|75c7|120|0,1389832143},"+
    			"{T28,mt_pulse,1,1389832343},"+
    			"{T30,pedo,4,2,0.15,1389833888},"+
    			"{T94,4.01,LBS,mcount$3$460$1$255#2533|7798|659|12#252a|1f59|662|7#2533|75c7|120|3,1389833943},"+
    			"{T28,mt_pulse,0,1389834063},"+
    			"{T30,pedo,10,5,0.37,1389835688},"+
    			"{T94,3.95,LBS,mcount$6$460$1$0#2533|7798|659|18#252a|1f59|662|14#2533|782e|651|13#2533|75c9|124|12#2533|7838|647|12#252a|1f5a|640|12,1389835743},"+
    			"{T30,pedo,10,5,0.37,1478706423},"+
    			"{T28,mt_pulse,64,1478706448},"+
    			"1478708434";
        UploadHistoricalDataImpl upload = new UploadHistoricalDataImpl();
        ReplyMessageContent result = upload.handleBasicMessage(new MessageContent(commandSeq.getBytes(), "KM8020"));
        assertEquals("3553720208273030",result.getIemiCode());
    }
	
	public static String HRHandler(){
		return "460001515535328,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T10,{T28,10,88,1267511609},1267518888";
	}
	
	public static String StepDataUpload(){
		return "460001515535328,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T10,{T30,pedo,4057,2231,120.21,1267501609},1267518888";
	}
	
	public static String LowPowerHandler(){
		return "460001515535328,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T10,{T82,battery low,1267511609},1267518888"; 
	}
	
	public static String SosGPSHandler(){
		return "460001515535328,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T10,{T85,SOS_GPS,104.063469,30.551357,181.899994,0.217000,221.479996,3,1267511609},1267518888";
	}
	
	public static String EmgCallHandler(){
		return "460001515535328,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T10,{T89,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,|help!|,1267511609},1267518888";
	}
	
	public static String SleepQualityDataUpload(){
		return "460001515535328,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T10,{T91,sleep info,01:30,08:55,07:25,89,59,61,86,70,111111;111111211111;111111111112;111111111211;111111111111;111111112212;121211111111;11111111112|222212;112221222212;111211111111;112121010201;112211122111;111122212211;121111111111;22111221122,1441762200},1267518888";
	}
	
	public static String MutiLBSHandler(){
		//模式1
		String s1 = "460001515535328,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T10,{T94,4.10,GPS,104.063469,30.551357,181.899994,0.217000,221.479996,LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-EDU|5c:63:bf:a4:bf:56$-27$CMCC&,1267511609},1267518888";
		String s2 = "460001515535328,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T10,{T94,4.10,LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,1267511609},1267518888";
		String s3 = "460001515535328,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T10,{T94,4.10,GPS,104.063469,30.551357,181.899994,0.217000,221.479996,LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,1267511609},1267518888";
		String s4 = "460001515535328,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T10,{T94,4.10,LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-EDU|5c:63:bf:a4:bf:56$-27$CMCC&,1267511609},1267518888";
		return s4;
		//IContext context = new ContextHandler(new HandlerFactory().createClass("T94"));
	}
	
	public static String BsWithMealSelectionHandler(){
		return "460001515535328,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T10,{T97,blood_sugar,22,1,2016-08-08 08:00:00,1441762200},1267518888";
	}
	
}
