package com.kmhc.model.util;

import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.junit.Test;

/**
    * @ClassName: com.kmhc.model.util.MatrixReadTest
    * @Description: TODO(这里用一句话描述这个类的作用)
    * @author xl
    * @date 2016年10月18日
    *
    */

public class MatrixReadTest {

    @Test
    public void testReadData() throws IOException{
        byte[] bytes = IOUtils.toByteArray(Thread.currentThread().getContextClassLoader().getResourceAsStream("charmode.data"));
        System.out.println(new String(bytes,0,2));
    }
}
