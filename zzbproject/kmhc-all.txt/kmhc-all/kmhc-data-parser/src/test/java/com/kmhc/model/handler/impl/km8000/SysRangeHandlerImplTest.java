package com.kmhc.model.handler.impl.km8000;



import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.StringUtil;



public class SysRangeHandlerImplTest   {

	public static final Logger log = LoggerFactory.getLogger(SysRangeHandlerImplTest.class);
	
	@Test
	public void SysRangeHandlerImpl(){
		           
		SpringBeanFacotry.getInstance().init("spring-common.xml");
		
		String hex = "3521510250199640"
				   + "4600052701548090"
				   + "00003100d50107df0b05111f000eab34363030303027930f793b3800ffffffffffffffffffff0634363030303027930f701734363030303027930ef71634363030303027930ef81534363030303027930eed1334363030303027930f151134363030303027930f8510050e696c22a9dfc401000a696c22aa2bc4010006696c22aa2bc30100640980258d98a80600b0d59d3bc668a80b00";
	
		byte[] msg = new byte[hex.length() / 2];

		for (int i = 0; i < hex.length() / 2; i++) {

			char a = hex.charAt(2 * i);
			char b = hex.charAt(2 * i + 1);

			byte f = Integer.valueOf(String.valueOf(a), 16).byteValue();
			byte r = Integer.valueOf(String.valueOf(b), 16).byteValue();

			msg[i] = (byte) ((f << 4) | r);
		}
		
		ReplyMessageContent replyMessageContent = new SysRangeHandlerImpl().handleMessage(msg);

		assertEquals("000900",StringUtil.toHexStringPadded(replyMessageContent.getMsg().get(0),0,replyMessageContent.getMsg().get(0).length));
	}

}
