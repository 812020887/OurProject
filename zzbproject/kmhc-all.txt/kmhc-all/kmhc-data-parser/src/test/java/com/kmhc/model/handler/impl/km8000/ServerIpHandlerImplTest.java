package com.kmhc.model.handler.impl.km8000;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.datacenter.dao.ProductSysSettingMMapper;
import com.kmhc.model.datacenter.model.ProductSysSettingM;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.StringUtil;

public class ServerIpHandlerImplTest {
	
	@Test
	public void ServerIpHandlerImpl() {
		
				
		SpringBeanFacotry.getInstance().init("spring-common.xml");

		//这里的数据库操作以后要注意修改啊
		String hex = "1111111111111110"+"4600781089444220"+
		             "3132303032353038343131343038323532"+
				     "3132303032353038343131343038323532"+
				     "3132303032353038343131343038323532"+
				       "01000000"
				     + "00"
				     + "010a000a"
				     + "000000"
				     + "00"
				     + "00"
				     + "0031";
		
	    //这里数据库的内容要注意
		String rehex = "003d4003"
				+ "3132303032353038343131343038323532"  // 120.25.84.114:8252
				+ "3132303032353038343131343038323532"
				+ "3132303032353038343131343038323532";		
        
		byte[] msg = new byte[hex.length() / 2];

		for (int i = 0; i < hex.length() / 2; i++) {

			char a = hex.charAt(2 * i);
			char b = hex.charAt(2 * i + 1);

			byte f = Integer.valueOf(String.valueOf(a), 16).byteValue();
			byte r = Integer.valueOf(String.valueOf(b), 16).byteValue();

			msg[i] = (byte) ((f << 4) | r);
		}
		
		ProductSysSettingMMapper pSMMapper = (ProductSysSettingMMapper) SpringBeanFacotry.getInstance()
				.getBean("productSysSettingMMapper");

		ProductSysSettingM record = new ProductSysSettingM();
		
		record.setImei("111111111111111");
		record.setImsi("12345678");
		record.setIp1("120.25.84.114:8252");
		record.setIp2("120.25.84.114:8252");
		record.setIp3("120.25.84.114:8252");
		pSMMapper.deleteByPrimaryKey("111111111111111"); 
		pSMMapper.insert(record);
		
		ReplyMessageContent replyMessageContent = new ServerIpHandlerImpl().handleMessage(msg);
		
		assertEquals("111111111111111",replyMessageContent.getIemiCode());
		
		String remsg = StringUtil.toHexStringPadded(replyMessageContent.getMsg().get(0),0,replyMessageContent.getMsg().get(0).length);
		assertEquals(rehex,remsg);
		
		pSMMapper.deleteByPrimaryKey("111111111111111"); 
		
	}

}
