package com.kmhc.model.handler.impl.km8020;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.kmhc.model.handler.impl.AbstractTest;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class MutiLBSHandlerImplTest extends AbstractTest {

	@Test
    public void normalTest(){
        String commandSeq = "zu1jgjwp80veawu,1,abcd,2011-12-15 10:00:00,1-2,356511170035899,8,T94,4.10,GPS,104.063469,30.551357,181.899994,0.217000,221.479996,LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-EDU|5c:63:bf:a4:bf:56$-27$CMCC&, 1267511609";
        MutiLBSHandlerImpl m = new MutiLBSHandlerImpl();
        ReplyMessageContent result = m.handleBasicMessage(new MessageContent(commandSeq.getBytes(), "KM8020"));
        assertEquals("356511170035899",result.getIemiCode());
    }
	
		// (1)当3种定位数据都有时：
		// 
		//
		// (2)当只有lbs定位数据时:
		// zu1jgjwp80veawu,1,abcd,2011-12-15 10:00:00,1-2,
		// 356511170035899,8,T94,4.10,
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		// 1267511609
		//
		//
		// (3)当上传lbs数据和gps数据时:
		// zu1jgjwp80veawu,1,abcd,2011-12-15 10:00:00,1-2,
		// 356511170035899,8,T94,4.10,
		// GPS,104.063469,30.551357,181.899994,0.217000,221.479996,
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		// 1267511609
		//
		// (4)当上传lbs数据和wifi定位数据时:
		// zu1jgjwp80veawu,1,abcd,2011-12-15 10:00:00,1-2,
		// 356511170035899,8,T94,4.10,
		// LBS,mcount$6$460$0$255#2503|ee51|67|46#2503|c3f8|557|28#2503|555e|543|18#2503|6953|559|18#2503|48ef|78|14#2736|702c|555|13,
		// WIFI,&mmac=f0:7d:68:9e:7d:18$-41$TPLink,&macs=22:27:1d:20:08:d5$-55$CMCC-EDU|5c:63:bf:a4:bf:56$-27$CMCC&,
		// 1267511609

		// av4mwbb8y1ut6gu,1,abcd,2016-08-11
		// 05:54:32,1-2,356511170035899,8,T94,3.76,GPS,120.745811,31.272255,28.200001,0.916000,0.000000,11.000000,LBS,mcount$0$0$0$0,1470894872

}
