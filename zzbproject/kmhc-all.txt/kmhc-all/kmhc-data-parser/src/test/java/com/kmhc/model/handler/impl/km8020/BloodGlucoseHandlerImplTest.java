package com.kmhc.model.handler.impl.km8020;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.kmhc.model.handler.impl.AbstractTest;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class BloodGlucoseHandlerImplTest extends AbstractTest{
	 	@Test
	    public void normalTest(){
	        String commandSeq = "a1d83kdeio3fg3k,1,abcd,2011-12-15 10:00:00,1-2,355372020827303,8,T63,0,0,0,0,0,0";
	        BloodGlucoseHandlerImpl b = new BloodGlucoseHandlerImpl();
	        ReplyMessageContent result = b.handleBasicMessage(new MessageContent(commandSeq.getBytes(), "KM8020"));
	        assertEquals("356511170035899",result.getIemiCode());
	 }
}
