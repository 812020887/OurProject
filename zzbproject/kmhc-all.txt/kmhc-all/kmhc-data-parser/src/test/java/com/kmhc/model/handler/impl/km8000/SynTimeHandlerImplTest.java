package com.kmhc.model.handler.impl.km8000;

import static org.junit.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.junit.Test;

import com.kmhc.model.handler.impl.km8000.SynTimeHandlerImpl;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.StringUtil;

public class SynTimeHandlerImplTest {
	
	
	@Test
	public void SynTimeHandlerImpl(){
		
		String hex = "86419802750665504600115005147900";
		
		byte[] msg =new byte[19];
		
		
	
    	for(int i =0 ; i<hex.length()/2;i++){
			
			char a = hex.charAt(2*i);
			char b = hex.charAt(2*i+1);
			
			byte f = Integer.valueOf(String.valueOf(a), 16).byteValue();
			byte r = Integer.valueOf(String.valueOf(b), 16).byteValue();
			
			msg[i] =  (byte) ((f<<4)|r);
		}
    	byte[] sysTime = new byte[7];
    	Date currentDate = new Date();
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    	sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
    	String dateStr = sdf.format(currentDate);
    	               
    	int yy = Integer.parseInt(dateStr.substring(0, 4));
    	
    	sysTime[0] = (byte)(yy >> 8 & 0xFF);
    	
    	sysTime[1] = (byte)(yy & 0xFF);
    	
    	sysTime[2] = (byte)Integer.parseInt(dateStr.substring(5, 7));
    	sysTime[3] = (byte)Integer.parseInt(dateStr.substring(8, 10));
    	sysTime[4] = (byte)Integer.parseInt(dateStr.substring(11, 13));
    	sysTime[5] = (byte)Integer.parseInt(dateStr.substring(14, 16));
    	sysTime[6] = (byte)Integer.parseInt(dateStr.substring(17, 19));
		
		ReplyMessageContent replyMessageContent = new SynTimeHandlerImpl().handleMessage(msg);
		assertEquals(replyMessageContent.getIemiCode(),"8641980275066550");
		
		assertEquals("864198027506655000107a"+StringUtil.toHexStringPadded(sysTime,0,7-1),StringUtil.toHexStringPadded(replyMessageContent.getMsg().get(0),0,replyMessageContent.getMsg().get(0).length-1));
	}

}
