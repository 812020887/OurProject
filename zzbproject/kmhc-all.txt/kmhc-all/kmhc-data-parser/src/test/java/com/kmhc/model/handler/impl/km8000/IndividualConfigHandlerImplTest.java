package com.kmhc.model.handler.impl.km8000;

import static org.junit.Assert.assertEquals;

import java.io.UnsupportedEncodingException;

import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.datacenter.model.ProductPerSettingM;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.StringUtil;

public class IndividualConfigHandlerImplTest {

	
	@Test
	public void IndividualConfigHandlerImpl() throws UnsupportedEncodingException {
		SpringBeanFacotry.getInstance().init("spring-common.xml");

		//String hex = "86419802750665504600115005147900000000000007313338303631323337363623232323232323232323232323232323232323232323232323232323232323232323313338303631323337363623232323232323232323232323232323232323232323232323232323232323232323003133383036313233373636232323230023232323232323232323232323232300232323232323232323232323232323000c0000000c0000000c0000000c0000000c00000007dd01010c000007dd01010c0000232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323000050006401f401900bb80190232323230050006401f401900bb80190232323230050006401f401900bb80190232323230300383634313938303237353036363535e4bd95e6958f00000000000007b201010006a402580258001978005a00000000000000000000000000000000000000000000000067";

		String hex = "8612320111251570460012094213140001000001010C323223232323232323232323232323313132232323232323232323232323313131322323232323232323232323323133232323232323232323232323333435332323232323232323232323313233323123232323232323232323003131313131313923232323232323230032323232323232392323232323232300333333333333333131392323232323010D027E010E037E010F037E0110037E0111037E0107E00C180C120107E00C190D1201393939393923232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323002300230023002301230000502323232323232323232323232323005023232323232323232323232323230050232323230200383631323332303131313235313537E9ACBCE9ACBC00000000011707C90C0CC9067C01B801AE00150101010100000000000000000000000000000000000000000000006F";
		
		byte[] msg = new byte[hex.length() / 2];

		for (int i = 0; i < hex.length() / 2; i++) {

			char a = hex.charAt(2 * i);
			char b = hex.charAt(2 * i + 1);

			byte f = Integer.valueOf(String.valueOf(a), 16).byteValue();
			byte r = Integer.valueOf(String.valueOf(b), 16).byteValue();

			msg[i] = (byte) ((f << 4) | r);
		}

		ProductPerSettingM record = new ProductPerSettingM();
		new IndividualConfigHandlerImpl().constructRecord(msg, record);
		
		assertEquals("861232011125157", record.getImei());
		assertEquals("460012094213140", record.getImsi());
		assertEquals((short)1, (short)record.getSosKeyDelay());
		assertEquals((short)0, (short)record.getFmlyKeyDelay());
		assertEquals((short)0, (short)record.getSosSms());
		assertEquals((short)1, (short)record.getFallSms());
		assertEquals((short)1, (short)record.getNonDistrub());
		assertEquals((short)12, (short)record.getTimezone());
		
		assertEquals(Short.valueOf("13"),record.getMedT1Hh());
		assertEquals(Short.valueOf("2"),record.getMedT1Mm());
		assertEquals(Short.valueOf("1"),record.getMedT1On());
		assertEquals(Short.valueOf("126"),record.getMedT1WeekdayFilter());
		
		assertEquals(Short.valueOf("17"),record.getMedT5Hh());
		assertEquals(Short.valueOf("3"),record.getMedT5Mm());
		assertEquals(Short.valueOf("1"),record.getMedT5On());
		assertEquals(Short.valueOf("126"),record.getMedT5WeekdayFilter());
		
		assertEquals("鬼鬼", record.getuName());
		assertEquals(Short.valueOf("23"), record.getuAge());
		assertEquals(Short.valueOf("1993"), record.getuBirthdateYy());		
		assertEquals(Short.valueOf("12"), record.getuBirthdateMm());
		assertEquals(Short.valueOf("12"), record.getuBirthdateDd());
		
		assertEquals(Short.valueOf("0"), record.getActiveG());
		
		assertEquals(Short.valueOf("21"), record.getuStep());
		assertEquals(Short.valueOf("1"), record.getuDaistolicLowerLimit());
		
		assertEquals(Short.valueOf("0"),record.getEfT3On());
		assertEquals(Short.valueOf("0"),record.getEfST3Hh());
		assertEquals(Short.valueOf("0"),record.getEfST3Mm());
		assertEquals(Short.valueOf("0"),record.getEfET3Hh());
		assertEquals(Short.valueOf("0"),record.getEfET3Mm());
		assertEquals(Short.valueOf("0"),record.getEfT3WeekdayFilter());
		
		assertEquals(Short.valueOf("111"), record.getChecksum());


		
		
		ReplyMessageContent replyMessageContent = new IndividualConfigHandlerImpl().handleMessage(msg);
		
      
		assertEquals("000900",StringUtil.toHexStringPadded(replyMessageContent.getMsg().get(0),0,replyMessageContent.getMsg().get(0).length));
		
	}
}
