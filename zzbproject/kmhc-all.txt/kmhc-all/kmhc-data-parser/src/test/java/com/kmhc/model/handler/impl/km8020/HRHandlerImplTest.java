package com.kmhc.model.handler.impl.km8020;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.kmhc.model.handler.impl.AbstractTest;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

public class HRHandlerImplTest extends AbstractTest{
	@Test
    public void normalTest(){
        String commandSeq = "a1d83kdeio3fg3k,1,abcd,2016-12-15 10:00:00,1-2,355372020827303,8,T28,mt_pulse,78,1267511609";
        HRHandlerImpl bp = new HRHandlerImpl();
        ReplyMessageContent result = bp.handleBasicMessage(new MessageContent(commandSeq.getBytes(), "KM8020"));
        assertEquals("355372020827303",result.getIemiCode());
    }
}
