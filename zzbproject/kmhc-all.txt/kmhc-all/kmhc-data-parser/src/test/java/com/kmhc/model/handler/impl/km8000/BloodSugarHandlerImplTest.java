package com.kmhc.model.handler.impl.km8000;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.msg.ReplyMessageContent;
import com.kmhc.model.util.StringUtil;

public class BloodSugarHandlerImplTest {
	
	
	@Test
	public void BloodSugarHandlerImpl() {
		SpringBeanFacotry.getInstance().init("spring-common.xml");

		String hex = "3521510250199640460005270154809007df0a1a10331901010037";

		// 偏移量 002437
		// imei 3521510250199640
		// imsi 4600052701548090
		// 日期 07df0a1a103319
		// 单位 01
		// 记录数 01
		// 血糖值 0037
		
		System.out.println("===================================================");
		System.out.println((short) ((0xFF & 0x01) << 8));
		System.out.println((short) ((0xFF & 0x3c)));
		System.out.println((short) ((0xFF & 0x01) << 8) | (0xFF & 0x3c));
		byte[] msg = new byte[hex.length() / 2];

		for (int i = 0; i < hex.length() / 2; i++) {

			char a = hex.charAt(2 * i);
			char b = hex.charAt(2 * i + 1);

			byte f = Integer.valueOf(String.valueOf(a), 16).byteValue();
			byte r = Integer.valueOf(String.valueOf(b), 16).byteValue();

			msg[i] = (byte) ((f << 4) | r);
		}

		ReplyMessageContent replyMessageContent = new BloodSugarHandlerImpl().handleMessage(msg);
		
        assertEquals("352151025019964",replyMessageContent.getIemiCode());
		
		//判断返回的包体是否正确
		assertEquals("000900",StringUtil.toHexStringPadded(replyMessageContent.getMsg().get(0),0,replyMessageContent.getMsg().get(0).length));
		
		
	}

}
