package com.kmhc.model.handler.impl.c100;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.framework.util.TripleDesHelper;
import com.kmhc.model.msg.MessageContent;
import com.kmhc.model.msg.ReplyMessageContent;

/**
    * @ClassName: com.kmhc.model.handler.impl.c100.ParamSyncHandlerImplTest
    * @Description: TODO(这里用一句话描述这个类的作用)
    * @author xl
    * @date 2016年10月17日
    *
    */



public class ParamSyncHandlerImplTest {

    @Before
    public void befor() throws InterruptedException{
        SpringBeanFacotry.getInstance().init("spring-common.xml");
    }
    @Test
    public void testParseData() throws InterruptedException{
        String commandSeq = "00190C0600500250109FFFFFFFFF57D018A357DA4F030920CC";
        ParamSyncHandlerImpl paramSyncHandlerImpl = new ParamSyncHandlerImpl();
        ReplyMessageContent result = paramSyncHandlerImpl.handleBasicMessage(new MessageContent(TripleDesHelper.hex2byte(commandSeq), "C100"));
        assertEquals("500250109FFFFFFFFF",result.getIemiCode());
        System.out.println(TripleDesHelper.byte2hex(result.getMsg().get(0),result.getMsg().get(0).length));
    }
}