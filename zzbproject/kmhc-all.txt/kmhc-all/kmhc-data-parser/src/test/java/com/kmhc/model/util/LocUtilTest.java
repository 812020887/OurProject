package com.kmhc.model.util;

import java.math.BigDecimal;

import org.junit.Test;

public class LocUtilTest {

    @Test
    public void testReverseGeocoding(){
        LocUtil.reverseGeocoding("25","114");
        LocUtil.reverseGeocoding(new BigDecimal(25.23), new BigDecimal(114.2355));
    }
    
    @Test
    public void testConvert(){
        System.out.println(LocUtil.conver("39.99047","116.481495"));
        //System.out.println(new BigDecimal(Double.parseDouble("23.3622322")).doubleValue());
    }
}
