package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingBloodglucose;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("memberSettingBloodglucoseMapper")
public interface MemberSettingBloodglucoseMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingBloodglucose record);

    MemberSettingBloodglucose selectByPrimaryKey(String imei);

    List<MemberSettingBloodglucose> selectAll();

    int updateByPrimaryKey(MemberSettingBloodglucose record);
    
    int update(MemberSettingBloodglucose record);
}