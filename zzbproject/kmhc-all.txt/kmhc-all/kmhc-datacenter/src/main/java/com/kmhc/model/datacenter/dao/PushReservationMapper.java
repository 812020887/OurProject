package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PushReservation;
import java.util.List;

public interface PushReservationMapper {
    int deleteByPrimaryKey(Long reservationId);

    int insert(PushReservation record);

    PushReservation selectByPrimaryKey(Long reservationId);

    List<PushReservation> selectAll();

    int updateByPrimaryKey(PushReservation record);
}