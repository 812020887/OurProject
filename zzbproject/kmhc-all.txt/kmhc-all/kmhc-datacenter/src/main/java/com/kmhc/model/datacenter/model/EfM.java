package com.kmhc.model.datacenter.model;

import java.util.Date;

public class EfM {
    private String batchKey;

    private String imei;

    private String imsi;

    private String type;

    private Short ver;

    private Short checksumS;

    private Short checksumP;

    private Short prcount;

    private Date createDate;

    private Date updateDate;

    private String isProcessed;

    private String isPushed;

    public String getBatchKey() {
        return batchKey;
    }

    public void setBatchKey(String batchKey) {
        this.batchKey = batchKey;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Short getVer() {
        return ver;
    }

    public void setVer(Short ver) {
        this.ver = ver;
    }

    public Short getChecksumS() {
        return checksumS;
    }

    public void setChecksumS(Short checksumS) {
        this.checksumS = checksumS;
    }

    public Short getChecksumP() {
        return checksumP;
    }

    public void setChecksumP(Short checksumP) {
        this.checksumP = checksumP;
    }

    public Short getPrcount() {
        return prcount;
    }

    public void setPrcount(Short prcount) {
        this.prcount = prcount;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getIsProcessed() {
        return isProcessed;
    }

    public void setIsProcessed(String isProcessed) {
        this.isProcessed = isProcessed;
    }

    public String getIsPushed() {
        return isPushed;
    }

    public void setIsPushed(String isPushed) {
        this.isPushed = isPushed;
    }
}