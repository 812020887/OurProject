package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingGeofenceBak2;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface MemberSettingGeofenceBak2Mapper {
    int deleteByPrimaryKey(@Param("gId") Integer gId, @Param("memberId") Long memberId);

    int insert(MemberSettingGeofenceBak2 record);

    MemberSettingGeofenceBak2 selectByPrimaryKey(@Param("gId") Integer gId, @Param("memberId") Long memberId);

    List<MemberSettingGeofenceBak2> selectAll();

    int updateByPrimaryKey(MemberSettingGeofenceBak2 record);
}