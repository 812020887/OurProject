package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.EmgITemp;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface EmgITempMapper {
    int deleteByPrimaryKey(@Param("emgDetailKey") String emgDetailKey, @Param("itemno") Short itemno);

    int insert(EmgITemp record);

    EmgITemp selectByPrimaryKey(@Param("emgDetailKey") String emgDetailKey, @Param("itemno") Short itemno);

    List<EmgITemp> selectAll();

    int updateByPrimaryKey(EmgITemp record);
}