package com.kmhc.model.datacenter.framework.orm;

import java.util.List;
import java.util.Map;

public interface IDAOTemplate<T> {
	
	/**
	 * 保存一条记录
	 * @param t   实体类
	 * @return    受影响的函数
	 */
	int save(T t);
	
	/**
	 * 批量保存记录
	 * @param list	实体类列表
	 * @return		受影响函数
	 */
	int batchSave(List<T> list);
	
	/**
	 * 更新一条记录
	 * @param t   实体类
	 * @return    受影响的行数
	 */
	int update(T t);
	
	/**
	 * 更新一条记录
	 * @param t         实体类
	 * @param property  根据属性更新
	 * @return          受影响的行数
	 */
	int update(T t, String property);
	
	/**
	 * 删除一条记录
	 * @param t   实体类
	 * @return    受影响的函数
	 */
	int delete(T t);
	
	/**
	 * 根据ID删除一条记录
	 * @param id  实体类
	 * @return    受影响的函数
	 */
	int deleteById(Integer id);
	
	/**
	 * 根据ID查找记录
	 * @param id  ID
	 * @return    实体类
	 */
	T findById(Integer id);
	
	/**
	 * 根据属性查找记录
	 * @param params 参数
	 * @param value  参数值
	 * @return       实体类
	 */
	T findByProperty(String params, Object value);
	
	/**
	 * 根据属性查找记录
	 * @param params 参数数组
	 * @param value  参数值数组
	 * @return       实体类
	 */
	T findByProperty(String[] params, Object[] value);
	
	/**
	 *  根据属性查找记录
	 * @param params 参数
	 * @return       实体类
	 */   
	T findByProperty(Map<String, Object> params);
	
	/**
	 * 查找所有的记录
	 * @return   实体类列表
	 */
	List<T> findAll();
	
	/**
	 * 根据关键字查找记录
	 * @param param      参数
	 * @param value      参数值
	 * @return           实体类列表
	 */
	List<T> findByKeywords(String param, Object value);
	
	/**
	 *  根据关键字查找记录
	 * @param params     参数组
	 * @param value      参数值组
	 * @return
	 */
	List<T> findByKeywords(String[] params, Object[] value);
	
	/**
	 * 根据关键字查找记录
	 * @param keywords 关键字
	 * @return         实体类列表
	 */ 
	List<T> findByKeywords(Map<String, Object> keywords);
	



}
