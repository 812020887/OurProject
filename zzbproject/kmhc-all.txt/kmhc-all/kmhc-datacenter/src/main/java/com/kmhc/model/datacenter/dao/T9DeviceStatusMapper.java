package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.T9DeviceStatus;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("t9DeviceStatusMapper")
public interface T9DeviceStatusMapper {
    int deleteByPrimaryKey(@Param("no") Integer no, @Param("imei") String imei);

    int insert(T9DeviceStatus record);

    T9DeviceStatus selectByPrimaryKey(@Param("no") Integer no, @Param("imei") String imei);

    List<T9DeviceStatus> selectAll();

    int updateByPrimaryKey(T9DeviceStatus record);
    
    T9DeviceStatus selectByImei(@Param("imei") String imei);
}