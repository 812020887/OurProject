package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.ProductSysSettingM;
import java.util.List;

import org.springframework.stereotype.Repository;
@Repository("productSysSettingMMapper")
public interface ProductSysSettingMMapper {
    int deleteByPrimaryKey(String imei);

    int insert(ProductSysSettingM record);

    ProductSysSettingM selectByPrimaryKey(String imei);

    List<ProductSysSettingM> selectAll();

    int updateByPrimaryKey(ProductSysSettingM record);
    
    int updateByPrimaryKeySelective(ProductSysSettingM record);
}