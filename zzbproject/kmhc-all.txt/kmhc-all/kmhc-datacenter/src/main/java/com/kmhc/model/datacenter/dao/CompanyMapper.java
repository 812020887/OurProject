package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.Company;
import java.util.List;

public interface CompanyMapper {
    int deleteByPrimaryKey(Long companyId);

    int insert(Company record);

    Company selectByPrimaryKey(Long companyId);

    List<Company> selectAll();

    int updateByPrimaryKey(Company record);
}