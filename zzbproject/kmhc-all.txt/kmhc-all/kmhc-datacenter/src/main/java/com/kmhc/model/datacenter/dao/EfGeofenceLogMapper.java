package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.EfGeofenceLog;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface EfGeofenceLogMapper {
    int deleteByPrimaryKey(@Param("batchKey") String batchKey, @Param("imei") String imei, @Param("geoNo") Short geoNo);

    int insert(EfGeofenceLog record);

    EfGeofenceLog selectByPrimaryKey(@Param("batchKey") String batchKey, @Param("imei") String imei, @Param("geoNo") Short geoNo);

    List<EfGeofenceLog> selectAll();

    int updateByPrimaryKey(EfGeofenceLog record);
}