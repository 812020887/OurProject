package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.T9StepSetting;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("t9StepSettingMapper")
public interface T9StepSettingMapper {
    int deleteByPrimaryKey(String imei);

    int insert(T9StepSetting record);

    T9StepSetting selectByPrimaryKey(String imei);

    List<T9StepSetting> selectAll();

    int updateByPrimaryKey(T9StepSetting record);
    
    int update(T9StepSetting record);
}