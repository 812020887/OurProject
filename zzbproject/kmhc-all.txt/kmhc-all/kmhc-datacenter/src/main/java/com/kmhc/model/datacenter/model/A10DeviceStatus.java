package com.kmhc.model.datacenter.model;

import java.math.BigDecimal;
import java.util.Date;

public class A10DeviceStatus {
    private Integer no;

    private String imei;

    private BigDecimal longitude;

    private BigDecimal latitude;

    private Date lbsTime;

    private Integer lowPowerStatus;

    private Integer electricFenceStatus;
    
    private Integer dropStatus;
    
    private Integer moveStatus;

    private Date updateTime;

    private Date createTime;
    
    private String address;
    
    private String power;
    
    private String locMode;
    
    private Integer standbyStauts;
    
	public Integer getNo() {
		return no;
	}

	public void setNo(Integer no) {
		this.no = no;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public BigDecimal getLongitude() {
		return longitude;
	}

	public void setLongitude(BigDecimal longitude) {
		this.longitude = longitude;
	}

	public BigDecimal getLatitude() {
		return latitude;
	}

	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}
	

	public Date getLbsTime() {
		return lbsTime;
	}

	public void setLbsTime(Date lbsTime) {
		this.lbsTime = lbsTime;
	}

	public Integer getLowPowerStatus() {
		return lowPowerStatus;
	}

	public void setLowPowerStatus(Integer lowPowerStatus) {
		this.lowPowerStatus = lowPowerStatus;
	}

	public Integer getElectricFenceStatus() {
		return electricFenceStatus;
	}

	public void setElectricFenceStatus(Integer electricFenceStatus) {
		this.electricFenceStatus = electricFenceStatus;
	}

	public Integer getDropStatus() {
		return dropStatus;
	}

	public void setDropStatus(Integer dropStatus) {
		this.dropStatus = dropStatus;
	}

	public Integer getMoveStatus() {
		return moveStatus;
	}

	public void setMoveStatus(Integer moveStatus) {
		this.moveStatus = moveStatus;
	}

	

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPower() {
		return power;
	}

	public void setPower(String power) {
		this.power = power;
	}

	public String getLocMode() {
		return locMode;
	}

	public void setLocMode(String locMode) {
		this.locMode = locMode;
	}

	public Integer getStandbyStauts() {
		return standbyStauts;
	}

	public void setStandbyStauts(Integer standbyStauts) {
		this.standbyStauts = standbyStauts;
	}
 
	
}