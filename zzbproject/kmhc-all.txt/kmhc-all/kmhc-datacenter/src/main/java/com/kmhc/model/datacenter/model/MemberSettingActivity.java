package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingActivity {
    private String imei;

    private Date updateTime;

    private String updated;

    private String activitySwitch;

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    public String getActivitySwitch() {
        return activitySwitch;
    }

    public void setActivitySwitch(String activitySwitch) {
        this.activitySwitch = activitySwitch;
    }
}