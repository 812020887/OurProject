package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingNonmovement {
    private Long memberId;

    private Date startTime;

    private Date endTime;

    private String weekly;

    private Byte alerted;

    private Date alertedTime;

    private Short status;

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getWeekly() {
        return weekly;
    }

    public void setWeekly(String weekly) {
        this.weekly = weekly;
    }

    public Byte getAlerted() {
        return alerted;
    }

    public void setAlerted(Byte alerted) {
        this.alerted = alerted;
    }

    public Date getAlertedTime() {
        return alertedTime;
    }

    public void setAlertedTime(Date alertedTime) {
        this.alertedTime = alertedTime;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }
}