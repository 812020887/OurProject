package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingGeofenceBak;
import java.util.List;

public interface MemberSettingGeofenceBakMapper {
    int deleteByPrimaryKey(Integer gId);

    int insert(MemberSettingGeofenceBak record);

    MemberSettingGeofenceBak selectByPrimaryKey(Integer gId);

    List<MemberSettingGeofenceBak> selectAll();

    int updateByPrimaryKey(MemberSettingGeofenceBak record);
}