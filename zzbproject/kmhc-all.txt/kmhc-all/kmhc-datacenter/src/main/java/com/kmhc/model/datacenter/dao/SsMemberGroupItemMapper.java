package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.SsMemberGroupItem;
import java.util.List;

public interface SsMemberGroupItemMapper {
    int deleteByPrimaryKey(Long itemId);

    int insert(SsMemberGroupItem record);

    SsMemberGroupItem selectByPrimaryKey(Long itemId);

    List<SsMemberGroupItem> selectAll();

    int updateByPrimaryKey(SsMemberGroupItem record);
}