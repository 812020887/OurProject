package com.kmhc.model.datacenter.model;

import java.math.BigDecimal;
import java.util.Date;

public class Guidercell2gps {
    private Long id;

    private String mcc;

    private String mnc;

    private String lacTen;

    private String cellTen;

    private String lacSixteen;

    private String cellSixteen;

    private BigDecimal lat;

    private BigDecimal lng;

    private BigDecimal oLat;

    private BigDecimal oLng;

    private String precision;

    private String address;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMcc() {
        return mcc;
    }

    public void setMcc(String mcc) {
        this.mcc = mcc;
    }

    public String getMnc() {
        return mnc;
    }

    public void setMnc(String mnc) {
        this.mnc = mnc;
    }

    public String getLacTen() {
        return lacTen;
    }

    public void setLacTen(String lacTen) {
        this.lacTen = lacTen;
    }

    public String getCellTen() {
        return cellTen;
    }

    public void setCellTen(String cellTen) {
        this.cellTen = cellTen;
    }

    public String getLacSixteen() {
        return lacSixteen;
    }

    public void setLacSixteen(String lacSixteen) {
        this.lacSixteen = lacSixteen;
    }

    public String getCellSixteen() {
        return cellSixteen;
    }

    public void setCellSixteen(String cellSixteen) {
        this.cellSixteen = cellSixteen;
    }

    public BigDecimal getLat() {
        return lat;
    }

    public void setLat(BigDecimal lat) {
        this.lat = lat;
    }

    public BigDecimal getLng() {
        return lng;
    }

    public void setLng(BigDecimal lng) {
        this.lng = lng;
    }

    public BigDecimal getoLat() {
        return oLat;
    }

    public void setoLat(BigDecimal oLat) {
        this.oLat = oLat;
    }

    public BigDecimal getoLng() {
        return oLng;
    }

    public void setoLng(BigDecimal oLng) {
        this.oLng = oLng;
    }

    public String getPrecision() {
        return precision;
    }

    public void setPrecision(String precision) {
        this.precision = precision;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}