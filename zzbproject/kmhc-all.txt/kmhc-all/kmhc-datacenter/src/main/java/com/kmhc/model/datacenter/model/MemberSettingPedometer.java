package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingPedometer {
    private String imei;

    private Date updateTime;

    private Integer stepRange;

    private Integer targetDistance;

    private Integer targetStepCount;

    private String updated;
    
    
    public MemberSettingPedometer() {
		super();
	}

	public MemberSettingPedometer(String imei) {
		super();
		this.imei = imei;
	}

	public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getStepRange() {
        return stepRange;
    }

    public void setStepRange(Integer stepRange) {
        this.stepRange = stepRange;
    }

    public Integer getTargetDistance() {
        return targetDistance;
    }

    public void setTargetDistance(Integer targetDistance) {
        this.targetDistance = targetDistance;
    }

    public Integer getTargetStepCount() {
        return targetStepCount;
    }

    public void setTargetStepCount(Integer targetStepCount) {
        this.targetStepCount = targetStepCount;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }
}