package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AngelLog;
import java.util.List;

public interface AngelLogMapper {
    int deleteByPrimaryKey(Long logId);

    int insert(AngelLog record);

    AngelLog selectByPrimaryKey(Long logId);

    List<AngelLog> selectAll();

    int updateByPrimaryKey(AngelLog record);
}