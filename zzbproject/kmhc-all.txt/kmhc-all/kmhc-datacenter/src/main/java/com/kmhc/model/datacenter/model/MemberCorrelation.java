package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberCorrelation {
    private Long memberCorrelationId;

    private Long memberEnduserId;

    private String personName1;

    private String personName2;

    private String personName3;

    private String personTel1;

    private String personTel2;

    private String personTel3;

    private String personRelation1;

    private String personRelation2;

    private String personRelation3;

    private String familyName1;

    private String familyName2;

    private String familyName3;

    private String familyTel1;

    private String familyTel2;

    private String familyTel3;

    private String familyPic1Url;

    private Integer familyPic1Status;

    private String familyPic2Url;

    private Integer familyPic2Status;

    private String familyPic3Url;

    private Integer familyPic3Status;

    private Date updatedTime;

    private Date createdTime;

    private String bloodPressure;

    private String buyFrom;

    private String callLimit;

    private String charge;

    private String electricity;

    private String emergency;

    private Date emergencyEndDate;

    private Date emergencyStartDate;

    private String emergencyYears;

    private String familyDefault;

    private String fatMeter;

    private String frimware;

    private String helpDefault;

    private String imei;

    private String location;

    private String loginId;

    private String loginPw;

    private String memberCode;

    private Date memberCreateTime;

    private String memberName;

    private Date memberUpdatedTime;

    private Integer offType;

    private String oxygen;

    private Date paymentEndDate;

    private Date paymentStartDate;

    private String productNt;

    private Date fw;

    private String psrTemp;

    private String ratesProgram;

    private String remark;

    private String sales;

    private String salesMail;

    private String salesTel;

    private String simProvided;

    private String specialSet;

    private String telSupport;

    private Date timeOff;

    private Date timeOn;

    private Date timeSync;

    private Date warrantEndDate;

    private Date warrantStartDate;

    private String warrantyYears;

    private String familypersonrelation1;

    private String familypersonrelation2;

    private String familypersonrelation3;
    
    
    public MemberCorrelation() {
		super();
	}

	public MemberCorrelation(Long memberEnduserId, Integer familyPic1Status,
			Integer familyPic2Status, Integer familyPic3Status, Date createdTime) {
		super();
		this.memberEnduserId = memberEnduserId;
		this.familyPic1Status = familyPic1Status;
		this.familyPic2Status = familyPic2Status;
		this.familyPic3Status = familyPic3Status;
		this.createdTime = createdTime;
	}

	public Long getMemberCorrelationId() {
        return memberCorrelationId;
    }

    public void setMemberCorrelationId(Long memberCorrelationId) {
        this.memberCorrelationId = memberCorrelationId;
    }

    public Long getMemberEnduserId() {
        return memberEnduserId;
    }

    public void setMemberEnduserId(Long memberEnduserId) {
        this.memberEnduserId = memberEnduserId;
    }

    public String getPersonName1() {
        return personName1;
    }

    public void setPersonName1(String personName1) {
        this.personName1 = personName1;
    }

    public String getPersonName2() {
        return personName2;
    }

    public void setPersonName2(String personName2) {
        this.personName2 = personName2;
    }

    public String getPersonName3() {
        return personName3;
    }

    public void setPersonName3(String personName3) {
        this.personName3 = personName3;
    }

    public String getPersonTel1() {
        return personTel1;
    }

    public void setPersonTel1(String personTel1) {
        this.personTel1 = personTel1;
    }

    public String getPersonTel2() {
        return personTel2;
    }

    public void setPersonTel2(String personTel2) {
        this.personTel2 = personTel2;
    }

    public String getPersonTel3() {
        return personTel3;
    }

    public void setPersonTel3(String personTel3) {
        this.personTel3 = personTel3;
    }

    public String getPersonRelation1() {
        return personRelation1;
    }

    public void setPersonRelation1(String personRelation1) {
        this.personRelation1 = personRelation1;
    }

    public String getPersonRelation2() {
        return personRelation2;
    }

    public void setPersonRelation2(String personRelation2) {
        this.personRelation2 = personRelation2;
    }

    public String getPersonRelation3() {
        return personRelation3;
    }

    public void setPersonRelation3(String personRelation3) {
        this.personRelation3 = personRelation3;
    }

    public String getFamilyName1() {
        return familyName1;
    }

    public void setFamilyName1(String familyName1) {
        this.familyName1 = familyName1;
    }

    public String getFamilyName2() {
        return familyName2;
    }

    public void setFamilyName2(String familyName2) {
        this.familyName2 = familyName2;
    }

    public String getFamilyName3() {
        return familyName3;
    }

    public void setFamilyName3(String familyName3) {
        this.familyName3 = familyName3;
    }

    public String getFamilyTel1() {
        return familyTel1;
    }

    public void setFamilyTel1(String familyTel1) {
        this.familyTel1 = familyTel1;
    }

    public String getFamilyTel2() {
        return familyTel2;
    }

    public void setFamilyTel2(String familyTel2) {
        this.familyTel2 = familyTel2;
    }

    public String getFamilyTel3() {
        return familyTel3;
    }

    public void setFamilyTel3(String familyTel3) {
        this.familyTel3 = familyTel3;
    }

    public String getFamilyPic1Url() {
        return familyPic1Url;
    }

    public void setFamilyPic1Url(String familyPic1Url) {
        this.familyPic1Url = familyPic1Url;
    }

    public Integer getFamilyPic1Status() {
        return familyPic1Status;
    }

    public void setFamilyPic1Status(Integer familyPic1Status) {
        this.familyPic1Status = familyPic1Status;
    }

    public String getFamilyPic2Url() {
        return familyPic2Url;
    }

    public void setFamilyPic2Url(String familyPic2Url) {
        this.familyPic2Url = familyPic2Url;
    }

    public Integer getFamilyPic2Status() {
        return familyPic2Status;
    }

    public void setFamilyPic2Status(Integer familyPic2Status) {
        this.familyPic2Status = familyPic2Status;
    }

    public String getFamilyPic3Url() {
        return familyPic3Url;
    }

    public void setFamilyPic3Url(String familyPic3Url) {
        this.familyPic3Url = familyPic3Url;
    }

    public Integer getFamilyPic3Status() {
        return familyPic3Status;
    }

    public void setFamilyPic3Status(Integer familyPic3Status) {
        this.familyPic3Status = familyPic3Status;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public String getBloodPressure() {
        return bloodPressure;
    }

    public void setBloodPressure(String bloodPressure) {
        this.bloodPressure = bloodPressure;
    }

    public String getBuyFrom() {
        return buyFrom;
    }

    public void setBuyFrom(String buyFrom) {
        this.buyFrom = buyFrom;
    }

    public String getCallLimit() {
        return callLimit;
    }

    public void setCallLimit(String callLimit) {
        this.callLimit = callLimit;
    }

    public String getCharge() {
        return charge;
    }

    public void setCharge(String charge) {
        this.charge = charge;
    }

    public String getElectricity() {
        return electricity;
    }

    public void setElectricity(String electricity) {
        this.electricity = electricity;
    }

    public String getEmergency() {
        return emergency;
    }

    public void setEmergency(String emergency) {
        this.emergency = emergency;
    }

    public Date getEmergencyEndDate() {
        return emergencyEndDate;
    }

    public void setEmergencyEndDate(Date emergencyEndDate) {
        this.emergencyEndDate = emergencyEndDate;
    }

    public Date getEmergencyStartDate() {
        return emergencyStartDate;
    }

    public void setEmergencyStartDate(Date emergencyStartDate) {
        this.emergencyStartDate = emergencyStartDate;
    }

    public String getEmergencyYears() {
        return emergencyYears;
    }

    public void setEmergencyYears(String emergencyYears) {
        this.emergencyYears = emergencyYears;
    }

    public String getFamilyDefault() {
        return familyDefault;
    }

    public void setFamilyDefault(String familyDefault) {
        this.familyDefault = familyDefault;
    }

    public String getFatMeter() {
        return fatMeter;
    }

    public void setFatMeter(String fatMeter) {
        this.fatMeter = fatMeter;
    }

    public String getFrimware() {
        return frimware;
    }

    public void setFrimware(String frimware) {
        this.frimware = frimware;
    }

    public String getHelpDefault() {
        return helpDefault;
    }

    public void setHelpDefault(String helpDefault) {
        this.helpDefault = helpDefault;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getLoginPw() {
        return loginPw;
    }

    public void setLoginPw(String loginPw) {
        this.loginPw = loginPw;
    }

    public String getMemberCode() {
        return memberCode;
    }

    public void setMemberCode(String memberCode) {
        this.memberCode = memberCode;
    }

    public Date getMemberCreateTime() {
        return memberCreateTime;
    }

    public void setMemberCreateTime(Date memberCreateTime) {
        this.memberCreateTime = memberCreateTime;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public Date getMemberUpdatedTime() {
        return memberUpdatedTime;
    }

    public void setMemberUpdatedTime(Date memberUpdatedTime) {
        this.memberUpdatedTime = memberUpdatedTime;
    }

    public Integer getOffType() {
        return offType;
    }

    public void setOffType(Integer offType) {
        this.offType = offType;
    }

    public String getOxygen() {
        return oxygen;
    }

    public void setOxygen(String oxygen) {
        this.oxygen = oxygen;
    }

    public Date getPaymentEndDate() {
        return paymentEndDate;
    }

    public void setPaymentEndDate(Date paymentEndDate) {
        this.paymentEndDate = paymentEndDate;
    }

    public Date getPaymentStartDate() {
        return paymentStartDate;
    }

    public void setPaymentStartDate(Date paymentStartDate) {
        this.paymentStartDate = paymentStartDate;
    }

    public String getProductNt() {
        return productNt;
    }

    public void setProductNt(String productNt) {
        this.productNt = productNt;
    }

    public Date getFw() {
        return fw;
    }

    public void setFw(Date fw) {
        this.fw = fw;
    }

    public String getPsrTemp() {
        return psrTemp;
    }

    public void setPsrTemp(String psrTemp) {
        this.psrTemp = psrTemp;
    }

    public String getRatesProgram() {
        return ratesProgram;
    }

    public void setRatesProgram(String ratesProgram) {
        this.ratesProgram = ratesProgram;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getSales() {
        return sales;
    }

    public void setSales(String sales) {
        this.sales = sales;
    }

    public String getSalesMail() {
        return salesMail;
    }

    public void setSalesMail(String salesMail) {
        this.salesMail = salesMail;
    }

    public String getSalesTel() {
        return salesTel;
    }

    public void setSalesTel(String salesTel) {
        this.salesTel = salesTel;
    }

    public String getSimProvided() {
        return simProvided;
    }

    public void setSimProvided(String simProvided) {
        this.simProvided = simProvided;
    }

    public String getSpecialSet() {
        return specialSet;
    }

    public void setSpecialSet(String specialSet) {
        this.specialSet = specialSet;
    }

    public String getTelSupport() {
        return telSupport;
    }

    public void setTelSupport(String telSupport) {
        this.telSupport = telSupport;
    }

    public Date getTimeOff() {
        return timeOff;
    }

    public void setTimeOff(Date timeOff) {
        this.timeOff = timeOff;
    }

    public Date getTimeOn() {
        return timeOn;
    }

    public void setTimeOn(Date timeOn) {
        this.timeOn = timeOn;
    }

    public Date getTimeSync() {
        return timeSync;
    }

    public void setTimeSync(Date timeSync) {
        this.timeSync = timeSync;
    }

    public Date getWarrantEndDate() {
        return warrantEndDate;
    }

    public void setWarrantEndDate(Date warrantEndDate) {
        this.warrantEndDate = warrantEndDate;
    }

    public Date getWarrantStartDate() {
        return warrantStartDate;
    }

    public void setWarrantStartDate(Date warrantStartDate) {
        this.warrantStartDate = warrantStartDate;
    }

    public String getWarrantyYears() {
        return warrantyYears;
    }

    public void setWarrantyYears(String warrantyYears) {
        this.warrantyYears = warrantyYears;
    }

    public String getFamilypersonrelation1() {
        return familypersonrelation1;
    }

    public void setFamilypersonrelation1(String familypersonrelation1) {
        this.familypersonrelation1 = familypersonrelation1;
    }

    public String getFamilypersonrelation2() {
        return familypersonrelation2;
    }

    public void setFamilypersonrelation2(String familypersonrelation2) {
        this.familypersonrelation2 = familypersonrelation2;
    }

    public String getFamilypersonrelation3() {
        return familypersonrelation3;
    }

    public void setFamilypersonrelation3(String familypersonrelation3) {
        this.familypersonrelation3 = familypersonrelation3;
    }
}