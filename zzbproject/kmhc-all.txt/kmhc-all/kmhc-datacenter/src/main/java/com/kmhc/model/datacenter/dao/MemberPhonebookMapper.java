package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberPhonebook;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface MemberPhonebookMapper {
    int deleteByPrimaryKey(@Param("imei") String imei, @Param("itemno") Short itemno);

    int insert(MemberPhonebook record);

    MemberPhonebook selectByPrimaryKey(@Param("imei") String imei, @Param("itemno") Short itemno);

    List<MemberPhonebook> selectAll();

    int updateByPrimaryKey(MemberPhonebook record);
}