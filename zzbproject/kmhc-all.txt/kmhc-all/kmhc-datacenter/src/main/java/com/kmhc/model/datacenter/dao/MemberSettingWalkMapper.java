package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingWalk;
import java.util.List;

public interface MemberSettingWalkMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingWalk record);

    MemberSettingWalk selectByPrimaryKey(String imei);

    List<MemberSettingWalk> selectAll();

    int updateByPrimaryKey(MemberSettingWalk record);
}