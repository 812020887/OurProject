package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingAutochange {
    private Long memberId;

    private String type;

    private Short value;

    private Short oldValue;

    private Date startTime;

    private Date endTime;

    private String weekly;

    private Byte changed;

    private Date changedTime;

    private Byte status;

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Short getValue() {
        return value;
    }

    public void setValue(Short value) {
        this.value = value;
    }

    public Short getOldValue() {
        return oldValue;
    }

    public void setOldValue(Short oldValue) {
        this.oldValue = oldValue;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getWeekly() {
        return weekly;
    }

    public void setWeekly(String weekly) {
        this.weekly = weekly;
    }

    public Byte getChanged() {
        return changed;
    }

    public void setChanged(Byte changed) {
        this.changed = changed;
    }

    public Date getChangedTime() {
        return changedTime;
    }

    public void setChangedTime(Date changedTime) {
        this.changedTime = changedTime;
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }
}