package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AngelOrder;
import java.util.List;

public interface AngelOrderMapper {
    int deleteByPrimaryKey(Long orderId);

    int insert(AngelOrder record);

    AngelOrder selectByPrimaryKey(Long orderId);

    List<AngelOrder> selectAll();

    int updateByPrimaryKey(AngelOrder record);
}