package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.EmgI;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("emgIMapper")
public interface EmgIMapper {
    int deleteByPrimaryKey(@Param("emgDetailKey") String emgDetailKey, @Param("itemno") Short itemno);

    int insert(EmgI record);
    
    int insertSelective(EmgI record);

    EmgI selectByPrimaryKey(@Param("emgDetailKey") String emgDetailKey, @Param("itemno") Short itemno);

    List<EmgI> selectAll();

    int updateByPrimaryKey(EmgI record);

    int insertList(List<EmgI> emgIList);
}