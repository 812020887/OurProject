package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrBloodpressure;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("psrBloodpressureMapper")
public interface PsrBloodpressureMapper {
	int deleteByPrimaryKey(@Param("sno") Integer sno, @Param("imei") String imei);

	int insert(PsrBloodpressure record);

	PsrBloodpressure selectByPrimaryKey(@Param("sno") Integer sno, @Param("imei") String imei);

	List<PsrBloodpressure> selectAll();

	int updateByPrimaryKey(PsrBloodpressure record);

	List<PsrBloodpressure> selectAllByImei(@Param("imei") String imei);

	List<PsrBloodpressure> selectCountDataByImei(@Param("imei") String imei, @Param("count") Integer count,
			@Param("index") Integer index);
	
	List<PsrBloodpressure> selectByDuring(@Param("imei") String imei, @Param("start") String start,
			@Param("end") String end);
	
	int selectByBpTime(PsrBloodpressure record);
}