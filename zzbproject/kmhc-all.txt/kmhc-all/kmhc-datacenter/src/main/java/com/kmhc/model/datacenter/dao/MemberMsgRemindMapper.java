package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberMsgRemind;
import java.util.List;

public interface MemberMsgRemindMapper {
    int deleteByPrimaryKey(Integer msgRemindId);

    int insert(MemberMsgRemind record);

    MemberMsgRemind selectByPrimaryKey(Integer msgRemindId);

    List<MemberMsgRemind> selectAll();

    int updateByPrimaryKey(MemberMsgRemind record);
}