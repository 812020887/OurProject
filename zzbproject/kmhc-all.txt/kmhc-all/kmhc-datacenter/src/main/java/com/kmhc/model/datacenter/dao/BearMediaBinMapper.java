package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.BearMediaBin;
import java.util.List;

public interface BearMediaBinMapper {
    int deleteByPrimaryKey(Long binId);

    int insert(BearMediaBin record);

    BearMediaBin selectByPrimaryKey(Long binId);

    List<BearMediaBin> selectAll();

    int updateByPrimaryKey(BearMediaBin record);
}