package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PrITemp;
import java.util.List;

public interface PrITempMapper {
    int insert(PrITemp record);

    List<PrITemp> selectAll();
}