package com.kmhc.model.datacenter.model;

public class AuthMapGkeySupplier {
    private Long sno;

    private Long gkeyId;

    private Long supplierId;

    private Byte enable;

    public Long getSno() {
        return sno;
    }

    public void setSno(Long sno) {
        this.sno = sno;
    }

    public Long getGkeyId() {
        return gkeyId;
    }

    public void setGkeyId(Long gkeyId) {
        this.gkeyId = gkeyId;
    }

    public Long getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Long supplierId) {
        this.supplierId = supplierId;
    }

    public Byte getEnable() {
        return enable;
    }

    public void setEnable(Byte enable) {
        this.enable = enable;
    }
}