package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingWeight {
    private String imei;

    private Date updateTime;

    private Integer sex;

    private Integer year;

    private Integer height;

    private Integer weight;

    private Integer targetWeight;

    private Integer bodyfat;

    private Integer targetFat;

    private String updated;

    private String allergies;

    private String medicalconditions;

    private String additionalcomments;

    private String reactiontypes;
    
    
    public MemberSettingWeight() {
		super();
	}

	public MemberSettingWeight(String imei) {
		super();
		this.imei = imei;
	}

	public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public Integer getTargetWeight() {
        return targetWeight;
    }

    public void setTargetWeight(Integer targetWeight) {
        this.targetWeight = targetWeight;
    }

    public Integer getBodyfat() {
        return bodyfat;
    }

    public void setBodyfat(Integer bodyfat) {
        this.bodyfat = bodyfat;
    }

    public Integer getTargetFat() {
        return targetFat;
    }

    public void setTargetFat(Integer targetFat) {
        this.targetFat = targetFat;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    public String getAllergies() {
        return allergies;
    }

    public void setAllergies(String allergies) {
        this.allergies = allergies;
    }

    public String getMedicalconditions() {
        return medicalconditions;
    }

    public void setMedicalconditions(String medicalconditions) {
        this.medicalconditions = medicalconditions;
    }

    public String getAdditionalcomments() {
        return additionalcomments;
    }

    public void setAdditionalcomments(String additionalcomments) {
        this.additionalcomments = additionalcomments;
    }

    public String getReactiontypes() {
        return reactiontypes;
    }

    public void setReactiontypes(String reactiontypes) {
        this.reactiontypes = reactiontypes;
    }
}