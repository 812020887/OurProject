package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberMsgVoicechannel;
import java.util.List;

public interface MemberMsgVoicechannelMapper {
    int deleteByPrimaryKey(Long voiceId);

    int insert(MemberMsgVoicechannel record);

    MemberMsgVoicechannel selectByPrimaryKey(Long voiceId);

    List<MemberMsgVoicechannel> selectAll();

    int updateByPrimaryKey(MemberMsgVoicechannel record);
}