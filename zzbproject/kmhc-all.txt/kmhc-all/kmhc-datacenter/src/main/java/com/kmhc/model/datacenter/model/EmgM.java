package com.kmhc.model.datacenter.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class EmgM {
    private String emgKey;

    private String imei;

    private String imsi;

    private String type;

    private String emgDetailKey;

    private Date emgDate;

    private Date fwDate;

    private Integer powerOffType;

    private Integer voltage;

    private String callerId;

    private Short cellidCount;

    private String mcc;

    private String mnc;

    private String lac;

    private Integer cellid;

    private Short rssi;

    private String gpsNsLat;

    private BigDecimal gpsLat;

    private String gpsEwLng;

    private BigDecimal gpsLng;

    private String address;

    private String myGpsNsLat;

    private BigDecimal myGpsLat;

    private String myGpsEwLng;

    private BigDecimal myGpsLng;

    private String wifiMac1;

    private Short wifiSignal1;

    private Short wifiChannel1;

    private Short wifiRatio1;

    private String wifiMac2;

    private Short wifiSignal2;

    private Short wifiChannel2;

    private Short wifiRatio2;

    private String wifiMac3;

    private Short wifiSignal3;

    private Short wifiChannel3;

    private Short wifiRatio3;

    private String locStatus;

    private String isvalid;

    private Date createDate;

    private Date updateDate;

    private BigDecimal wifiLat;

    private BigDecimal wifiLng;

    private String wifiStatus;

    private BigDecimal mcellLat;

    private BigDecimal mcellLng;

    private String mcellStatus;

    private String myAddress;

    private String wifiAddress;

    private String mcellAddress;

    private Double hpe;

    private String wifiMac4;

    private Short wifiSignal4;

    private Short wifiChannel4;

    private Short wifiRatio4;

    private String wifiMac5;

    private Short wifiSignal5;

    private Short wifiChannel5;

    private Short wifiRatio5;

    private String wifiMac6;

    private Short wifiSignal6;

    private Short wifiChannel6;

    private Short wifiRatio6;

    private String wifiMac7;

    private Short wifiSignal7;

    private Short wifiChannel7;

    private Short wifiRatio7;

    private String wifiMac8;

    private Short wifiSignal8;

    private Short wifiChannel8;

    private Short wifiRatio8;

    private String wifiMac9;

    private Short wifiSignal9;

    private Short wifiChannel9;

    private Short wifiRatio9;

    private String wifiMac10;

    private Short wifiSignal10;

    private Short wifiChannel10;

    private Short wifiRatio10;

    private Cell cell ;
    
    private List<Cell> cells ;
    
    private String locType ;
    
    public String getEmgKey() {
        return emgKey;
    }

    public void setEmgKey(String emgKey) {
        this.emgKey = emgKey;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEmgDetailKey() {
        return emgDetailKey;
    }

    public void setEmgDetailKey(String emgDetailKey) {
        this.emgDetailKey = emgDetailKey;
    }

    public Date getEmgDate() {
        return emgDate;
    }

    public void setEmgDate(Date emgDate) {
        this.emgDate = emgDate;
    }

    public Date getFwDate() {
        return fwDate;
    }

    public void setFwDate(Date fwDate) {
        this.fwDate = fwDate;
    }

    public Integer getPowerOffType() {
        return powerOffType;
    }

    public void setPowerOffType(Integer powerOffType) {
        this.powerOffType = powerOffType;
    }

    public Integer getVoltage() {
        return voltage;
    }

    public void setVoltage(Integer voltage) {
        this.voltage = voltage;
    }

    public String getCallerId() {
        return callerId;
    }

    public void setCallerId(String callerId) {
        this.callerId = callerId;
    }

    public Short getCellidCount() {
        return cellidCount;
    }

    public void setCellidCount(Short cellidCount) {
        this.cellidCount = cellidCount;
    }

    public String getMcc() {
        return mcc;
    }

    public void setMcc(String mcc) {
        this.mcc = mcc;
    }

    public String getMnc() {
        return mnc;
    }

    public void setMnc(String mnc) {
        this.mnc = mnc;
    }

    public String getLac() {
        return lac;
    }

    public void setLac(String lac) {
        this.lac = lac;
    }

    public Integer getCellid() {
        return cellid;
    }

    public void setCellid(Integer cellid) {
        this.cellid = cellid;
    }

    public Short getRssi() {
        return rssi;
    }

    public void setRssi(Short rssi) {
        this.rssi = rssi;
    }

    public String getGpsNsLat() {
        return gpsNsLat;
    }

    public void setGpsNsLat(String gpsNsLat) {
        this.gpsNsLat = gpsNsLat;
    }

    public BigDecimal getGpsLat() {
        return gpsLat;
    }

    public void setGpsLat(BigDecimal gpsLat) {
        this.gpsLat = gpsLat;
    }

    public String getGpsEwLng() {
        return gpsEwLng;
    }

    public void setGpsEwLng(String gpsEwLng) {
        this.gpsEwLng = gpsEwLng;
    }

    public BigDecimal getGpsLng() {
        return gpsLng;
    }

    public void setGpsLng(BigDecimal gpsLng) {
        this.gpsLng = gpsLng;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMyGpsNsLat() {
        return myGpsNsLat;
    }

    public void setMyGpsNsLat(String myGpsNsLat) {
        this.myGpsNsLat = myGpsNsLat;
    }

    public BigDecimal getMyGpsLat() {
        return myGpsLat;
    }

    public void setMyGpsLat(BigDecimal myGpsLat) {
        this.myGpsLat = myGpsLat;
    }

    public String getMyGpsEwLng() {
        return myGpsEwLng;
    }

    public void setMyGpsEwLng(String myGpsEwLng) {
        this.myGpsEwLng = myGpsEwLng;
    }

    public BigDecimal getMyGpsLng() {
        return myGpsLng;
    }

    public void setMyGpsLng(BigDecimal myGpsLng) {
        this.myGpsLng = myGpsLng;
    }

    public String getWifiMac1() {
        return wifiMac1;
    }

    public void setWifiMac1(String wifiMac1) {
        this.wifiMac1 = wifiMac1;
    }

    public Short getWifiSignal1() {
        return wifiSignal1;
    }

    public void setWifiSignal1(Short wifiSignal1) {
        this.wifiSignal1 = wifiSignal1;
    }

    public Short getWifiChannel1() {
        return wifiChannel1;
    }

    public void setWifiChannel1(Short wifiChannel1) {
        this.wifiChannel1 = wifiChannel1;
    }

    public Short getWifiRatio1() {
        return wifiRatio1;
    }

    public void setWifiRatio1(Short wifiRatio1) {
        this.wifiRatio1 = wifiRatio1;
    }

    public String getWifiMac2() {
        return wifiMac2;
    }

    public void setWifiMac2(String wifiMac2) {
        this.wifiMac2 = wifiMac2;
    }

    public Short getWifiSignal2() {
        return wifiSignal2;
    }

    public void setWifiSignal2(Short wifiSignal2) {
        this.wifiSignal2 = wifiSignal2;
    }

    public Short getWifiChannel2() {
        return wifiChannel2;
    }

    public void setWifiChannel2(Short wifiChannel2) {
        this.wifiChannel2 = wifiChannel2;
    }

    public Short getWifiRatio2() {
        return wifiRatio2;
    }

    public void setWifiRatio2(Short wifiRatio2) {
        this.wifiRatio2 = wifiRatio2;
    }

    public String getWifiMac3() {
        return wifiMac3;
    }

    public void setWifiMac3(String wifiMac3) {
        this.wifiMac3 = wifiMac3;
    }

    public Short getWifiSignal3() {
        return wifiSignal3;
    }

    public void setWifiSignal3(Short wifiSignal3) {
        this.wifiSignal3 = wifiSignal3;
    }

    public Short getWifiChannel3() {
        return wifiChannel3;
    }

    public void setWifiChannel3(Short wifiChannel3) {
        this.wifiChannel3 = wifiChannel3;
    }

    public Short getWifiRatio3() {
        return wifiRatio3;
    }

    public void setWifiRatio3(Short wifiRatio3) {
        this.wifiRatio3 = wifiRatio3;
    }

    public String getLocStatus() {
        return locStatus;
    }

    public void setLocStatus(String locStatus) {
        this.locStatus = locStatus;
    }

    public String getIsvalid() {
        return isvalid;
    }

    public void setIsvalid(String isvalid) {
        this.isvalid = isvalid;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public BigDecimal getWifiLat() {
        return wifiLat;
    }

    public void setWifiLat(BigDecimal wifiLat) {
        this.wifiLat = wifiLat;
    }

    public BigDecimal getWifiLng() {
        return wifiLng;
    }

    public void setWifiLng(BigDecimal wifiLng) {
        this.wifiLng = wifiLng;
    }

    public String getWifiStatus() {
        return wifiStatus;
    }

    public void setWifiStatus(String wifiStatus) {
        this.wifiStatus = wifiStatus;
    }

    public BigDecimal getMcellLat() {
        return mcellLat;
    }

    public void setMcellLat(BigDecimal mcellLat) {
        this.mcellLat = mcellLat;
    }

    public BigDecimal getMcellLng() {
        return mcellLng;
    }

    public void setMcellLng(BigDecimal mcellLng) {
        this.mcellLng = mcellLng;
    }

    public String getMcellStatus() {
        return mcellStatus;
    }

    public void setMcellStatus(String mcellStatus) {
        this.mcellStatus = mcellStatus;
    }

    public String getMyAddress() {
        return myAddress;
    }

    public void setMyAddress(String myAddress) {
        this.myAddress = myAddress;
    }

    public String getWifiAddress() {
        return wifiAddress;
    }

    public void setWifiAddress(String wifiAddress) {
        this.wifiAddress = wifiAddress;
    }

    public String getMcellAddress() {
        return mcellAddress;
    }

    public void setMcellAddress(String mcellAddress) {
        this.mcellAddress = mcellAddress;
    }

    public Double getHpe() {
        return hpe;
    }

    public void setHpe(Double hpe) {
        this.hpe = hpe;
    }

    public String getWifiMac4() {
        return wifiMac4;
    }

    public void setWifiMac4(String wifiMac4) {
        this.wifiMac4 = wifiMac4;
    }

    public Short getWifiSignal4() {
        return wifiSignal4;
    }

    public void setWifiSignal4(Short wifiSignal4) {
        this.wifiSignal4 = wifiSignal4;
    }

    public Short getWifiChannel4() {
        return wifiChannel4;
    }

    public void setWifiChannel4(Short wifiChannel4) {
        this.wifiChannel4 = wifiChannel4;
    }

    public Short getWifiRatio4() {
        return wifiRatio4;
    }

    public void setWifiRatio4(Short wifiRatio4) {
        this.wifiRatio4 = wifiRatio4;
    }

    public String getWifiMac5() {
        return wifiMac5;
    }

    public void setWifiMac5(String wifiMac5) {
        this.wifiMac5 = wifiMac5;
    }

    public Short getWifiSignal5() {
        return wifiSignal5;
    }

    public void setWifiSignal5(Short wifiSignal5) {
        this.wifiSignal5 = wifiSignal5;
    }

    public Short getWifiChannel5() {
        return wifiChannel5;
    }

    public void setWifiChannel5(Short wifiChannel5) {
        this.wifiChannel5 = wifiChannel5;
    }

    public Short getWifiRatio5() {
        return wifiRatio5;
    }

    public void setWifiRatio5(Short wifiRatio5) {
        this.wifiRatio5 = wifiRatio5;
    }

    public String getWifiMac6() {
        return wifiMac6;
    }

    public void setWifiMac6(String wifiMac6) {
        this.wifiMac6 = wifiMac6;
    }

    public Short getWifiSignal6() {
        return wifiSignal6;
    }

    public void setWifiSignal6(Short wifiSignal6) {
        this.wifiSignal6 = wifiSignal6;
    }

    public Short getWifiChannel6() {
        return wifiChannel6;
    }

    public void setWifiChannel6(Short wifiChannel6) {
        this.wifiChannel6 = wifiChannel6;
    }

    public Short getWifiRatio6() {
        return wifiRatio6;
    }

    public void setWifiRatio6(Short wifiRatio6) {
        this.wifiRatio6 = wifiRatio6;
    }

    public String getWifiMac7() {
        return wifiMac7;
    }

    public void setWifiMac7(String wifiMac7) {
        this.wifiMac7 = wifiMac7;
    }

    public Short getWifiSignal7() {
        return wifiSignal7;
    }

    public void setWifiSignal7(Short wifiSignal7) {
        this.wifiSignal7 = wifiSignal7;
    }

    public Short getWifiChannel7() {
        return wifiChannel7;
    }

    public void setWifiChannel7(Short wifiChannel7) {
        this.wifiChannel7 = wifiChannel7;
    }

    public Short getWifiRatio7() {
        return wifiRatio7;
    }

    public void setWifiRatio7(Short wifiRatio7) {
        this.wifiRatio7 = wifiRatio7;
    }

    public String getWifiMac8() {
        return wifiMac8;
    }

    public void setWifiMac8(String wifiMac8) {
        this.wifiMac8 = wifiMac8;
    }

    public Short getWifiSignal8() {
        return wifiSignal8;
    }

    public void setWifiSignal8(Short wifiSignal8) {
        this.wifiSignal8 = wifiSignal8;
    }

    public Short getWifiChannel8() {
        return wifiChannel8;
    }

    public void setWifiChannel8(Short wifiChannel8) {
        this.wifiChannel8 = wifiChannel8;
    }

    public Short getWifiRatio8() {
        return wifiRatio8;
    }

    public void setWifiRatio8(Short wifiRatio8) {
        this.wifiRatio8 = wifiRatio8;
    }

    public String getWifiMac9() {
        return wifiMac9;
    }

    public void setWifiMac9(String wifiMac9) {
        this.wifiMac9 = wifiMac9;
    }

    public Short getWifiSignal9() {
        return wifiSignal9;
    }

    public void setWifiSignal9(Short wifiSignal9) {
        this.wifiSignal9 = wifiSignal9;
    }

    public Short getWifiChannel9() {
        return wifiChannel9;
    }

    public void setWifiChannel9(Short wifiChannel9) {
        this.wifiChannel9 = wifiChannel9;
    }

    public Short getWifiRatio9() {
        return wifiRatio9;
    }

    public void setWifiRatio9(Short wifiRatio9) {
        this.wifiRatio9 = wifiRatio9;
    }

    public String getWifiMac10() {
        return wifiMac10;
    }

    public void setWifiMac10(String wifiMac10) {
        this.wifiMac10 = wifiMac10;
    }

    public Short getWifiSignal10() {
        return wifiSignal10;
    }

    public void setWifiSignal10(Short wifiSignal10) {
        this.wifiSignal10 = wifiSignal10;
    }

    public Short getWifiChannel10() {
        return wifiChannel10;
    }

    public void setWifiChannel10(Short wifiChannel10) {
        this.wifiChannel10 = wifiChannel10;
    }

    public Short getWifiRatio10() {
        return wifiRatio10;
    }

    public void setWifiRatio10(Short wifiRatio10) {
        this.wifiRatio10 = wifiRatio10;
    }

    public Cell getCell() {
        return cell;
    }

    public void setCell(Cell cell) {
        this.cell = cell;
    }

    public List<Cell> getCells() {
        return cells;
    }

    public void setCells(List<Cell> cells) {
        this.cells = cells;
    }

	public String getLocType() {
		return locType;
	}

	public void setLocType(String locType) {
		this.locType = locType;
	}
    
}