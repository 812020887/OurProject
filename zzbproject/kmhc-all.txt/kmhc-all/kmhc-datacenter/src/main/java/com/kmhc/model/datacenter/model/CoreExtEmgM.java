package com.kmhc.model.datacenter.model;

public class CoreExtEmgM {
    private String emgKey;

    private String imei;

    private Double voltagePercent;

    public String getEmgKey() {
        return emgKey;
    }

    public void setEmgKey(String emgKey) {
        this.emgKey = emgKey;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Double getVoltagePercent() {
        return voltagePercent;
    }

    public void setVoltagePercent(Double voltagePercent) {
        this.voltagePercent = voltagePercent;
    }
}