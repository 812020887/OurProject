package com.kmhc.model.datacenter.model;

import java.math.BigDecimal;
import java.util.Date;

public class MemberSettingLeavehome {
    private String imei;

    private Date updateTime;

    private Short number;

    private Date startTime;

    private Date endTime;

    private BigDecimal longitude;

    private BigDecimal latitude;

    private Integer radius;

    private String address;

    private String updated;

    private Short t1Hex;

    private Short t2Hex;

    private Short t3Hex;

    private Short t4Hex;

    private Short t5Hex;

    private Short t6Hex;

    private Short t7Hex;

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Short getNumber() {
        return number;
    }

    public void setNumber(Short number) {
        this.number = number;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public Integer getRadius() {
        return radius;
    }

    public void setRadius(Integer radius) {
        this.radius = radius;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    public Short getT1Hex() {
        return t1Hex;
    }

    public void setT1Hex(Short t1Hex) {
        this.t1Hex = t1Hex;
    }

    public Short getT2Hex() {
        return t2Hex;
    }

    public void setT2Hex(Short t2Hex) {
        this.t2Hex = t2Hex;
    }

    public Short getT3Hex() {
        return t3Hex;
    }

    public void setT3Hex(Short t3Hex) {
        this.t3Hex = t3Hex;
    }

    public Short getT4Hex() {
        return t4Hex;
    }

    public void setT4Hex(Short t4Hex) {
        this.t4Hex = t4Hex;
    }

    public Short getT5Hex() {
        return t5Hex;
    }

    public void setT5Hex(Short t5Hex) {
        this.t5Hex = t5Hex;
    }

    public Short getT6Hex() {
        return t6Hex;
    }

    public void setT6Hex(Short t6Hex) {
        this.t6Hex = t6Hex;
    }

    public Short getT7Hex() {
        return t7Hex;
    }

    public void setT7Hex(Short t7Hex) {
        this.t7Hex = t7Hex;
    }
}