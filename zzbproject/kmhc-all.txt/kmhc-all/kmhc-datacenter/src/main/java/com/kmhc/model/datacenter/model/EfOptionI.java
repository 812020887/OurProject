package com.kmhc.model.datacenter.model;

import java.math.BigDecimal;
import java.util.Date;

public class EfOptionI {
    private String batchDetailKey;

    private BigDecimal temp = new BigDecimal(0.0);

    private Float pa = 0.0f;

    private String gpsNsLat;

    private BigDecimal gpsLat;

    private String gpsEwLng;

    private BigDecimal gpsLng;

    private String wifiMac ;

    private Short wifiSignal = 0;

    private Short wifiChannel = 0;

    private Short wifiRatio = 0;

    private Integer gSensorAvg = 0;

    private Integer gSensorMax = 0;

    private Integer gyroSensorAvg = 0;

    private Integer gyroSensorMax = 0;

    private String address = "";

    private String locStatus = "N";

    private String isvalid = "Y";

    private Date createDate;

    private Date updateDate;

    private BigDecimal wifiLat = new BigDecimal(0.0);

    private BigDecimal wifiLng = new BigDecimal(0.0);

    private String wifiStatus;

    private String wifiAddress = "";

    private String wifiMac2 ;

    private Short wifiSignal2 = 0;

    private Short wifiChannel2 = 0;

    private Short wifiRatio2 = 0;

    private String wifiMac3;

    private Short wifiSignal3 = 0;

    private Short wifiChannel3 = 0;

    private Short wifiRatio3 = 0;

    private String wifiMac4;

    private Short wifiSignal4 = 0;

    private Short wifiChannel4 = 0;

    private Short wifiRatio4 = 0;

    private String wifiMac5;

    private Short wifiSignal5 = 0;

    private Short wifiChannel5 = 0;

    private Short wifiRatio5 = 0;

    private String wifiMac6;

    private Short wifiSignal6 = 0;

    private Short wifiChannel6 = 0;

    private Short wifiRatio6 = 0;

    private String wifiMac7;

    private Short wifiSignal7 = 0;

    private Short wifiChannel7 = 0;

    private Short wifiRatio7 = 0;

    private String wifiMac8;

    private Short wifiSignal8 = 0;

    private Short wifiChannel8 = 0;

    private Short wifiRatio8 = 0;

    private String wifiMac9;

    private Short wifiSignal9 = 0;

    private Short wifiChannel9 = 0;

    private Short wifiRatio9 = 0;

    private String wifiMac10;

    private Short wifiSignal10 = 0;

    private Short wifiChannel10 = 0;

    private Short wifiRatio10 = 0;

    public String getBatchDetailKey() {
        return batchDetailKey;
    }

    public void setBatchDetailKey(String batchDetailKey) {
        this.batchDetailKey = batchDetailKey;
    }

    public BigDecimal getTemp() {
        return temp;
    }

    public void setTemp(BigDecimal temp) {
        this.temp = temp;
    }

    public Float getPa() {
        return pa;
    }

    public void setPa(Float pa) {
        this.pa = pa;
    }

    public String getGpsNsLat() {
        return gpsNsLat;
    }

    public void setGpsNsLat(String gpsNsLat) {
        this.gpsNsLat = gpsNsLat;
    }

    public BigDecimal getGpsLat() {
        return gpsLat;
    }

    public void setGpsLat(BigDecimal gpsLat) {
        this.gpsLat = gpsLat;
    }

    public String getGpsEwLng() {
        return gpsEwLng;
    }

    public void setGpsEwLng(String gpsEwLng) {
        this.gpsEwLng = gpsEwLng;
    }

    public BigDecimal getGpsLng() {
        return gpsLng;
    }

    public void setGpsLng(BigDecimal gpsLng) {
        this.gpsLng = gpsLng;
    }

    public String getWifiMac() {
        return wifiMac;
    }

    public void setWifiMac(String wifiMac) {
        this.wifiMac = wifiMac;
    }

    public Short getWifiSignal() {
        return wifiSignal;
    }

    public void setWifiSignal(Short wifiSignal) {
        this.wifiSignal = wifiSignal;
    }

    public Short getWifiChannel() {
        return wifiChannel;
    }

    public void setWifiChannel(Short wifiChannel) {
        this.wifiChannel = wifiChannel;
    }

    public Short getWifiRatio() {
        return wifiRatio;
    }

    public void setWifiRatio(Short wifiRatio) {
        this.wifiRatio = wifiRatio;
    }

    public Integer getgSensorAvg() {
        return gSensorAvg;
    }

    public void setgSensorAvg(Integer gSensorAvg) {
        this.gSensorAvg = gSensorAvg;
    }

    public Integer getgSensorMax() {
        return gSensorMax;
    }

    public void setgSensorMax(Integer gSensorMax) {
        this.gSensorMax = gSensorMax;
    }

    public Integer getGyroSensorAvg() {
        return gyroSensorAvg;
    }

    public void setGyroSensorAvg(Integer gyroSensorAvg) {
        this.gyroSensorAvg = gyroSensorAvg;
    }

    public Integer getGyroSensorMax() {
        return gyroSensorMax;
    }

    public void setGyroSensorMax(Integer gyroSensorMax) {
        this.gyroSensorMax = gyroSensorMax;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLocStatus() {
        return locStatus;
    }

    public void setLocStatus(String locStatus) {
        this.locStatus = locStatus;
    }

    public String getIsvalid() {
        return isvalid;
    }

    public void setIsvalid(String isvalid) {
        this.isvalid = isvalid;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public BigDecimal getWifiLat() {
        return wifiLat;
    }

    public void setWifiLat(BigDecimal wifiLat) {
        this.wifiLat = wifiLat;
    }

    public BigDecimal getWifiLng() {
        return wifiLng;
    }

    public void setWifiLng(BigDecimal wifiLng) {
        this.wifiLng = wifiLng;
    }

    public String getWifiStatus() {
        return wifiStatus;
    }

    public void setWifiStatus(String wifiStatus) {
        this.wifiStatus = wifiStatus;
    }

    public String getWifiAddress() {
        return wifiAddress;
    }

    public void setWifiAddress(String wifiAddress) {
        this.wifiAddress = wifiAddress;
    }

    public String getWifiMac2() {
        return wifiMac2;
    }

    public void setWifiMac2(String wifiMac2) {
        this.wifiMac2 = wifiMac2;
    }

    public Short getWifiSignal2() {
        return wifiSignal2;
    }

    public void setWifiSignal2(Short wifiSignal2) {
        this.wifiSignal2 = wifiSignal2;
    }

    public Short getWifiChannel2() {
        return wifiChannel2;
    }

    public void setWifiChannel2(Short wifiChannel2) {
        this.wifiChannel2 = wifiChannel2;
    }

    public Short getWifiRatio2() {
        return wifiRatio2;
    }

    public void setWifiRatio2(Short wifiRatio2) {
        this.wifiRatio2 = wifiRatio2;
    }

    public String getWifiMac3() {
        return wifiMac3;
    }

    public void setWifiMac3(String wifiMac3) {
        this.wifiMac3 = wifiMac3;
    }

    public Short getWifiSignal3() {
        return wifiSignal3;
    }

    public void setWifiSignal3(Short wifiSignal3) {
        this.wifiSignal3 = wifiSignal3;
    }

    public Short getWifiChannel3() {
        return wifiChannel3;
    }

    public void setWifiChannel3(Short wifiChannel3) {
        this.wifiChannel3 = wifiChannel3;
    }

    public Short getWifiRatio3() {
        return wifiRatio3;
    }

    public void setWifiRatio3(Short wifiRatio3) {
        this.wifiRatio3 = wifiRatio3;
    }

    public String getWifiMac4() {
        return wifiMac4;
    }

    public void setWifiMac4(String wifiMac4) {
        this.wifiMac4 = wifiMac4;
    }

    public Short getWifiSignal4() {
        return wifiSignal4;
    }

    public void setWifiSignal4(Short wifiSignal4) {
        this.wifiSignal4 = wifiSignal4;
    }

    public Short getWifiChannel4() {
        return wifiChannel4;
    }

    public void setWifiChannel4(Short wifiChannel4) {
        this.wifiChannel4 = wifiChannel4;
    }

    public Short getWifiRatio4() {
        return wifiRatio4;
    }

    public void setWifiRatio4(Short wifiRatio4) {
        this.wifiRatio4 = wifiRatio4;
    }

    public String getWifiMac5() {
        return wifiMac5;
    }

    public void setWifiMac5(String wifiMac5) {
        this.wifiMac5 = wifiMac5;
    }

    public Short getWifiSignal5() {
        return wifiSignal5;
    }

    public void setWifiSignal5(Short wifiSignal5) {
        this.wifiSignal5 = wifiSignal5;
    }

    public Short getWifiChannel5() {
        return wifiChannel5;
    }

    public void setWifiChannel5(Short wifiChannel5) {
        this.wifiChannel5 = wifiChannel5;
    }

    public Short getWifiRatio5() {
        return wifiRatio5;
    }

    public void setWifiRatio5(Short wifiRatio5) {
        this.wifiRatio5 = wifiRatio5;
    }

    public String getWifiMac6() {
        return wifiMac6;
    }

    public void setWifiMac6(String wifiMac6) {
        this.wifiMac6 = wifiMac6;
    }

    public Short getWifiSignal6() {
        return wifiSignal6;
    }

    public void setWifiSignal6(Short wifiSignal6) {
        this.wifiSignal6 = wifiSignal6;
    }

    public Short getWifiChannel6() {
        return wifiChannel6;
    }

    public void setWifiChannel6(Short wifiChannel6) {
        this.wifiChannel6 = wifiChannel6;
    }

    public Short getWifiRatio6() {
        return wifiRatio6;
    }

    public void setWifiRatio6(Short wifiRatio6) {
        this.wifiRatio6 = wifiRatio6;
    }

    public String getWifiMac7() {
        return wifiMac7;
    }

    public void setWifiMac7(String wifiMac7) {
        this.wifiMac7 = wifiMac7;
    }

    public Short getWifiSignal7() {
        return wifiSignal7;
    }

    public void setWifiSignal7(Short wifiSignal7) {
        this.wifiSignal7 = wifiSignal7;
    }

    public Short getWifiChannel7() {
        return wifiChannel7;
    }

    public void setWifiChannel7(Short wifiChannel7) {
        this.wifiChannel7 = wifiChannel7;
    }

    public Short getWifiRatio7() {
        return wifiRatio7;
    }

    public void setWifiRatio7(Short wifiRatio7) {
        this.wifiRatio7 = wifiRatio7;
    }

    public String getWifiMac8() {
        return wifiMac8;
    }

    public void setWifiMac8(String wifiMac8) {
        this.wifiMac8 = wifiMac8;
    }

    public Short getWifiSignal8() {
        return wifiSignal8;
    }

    public void setWifiSignal8(Short wifiSignal8) {
        this.wifiSignal8 = wifiSignal8;
    }

    public Short getWifiChannel8() {
        return wifiChannel8;
    }

    public void setWifiChannel8(Short wifiChannel8) {
        this.wifiChannel8 = wifiChannel8;
    }

    public Short getWifiRatio8() {
        return wifiRatio8;
    }

    public void setWifiRatio8(Short wifiRatio8) {
        this.wifiRatio8 = wifiRatio8;
    }

    public String getWifiMac9() {
        return wifiMac9;
    }

    public void setWifiMac9(String wifiMac9) {
        this.wifiMac9 = wifiMac9;
    }

    public Short getWifiSignal9() {
        return wifiSignal9;
    }

    public void setWifiSignal9(Short wifiSignal9) {
        this.wifiSignal9 = wifiSignal9;
    }

    public Short getWifiChannel9() {
        return wifiChannel9;
    }

    public void setWifiChannel9(Short wifiChannel9) {
        this.wifiChannel9 = wifiChannel9;
    }

    public Short getWifiRatio9() {
        return wifiRatio9;
    }

    public void setWifiRatio9(Short wifiRatio9) {
        this.wifiRatio9 = wifiRatio9;
    }

    public String getWifiMac10() {
        return wifiMac10;
    }

    public void setWifiMac10(String wifiMac10) {
        this.wifiMac10 = wifiMac10;
    }

    public Short getWifiSignal10() {
        return wifiSignal10;
    }

    public void setWifiSignal10(Short wifiSignal10) {
        this.wifiSignal10 = wifiSignal10;
    }

    public Short getWifiChannel10() {
        return wifiChannel10;
    }

    public void setWifiChannel10(Short wifiChannel10) {
        this.wifiChannel10 = wifiChannel10;
    }

    public Short getWifiRatio10() {
        return wifiRatio10;
    }

    public void setWifiRatio10(Short wifiRatio10) {
        this.wifiRatio10 = wifiRatio10;
    }
}