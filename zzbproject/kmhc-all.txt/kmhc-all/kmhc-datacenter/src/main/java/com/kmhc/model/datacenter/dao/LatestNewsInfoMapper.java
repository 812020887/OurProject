package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.LatestNewsInfo;
import java.util.List;

public interface LatestNewsInfoMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(LatestNewsInfo record);

    LatestNewsInfo selectByPrimaryKey(Integer id);

    List<LatestNewsInfo> selectAll();

    int updateByPrimaryKey(LatestNewsInfo record);
}