package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingHardware;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("memberSettingHardwareMapper")
public interface MemberSettingHardwareMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingHardware record);

    MemberSettingHardware selectByPrimaryKey(String imei);

    List<MemberSettingHardware> selectAll();

    int updateByPrimaryKey(MemberSettingHardware record);
}