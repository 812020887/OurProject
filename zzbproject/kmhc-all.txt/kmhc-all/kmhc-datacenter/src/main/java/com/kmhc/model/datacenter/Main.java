package com.kmhc.model.datacenter;

import java.util.List;
import com.kmhc.framework.core.SpringBeanFacotry;
import com.kmhc.model.datacenter.model.AdminUser;
import com.kmhc.model.datacenter.service.IBasicService;


public class Main {
	
	public static void main(String[] args) {
		
	}

}
