package com.kmhc.model.datacenter.model;

import java.util.Date;

public class BearMediaMemberList {
    private Long memberId;

    private Long mbeId;

    private Date createDate;

    private Date updateDate;

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public Long getMbeId() {
        return mbeId;
    }

    public void setMbeId(Long mbeId) {
        this.mbeId = mbeId;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}