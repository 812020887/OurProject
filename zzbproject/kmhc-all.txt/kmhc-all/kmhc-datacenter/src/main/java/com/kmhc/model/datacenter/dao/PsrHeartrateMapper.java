package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrHeartrate;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("psrHeartrateMapper")
public interface PsrHeartrateMapper {
	int deleteByPrimaryKey(Integer sno);

	int insert(PsrHeartrate record);

	PsrHeartrate selectByPrimaryKey(Integer sno);

	List<PsrHeartrate> selectAll();

	int updateByPrimaryKey(PsrHeartrate record);

	List<PsrHeartrate> selectAllByImei(@Param("imei") String imei);

	List<PsrHeartrate> selectCountByImei(@Param("imei") String imei, @Param("index") Integer index,
			@Param("count") Integer count);
	
	List<PsrHeartrate> selectDuringByImei(@Param("imei") String imei, @Param("start") String start,
			@Param("end") String end);
	
	int selectByBpTime(PsrHeartrate record);

}