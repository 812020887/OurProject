package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.Wifi2gps;
import java.math.BigDecimal;
import java.util.List;

public interface Wifi2gpsMapper {
    int deleteByPrimaryKey(BigDecimal id);

    int insert(Wifi2gps record);

    Wifi2gps selectByPrimaryKey(BigDecimal id);

    List<Wifi2gps> selectAll();

    int updateByPrimaryKey(Wifi2gps record);
}