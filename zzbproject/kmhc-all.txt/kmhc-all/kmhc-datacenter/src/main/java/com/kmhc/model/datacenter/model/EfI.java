package com.kmhc.model.datacenter.model;

import java.math.BigDecimal;
import java.util.Date;

public class EfI {
    private String batchKey;

    private String imei;

    private Short itemno;

    private String batchDetailKey;

    private Date prDate;

    private Integer voltage;

    private String mcc;

    private String mnc;

    private String lac;

    private Integer cellid;

    private Short rssi;

    private Short dataMap1;

    private Short dataMap2;

    private String gpsNsLat;

    private BigDecimal gpsLat;

    private String gpsEwLng;

    private BigDecimal gpsLng;

    private String address;

    private String locStatus = "Z";

    private String isvalid = "Y";

    private Date createDate;

    private Date updateDate;

    private BigDecimal mcellLat = new BigDecimal(0.0);

    private BigDecimal mcellLng = new BigDecimal(0.0);

    private String mcellStatus = "Y";

    private String mcellAddress;

    private BigDecimal wifiLat;

    private BigDecimal wifiLng;

    private String wifiAddress;

    private BigDecimal myGpsLat;

    private BigDecimal myGpsLng;

    private String myAddress;

    private Double hpe;

    public String getBatchKey() {
        return batchKey;
    }

    public void setBatchKey(String batchKey) {
        this.batchKey = batchKey;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Short getItemno() {
        return itemno;
    }

    public void setItemno(Short itemno) {
        this.itemno = itemno;
    }

    public String getBatchDetailKey() {
        return batchDetailKey;
    }

    public void setBatchDetailKey(String batchDetailKey) {
        this.batchDetailKey = batchDetailKey;
    }

    public Date getPrDate() {
        return prDate;
    }

    public void setPrDate(Date prDate) {
        this.prDate = prDate;
    }

    public Integer getVoltage() {
        return voltage;
    }

    public void setVoltage(Integer voltage) {
        this.voltage = voltage;
    }

    public String getMcc() {
        return mcc;
    }

    public void setMcc(String mcc) {
        this.mcc = mcc;
    }

    public String getMnc() {
        return mnc;
    }

    public void setMnc(String mnc) {
        this.mnc = mnc;
    }

    public String getLac() {
        return lac;
    }

    public void setLac(String lac) {
        this.lac = lac;
    }

    public Integer getCellid() {
        return cellid;
    }

    public void setCellid(Integer cellid) {
        this.cellid = cellid;
    }

    public Short getRssi() {
        return rssi;
    }

    public void setRssi(Short rssi) {
        this.rssi = rssi;
    }

    public Short getDataMap1() {
        return dataMap1;
    }

    public void setDataMap1(Short dataMap1) {
        this.dataMap1 = dataMap1;
    }

    public Short getDataMap2() {
        return dataMap2;
    }

    public void setDataMap2(Short dataMap2) {
        this.dataMap2 = dataMap2;
    }

    public String getGpsNsLat() {
        return gpsNsLat;
    }

    public void setGpsNsLat(String gpsNsLat) {
        this.gpsNsLat = gpsNsLat;
    }

    public BigDecimal getGpsLat() {
        return gpsLat;
    }

    public void setGpsLat(BigDecimal gpsLat) {
        this.gpsLat = gpsLat;
    }

    public String getGpsEwLng() {
        return gpsEwLng;
    }

    public void setGpsEwLng(String gpsEwLng) {
        this.gpsEwLng = gpsEwLng;
    }

    public BigDecimal getGpsLng() {
        return gpsLng;
    }

    public void setGpsLng(BigDecimal gpsLng) {
        this.gpsLng = gpsLng;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLocStatus() {
        return locStatus;
    }

    public void setLocStatus(String locStatus) {
        this.locStatus = locStatus;
    }

    public String getIsvalid() {
        return isvalid;
    }

    public void setIsvalid(String isvalid) {
        this.isvalid = isvalid;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public BigDecimal getMcellLat() {
        return mcellLat;
    }

    public void setMcellLat(BigDecimal mcellLat) {
        this.mcellLat = mcellLat;
    }

    public BigDecimal getMcellLng() {
        return mcellLng;
    }

    public void setMcellLng(BigDecimal mcellLng) {
        this.mcellLng = mcellLng;
    }

    public String getMcellStatus() {
        return mcellStatus;
    }

    public void setMcellStatus(String mcellStatus) {
        this.mcellStatus = mcellStatus;
    }

    public String getMcellAddress() {
        return mcellAddress;
    }

    public void setMcellAddress(String mcellAddress) {
        this.mcellAddress = mcellAddress;
    }

    public BigDecimal getWifiLat() {
        return wifiLat;
    }

    public void setWifiLat(BigDecimal wifiLat) {
        this.wifiLat = wifiLat;
    }

    public BigDecimal getWifiLng() {
        return wifiLng;
    }

    public void setWifiLng(BigDecimal wifiLng) {
        this.wifiLng = wifiLng;
    }

    public String getWifiAddress() {
        return wifiAddress;
    }

    public void setWifiAddress(String wifiAddress) {
        this.wifiAddress = wifiAddress;
    }

    public BigDecimal getMyGpsLat() {
        return myGpsLat;
    }

    public void setMyGpsLat(BigDecimal myGpsLat) {
        this.myGpsLat = myGpsLat;
    }

    public BigDecimal getMyGpsLng() {
        return myGpsLng;
    }

    public void setMyGpsLng(BigDecimal myGpsLng) {
        this.myGpsLng = myGpsLng;
    }

    public String getMyAddress() {
        return myAddress;
    }

    public void setMyAddress(String myAddress) {
        this.myAddress = myAddress;
    }

    public Double getHpe() {
        return hpe;
    }

    public void setHpe(Double hpe) {
        this.hpe = hpe;
    }
}