package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AuthMapGkeyMember;
import java.util.List;

public interface AuthMapGkeyMemberMapper {
    int deleteByPrimaryKey(Long sno);

    int insert(AuthMapGkeyMember record);

    AuthMapGkeyMember selectByPrimaryKey(Long sno);

    List<AuthMapGkeyMember> selectAll();

    int updateByPrimaryKey(AuthMapGkeyMember record);
}