package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.Opencell2gps;
import java.util.List;

public interface Opencell2gpsMapper {
    int insert(Opencell2gps record);

    List<Opencell2gps> selectAll();
}