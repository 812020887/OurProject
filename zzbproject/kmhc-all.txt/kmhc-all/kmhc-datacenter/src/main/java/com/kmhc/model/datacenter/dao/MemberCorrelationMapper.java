package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberCorrelation;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("memberCorrelationMapper")
public interface MemberCorrelationMapper {
    int deleteByPrimaryKey(Long memberCorrelationId);

    int insert(MemberCorrelation record);

    MemberCorrelation selectByPrimaryKey(Long memberCorrelationId);

    List<MemberCorrelation> selectAll();

    int updateByPrimaryKey(MemberCorrelation record);
    
    MemberCorrelation selectByUserId(Long userId);
}