package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.CheckRM;
import java.util.List;

import org.springframework.stereotype.Repository;
@Repository("checkRMMapper")
public interface CheckRMMapper {
    int deleteByPrimaryKey(String imei);

    int insert(CheckRM record);

    CheckRM selectByPrimaryKey(String imei);

    List<CheckRM> selectAll();

    int updateByPrimaryKey(CheckRM record);
}