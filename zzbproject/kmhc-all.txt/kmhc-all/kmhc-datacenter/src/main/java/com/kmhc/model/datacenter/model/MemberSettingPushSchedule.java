package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingPushSchedule {
    private Long scheduleId;

    private Long pushId;

    private Date serverReservationTime;

    private Date userReservationTime;

    private String serverDayOfPerweek;

    private Date serverTimeOfPerweek;

    private String userTimeZone;

    private String userDayOfPerweek;

    private Date userTimeOfPerweek;

    private Date createdTime;

    private Date updateTime;

    public Long getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(Long scheduleId) {
        this.scheduleId = scheduleId;
    }

    public Long getPushId() {
        return pushId;
    }

    public void setPushId(Long pushId) {
        this.pushId = pushId;
    }

    public Date getServerReservationTime() {
        return serverReservationTime;
    }

    public void setServerReservationTime(Date serverReservationTime) {
        this.serverReservationTime = serverReservationTime;
    }

    public Date getUserReservationTime() {
        return userReservationTime;
    }

    public void setUserReservationTime(Date userReservationTime) {
        this.userReservationTime = userReservationTime;
    }

    public String getServerDayOfPerweek() {
        return serverDayOfPerweek;
    }

    public void setServerDayOfPerweek(String serverDayOfPerweek) {
        this.serverDayOfPerweek = serverDayOfPerweek;
    }

    public Date getServerTimeOfPerweek() {
        return serverTimeOfPerweek;
    }

    public void setServerTimeOfPerweek(Date serverTimeOfPerweek) {
        this.serverTimeOfPerweek = serverTimeOfPerweek;
    }

    public String getUserTimeZone() {
        return userTimeZone;
    }

    public void setUserTimeZone(String userTimeZone) {
        this.userTimeZone = userTimeZone;
    }

    public String getUserDayOfPerweek() {
        return userDayOfPerweek;
    }

    public void setUserDayOfPerweek(String userDayOfPerweek) {
        this.userDayOfPerweek = userDayOfPerweek;
    }

    public Date getUserTimeOfPerweek() {
        return userTimeOfPerweek;
    }

    public void setUserTimeOfPerweek(Date userTimeOfPerweek) {
        this.userTimeOfPerweek = userTimeOfPerweek;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}