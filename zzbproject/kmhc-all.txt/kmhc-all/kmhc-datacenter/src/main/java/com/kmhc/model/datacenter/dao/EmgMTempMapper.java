package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.EmgMTemp;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface EmgMTempMapper {
    int deleteByPrimaryKey(@Param("emgKey") String emgKey, @Param("imei") String imei);

    int insert(EmgMTemp record);

    EmgMTemp selectByPrimaryKey(@Param("emgKey") String emgKey, @Param("imei") String imei);

    List<EmgMTemp> selectAll();

    int updateByPrimaryKey(EmgMTemp record);
}