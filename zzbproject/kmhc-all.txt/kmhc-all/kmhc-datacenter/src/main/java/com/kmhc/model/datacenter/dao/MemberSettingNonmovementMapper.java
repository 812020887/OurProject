package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingNonmovement;
import java.util.List;

public interface MemberSettingNonmovementMapper {
    int deleteByPrimaryKey(Long memberId);

    int insert(MemberSettingNonmovement record);

    MemberSettingNonmovement selectByPrimaryKey(Long memberId);

    List<MemberSettingNonmovement> selectAll();

    int updateByPrimaryKey(MemberSettingNonmovement record);
}