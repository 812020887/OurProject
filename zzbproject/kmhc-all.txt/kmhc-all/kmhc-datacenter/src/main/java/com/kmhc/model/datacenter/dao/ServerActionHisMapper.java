package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.ServerActionHis;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("serverActionHisMapper")
public interface ServerActionHisMapper {
    int deleteByPrimaryKey(@Param("uid") String uid, @Param("imei") String imei, @Param("protocol") String protocol);

    int insert(ServerActionHis record);

    ServerActionHis selectByPrimaryKey(@Param("uid") String uid, @Param("imei") String imei, @Param("protocol") String protocol);

    ServerActionHis selectByImeiAndType( @Param("imei") String imei, @Param("protocol") String protocol);
    
    List<ServerActionHis> selectAll();

    int updateByPrimaryKey(ServerActionHis record);
    
	int deleteByImemAndType(@Param("imei") String imei, @Param("protocol") String protocol);

}