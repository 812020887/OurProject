package com.kmhc.model.datacenter.model;

import java.util.Date;

public class AuthUseLimit {
    private Long sno;

    private Long gkeyId;

    private Long useLimit;

    private Integer dates;

    private Integer weekes;

    private Integer months;

    private Integer years;

    private Date startDate;

    private Date endDate;

    private Byte enable;

    private Byte limitType;

    public Long getSno() {
        return sno;
    }

    public void setSno(Long sno) {
        this.sno = sno;
    }

    public Long getGkeyId() {
        return gkeyId;
    }

    public void setGkeyId(Long gkeyId) {
        this.gkeyId = gkeyId;
    }

    public Long getUseLimit() {
        return useLimit;
    }

    public void setUseLimit(Long useLimit) {
        this.useLimit = useLimit;
    }

    public Integer getDates() {
        return dates;
    }

    public void setDates(Integer dates) {
        this.dates = dates;
    }

    public Integer getWeekes() {
        return weekes;
    }

    public void setWeekes(Integer weekes) {
        this.weekes = weekes;
    }

    public Integer getMonths() {
        return months;
    }

    public void setMonths(Integer months) {
        this.months = months;
    }

    public Integer getYears() {
        return years;
    }

    public void setYears(Integer years) {
        this.years = years;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Byte getEnable() {
        return enable;
    }

    public void setEnable(Byte enable) {
        this.enable = enable;
    }

    public Byte getLimitType() {
        return limitType;
    }

    public void setLimitType(Byte limitType) {
        this.limitType = limitType;
    }
}