package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.ImeiLog;

import java.util.List;
import org.springframework.stereotype.Repository;

@Repository
public interface ImeiLogMapper {
    int deleteByPrimaryKey(Long imeilogId);

    int insert(ImeiLog record);

    ImeiLog selectByPrimaryKey(Long imeilogId);

    List<ImeiLog> selectAll();

    int updateByPrimaryKey(ImeiLog record);
    
}