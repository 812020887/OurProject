package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.Guidercell2gps;
import java.util.List;

public interface Guidercell2gpsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Guidercell2gps record);

    Guidercell2gps selectByPrimaryKey(Long id);

    List<Guidercell2gps> selectAll();

    int updateByPrimaryKey(Guidercell2gps record);
}