package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.BearParameter;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BearParameterMapper {
    int deleteByPrimaryKey(@Param("parameterName") String parameterName, @Param("itemNo") Integer itemNo, @Param("parameterType") String parameterType, @Param("memberId") Long memberId);

    int insert(BearParameter record);

    BearParameter selectByPrimaryKey(@Param("parameterName") String parameterName, @Param("itemNo") Integer itemNo, @Param("parameterType") String parameterType, @Param("memberId") Long memberId);

    List<BearParameter> selectAll();

    int updateByPrimaryKey(BearParameter record);
}