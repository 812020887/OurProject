package com.kmhc.model.datacenter.model;

import java.util.Date;

public class Member {
    private Long memberId;

    private Integer inxNo;

    private String account;

    private String address;

    private String cellPhone;

    private Date createdTime;

    private String email;

    private String imei;

    private String memberCode;

    private String password;

    private String pic;

    private String realName;

    private Integer sex;

    private Integer status;

    private String telSupport;

    private Integer bpUpperboundH;

    private Integer bpUpperboundL;

    private Integer bpLowerboundH;

    private Integer bpLowerboundL;

    private Date updatedTime;

    private Date memberBirthday;

    private String memberIdNumber;

    private String memberRemark;

    private String memberTel;

    private Long type;

    private String otherPic;

    private String sn;

    private String pn;

    private String encryptDeviceToken;

    private String contactName;

    private Long companyId;

    private String familypersonrelation1;

    private String familypersonrelation2;

    private String familypersonrelation3;

    private Integer istomohw;

    private Integer areacode;

    private Long supplierId;

    private String streetaddress;

    private String suburb;

    private String state;

    private String postcode;

    private String country;
    
    private String guardianName;
    
    private String guardianPhone;

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public Integer getInxNo() {
        return inxNo;
    }

    public void setInxNo(Integer inxNo) {
        this.inxNo = inxNo;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCellPhone() {
        return cellPhone;
    }

    public void setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getMemberCode() {
        return memberCode;
    }

    public void setMemberCode(String memberCode) {
        this.memberCode = memberCode;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getTelSupport() {
        return telSupport;
    }

    public void setTelSupport(String telSupport) {
        this.telSupport = telSupport;
    }

    public Integer getBpUpperboundH() {
        return bpUpperboundH;
    }

    public void setBpUpperboundH(Integer bpUpperboundH) {
        this.bpUpperboundH = bpUpperboundH;
    }

    public Integer getBpUpperboundL() {
        return bpUpperboundL;
    }

    public void setBpUpperboundL(Integer bpUpperboundL) {
        this.bpUpperboundL = bpUpperboundL;
    }

    public Integer getBpLowerboundH() {
        return bpLowerboundH;
    }

    public void setBpLowerboundH(Integer bpLowerboundH) {
        this.bpLowerboundH = bpLowerboundH;
    }

    public Integer getBpLowerboundL() {
        return bpLowerboundL;
    }

    public void setBpLowerboundL(Integer bpLowerboundL) {
        this.bpLowerboundL = bpLowerboundL;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public Date getMemberBirthday() {
        return memberBirthday;
    }

    public void setMemberBirthday(Date memberBirthday) {
        this.memberBirthday = memberBirthday;
    }

    public String getMemberIdNumber() {
        return memberIdNumber;
    }

    public void setMemberIdNumber(String memberIdNumber) {
        this.memberIdNumber = memberIdNumber;
    }

    public String getMemberRemark() {
        return memberRemark;
    }

    public void setMemberRemark(String memberRemark) {
        this.memberRemark = memberRemark;
    }

    public String getMemberTel() {
        return memberTel;
    }

    public void setMemberTel(String memberTel) {
        this.memberTel = memberTel;
    }

    public Long getType() {
        return type;
    }

    public void setType(Long type) {
        this.type = type;
    }

    public String getOtherPic() {
        return otherPic;
    }

    public void setOtherPic(String otherPic) {
        this.otherPic = otherPic;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getPn() {
        return pn;
    }

    public void setPn(String pn) {
        this.pn = pn;
    }

    public String getEncryptDeviceToken() {
        return encryptDeviceToken;
    }

    public void setEncryptDeviceToken(String encryptDeviceToken) {
        this.encryptDeviceToken = encryptDeviceToken;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public String getFamilypersonrelation1() {
        return familypersonrelation1;
    }

    public void setFamilypersonrelation1(String familypersonrelation1) {
        this.familypersonrelation1 = familypersonrelation1;
    }

    public String getFamilypersonrelation2() {
        return familypersonrelation2;
    }

    public void setFamilypersonrelation2(String familypersonrelation2) {
        this.familypersonrelation2 = familypersonrelation2;
    }

    public String getFamilypersonrelation3() {
        return familypersonrelation3;
    }

    public void setFamilypersonrelation3(String familypersonrelation3) {
        this.familypersonrelation3 = familypersonrelation3;
    }

    public Integer getIstomohw() {
        return istomohw;
    }

    public void setIstomohw(Integer istomohw) {
        this.istomohw = istomohw;
    }

    public Integer getAreacode() {
        return areacode;
    }

    public void setAreacode(Integer areacode) {
        this.areacode = areacode;
    }

    public Long getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Long supplierId) {
        this.supplierId = supplierId;
    }

    public String getStreetaddress() {
        return streetaddress;
    }

    public void setStreetaddress(String streetaddress) {
        this.streetaddress = streetaddress;
    }

    public String getSuburb() {
        return suburb;
    }

    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

	public String getGuardianName() {
		return guardianName;
	}

	public void setGuardianName(String guardianName) {
		this.guardianName = guardianName;
	}

	public String getGuardianPhone() {
		return guardianPhone;
	}

	public void setGuardianPhone(String guardianPhone) {
		this.guardianPhone = guardianPhone;
	}
}