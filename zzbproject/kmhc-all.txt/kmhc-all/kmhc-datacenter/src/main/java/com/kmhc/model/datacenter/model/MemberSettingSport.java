package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingSport {
    private String imei;

    private Integer targetStep;

    private Integer targetDistance;

    private Date targetTime;

    private Integer targetHeat;

    private Date createDate;

    private Date updateDate;

    private String updated;

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Integer getTargetStep() {
        return targetStep;
    }

    public void setTargetStep(Integer targetStep) {
        this.targetStep = targetStep;
    }

    public Integer getTargetDistance() {
        return targetDistance;
    }

    public void setTargetDistance(Integer targetDistance) {
        this.targetDistance = targetDistance;
    }

    public Date getTargetTime() {
        return targetTime;
    }

    public void setTargetTime(Date targetTime) {
        this.targetTime = targetTime;
    }

    public Integer getTargetHeat() {
        return targetHeat;
    }

    public void setTargetHeat(Integer targetHeat) {
        this.targetHeat = targetHeat;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }
}