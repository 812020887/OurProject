package com.kmhc.model.datacenter.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Name: Gps.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.pojo.Gps.java]
 * Description: GPS数据对象  
 * 
 * @since JDK1.7
 * @see
 *
 * @author: xl
 * @date: 2015年11月17日 上午9:09:50
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class Gps {

    private BigDecimal lat;
    private BigDecimal lng;
    private String directionLat;
    private String directionLng;
    private String isValid;
    private String address ;
    
    public Gps(double lat,double lng,String directionLat,String directionLng,String isValid){
        this(new BigDecimal(lat).setScale(6, RoundingMode.HALF_EVEN),new BigDecimal(lng).setScale(6, RoundingMode.HALF_EVEN),directionLat,directionLng,isValid);
    }
    
    public Gps(BigDecimal lat,BigDecimal lng,String directionLat,String directionLng,String isValid){
        this.lat = lat ;
        this.lng = lng ;
        this.directionLat = directionLat ;
        this.directionLng = directionLng ;
        this.isValid = isValid;
    }
    
    public BigDecimal getLat() {
        return lat;
    }
    public void setLat(BigDecimal lat) {
        this.lat = lat;
    }
    public BigDecimal getLng() {
        return lng;
    }
    public void setLng(BigDecimal lng) {
        this.lng = lng;
    }
    public String getDirectionLat() {
        return directionLat;
    }
    public void setDirectionLat(String directionLat) {
        this.directionLat = directionLat;
    }
    public String getDirectionLng() {
        return directionLng;
    }
    public void setDirectionLng(String directionLng) {
        this.directionLng = directionLng;
    }
    public String getIsValid() {
        return isValid;
    }
    public void setIsValid(String isValid) {
        this.isValid = isValid;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
