package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrOxy;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("psrOxyMapper")
public interface PsrOxyMapper {
	int deleteByPrimaryKey(@Param("sno") Integer sno, @Param("imei") String imei);

	int insert(PsrOxy record);

	PsrOxy selectByPrimaryKey(@Param("sno") Integer sno, @Param("imei") String imei);

	List<PsrOxy> selectAll();

	int updateByPrimaryKey(PsrOxy record);

	List<PsrOxy> selectAllByImei(@Param("imei") String imei);

	List<PsrOxy> selectCountByImei(@Param("imei") String imei, @Param("index") Integer index,
			@Param("count") Integer count);

	List<PsrOxy> selectDuringByImei(@Param("imei") String imei, @Param("start") String start, @Param("end") String end);

	int selectByOXYTime (PsrOxy record);
}