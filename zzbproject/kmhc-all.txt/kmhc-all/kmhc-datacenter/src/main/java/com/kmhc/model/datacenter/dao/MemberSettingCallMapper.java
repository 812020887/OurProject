package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingCall;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("memberSettingCallMapper")
public interface MemberSettingCallMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingCall record);

    MemberSettingCall selectByPrimaryKey(String imei);

    List<MemberSettingCall> selectAll();

    int updateByPrimaryKey(MemberSettingCall record);
}