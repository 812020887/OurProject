package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.ProductStatusM;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ProductStatusMMapper {
    int deleteByPrimaryKey(@Param("snKey") Integer snKey, @Param("key") String key);

    int insert(ProductStatusM record);

    ProductStatusM selectByPrimaryKey(@Param("snKey") Integer snKey, @Param("key") String key);

    List<ProductStatusM> selectAll();

    int updateByPrimaryKey(ProductStatusM record);
}