package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.Supplier;
import java.util.List;

public interface SupplierMapper {
    int deleteByPrimaryKey(Long supplierId);

    int insert(Supplier record);

    Supplier selectByPrimaryKey(Long supplierId);

    List<Supplier> selectAll();

    int updateByPrimaryKey(Supplier record);
}