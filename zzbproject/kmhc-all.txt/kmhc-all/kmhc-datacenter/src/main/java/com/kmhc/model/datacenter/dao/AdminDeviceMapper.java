package com.kmhc.model.datacenter.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.kmhc.model.datacenter.model.AdminDevice;
import com.kmhc.model.datacenter.model.AdminDeviceKey;

@Repository("adminDeviceMapper")
public interface AdminDeviceMapper extends IMapper {
    int deleteByPrimaryKey(AdminDeviceKey key);
    
    int deleteByAdminId(@Param("admin_id")Long admin_id);
    
    int deleteByAdminIdAndNotInImeis(AdminDevice record);

    int insert(AdminDevice record);

    int insertSelective(AdminDevice record);

    AdminDevice selectByPrimaryKey(AdminDeviceKey key);
    
    List<AdminDevice> selectByAdminId(@Param("admin_id")Long admin_id);

    int updateByPrimaryKeySelective(AdminDevice record);

    int updateByPrimaryKey(AdminDevice record);
}