package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.CoreExtGwLogPost;
import java.util.List;

public interface CoreExtGwLogPostMapper {
    int deleteByPrimaryKey(Long postid);

    int insert(CoreExtGwLogPost record);

    CoreExtGwLogPost selectByPrimaryKey(Long postid);

    List<CoreExtGwLogPost> selectAll();

    int updateByPrimaryKey(CoreExtGwLogPost record);
}