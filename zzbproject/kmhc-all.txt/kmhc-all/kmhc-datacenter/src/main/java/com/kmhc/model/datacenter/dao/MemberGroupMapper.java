package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberGroup;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("memberGroupMapper")
public interface MemberGroupMapper {
    int deleteByPrimaryKey(Long memberGroupId);

    int insert(MemberGroup record);

    MemberGroup selectByPrimaryKey(Long memberGroupId);
    
    MemberGroup selectByMemberId(Long memberId);

    List<MemberGroup> selectAll();

    int updateByPrimaryKey(MemberGroup record);
}