package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AngelFunction;
import java.util.List;

public interface AngelFunctionMapper {
    int deleteByPrimaryKey(Long functionId);

    int insert(AngelFunction record);

    AngelFunction selectByPrimaryKey(Long functionId);

    List<AngelFunction> selectAll();

    int updateByPrimaryKey(AngelFunction record);
}