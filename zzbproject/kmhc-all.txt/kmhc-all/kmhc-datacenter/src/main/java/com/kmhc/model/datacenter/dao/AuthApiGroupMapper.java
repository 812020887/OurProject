package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AuthApiGroup;
import java.util.List;

public interface AuthApiGroupMapper {
    int deleteByPrimaryKey(Long sno);

    int insert(AuthApiGroup record);

    AuthApiGroup selectByPrimaryKey(Long sno);

    List<AuthApiGroup> selectAll();

    int updateByPrimaryKey(AuthApiGroup record);
}