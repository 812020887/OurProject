package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingOtherpic {
    private String imei;

    private String otherPic1Url;

    private Integer otherPic1Status;

    private String otherPic1Remark;

    private String otherPic2Url;

    private Integer otherPic2Status;

    private String otherPic2Remark;

    private String otherPic3Url;

    private Integer otherPic3Status;

    private String otherPic3Remark;

    private String otherPic4Url;

    private Integer otherPic4Status;

    private String otherPic4Remark;

    private Date updateTime;

    private Date createTime;
    
    public MemberSettingOtherpic() {
		super();
	}

	public MemberSettingOtherpic(String imei, Integer otherPic1Status,
			Integer otherPic2Status, Integer otherPic3Status,
			Integer otherPic4Status, Date createTime) {
		super();
		this.imei = imei;
		this.otherPic1Status = otherPic1Status;
		this.otherPic2Status = otherPic2Status;
		this.otherPic3Status = otherPic3Status;
		this.otherPic4Status = otherPic4Status;
		this.createTime = createTime;
	}

	public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getOtherPic1Url() {
        return otherPic1Url;
    }

    public void setOtherPic1Url(String otherPic1Url) {
        this.otherPic1Url = otherPic1Url;
    }

    public Integer getOtherPic1Status() {
        return otherPic1Status;
    }

    public void setOtherPic1Status(Integer otherPic1Status) {
        this.otherPic1Status = otherPic1Status;
    }

    public String getOtherPic1Remark() {
        return otherPic1Remark;
    }

    public void setOtherPic1Remark(String otherPic1Remark) {
        this.otherPic1Remark = otherPic1Remark;
    }

    public String getOtherPic2Url() {
        return otherPic2Url;
    }

    public void setOtherPic2Url(String otherPic2Url) {
        this.otherPic2Url = otherPic2Url;
    }

    public Integer getOtherPic2Status() {
        return otherPic2Status;
    }

    public void setOtherPic2Status(Integer otherPic2Status) {
        this.otherPic2Status = otherPic2Status;
    }

    public String getOtherPic2Remark() {
        return otherPic2Remark;
    }

    public void setOtherPic2Remark(String otherPic2Remark) {
        this.otherPic2Remark = otherPic2Remark;
    }

    public String getOtherPic3Url() {
        return otherPic3Url;
    }

    public void setOtherPic3Url(String otherPic3Url) {
        this.otherPic3Url = otherPic3Url;
    }

    public Integer getOtherPic3Status() {
        return otherPic3Status;
    }

    public void setOtherPic3Status(Integer otherPic3Status) {
        this.otherPic3Status = otherPic3Status;
    }

    public String getOtherPic3Remark() {
        return otherPic3Remark;
    }

    public void setOtherPic3Remark(String otherPic3Remark) {
        this.otherPic3Remark = otherPic3Remark;
    }

    public String getOtherPic4Url() {
        return otherPic4Url;
    }

    public void setOtherPic4Url(String otherPic4Url) {
        this.otherPic4Url = otherPic4Url;
    }

    public Integer getOtherPic4Status() {
        return otherPic4Status;
    }

    public void setOtherPic4Status(Integer otherPic4Status) {
        this.otherPic4Status = otherPic4Status;
    }

    public String getOtherPic4Remark() {
        return otherPic4Remark;
    }

    public void setOtherPic4Remark(String otherPic4Remark) {
        this.otherPic4Remark = otherPic4Remark;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}