package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingPushTo;
import java.util.List;

public interface MemberSettingPushToMapper {
    int deleteByPrimaryKey(Long toId);

    int insert(MemberSettingPushTo record);

    MemberSettingPushTo selectByPrimaryKey(Long toId);

    List<MemberSettingPushTo> selectAll();

    int updateByPrimaryKey(MemberSettingPushTo record);
}