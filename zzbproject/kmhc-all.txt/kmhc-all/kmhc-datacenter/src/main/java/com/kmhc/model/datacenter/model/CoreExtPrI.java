package com.kmhc.model.datacenter.model;

public class CoreExtPrI {
    private String batchKey;

    private String imei;

    private Short itemno;

    private Double voltagePercent;

    public String getBatchKey() {
        return batchKey;
    }

    public void setBatchKey(String batchKey) {
        this.batchKey = batchKey;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Short getItemno() {
        return itemno;
    }

    public void setItemno(Short itemno) {
        this.itemno = itemno;
    }

    public Double getVoltagePercent() {
        return voltagePercent;
    }

    public void setVoltagePercent(Double voltagePercent) {
        this.voltagePercent = voltagePercent;
    }
}