package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrBs;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("psrBsMapper")
public interface PsrBsMapper {
    int deleteByPrimaryKey(@Param("sno") Integer sno, @Param("imei") String imei);

    int insert(PsrBs record);

    PsrBs selectByPrimaryKey(@Param("sno") Integer sno, @Param("imei") String imei);

    List<PsrBs> selectAll();

    int updateByPrimaryKey(PsrBs record);
    
    List<PsrBs> selectAllByImei( @Param("imei") String imei);
    
    List<PsrBs> selectCountByImei( @Param("imei") String imei,@Param("index")Integer index,@Param("count")Integer count);
    
    List<PsrBs>selectByDuring(@Param("imei") String imei,@Param("start") String start,@Param("end") String end);
 
    int selectByBsTime(PsrBs record);
}