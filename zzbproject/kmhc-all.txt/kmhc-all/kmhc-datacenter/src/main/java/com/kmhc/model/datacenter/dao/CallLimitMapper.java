package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.CallLimit;
import java.util.List;

public interface CallLimitMapper {
    int deleteByPrimaryKey(String imei);

    int insert(CallLimit record);

    CallLimit selectByPrimaryKey(String imei);

    List<CallLimit> selectAll();

    int updateByPrimaryKey(CallLimit record);
}