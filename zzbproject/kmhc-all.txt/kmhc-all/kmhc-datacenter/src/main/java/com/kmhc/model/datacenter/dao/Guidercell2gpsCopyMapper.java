package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.Guidercell2gpsCopy;
import java.util.List;

public interface Guidercell2gpsCopyMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Guidercell2gpsCopy record);

    Guidercell2gpsCopy selectByPrimaryKey(Long id);

    List<Guidercell2gpsCopy> selectAll();

    int updateByPrimaryKey(Guidercell2gpsCopy record);
}