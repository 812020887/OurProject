package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.Member;
import com.kmhc.model.datacenter.pojo.PersonalSetup_View;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository("memberMapper")
public interface MemberMapper {
    int deleteByPrimaryKey(Long memberId);

    int insert(Member record);

    Member selectByPrimaryKey(Long memberId);
    
    Member selectByAccount(String account);

    List<Member> selectAll();

    int updateByPrimaryKey(Member record);
    
    int updateByAccountSelective(Member record);
    
    List<Member> selectByLastImeiCode( Long lastMemberId );
    
    PersonalSetup_View getMemberFamilyPhoto(String imei);
    
    Member selectByImei(String imei);
    
    Map<String,Object> find8000Gps(String imei); 
    
    Map<String,Object> find8020Gps(String imei); 
    
}