package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.T9ContactInfo;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("t9ContactInfoMapper")
public interface T9ContactInfoMapper {
    int deleteByPrimaryKey(String imei);

    int insert(T9ContactInfo record);

    T9ContactInfo selectByPrimaryKey(String imei);

    List<T9ContactInfo> selectAll();

    int updateByPrimaryKey(T9ContactInfo record);
    
    int update(T9ContactInfo record);
}