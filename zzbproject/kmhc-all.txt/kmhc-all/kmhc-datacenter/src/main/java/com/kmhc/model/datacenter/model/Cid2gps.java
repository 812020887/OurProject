package com.kmhc.model.datacenter.model;

import java.math.BigDecimal;
import java.util.Date;

public class Cid2gps {
    private String mcc;

    private String mnc;

    private String lac;

    private Integer cellid;

    private String gpsNsLat;

    private BigDecimal gpsLat;

    private String gpsEwLng;

    private BigDecimal gpsLng;

    private String address;

    private Double acc;

    private String isvalid;

    private Date updated;

    public String getMcc() {
        return mcc;
    }

    public void setMcc(String mcc) {
        this.mcc = mcc;
    }

    public String getMnc() {
        return mnc;
    }

    public void setMnc(String mnc) {
        this.mnc = mnc;
    }

    public String getLac() {
        return lac;
    }

    public void setLac(String lac) {
        this.lac = lac;
    }

    public Integer getCellid() {
        return cellid;
    }

    public void setCellid(Integer cellid) {
        this.cellid = cellid;
    }

    public String getGpsNsLat() {
        return gpsNsLat;
    }

    public void setGpsNsLat(String gpsNsLat) {
        this.gpsNsLat = gpsNsLat;
    }

    public BigDecimal getGpsLat() {
        return gpsLat;
    }

    public void setGpsLat(BigDecimal gpsLat) {
        this.gpsLat = gpsLat;
    }

    public String getGpsEwLng() {
        return gpsEwLng;
    }

    public void setGpsEwLng(String gpsEwLng) {
        this.gpsEwLng = gpsEwLng;
    }

    public BigDecimal getGpsLng() {
        return gpsLng;
    }

    public void setGpsLng(BigDecimal gpsLng) {
        this.gpsLng = gpsLng;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Double getAcc() {
        return acc;
    }

    public void setAcc(Double acc) {
        this.acc = acc;
    }

    public String getIsvalid() {
        return isvalid;
    }

    public void setIsvalid(String isvalid) {
        this.isvalid = isvalid;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }
}