package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrWalk;
import java.util.List;

public interface PsrWalkMapper {
    int deleteByPrimaryKey(Long sno);

    int insert(PsrWalk record);

    PsrWalk selectByPrimaryKey(Long sno);

    List<PsrWalk> selectAll();

    int updateByPrimaryKey(PsrWalk record);
}