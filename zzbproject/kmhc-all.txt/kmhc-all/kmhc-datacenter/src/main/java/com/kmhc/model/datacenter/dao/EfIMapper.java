package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.EfI;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("efIMapper")
public interface EfIMapper {
    int deleteByPrimaryKey(@Param("batchKey") String batchKey, @Param("imei") String imei, @Param("itemno") Short itemno);

    int insert(EfI record);

    EfI selectByPrimaryKey(@Param("batchKey") String batchKey, @Param("imei") String imei, @Param("itemno") Short itemno);

    List<EfI> selectAll();

    int updateByPrimaryKey(EfI record);
}