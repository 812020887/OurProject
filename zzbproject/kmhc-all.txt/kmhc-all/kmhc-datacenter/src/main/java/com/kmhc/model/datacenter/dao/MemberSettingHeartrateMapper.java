package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingHeartrate;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("memberSettingHeartrateMapper")
public interface MemberSettingHeartrateMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingHeartrate record);

    MemberSettingHeartrate selectByPrimaryKey(String imei);

    List<MemberSettingHeartrate> selectAll();

    int updateByPrimaryKey(MemberSettingHeartrate record);
    
    int update(MemberSettingHeartrate record);
}