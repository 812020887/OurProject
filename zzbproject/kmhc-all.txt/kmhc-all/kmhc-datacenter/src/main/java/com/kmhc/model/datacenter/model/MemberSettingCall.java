package com.kmhc.model.datacenter.model;

public class MemberSettingCall {
    private String imei;

    private Integer dateTime1;

    private Integer dateTime2;

    private Integer dateTime3;

    private Integer dateTime4;

    private String updated;
    
    
    public MemberSettingCall() {
		super();
	}

	public MemberSettingCall(String imei) {
		super();
		this.imei = imei;
	}

	public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Integer getDateTime1() {
        return dateTime1;
    }

    public void setDateTime1(Integer dateTime1) {
        this.dateTime1 = dateTime1;
    }

    public Integer getDateTime2() {
        return dateTime2;
    }

    public void setDateTime2(Integer dateTime2) {
        this.dateTime2 = dateTime2;
    }

    public Integer getDateTime3() {
        return dateTime3;
    }

    public void setDateTime3(Integer dateTime3) {
        this.dateTime3 = dateTime3;
    }

    public Integer getDateTime4() {
        return dateTime4;
    }

    public void setDateTime4(Integer dateTime4) {
        this.dateTime4 = dateTime4;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }
}