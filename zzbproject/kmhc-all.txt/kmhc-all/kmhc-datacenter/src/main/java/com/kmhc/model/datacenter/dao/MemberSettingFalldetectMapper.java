package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingFalldetect;
import java.util.List;

public interface MemberSettingFalldetectMapper {
    int deleteByPrimaryKey(Long memberId);

    int insert(MemberSettingFalldetect record);

    MemberSettingFalldetect selectByPrimaryKey(Long memberId);

    List<MemberSettingFalldetect> selectAll();

    int updateByPrimaryKey(MemberSettingFalldetect record);
}