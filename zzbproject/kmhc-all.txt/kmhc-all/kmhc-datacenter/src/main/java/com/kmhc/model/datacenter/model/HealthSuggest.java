package com.kmhc.model.datacenter.model;

import java.util.Date;

public class HealthSuggest {
    private Long suggestId;

    private Integer suggestValue;

    private Long memberId;

    private String suggestContent;

    private Date suggestUpdate;

    private Date createDate;

    public Long getSuggestId() {
        return suggestId;
    }

    public void setSuggestId(Long suggestId) {
        this.suggestId = suggestId;
    }

    public Integer getSuggestValue() {
        return suggestValue;
    }

    public void setSuggestValue(Integer suggestValue) {
        this.suggestValue = suggestValue;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public String getSuggestContent() {
        return suggestContent;
    }

    public void setSuggestContent(String suggestContent) {
        this.suggestContent = suggestContent;
    }

    public Date getSuggestUpdate() {
        return suggestUpdate;
    }

    public void setSuggestUpdate(Date suggestUpdate) {
        this.suggestUpdate = suggestUpdate;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}