package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PerWeather;
import java.util.List;

import org.springframework.stereotype.Repository;
@Repository
public interface PerWeatherMapper {
    int deleteByPrimaryKey(String imei);

    int insert(PerWeather record);

    PerWeather selectByPrimaryKey(String imei);

    List<PerWeather> selectAll();

    int updateByPrimaryKey(PerWeather record);
    
    int filter_Per_Weather(String imei);
}