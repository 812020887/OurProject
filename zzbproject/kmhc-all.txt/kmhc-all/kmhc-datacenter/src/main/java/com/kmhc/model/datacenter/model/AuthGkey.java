package com.kmhc.model.datacenter.model;

public class AuthGkey {
    private Long son;

    private Long gkeyId;

    private String gkey;

    private Byte gkeyType;

    private String remark;

    public Long getSon() {
        return son;
    }

    public void setSon(Long son) {
        this.son = son;
    }

    public Long getGkeyId() {
        return gkeyId;
    }

    public void setGkeyId(Long gkeyId) {
        this.gkeyId = gkeyId;
    }

    public String getGkey() {
        return gkey;
    }

    public void setGkey(String gkey) {
        this.gkey = gkey;
    }

    public Byte getGkeyType() {
        return gkeyType;
    }

    public void setGkeyType(Byte gkeyType) {
        this.gkeyType = gkeyType;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}