package com.kmhc.model.datacenter.dao;

import org.springframework.stereotype.Repository;

import com.kmhc.model.datacenter.model.AdminMuteVariable;

@Repository("adminMuteVariableMapper")
public interface AdminMuteVariableMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(AdminMuteVariable record);

    int insertSelective(AdminMuteVariable record);

    AdminMuteVariable selectByPrimaryKey(Integer id);
    
    AdminMuteVariable selectByAdminId(Long admin_id);

    int updateByPrimaryKeySelective(AdminMuteVariable record);

    int updateByPrimaryKey(AdminMuteVariable record);
}