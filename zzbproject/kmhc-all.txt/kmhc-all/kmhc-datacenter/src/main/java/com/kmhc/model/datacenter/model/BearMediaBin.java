package com.kmhc.model.datacenter.model;

public class BearMediaBin {
    private Long binId;

    private String binName;

    private Integer mbeCount;

    private Long fileSize;

    private String fileUrl;

    public Long getBinId() {
        return binId;
    }

    public void setBinId(Long binId) {
        this.binId = binId;
    }

    public String getBinName() {
        return binName;
    }

    public void setBinName(String binName) {
        this.binName = binName;
    }

    public Integer getMbeCount() {
        return mbeCount;
    }

    public void setMbeCount(Integer mbeCount) {
        this.mbeCount = mbeCount;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }
}