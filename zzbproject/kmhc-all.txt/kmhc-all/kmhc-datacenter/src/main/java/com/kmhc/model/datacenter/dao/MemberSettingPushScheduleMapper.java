package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingPushSchedule;
import java.util.List;

public interface MemberSettingPushScheduleMapper {
    int deleteByPrimaryKey(Long scheduleId);

    int insert(MemberSettingPushSchedule record);

    MemberSettingPushSchedule selectByPrimaryKey(Long scheduleId);

    List<MemberSettingPushSchedule> selectAll();

    int updateByPrimaryKey(MemberSettingPushSchedule record);
}