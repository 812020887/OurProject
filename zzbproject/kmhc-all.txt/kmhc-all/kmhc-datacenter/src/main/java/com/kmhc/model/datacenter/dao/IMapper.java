package com.kmhc.model.datacenter.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public interface IMapper {
	List<Map> selectSelectiveAll(Map map);
	List<Map<String, String>> selectDatatablesViewAll(Map queryMap);
}
