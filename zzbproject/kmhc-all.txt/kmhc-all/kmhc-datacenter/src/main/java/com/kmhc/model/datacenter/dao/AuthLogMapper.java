package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AuthLog;
import java.util.List;

public interface AuthLogMapper {
    int deleteByPrimaryKey(Long sno);

    int insert(AuthLog record);

    AuthLog selectByPrimaryKey(Long sno);

    List<AuthLog> selectAll();

    int updateByPrimaryKey(AuthLog record);
}