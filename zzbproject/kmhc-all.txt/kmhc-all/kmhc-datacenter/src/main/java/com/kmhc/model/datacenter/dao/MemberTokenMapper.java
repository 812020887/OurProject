package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberToken;
import java.util.List;

public interface MemberTokenMapper {
    int deleteByPrimaryKey(Long id);

    int insert(MemberToken record);

    MemberToken selectByPrimaryKey(Long id);

    List<MemberToken> selectAll();

    int updateByPrimaryKey(MemberToken record);
}