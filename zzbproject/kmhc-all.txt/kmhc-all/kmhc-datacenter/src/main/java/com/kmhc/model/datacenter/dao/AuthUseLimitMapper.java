package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AuthUseLimit;
import java.util.List;

public interface AuthUseLimitMapper {
    int deleteByPrimaryKey(Long sno);

    int insert(AuthUseLimit record);

    AuthUseLimit selectByPrimaryKey(Long sno);

    List<AuthUseLimit> selectAll();

    int updateByPrimaryKey(AuthUseLimit record);
}