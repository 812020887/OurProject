package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.HealthSuggest;
import java.util.List;

public interface HealthSuggestMapper {
    int deleteByPrimaryKey(Long suggestId);

    int insert(HealthSuggest record);

    HealthSuggest selectByPrimaryKey(Long suggestId);

    List<HealthSuggest> selectAll();

    int updateByPrimaryKey(HealthSuggest record);
}