package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.T9SilentSetting;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("t9SilentSettingMapper")
public interface T9SilentSettingMapper {
    int deleteByPrimaryKey(String imei);

    int insert(T9SilentSetting record);

    T9SilentSetting selectByPrimaryKey(String imei);

    List<T9SilentSetting> selectAll();

    int updateByPrimaryKey(T9SilentSetting record);
    
    int update(T9SilentSetting record);
}