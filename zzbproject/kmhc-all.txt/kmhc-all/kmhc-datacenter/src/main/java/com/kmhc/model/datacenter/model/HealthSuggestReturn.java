package com.kmhc.model.datacenter.model;

import java.util.Date;

public class HealthSuggestReturn {
    private Integer no;

    private Integer returnType;

    private Long returnId;

    private String returnContent;

    private Date suggestUpdate;

    private Date createDate;

    private Long suggestId;

    public Integer getNo() {
        return no;
    }

    public void setNo(Integer no) {
        this.no = no;
    }

    public Integer getReturnType() {
        return returnType;
    }

    public void setReturnType(Integer returnType) {
        this.returnType = returnType;
    }

    public Long getReturnId() {
        return returnId;
    }

    public void setReturnId(Long returnId) {
        this.returnId = returnId;
    }

    public String getReturnContent() {
        return returnContent;
    }

    public void setReturnContent(String returnContent) {
        this.returnContent = returnContent;
    }

    public Date getSuggestUpdate() {
        return suggestUpdate;
    }

    public void setSuggestUpdate(Date suggestUpdate) {
        this.suggestUpdate = suggestUpdate;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Long getSuggestId() {
        return suggestId;
    }

    public void setSuggestId(Long suggestId) {
        this.suggestId = suggestId;
    }
}