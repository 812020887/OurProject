package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingWalk {
    private String imei;

    private Integer targetStep;

    private Integer targetHeat;

    private String updated;

    private Date createDate;

    private Date updateDate;

    private Double weight;

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Integer getTargetStep() {
        return targetStep;
    }

    public void setTargetStep(Integer targetStep) {
        this.targetStep = targetStep;
    }

    public Integer getTargetHeat() {
        return targetHeat;
    }

    public void setTargetHeat(Integer targetHeat) {
        this.targetHeat = targetHeat;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }
}