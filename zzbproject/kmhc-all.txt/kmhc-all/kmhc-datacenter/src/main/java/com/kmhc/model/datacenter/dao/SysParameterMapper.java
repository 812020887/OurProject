package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.SysParameter;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("sysParameterMapper")
public interface SysParameterMapper {
    int deleteByPrimaryKey(@Param("type") String type, @Param("name") String name, @Param("itemNo") Integer itemNo);

    int insert(SysParameter record);

    SysParameter selectByPrimaryKey(@Param("type") String type, @Param("name") String name, @Param("itemNo") Integer itemNo);

    List<SysParameter> selectAll();

    int updateByPrimaryKey(SysParameter record);
    
    SysParameter selectByName( @Param("name") String name);
}