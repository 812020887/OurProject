package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.VoiceUploadRecord;

import java.util.Date;
import java.util.List;
import org.apache.ibatis.annotations.Param;

import org.springframework.stereotype.Repository;

@Repository("voiceUploadRecordMapper")
public interface VoiceUploadRecordMapper {
    int deleteByPrimaryKey(@Param("imei") String imei, @Param("timen") Long timen);

    int insert(VoiceUploadRecord record);

    VoiceUploadRecord selectByPrimaryKey(@Param("imei") String imei, @Param("timen") Long timen);
    
    List<VoiceUploadRecord> selectFromWatchByImeiTime(@Param("imei") String imei, @Param("timen") Long timen);

    List<VoiceUploadRecord> selectFromMobileByImei(@Param("imei") String imei);
    
    List<VoiceUploadRecord> selectUndownloadFromMobileByImei(@Param("imei") String imei);
    
    List<VoiceUploadRecord> selectAllOverTimeAndDownloaded(@Param("date") Date date);
    
    List<VoiceUploadRecord> selectAll();

    int updateByPrimaryKey(VoiceUploadRecord record);
}