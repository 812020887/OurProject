package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberAreacode;
import java.util.List;

public interface MemberAreacodeMapper {
    int insert(MemberAreacode record);

    List<MemberAreacode> selectAll();
}