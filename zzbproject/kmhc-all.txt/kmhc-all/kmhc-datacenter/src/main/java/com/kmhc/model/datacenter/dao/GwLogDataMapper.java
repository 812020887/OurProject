package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.GwLogData;
import java.util.List;

public interface GwLogDataMapper {
    int deleteByPrimaryKey(Integer logId);

    int insert(GwLogData record);

    GwLogData selectByPrimaryKey(Integer logId);

    List<GwLogData> selectAll();

    int updateByPrimaryKey(GwLogData record);
}