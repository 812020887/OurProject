package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AuthMapGkeyApi;
import java.util.List;

public interface AuthMapGkeyApiMapper {
    int deleteByPrimaryKey(Long sno);

    int insert(AuthMapGkeyApi record);

    AuthMapGkeyApi selectByPrimaryKey(Long sno);

    List<AuthMapGkeyApi> selectAll();

    int updateByPrimaryKey(AuthMapGkeyApi record);
}