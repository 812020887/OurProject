package com.kmhc.model.datacenter.model;

import java.math.BigDecimal;
import java.util.Date;

public class Company {
    private Long companyId;

    private String name;

    private String pushUrl;

    private String pushAccount;

    private String pushPassword;

    private BigDecimal ispush;

    private BigDecimal uservisible;

    private String remark;

    private Date createdTime;

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPushUrl() {
        return pushUrl;
    }

    public void setPushUrl(String pushUrl) {
        this.pushUrl = pushUrl;
    }

    public String getPushAccount() {
        return pushAccount;
    }

    public void setPushAccount(String pushAccount) {
        this.pushAccount = pushAccount;
    }

    public String getPushPassword() {
        return pushPassword;
    }

    public void setPushPassword(String pushPassword) {
        this.pushPassword = pushPassword;
    }

    public BigDecimal getIspush() {
        return ispush;
    }

    public void setIspush(BigDecimal ispush) {
        this.ispush = ispush;
    }

    public BigDecimal getUservisible() {
        return uservisible;
    }

    public void setUservisible(BigDecimal uservisible) {
        this.uservisible = uservisible;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }
}