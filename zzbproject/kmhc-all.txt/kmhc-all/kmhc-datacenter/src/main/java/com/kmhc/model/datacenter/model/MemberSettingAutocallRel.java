package com.kmhc.model.datacenter.model;

public class MemberSettingAutocallRel {
    private Integer memberId;

    private String whitelistrelationship1;

    private String whitelistrelationship2;

    private String whitelistrelationship3;

    private String whitelistrelationship4;

    private String whitelistrelationship5;

    private String whitelistrelationship6;

    private String whitelistrelationship7;

    private String whitelistrelationship8;

    private String whitelistrelationship9;

    private String whitelistrelationship10;

    private String whitelistrelationship11;

    private String whitelistrelationship12;

    private String whitelistrelationship13;

    private String whitelistrelationship14;

    private String whitelistrelationship15;

    private String whitelistrelationship16;

    private String whitelistrelationship17;

    private String whitelistrelationship18;

    private String whitelistrelationship19;

    private String whitelistrelationship20;

    private String name1;

    private String name2;

    private String name3;

    private String name4;

    private String name5;

    private String name6;

    private String name7;

    private String name8;

    private String name9;

    private String name10;

    private String name11;

    private String name12;

    private String name13;

    private String name14;

    private String name15;

    private String name16;

    private String name17;

    private String name18;

    private String name19;

    private String name20;

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public String getWhitelistrelationship1() {
        return whitelistrelationship1;
    }

    public void setWhitelistrelationship1(String whitelistrelationship1) {
        this.whitelistrelationship1 = whitelistrelationship1;
    }

    public String getWhitelistrelationship2() {
        return whitelistrelationship2;
    }

    public void setWhitelistrelationship2(String whitelistrelationship2) {
        this.whitelistrelationship2 = whitelistrelationship2;
    }

    public String getWhitelistrelationship3() {
        return whitelistrelationship3;
    }

    public void setWhitelistrelationship3(String whitelistrelationship3) {
        this.whitelistrelationship3 = whitelistrelationship3;
    }

    public String getWhitelistrelationship4() {
        return whitelistrelationship4;
    }

    public void setWhitelistrelationship4(String whitelistrelationship4) {
        this.whitelistrelationship4 = whitelistrelationship4;
    }

    public String getWhitelistrelationship5() {
        return whitelistrelationship5;
    }

    public void setWhitelistrelationship5(String whitelistrelationship5) {
        this.whitelistrelationship5 = whitelistrelationship5;
    }

    public String getWhitelistrelationship6() {
        return whitelistrelationship6;
    }

    public void setWhitelistrelationship6(String whitelistrelationship6) {
        this.whitelistrelationship6 = whitelistrelationship6;
    }

    public String getWhitelistrelationship7() {
        return whitelistrelationship7;
    }

    public void setWhitelistrelationship7(String whitelistrelationship7) {
        this.whitelistrelationship7 = whitelistrelationship7;
    }

    public String getWhitelistrelationship8() {
        return whitelistrelationship8;
    }

    public void setWhitelistrelationship8(String whitelistrelationship8) {
        this.whitelistrelationship8 = whitelistrelationship8;
    }

    public String getWhitelistrelationship9() {
        return whitelistrelationship9;
    }

    public void setWhitelistrelationship9(String whitelistrelationship9) {
        this.whitelistrelationship9 = whitelistrelationship9;
    }

    public String getWhitelistrelationship10() {
        return whitelistrelationship10;
    }

    public void setWhitelistrelationship10(String whitelistrelationship10) {
        this.whitelistrelationship10 = whitelistrelationship10;
    }

    public String getWhitelistrelationship11() {
        return whitelistrelationship11;
    }

    public void setWhitelistrelationship11(String whitelistrelationship11) {
        this.whitelistrelationship11 = whitelistrelationship11;
    }

    public String getWhitelistrelationship12() {
        return whitelistrelationship12;
    }

    public void setWhitelistrelationship12(String whitelistrelationship12) {
        this.whitelistrelationship12 = whitelistrelationship12;
    }

    public String getWhitelistrelationship13() {
        return whitelistrelationship13;
    }

    public void setWhitelistrelationship13(String whitelistrelationship13) {
        this.whitelistrelationship13 = whitelistrelationship13;
    }

    public String getWhitelistrelationship14() {
        return whitelistrelationship14;
    }

    public void setWhitelistrelationship14(String whitelistrelationship14) {
        this.whitelistrelationship14 = whitelistrelationship14;
    }

    public String getWhitelistrelationship15() {
        return whitelistrelationship15;
    }

    public void setWhitelistrelationship15(String whitelistrelationship15) {
        this.whitelistrelationship15 = whitelistrelationship15;
    }

    public String getWhitelistrelationship16() {
        return whitelistrelationship16;
    }

    public void setWhitelistrelationship16(String whitelistrelationship16) {
        this.whitelistrelationship16 = whitelistrelationship16;
    }

    public String getWhitelistrelationship17() {
        return whitelistrelationship17;
    }

    public void setWhitelistrelationship17(String whitelistrelationship17) {
        this.whitelistrelationship17 = whitelistrelationship17;
    }

    public String getWhitelistrelationship18() {
        return whitelistrelationship18;
    }

    public void setWhitelistrelationship18(String whitelistrelationship18) {
        this.whitelistrelationship18 = whitelistrelationship18;
    }

    public String getWhitelistrelationship19() {
        return whitelistrelationship19;
    }

    public void setWhitelistrelationship19(String whitelistrelationship19) {
        this.whitelistrelationship19 = whitelistrelationship19;
    }

    public String getWhitelistrelationship20() {
        return whitelistrelationship20;
    }

    public void setWhitelistrelationship20(String whitelistrelationship20) {
        this.whitelistrelationship20 = whitelistrelationship20;
    }

    public String getName1() {
        return name1;
    }

    public void setName1(String name1) {
        this.name1 = name1;
    }

    public String getName2() {
        return name2;
    }

    public void setName2(String name2) {
        this.name2 = name2;
    }

    public String getName3() {
        return name3;
    }

    public void setName3(String name3) {
        this.name3 = name3;
    }

    public String getName4() {
        return name4;
    }

    public void setName4(String name4) {
        this.name4 = name4;
    }

    public String getName5() {
        return name5;
    }

    public void setName5(String name5) {
        this.name5 = name5;
    }

    public String getName6() {
        return name6;
    }

    public void setName6(String name6) {
        this.name6 = name6;
    }

    public String getName7() {
        return name7;
    }

    public void setName7(String name7) {
        this.name7 = name7;
    }

    public String getName8() {
        return name8;
    }

    public void setName8(String name8) {
        this.name8 = name8;
    }

    public String getName9() {
        return name9;
    }

    public void setName9(String name9) {
        this.name9 = name9;
    }

    public String getName10() {
        return name10;
    }

    public void setName10(String name10) {
        this.name10 = name10;
    }

    public String getName11() {
        return name11;
    }

    public void setName11(String name11) {
        this.name11 = name11;
    }

    public String getName12() {
        return name12;
    }

    public void setName12(String name12) {
        this.name12 = name12;
    }

    public String getName13() {
        return name13;
    }

    public void setName13(String name13) {
        this.name13 = name13;
    }

    public String getName14() {
        return name14;
    }

    public void setName14(String name14) {
        this.name14 = name14;
    }

    public String getName15() {
        return name15;
    }

    public void setName15(String name15) {
        this.name15 = name15;
    }

    public String getName16() {
        return name16;
    }

    public void setName16(String name16) {
        this.name16 = name16;
    }

    public String getName17() {
        return name17;
    }

    public void setName17(String name17) {
        this.name17 = name17;
    }

    public String getName18() {
        return name18;
    }

    public void setName18(String name18) {
        this.name18 = name18;
    }

    public String getName19() {
        return name19;
    }

    public void setName19(String name19) {
        this.name19 = name19;
    }

    public String getName20() {
        return name20;
    }

    public void setName20(String name20) {
        this.name20 = name20;
    }
}