package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingFall;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("memberSettingFallMapper")
public interface MemberSettingFallMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingFall record);

    MemberSettingFall selectByPrimaryKey(String imei);

    List<MemberSettingFall> selectAll();

    int updateByPrimaryKey(MemberSettingFall record);
}