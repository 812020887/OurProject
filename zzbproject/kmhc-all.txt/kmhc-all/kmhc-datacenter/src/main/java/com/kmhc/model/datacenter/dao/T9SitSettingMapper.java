package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.T9SitSetting;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("t9SitSettingMapper")
public interface T9SitSettingMapper {
    int deleteByPrimaryKey(String imei);

    int insert(T9SitSetting record);

    T9SitSetting selectByPrimaryKey(String imei);

    List<T9SitSetting> selectAll();

    int updateByPrimaryKey(T9SitSetting record);
    
    int update(T9SitSetting record);
}