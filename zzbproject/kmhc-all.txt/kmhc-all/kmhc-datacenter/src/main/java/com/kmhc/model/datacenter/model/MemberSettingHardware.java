package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingHardware {
    private String imei;

    private Date updateTime;

    private String switch1;

    private String switch2;

    private String switch3;

    private String switch4;

    private String switch5;

    private String area;

    private Integer language;

    private String updated;

    private Integer speakLang;
    

    public MemberSettingHardware() {
		super();
	}

	public MemberSettingHardware(String imei) {
		super();
		this.imei = imei;
	}

	public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getSwitch1() {
        return switch1;
    }

    public void setSwitch1(String switch1) {
        this.switch1 = switch1;
    }

    public String getSwitch2() {
        return switch2;
    }

    public void setSwitch2(String switch2) {
        this.switch2 = switch2;
    }

    public String getSwitch3() {
        return switch3;
    }

    public void setSwitch3(String switch3) {
        this.switch3 = switch3;
    }

    public String getSwitch4() {
        return switch4;
    }

    public void setSwitch4(String switch4) {
        this.switch4 = switch4;
    }

    public String getSwitch5() {
        return switch5;
    }

    public void setSwitch5(String switch5) {
        this.switch5 = switch5;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public Integer getLanguage() {
        return language;
    }

    public void setLanguage(Integer language) {
        this.language = language;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    public Integer getSpeakLang() {
        return speakLang;
    }

    public void setSpeakLang(Integer speakLang) {
        this.speakLang = speakLang;
    }
}