package com.kmhc.model.datacenter.model;

import java.util.Date;

public class AuthMobileCard {
	
	Long sim;
	String status;
	Date create_time;
	Date update_time;
	
	public Long getSim() {
		return sim;
	}
	public void setSim(Long sim) {
		this.sim = sim;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}
	public Date getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(Date update_time) {
		this.update_time = update_time;
	}
	
}
