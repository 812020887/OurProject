package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrHeartrateRow;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("psrHeartrateRowMapper")
public interface PsrHeartrateRowMapper {
    int deleteByPrimaryKey(@Param("hrDate") String hrDate, @Param("itemno") Integer itemno);

    int insert(PsrHeartrateRow record);

    PsrHeartrateRow selectByPrimaryKey(@Param("hrDate") String hrDate, @Param("itemno") Integer itemno);

    List<PsrHeartrateRow> selectAll();

    int updateByPrimaryKey(PsrHeartrateRow record);
}