package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrTellog;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
@Repository
public interface PsrTellogMapper {
    int deleteByPrimaryKey(@Param("imei") String imei, @Param("sno") Integer sno);

    int insert(PsrTellog record);

    PsrTellog selectByPrimaryKey(@Param("imei") String imei, @Param("sno") Integer sno);

    List<PsrTellog> selectAll();

    int updateByPrimaryKey(PsrTellog record);
}