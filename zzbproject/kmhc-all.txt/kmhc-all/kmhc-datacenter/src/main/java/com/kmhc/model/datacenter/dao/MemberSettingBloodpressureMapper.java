package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingBloodpressure;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("memberSettingBloodpressureMapper")
public interface MemberSettingBloodpressureMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingBloodpressure record);

    MemberSettingBloodpressure selectByPrimaryKey(String imei);

    List<MemberSettingBloodpressure> selectAll();

    int updateByPrimaryKey(MemberSettingBloodpressure record);
    
    int update(MemberSettingBloodpressure record);
}