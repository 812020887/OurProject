package com.kmhc.model.datacenter.model;

import java.util.Date;

public class GwLogReturn {
    private Long postid;

    private Short status;

    private String msg;

    private String retrunData;

    private Date createDate;

    public Long getPostid() {
        return postid;
    }

    public void setPostid(Long postid) {
        this.postid = postid;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getRetrunData() {
        return retrunData;
    }

    public void setRetrunData(String retrunData) {
        this.retrunData = retrunData;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}