package com.kmhc.model.datacenter.model;

public class AuthHost {
    private Long sno;

    private Long gkeyId;

    private String ipDomain;

    private Byte hostType;

    private Byte enable;

    public Long getSno() {
        return sno;
    }

    public void setSno(Long sno) {
        this.sno = sno;
    }

    public Long getGkeyId() {
        return gkeyId;
    }

    public void setGkeyId(Long gkeyId) {
        this.gkeyId = gkeyId;
    }

    public String getIpDomain() {
        return ipDomain;
    }

    public void setIpDomain(String ipDomain) {
        this.ipDomain = ipDomain;
    }

    public Byte getHostType() {
        return hostType;
    }

    public void setHostType(Byte hostType) {
        this.hostType = hostType;
    }

    public Byte getEnable() {
        return enable;
    }

    public void setEnable(Byte enable) {
        this.enable = enable;
    }
}