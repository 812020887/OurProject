package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingAutochange;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("memberSettingAutochangeMapper")
public interface MemberSettingAutochangeMapper {
    int deleteByPrimaryKey(@Param("memberId") Long memberId, @Param("type") String type);

    int insert(MemberSettingAutochange record);

    MemberSettingAutochange selectByPrimaryKey(@Param("memberId") Long memberId, @Param("type") String type);

    List<MemberSettingAutochange> selectAll();

    int updateByPrimaryKey(MemberSettingAutochange record);
}