package com.kmhc.model.datacenter.model;

import java.util.Date;

public class ImeiLog {
    private Long imeilogId;

    private Long memberId;

    private String imei;

    private Short used;

    private Date createtime;

    public Long getImeilogId() {
        return imeilogId;
    }

    public void setImeilogId(Long imeilogId) {
        this.imeilogId = imeilogId;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Short getUsed() {
        return used;
    }

    public void setUsed(Short used) {
        this.used = used;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }
}