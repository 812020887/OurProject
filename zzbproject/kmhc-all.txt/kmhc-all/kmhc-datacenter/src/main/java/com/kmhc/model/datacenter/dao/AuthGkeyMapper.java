package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AuthGkey;
import java.util.List;

public interface AuthGkeyMapper {
    int deleteByPrimaryKey(Long son);

    int insert(AuthGkey record);

    AuthGkey selectByPrimaryKey(Long son);

    List<AuthGkey> selectAll();

    int updateByPrimaryKey(AuthGkey record);
}