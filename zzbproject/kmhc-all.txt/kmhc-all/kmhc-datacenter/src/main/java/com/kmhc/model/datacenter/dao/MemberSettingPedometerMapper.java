package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingPedometer;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("memberSettingPedometerMapper")
public interface MemberSettingPedometerMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingPedometer record);

    MemberSettingPedometer selectByPrimaryKey(String imei);

    List<MemberSettingPedometer> selectAll();

    int updateByPrimaryKey(MemberSettingPedometer record);
}