package com.kmhc.model.datacenter.model;

import java.util.Date;

public class CheckRM {
    private String imei;

    private String imsi;

    private String batchDetailKey;

    private String name;

    private Integer currentVal;

    private Integer onLineStatus;

    private Date createDate;

    private Date updateDate;
    
    

    public CheckRM() {
		super();
	}
    
	public CheckRM(String imei, String name, Integer currentVal,
			Integer onLineStatus) {
		super();
		this.imei = imei;
		this.name = name;
		this.currentVal = currentVal;
		this.onLineStatus = onLineStatus;
	}



	public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getBatchDetailKey() {
        return batchDetailKey;
    }

    public void setBatchDetailKey(String batchDetailKey) {
        this.batchDetailKey = batchDetailKey;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCurrentVal() {
        return currentVal;
    }

    public void setCurrentVal(Integer currentVal) {
        this.currentVal = currentVal;
    }

    public Integer getOnLineStatus() {
        return onLineStatus;
    }

    public void setOnLineStatus(Integer onLineStatus) {
        this.onLineStatus = onLineStatus;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}