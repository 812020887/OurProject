package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingSport;
import java.util.List;

public interface MemberSettingSportMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingSport record);

    MemberSettingSport selectByPrimaryKey(String imei);

    List<MemberSettingSport> selectAll();

    int updateByPrimaryKey(MemberSettingSport record);
}