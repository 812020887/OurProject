package com.kmhc.model.datacenter.dao;
import com.kmhc.model.datacenter.model.PsrStep;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PsrStepMapper{
    int deleteByPrimaryKey(Integer sno);

    int insert(PsrStep record);

    PsrStep selectByPrimaryKey(Integer sno);

    List<PsrStep> selectAll();

    int updateByPrimaryKey(PsrStep record);
    
    List<PsrStep> selectAllByImei(@Param("imei") String imei);

	List<PsrStep> selectCountByImei(@Param("imei") String imei, @Param("index") Integer index,
			@Param("count") Integer count);
	
	List<PsrStep> selectDuringByImei(@Param("imei") String imei, @Param("start") String start,
			@Param("end") String end);
	
	int selectByETime(PsrStep psrStep);
}