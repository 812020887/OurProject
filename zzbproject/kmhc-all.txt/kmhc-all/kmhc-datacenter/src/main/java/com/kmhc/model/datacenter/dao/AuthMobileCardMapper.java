package com.kmhc.model.datacenter.dao;

import org.springframework.stereotype.Repository;


@Repository("authMobileCardMapper")
public interface AuthMobileCardMapper {
	
    String selectByPrimaryKey(Long sim);
    
    void updateByPrimaryKey(Long sim);

}