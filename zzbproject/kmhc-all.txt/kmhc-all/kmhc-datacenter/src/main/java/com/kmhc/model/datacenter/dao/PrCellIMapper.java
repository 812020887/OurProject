package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PrCellI;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
@Repository
public interface PrCellIMapper {
    int deleteByPrimaryKey(@Param("batchDetailKey") String batchDetailKey, @Param("itemno") Short itemno);

    int insert(PrCellI record);

    int insertSelective(PrCellI record);
    
    PrCellI selectByPrimaryKey(@Param("batchDetailKey") String batchDetailKey, @Param("itemno") Short itemno);

    List<PrCellI> selectAll();

    int updateByPrimaryKey(PrCellI record);
}