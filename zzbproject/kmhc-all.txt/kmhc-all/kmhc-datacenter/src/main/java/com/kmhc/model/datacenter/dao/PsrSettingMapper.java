package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrSetting;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("psrSettingMapper")
public interface PsrSettingMapper {
	int deleteByPrimaryKey(Integer sId);

	int insert(PsrSetting record);

	PsrSetting selectByPrimaryKey(Integer sId);

	List<PsrSetting> selectAll();

	int updateByPrimaryKey(PsrSetting record);

	List<PsrSetting> selectByImeiAndType(@Param("imei") String imei, @Param("type") String type);

	List<PsrSetting> selectAllByImei(@Param("imei") String imei);
	
	
	int selectCountByImei(@Param("imei") String imei);

	PsrSetting selectSingleByTeamAndType(@Param("imei") String imei, @Param("team") String team, @Param("type") String type);

	@Transactional
	int deleteAllByImei(@Param("imei") String imei);

	@Transactional
	int deleteSingleByTeamAndType(@Param("imei") String imei, @Param("team") String team, @Param("type") String type);

	@Transactional
	int insertSingle(@Param("setting") PsrSetting setting);

	@Transactional
	int updataSingleByTeamAndType(@Param("setting") PsrSetting setting,@Param("team") String team,@Param("type") String type);

}