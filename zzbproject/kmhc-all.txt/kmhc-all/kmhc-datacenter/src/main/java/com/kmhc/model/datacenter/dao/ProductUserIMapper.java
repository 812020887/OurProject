package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.ProductUserI;
import java.util.List;

public interface ProductUserIMapper {
    int deleteByPrimaryKey(Integer sno);

    int insert(ProductUserI record);

    ProductUserI selectByPrimaryKey(Integer sno);

    List<ProductUserI> selectAll();

    int updateByPrimaryKey(ProductUserI record);
}