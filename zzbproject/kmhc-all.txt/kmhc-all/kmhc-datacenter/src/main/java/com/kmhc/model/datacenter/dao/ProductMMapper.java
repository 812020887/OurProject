package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.ProductM;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ProductMMapper {
    int deleteByPrimaryKey(@Param("snKey") Integer snKey, @Param("idxNo") String idxNo);

    int insert(ProductM record);

    ProductM selectByPrimaryKey(@Param("snKey") Integer snKey, @Param("idxNo") String idxNo);

    List<ProductM> selectAll();

    int updateByPrimaryKey(ProductM record);
}