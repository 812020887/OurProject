package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PrOptionI;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
@Repository
public interface PrOptionIMapper {
    int deleteByPrimaryKey(String batchDetailKey);

    int insert(PrOptionI record);

    PrOptionI selectByPrimaryKey(String batchDetailKey);

    List<PrOptionI> selectAll();

    int updateByPrimaryKey(PrOptionI record);
}