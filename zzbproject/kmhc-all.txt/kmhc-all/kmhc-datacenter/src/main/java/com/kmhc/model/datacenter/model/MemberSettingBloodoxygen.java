package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingBloodoxygen {
    private String imei;

    private Date updateTime;

    private Integer boH;

    private Integer boL;

    private String updated;
    
    
    
    public MemberSettingBloodoxygen() {
		super();
	}

	public MemberSettingBloodoxygen(String imei) {
		super();
		this.imei = imei;
	}
	
	public MemberSettingBloodoxygen(String imei, Integer boH, Integer boL,
			String updated) {
		super();
		this.imei = imei;
		this.boH = boH;
		this.boL = boL;
		this.updated = updated;
	}

	public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getBoH() {
        return boH;
    }

    public void setBoH(Integer boH) {
        this.boH = boH;
    }

    public Integer getBoL() {
        return boL;
    }

    public void setBoL(Integer boL) {
        this.boL = boL;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }
}