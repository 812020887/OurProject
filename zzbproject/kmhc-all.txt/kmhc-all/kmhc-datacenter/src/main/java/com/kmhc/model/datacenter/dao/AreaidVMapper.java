package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AreaidV;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;
@Repository
public interface AreaidVMapper {
    int insert(AreaidV record);

    List<AreaidV> selectAll();
    
    List<AreaidV> selectByAreaName(HashMap<String, String> word);
    
    List<AreaidV> selectByAreaCityName(String cityName);
}