package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrBatchMaster;
import java.util.List;

public interface PsrBatchMasterMapper {
    int insert(PsrBatchMaster record);

    List<PsrBatchMaster> selectAll();
}