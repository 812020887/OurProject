package com.kmhc.model.datacenter.framework.orm;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class MyBatisDAOAdapter<T> extends SqlSessionDaoSupport 
	implements IDAOTemplate<T> {
	
	
    @Autowired(required = false)
    public void setSuperSessionFactory(SqlSessionFactory sqlSessionFactory) {
    	super.setSqlSessionFactory(sqlSessionFactory);
    };
   
	
	@Override
	public int save(T t) {
		return 0;
	}
	
	@Override
	public int batchSave(List<T> list) {
		return 0;
	}
	
	@Override
	public int update(T t) {
		return 0;
	}
	
	@Override
	public int update(T t, String property) {
		return 0;
	}

	@Override
	public int delete(T t) {
		return 0;
	}

	@Override
	public int deleteById(Integer id) {
		return 0;
	}

	@Override
	public T findById(Integer id) {
		return null;
	}

	@Override
	public List<T> findAll() {
		return null;
	}

	@Override
	public T findByProperty(String param, Object value) {
		return findByProperty(new String[] { param }, new Object[] { value });
	}
	
	@Override
	public T findByProperty(String[] params, Object[] value) {
		if (params.length != value.length) throw new IllegalArgumentException();
		
		final Map<String, Object> keywords = new HashMap<String, Object>();
		for (int i = 0; i < params.length; i++) {
			keywords.put(params[i], value[i]);
		}
		return findByProperty(keywords);
	}
	
	@Override
	public T findByProperty(Map<String, Object> keywords) {
		final List<T> dbDatas = findByKeywords(keywords);
		return dbDatas.size() == 0 ? null : dbDatas.get(0);
	}
	
	@Override
	public List<T> findByKeywords(String param, Object value) {
		return findByKeywords(new String[] { param }, new Object[] { value });
	}

	@Override
	public List<T> findByKeywords(String[] params, Object[] value) {
		if (params.length != value.length) throw new IllegalArgumentException();
		
		final Map<String, Object> keywords = new HashMap<String, Object>();
		for (int i = 0; i < params.length; i++) {
			keywords.put(params[i], value[i]);
		}
		return findByKeywords(keywords);
	}

	@Override
	public List<T> findByKeywords(Map<String, Object> keywords) {
		return null;
	}
	

}
