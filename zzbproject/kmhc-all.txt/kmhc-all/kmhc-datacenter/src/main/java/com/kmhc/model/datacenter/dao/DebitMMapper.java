package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.DebitM;
import java.util.List;

import org.springframework.stereotype.Repository;
@Repository("debitMMapper")
public interface DebitMMapper {
    int deleteByPrimaryKey(String imei);

    int insert(DebitM record);

    DebitM selectByPrimaryKey(String imei);

    List<DebitM> selectAll();

    int updateByPrimaryKey(DebitM record);
}