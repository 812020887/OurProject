package com.kmhc.model.datacenter.model;

public class BearMediaMbe {
    private Long mbeId;

    private String title;

    private String mbeName;

    private Long fileSize;

    private String fileUrl;

    public Long getMbeId() {
        return mbeId;
    }

    public void setMbeId(Long mbeId) {
        this.mbeId = mbeId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMbeName() {
        return mbeName;
    }

    public void setMbeName(String mbeName) {
        this.mbeName = mbeName;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }
}