package com.kmhc.model.datacenter.model;

import java.util.Date;

public class AngelOrder {
    private Long orderId;

    private Date createdTime;

    private Integer pay;

    private Integer price;

    private Integer status;

    private Date updatedTime;

    private Long memberId;

    private Long usedFunctionId;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public Integer getPay() {
        return pay;
    }

    public void setPay(Integer pay) {
        this.pay = pay;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public Long getUsedFunctionId() {
        return usedFunctionId;
    }

    public void setUsedFunctionId(Long usedFunctionId) {
        this.usedFunctionId = usedFunctionId;
    }
}