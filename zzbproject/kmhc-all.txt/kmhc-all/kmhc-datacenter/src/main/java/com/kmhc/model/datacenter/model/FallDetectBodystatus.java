package com.kmhc.model.datacenter.model;

import java.util.Date;

public class FallDetectBodystatus {
    private Long detectSno;

    private Long memberId;

    private Date fdDate;

    private Integer activeDate;

    private String status;

    private Byte updatedStatus;

    private Date createDate;

    private Date updateDate;

    public Long getDetectSno() {
        return detectSno;
    }

    public void setDetectSno(Long detectSno) {
        this.detectSno = detectSno;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public Date getFdDate() {
        return fdDate;
    }

    public void setFdDate(Date fdDate) {
        this.fdDate = fdDate;
    }

    public Integer getActiveDate() {
        return activeDate;
    }

    public void setActiveDate(Integer activeDate) {
        this.activeDate = activeDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Byte getUpdatedStatus() {
        return updatedStatus;
    }

    public void setUpdatedStatus(Byte updatedStatus) {
        this.updatedStatus = updatedStatus;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}