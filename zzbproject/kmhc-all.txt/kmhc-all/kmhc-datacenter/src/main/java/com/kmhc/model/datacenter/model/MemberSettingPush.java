package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingPush {
    private Long pushId;

    private String pushowneraccount;

    private Byte status;

    private String actionType;

    private String title;

    private String content;

    private Byte pushType;

    private Date createdTime;

    private Date updateTime;

    private Integer receiverCount;

    private Byte pushowneraccountrole;

    public Long getPushId() {
        return pushId;
    }

    public void setPushId(Long pushId) {
        this.pushId = pushId;
    }

    public String getPushowneraccount() {
        return pushowneraccount;
    }

    public void setPushowneraccount(String pushowneraccount) {
        this.pushowneraccount = pushowneraccount;
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Byte getPushType() {
        return pushType;
    }

    public void setPushType(Byte pushType) {
        this.pushType = pushType;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getReceiverCount() {
        return receiverCount;
    }

    public void setReceiverCount(Integer receiverCount) {
        this.receiverCount = receiverCount;
    }

    public Byte getPushowneraccountrole() {
        return pushowneraccountrole;
    }

    public void setPushowneraccountrole(Byte pushowneraccountrole) {
        this.pushowneraccountrole = pushowneraccountrole;
    }
}