package com.kmhc.model.datacenter.model;

import java.io.Serializable;
import java.util.Date;

public class DeviceList implements Serializable{
        
    private static final long serialVersionUID = 1L;

    private String imei;

    private Long type;

    private String color;

    private String batch;

    private String sn;

    private Date createdate;

    private Long no;
    
    public DeviceList() {
		super();
	}

	public DeviceList(String imei, Long type, String color, String batch,
			String sn) {
		super();
		this.imei = imei;
		this.type = type;
		this.color = color;
		this.batch = batch;
		this.sn = sn;
	}

	public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Long getType() {
        return type;
    }

    public void setType(Long type) {
        this.type = type;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Long getNo() {
        return no;
    }

    public void setNo(Long no) {
        this.no = no;
    }
}