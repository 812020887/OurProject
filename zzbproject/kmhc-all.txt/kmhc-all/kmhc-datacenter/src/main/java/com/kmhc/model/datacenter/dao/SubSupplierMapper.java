package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.SubSupplier;
import java.util.List;

public interface SubSupplierMapper {
    int deleteByPrimaryKey(Long subSupplierId);

    int insert(SubSupplier record);

    SubSupplier selectByPrimaryKey(Long subSupplierId);

    List<SubSupplier> selectAll();

    int updateByPrimaryKey(SubSupplier record);
}