package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.EfCellI;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("efCellIMapper")
public interface EfCellIMapper {
    int deleteByPrimaryKey(@Param("batchDetailKey") String batchDetailKey, @Param("itemno") Short itemno);

    int insert(EfCellI record);

    EfCellI selectByPrimaryKey(@Param("batchDetailKey") String batchDetailKey, @Param("itemno") Short itemno);

    List<EfCellI> selectAll();

    int updateByPrimaryKey(EfCellI record);
}