package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AuthMapGkeySupplier;
import java.util.List;

public interface AuthMapGkeySupplierMapper {
    int deleteByPrimaryKey(Long sno);

    int insert(AuthMapGkeySupplier record);

    AuthMapGkeySupplier selectByPrimaryKey(Long sno);

    List<AuthMapGkeySupplier> selectAll();

    int updateByPrimaryKey(AuthMapGkeySupplier record);
}