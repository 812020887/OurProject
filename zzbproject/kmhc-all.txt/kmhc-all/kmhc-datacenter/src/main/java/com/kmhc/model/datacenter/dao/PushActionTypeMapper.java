package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PushActionType;
import java.util.List;

public interface PushActionTypeMapper {
    int deleteByPrimaryKey(Long actionId);

    int insert(PushActionType record);

    PushActionType selectByPrimaryKey(Long actionId);

    List<PushActionType> selectAll();

    int updateByPrimaryKey(PushActionType record);
}