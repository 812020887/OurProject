package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.GwLogException;
import java.util.List;

public interface GwLogExceptionMapper {
    int deleteByPrimaryKey(Long postid);

    int insert(GwLogException record);

    GwLogException selectByPrimaryKey(Long postid);

    List<GwLogException> selectAll();

    int updateByPrimaryKey(GwLogException record);
}