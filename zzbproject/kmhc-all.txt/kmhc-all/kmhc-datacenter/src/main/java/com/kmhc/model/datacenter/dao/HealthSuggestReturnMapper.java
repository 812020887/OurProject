package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.HealthSuggestReturn;
import java.util.List;

public interface HealthSuggestReturnMapper {
    int insert(HealthSuggestReturn record);

    List<HealthSuggestReturn> selectAll();
}