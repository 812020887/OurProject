package com.kmhc.model.datacenter.model;

public class BearParameter {
    private String parameterName;

    private Integer itemNo;

    private String parameterType;

    private Long memberId;

    private String itemName;

    private String parameterValue;

    private String itemNameEn;

    private String itemNameJp;

    private String itemNameCn;

    public String getParameterName() {
        return parameterName;
    }

    public void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }

    public Integer getItemNo() {
        return itemNo;
    }

    public void setItemNo(Integer itemNo) {
        this.itemNo = itemNo;
    }

    public String getParameterType() {
        return parameterType;
    }

    public void setParameterType(String parameterType) {
        this.parameterType = parameterType;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getParameterValue() {
        return parameterValue;
    }

    public void setParameterValue(String parameterValue) {
        this.parameterValue = parameterValue;
    }

    public String getItemNameEn() {
        return itemNameEn;
    }

    public void setItemNameEn(String itemNameEn) {
        this.itemNameEn = itemNameEn;
    }

    public String getItemNameJp() {
        return itemNameJp;
    }

    public void setItemNameJp(String itemNameJp) {
        this.itemNameJp = itemNameJp;
    }

    public String getItemNameCn() {
        return itemNameCn;
    }

    public void setItemNameCn(String itemNameCn) {
        this.itemNameCn = itemNameCn;
    }
}