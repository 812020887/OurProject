package com.kmhc.model.datacenter.model;

import java.util.Date;

public class EfGeofenceLog {
    private String batchKey;

    private String imei;

    private Short geoNo;

    private Short locationType;

    private Short pushType;

    private Date createDate;

    private String points;

    public String getBatchKey() {
        return batchKey;
    }

    public void setBatchKey(String batchKey) {
        this.batchKey = batchKey;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Short getGeoNo() {
        return geoNo;
    }

    public void setGeoNo(Short geoNo) {
        this.geoNo = geoNo;
    }

    public Short getLocationType() {
        return locationType;
    }

    public void setLocationType(Short locationType) {
        this.locationType = locationType;
    }

    public Short getPushType() {
        return pushType;
    }

    public void setPushType(Short pushType) {
        this.pushType = pushType;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getPoints() {
        return points;
    }

    public void setPoints(String points) {
        this.points = points;
    }
}