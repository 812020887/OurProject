package com.kmhc.model.datacenter.dao;

import org.springframework.stereotype.Repository;

import com.kmhc.model.datacenter.model.C100DeviceStatus;
@Repository("c100DeviceStatusMapper")
public interface C100DeviceStatusMapper {
    int deleteByPrimaryKey(Integer no);
    
    int insert(C100DeviceStatus record);

    int insertSelective(C100DeviceStatus record);

    C100DeviceStatus selectByPrimaryKey(Integer no);
    
    C100DeviceStatus selectByImei(String imei);

    int updateByPrimaryKeySelective(C100DeviceStatus record);

    int updateByPrimaryKey(C100DeviceStatus record);
}