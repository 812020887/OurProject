package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.SsMemberGroup;
import java.util.List;

public interface SsMemberGroupMapper {
    int deleteByPrimaryKey(Long groupId);

    int insert(SsMemberGroup record);

    SsMemberGroup selectByPrimaryKey(Long groupId);

    List<SsMemberGroup> selectAll();

    int updateByPrimaryKey(SsMemberGroup record);
}