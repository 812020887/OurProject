package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.Cid2gps;
import java.util.List;

public interface Cid2gpsMapper {
    int insert(Cid2gps record);

    List<Cid2gps> selectAll();
}