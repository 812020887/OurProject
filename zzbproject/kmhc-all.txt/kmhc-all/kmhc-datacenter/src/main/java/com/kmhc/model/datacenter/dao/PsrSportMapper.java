package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrSport;
import java.util.List;

public interface PsrSportMapper {
    int deleteByPrimaryKey(Long sno);

    int insert(PsrSport record);

    PsrSport selectByPrimaryKey(Long sno);

    List<PsrSport> selectAll();

    int updateByPrimaryKey(PsrSport record);
}