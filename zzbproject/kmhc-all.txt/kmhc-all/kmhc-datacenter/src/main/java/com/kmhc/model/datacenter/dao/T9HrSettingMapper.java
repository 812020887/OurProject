package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.T9HrSetting;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("t9HrSettingMapper")
public interface T9HrSettingMapper {
    int deleteByPrimaryKey(String imei);

    int insert(T9HrSetting record);

    T9HrSetting selectByPrimaryKey(String imei);

    List<T9HrSetting> selectAll();

    int updateByPrimaryKey(T9HrSetting record);
    
    int update(T9HrSetting record);
}