package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingActivity;
import java.util.List;

public interface MemberSettingActivityMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingActivity record);

    MemberSettingActivity selectByPrimaryKey(String imei);

    List<MemberSettingActivity> selectAll();

    int updateByPrimaryKey(MemberSettingActivity record);
}