package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AdminUser;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository  
public interface AdminUserMapper {
    int deleteByPrimaryKey(Long adminUserId);

    int insert(AdminUser record);

    AdminUser selectByPrimaryKey(Long adminUserId);

    List<AdminUser> selectAll();

    int updateByPrimaryKey(AdminUser record);
}