package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.T9LbsSetting;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("t9LbsSettingMapper")
public interface T9LbsSettingMapper {
    int deleteByPrimaryKey(String imei);

    int insert(T9LbsSetting record);

    T9LbsSetting selectByPrimaryKey(String imei);

    List<T9LbsSetting> selectAll();

    int updateByPrimaryKey(T9LbsSetting record);
    
    int update(T9LbsSetting record);
}