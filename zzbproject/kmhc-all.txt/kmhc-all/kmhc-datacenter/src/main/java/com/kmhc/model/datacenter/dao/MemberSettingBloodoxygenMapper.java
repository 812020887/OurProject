package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingBloodoxygen;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("memberSettingBloodoxygenMapper")
public interface MemberSettingBloodoxygenMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingBloodoxygen record);

    MemberSettingBloodoxygen selectByPrimaryKey(String imei);

    List<MemberSettingBloodoxygen> selectAll();

    int updateByPrimaryKey(MemberSettingBloodoxygen record);
    
    int update(MemberSettingBloodoxygen record);
}