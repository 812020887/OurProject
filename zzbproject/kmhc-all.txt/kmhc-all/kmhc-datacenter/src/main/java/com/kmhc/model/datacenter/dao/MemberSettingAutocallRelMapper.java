package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingAutocallRel;
import java.util.List;

public interface MemberSettingAutocallRelMapper {
    int deleteByPrimaryKey(Integer memberId);

    int insert(MemberSettingAutocallRel record);

    MemberSettingAutocallRel selectByPrimaryKey(Integer memberId);

    List<MemberSettingAutocallRel> selectAll();

    int updateByPrimaryKey(MemberSettingAutocallRel record);
}