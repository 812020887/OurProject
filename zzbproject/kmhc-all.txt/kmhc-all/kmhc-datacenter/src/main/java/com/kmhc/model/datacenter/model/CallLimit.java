package com.kmhc.model.datacenter.model;

import java.util.Date;

public class CallLimit {
    private String imei;

    private Integer number;

    private Date limitBegin;

    private Date limitEnd;

    private Date updateDate;

    private Short t1Hex;

    private Short t2Hex;

    private Short t3Hex;

    private Short t4Hex;

    private Short t5Hex;

    private Short t6Hex;

    private Short t7Hex;

    private Short mode;

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Date getLimitBegin() {
        return limitBegin;
    }

    public void setLimitBegin(Date limitBegin) {
        this.limitBegin = limitBegin;
    }

    public Date getLimitEnd() {
        return limitEnd;
    }

    public void setLimitEnd(Date limitEnd) {
        this.limitEnd = limitEnd;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Short getT1Hex() {
        return t1Hex;
    }

    public void setT1Hex(Short t1Hex) {
        this.t1Hex = t1Hex;
    }

    public Short getT2Hex() {
        return t2Hex;
    }

    public void setT2Hex(Short t2Hex) {
        this.t2Hex = t2Hex;
    }

    public Short getT3Hex() {
        return t3Hex;
    }

    public void setT3Hex(Short t3Hex) {
        this.t3Hex = t3Hex;
    }

    public Short getT4Hex() {
        return t4Hex;
    }

    public void setT4Hex(Short t4Hex) {
        this.t4Hex = t4Hex;
    }

    public Short getT5Hex() {
        return t5Hex;
    }

    public void setT5Hex(Short t5Hex) {
        this.t5Hex = t5Hex;
    }

    public Short getT6Hex() {
        return t6Hex;
    }

    public void setT6Hex(Short t6Hex) {
        this.t6Hex = t6Hex;
    }

    public Short getT7Hex() {
        return t7Hex;
    }

    public void setT7Hex(Short t7Hex) {
        this.t7Hex = t7Hex;
    }

    public Short getMode() {
        return mode;
    }

    public void setMode(Short mode) {
        this.mode = mode;
    }
}