package com.kmhc.model.datacenter.model;

import java.util.Date;
import java.util.List;

public class AdminDevice extends AdminDeviceKey {
	
	private List<String> imeis;
	
    private Date updated_time;

    private Date created_time;

	public List<String> getImeis() {
		return imeis;
	}

	public void setImeis(List<String> imeis) {
		this.imeis = imeis;
	}

	public Date getUpdated_time() {
        return updated_time;
    }

    public void setUpdated_time(Date updated_time) {
        this.updated_time = updated_time;
    }

    public Date getCreated_time() {
        return created_time;
    }

    public void setCreated_time(Date created_time) {
        this.created_time = created_time;
    }
}