package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.DeviceSettingGfenceSp;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("deviceSettingGfenceSpMapper")
public interface DeviceSettingGfenceSpMapper {
    int deleteByPrimaryKey(String imei);

    int insert(DeviceSettingGfenceSp record);

    DeviceSettingGfenceSp selectByPrimaryKey(String imei);

    List<DeviceSettingGfenceSp> selectAll();

    int updateByPrimaryKey(DeviceSettingGfenceSp record);
}