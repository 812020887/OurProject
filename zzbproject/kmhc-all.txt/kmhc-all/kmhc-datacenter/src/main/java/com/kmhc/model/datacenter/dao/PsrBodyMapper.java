package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrBody;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PsrBodyMapper {
    int deleteByPrimaryKey(@Param("sno") Integer sno, @Param("imei") String imei);

    int insert(PsrBody record);

    PsrBody selectByPrimaryKey(@Param("sno") Integer sno, @Param("imei") String imei);

    List<PsrBody> selectAll();

    int updateByPrimaryKey(PsrBody record);
}