package com.kmhc.model.datacenter.model;

import java.math.BigDecimal;
import java.util.Date;

public class CheckRI {
    private String batchDetailKey;

    private String imei;

    private Date checkInDate;

    private Date checkOutDate;

    private Integer val;

    private String inGpsNsLat;

    private BigDecimal inGpsLat;

    private String inGpsEwLng;

    private BigDecimal inGpsLng;

    private String inAddress;

    private String inLocStatus;

    private String inIsvalid;

    private Double inHpe;

    private String outGpsNsLat;

    private BigDecimal outGpsLat;

    private String outGpsEwLng;

    private BigDecimal outGpsLng;

    private String outAddress;

    private String outLocStatus;

    private String outIsvalid;

    private Double outHpe;

    private Date createDate;

    private Date updateDate;

    public String getBatchDetailKey() {
        return batchDetailKey;
    }

    public void setBatchDetailKey(String batchDetailKey) {
        this.batchDetailKey = batchDetailKey;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Date getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(Date checkInDate) {
        this.checkInDate = checkInDate;
    }

    public Date getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(Date checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public Integer getVal() {
        return val;
    }

    public void setVal(Integer val) {
        this.val = val;
    }

    public String getInGpsNsLat() {
        return inGpsNsLat;
    }

    public void setInGpsNsLat(String inGpsNsLat) {
        this.inGpsNsLat = inGpsNsLat;
    }

    public BigDecimal getInGpsLat() {
        return inGpsLat;
    }

    public void setInGpsLat(BigDecimal inGpsLat) {
        this.inGpsLat = inGpsLat;
    }

    public String getInGpsEwLng() {
        return inGpsEwLng;
    }

    public void setInGpsEwLng(String inGpsEwLng) {
        this.inGpsEwLng = inGpsEwLng;
    }

    public BigDecimal getInGpsLng() {
        return inGpsLng;
    }

    public void setInGpsLng(BigDecimal inGpsLng) {
        this.inGpsLng = inGpsLng;
    }

    public String getInAddress() {
        return inAddress;
    }

    public void setInAddress(String inAddress) {
        this.inAddress = inAddress;
    }

    public String getInLocStatus() {
        return inLocStatus;
    }

    public void setInLocStatus(String inLocStatus) {
        this.inLocStatus = inLocStatus;
    }

    public String getInIsvalid() {
        return inIsvalid;
    }

    public void setInIsvalid(String inIsvalid) {
        this.inIsvalid = inIsvalid;
    }

    public Double getInHpe() {
        return inHpe;
    }

    public void setInHpe(Double inHpe) {
        this.inHpe = inHpe;
    }

    public String getOutGpsNsLat() {
        return outGpsNsLat;
    }

    public void setOutGpsNsLat(String outGpsNsLat) {
        this.outGpsNsLat = outGpsNsLat;
    }

    public BigDecimal getOutGpsLat() {
        return outGpsLat;
    }

    public void setOutGpsLat(BigDecimal outGpsLat) {
        this.outGpsLat = outGpsLat;
    }

    public String getOutGpsEwLng() {
        return outGpsEwLng;
    }

    public void setOutGpsEwLng(String outGpsEwLng) {
        this.outGpsEwLng = outGpsEwLng;
    }

    public BigDecimal getOutGpsLng() {
        return outGpsLng;
    }

    public void setOutGpsLng(BigDecimal outGpsLng) {
        this.outGpsLng = outGpsLng;
    }

    public String getOutAddress() {
        return outAddress;
    }

    public void setOutAddress(String outAddress) {
        this.outAddress = outAddress;
    }

    public String getOutLocStatus() {
        return outLocStatus;
    }

    public void setOutLocStatus(String outLocStatus) {
        this.outLocStatus = outLocStatus;
    }

    public String getOutIsvalid() {
        return outIsvalid;
    }

    public void setOutIsvalid(String outIsvalid) {
        this.outIsvalid = outIsvalid;
    }

    public Double getOutHpe() {
        return outHpe;
    }

    public void setOutHpe(Double outHpe) {
        this.outHpe = outHpe;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}