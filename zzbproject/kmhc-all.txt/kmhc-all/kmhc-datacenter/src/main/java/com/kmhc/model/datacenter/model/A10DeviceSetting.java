package com.kmhc.model.datacenter.model;

import java.math.BigDecimal;
import java.util.Date;

public class A10DeviceSetting {
    private Integer id;

    private String imei;
    
    private String uploadTime;
    
    private String centerPhone;
    
    private String sos1;
    
    private String sos2;
    
    private String sos3;
    //語音時區
    private String lz;
    
    private String moveAlm;
    
    private String moveSms; 
    
    private String movesPho;
    
    private Date updateTime;
    
    private Date createTime;
    
    private String ip;
    
    private Integer port;
    
    private Boolean electricSwitch;
    
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getUploadTime() {
		return uploadTime;
	}

	public void setUploadTime(String uploadTime) {
		this.uploadTime = uploadTime;
	}

	public String getCenterPhone() {
		return centerPhone;
	}

	public void setCenterPhone(String centerPhone) {
		this.centerPhone = centerPhone;
	}

	public String getSos1() {
		return sos1;
	}

	public void setSos1(String sos1) {
		this.sos1 = sos1;
	}

	public String getSos2() {
		return sos2;
	}

	public void setSos2(String sos2) {
		this.sos2 = sos2;
	}

	public String getSos3() {
		return sos3;
	}

	public void setSos3(String sos3) {
		this.sos3 = sos3;
	}

	public String getLz() {
		return lz;
	}

	public void setLz(String lz) {
		this.lz = lz;
	}
	
	

	public String getMoveAlm() {
		return moveAlm;
	}

	public void setMoveAlm(String moveAlm) {
		this.moveAlm = moveAlm;
	}

	public String getMoveSms() {
		return moveSms;
	}

	public void setMoveSms(String moveSms) {
		this.moveSms = moveSms;
	}

	public String getMovesPho() {
		return movesPho;
	}

	public void setMovesPho(String movesPho) {
		this.movesPho = movesPho;
	}

	public Boolean getElectricSwitch() {
		return electricSwitch;
	}

	public void setElectricSwitch(Boolean electricSwitch) {
		this.electricSwitch = electricSwitch;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	} 
 
	
	
}