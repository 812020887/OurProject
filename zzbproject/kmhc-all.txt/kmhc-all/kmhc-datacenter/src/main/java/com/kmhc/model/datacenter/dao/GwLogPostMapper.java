package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.GwLogPost;
import java.util.List;

public interface GwLogPostMapper {
    int deleteByPrimaryKey(Long postid);

    int insert(GwLogPost record);

    GwLogPost selectByPrimaryKey(Long postid);

    List<GwLogPost> selectAll();

    int updateByPrimaryKey(GwLogPost record);
}