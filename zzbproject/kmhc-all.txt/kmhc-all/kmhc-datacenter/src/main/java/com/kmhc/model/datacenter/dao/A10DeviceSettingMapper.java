package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.A10DeviceSetting;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("a10DeviceSettingMapper")
public interface A10DeviceSettingMapper {
	int deleteByPrimaryKey(@Param("id") Integer no, @Param("imei") String imei);

    int insert(A10DeviceSetting record);

    A10DeviceSetting selectByPrimaryKey(@Param("no") Integer no, @Param("imei") String imei);

    List<A10DeviceSetting> selectAll();

    int updateByPrimaryKeySelective(A10DeviceSetting record);
    
    A10DeviceSetting selectByImei(@Param("imei") String imei);

    int insertSelective(A10DeviceSetting record);
}