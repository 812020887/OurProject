package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrOxy;
import com.kmhc.model.datacenter.model.T9Sleep;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface T9SleepMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(T9Sleep record);

    T9Sleep selectByPrimaryKey(Integer id);

    List<T9Sleep> selectAll();
    
    int selectBySETime (T9Sleep record);

    int updateByPrimaryKey(T9Sleep record);

    
        /**
        * @Title: selectCountDataByImei
        * @Description: 查询最近count条数据
        * @param imei
        * @param count
        * @return
        */
        
    List<T9Sleep> selectCountDataByImei(@Param("imei")String imei,@Param("startDate")String startDate,@Param("endDate") String endDate);
}