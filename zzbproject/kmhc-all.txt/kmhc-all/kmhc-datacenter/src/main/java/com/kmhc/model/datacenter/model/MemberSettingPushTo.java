package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingPushTo {
    private Long toId;

    private Long pushId;

    private Long memberId;

    private Date createdTime;

    private Date updateTime;

    private Long pushMemberType;

    public Long getToId() {
        return toId;
    }

    public void setToId(Long toId) {
        this.toId = toId;
    }

    public Long getPushId() {
        return pushId;
    }

    public void setPushId(Long pushId) {
        this.pushId = pushId;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getPushMemberType() {
        return pushMemberType;
    }

    public void setPushMemberType(Long pushMemberType) {
        this.pushMemberType = pushMemberType;
    }
}