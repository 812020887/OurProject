package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberGeofencePushLog {
    private Integer gId;

    private Short pushType;

    private Date processTime;

    public Integer getgId() {
        return gId;
    }

    public void setgId(Integer gId) {
        this.gId = gId;
    }

    public Short getPushType() {
        return pushType;
    }

    public void setPushType(Short pushType) {
        this.pushType = pushType;
    }

    public Date getProcessTime() {
        return processTime;
    }

    public void setProcessTime(Date processTime) {
        this.processTime = processTime;
    }
}