package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingMapMarker;
import java.util.List;

public interface MemberSettingMapMarkerMapper {
    int deleteByPrimaryKey(Long sno);

    int insert(MemberSettingMapMarker record);

    MemberSettingMapMarker selectByPrimaryKey(Long sno);

    List<MemberSettingMapMarker> selectAll();

    int updateByPrimaryKey(MemberSettingMapMarker record);
}