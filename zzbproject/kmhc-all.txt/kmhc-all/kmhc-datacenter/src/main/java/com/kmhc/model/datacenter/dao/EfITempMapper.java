package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.EfITemp;
import java.util.List;

public interface EfITempMapper {
    int insert(EfITemp record);

    List<EfITemp> selectAll();
}