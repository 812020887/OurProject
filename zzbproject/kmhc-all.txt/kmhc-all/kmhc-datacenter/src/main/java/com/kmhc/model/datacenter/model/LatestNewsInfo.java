package com.kmhc.model.datacenter.model;

import java.util.Date;

public class LatestNewsInfo {
    private Integer id;

    private String name;

    private Date releaseDate;

    private Date newsStartDate;

    private Date newsEndDate;

    private Integer latestNewsStatusId;

    private String logoImagePath;

    private String newsDetail;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public Date getNewsStartDate() {
        return newsStartDate;
    }

    public void setNewsStartDate(Date newsStartDate) {
        this.newsStartDate = newsStartDate;
    }

    public Date getNewsEndDate() {
        return newsEndDate;
    }

    public void setNewsEndDate(Date newsEndDate) {
        this.newsEndDate = newsEndDate;
    }

    public Integer getLatestNewsStatusId() {
        return latestNewsStatusId;
    }

    public void setLatestNewsStatusId(Integer latestNewsStatusId) {
        this.latestNewsStatusId = latestNewsStatusId;
    }

    public String getLogoImagePath() {
        return logoImagePath;
    }

    public void setLogoImagePath(String logoImagePath) {
        this.logoImagePath = logoImagePath;
    }

    public String getNewsDetail() {
        return newsDetail;
    }

    public void setNewsDetail(String newsDetail) {
        this.newsDetail = newsDetail;
    }
}