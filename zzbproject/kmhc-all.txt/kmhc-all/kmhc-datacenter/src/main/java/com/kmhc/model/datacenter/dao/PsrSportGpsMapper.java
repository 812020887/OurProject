package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrSportGps;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PsrSportGpsMapper {
    int deleteByPrimaryKey(@Param("itemno") Integer itemno, @Param("batchDetailKey") String batchDetailKey);

    int insert(PsrSportGps record);

    PsrSportGps selectByPrimaryKey(@Param("itemno") Integer itemno, @Param("batchDetailKey") String batchDetailKey);

    List<PsrSportGps> selectAll();

    int updateByPrimaryKey(PsrSportGps record);
}