package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.EfM;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("efMMapper")
public interface EfMMapper {
    int deleteByPrimaryKey(@Param("batchKey") String batchKey, @Param("imei") String imei);

    int insert(EfM record);

    EfM selectByPrimaryKey(@Param("batchKey") String batchKey, @Param("imei") String imei);

    List<EfM> selectAll();

    int updateByPrimaryKey(EfM record);
}