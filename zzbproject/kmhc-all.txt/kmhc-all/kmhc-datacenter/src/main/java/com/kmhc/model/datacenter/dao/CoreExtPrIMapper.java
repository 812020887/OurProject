package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.CoreExtPrI;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CoreExtPrIMapper {
    int deleteByPrimaryKey(@Param("batchKey") String batchKey, @Param("imei") String imei, @Param("itemno") Short itemno);

    int insert(CoreExtPrI record);

    CoreExtPrI selectByPrimaryKey(@Param("batchKey") String batchKey, @Param("imei") String imei, @Param("itemno") Short itemno);

    List<CoreExtPrI> selectAll();

    int updateByPrimaryKey(CoreExtPrI record);
}