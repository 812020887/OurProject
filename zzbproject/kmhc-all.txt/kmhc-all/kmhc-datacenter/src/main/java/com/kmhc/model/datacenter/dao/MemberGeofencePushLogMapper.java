package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberGeofencePushLog;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface MemberGeofencePushLogMapper {
    int deleteByPrimaryKey(@Param("gId") Integer gId, @Param("pushType") Short pushType);

    int insert(MemberGeofencePushLog record);

    MemberGeofencePushLog selectByPrimaryKey(@Param("gId") Integer gId, @Param("pushType") Short pushType);

    List<MemberGeofencePushLog> selectAll();

    int updateByPrimaryKey(MemberGeofencePushLog record);
}