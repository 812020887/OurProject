package com.kmhc.model.datacenter.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import com.kmhc.model.datacenter.model.RPushHistory;

@Repository("rPushHistoryMapper")
public interface RPushHistoryMapper {

	int insertSelective(@Param("list") List<RPushHistory> list);

	List<RPushHistory> selectAllByAccount(@Param("account") String account);

	List<RPushHistory> selectCountByAccount(@Param("account") String account, @Param("index") Integer index,
			@Param("count") Integer count);

	int deleteByPrimaryKey(@Param("ids") long[] ids);

}