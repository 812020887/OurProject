package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingLeavehome;
import java.util.List;

public interface MemberSettingLeavehomeMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingLeavehome record);

    MemberSettingLeavehome selectByPrimaryKey(String imei);

    List<MemberSettingLeavehome> selectAll();

    int updateByPrimaryKey(MemberSettingLeavehome record);
}