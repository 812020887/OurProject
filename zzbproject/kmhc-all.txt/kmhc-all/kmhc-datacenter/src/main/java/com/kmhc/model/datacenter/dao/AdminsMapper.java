package com.kmhc.model.datacenter.dao;

import org.springframework.stereotype.Repository;

import com.kmhc.model.datacenter.model.Admins;
@Repository("adminsMapper")
public interface AdminsMapper extends IMapper {
    int deleteByPrimaryKey(Long admin_id);

    int insert(Admins record);

    int insertSelective(Admins record);

    Admins selectByPrimaryKey(Long admin_id);
    
    Admins selectByAccount(Admins record);
    
    int updateByPrimaryKeySelective(Admins record);

    int updateByPrimaryKey(Admins record);
}