package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrStepGps;
import java.util.List;

public interface PsrStepGpsMapper {
    int deleteByPrimaryKey(String batchDetailKey);

    int insert(PsrStepGps record);

    PsrStepGps selectByPrimaryKey(String batchDetailKey);

    List<PsrStepGps> selectAll();

    int updateByPrimaryKey(PsrStepGps record);
}