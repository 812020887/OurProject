package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingBloodglucose {
    private String imei;

    private Date updateTime;

    private Integer beforeMealH;

    private Integer beforeMealL;

    private Integer afterMealH;

    private Integer afterMealL;

    private Integer beforeBedH;

    private Integer beforeBedL;

    private Date breakfastS;

    private Date breakfastE;

    private Date lunchS;

    private Date lunchE;

    private Date dinnerS;

    private Date dinnerE;

    private String updated;
    
    
    public MemberSettingBloodglucose() {
		super();
	}

	public MemberSettingBloodglucose(String imei) {
		super();
		this.imei = imei;
	}
	
	public MemberSettingBloodglucose(String imei, Integer beforeMealH,
			Integer beforeMealL, Integer afterMealH, Integer afterMealL,
			Integer beforeBedH, Integer beforeBedL, Date breakfastS,
			Date breakfastE, Date lunchS, Date lunchE, Date dinnerS,
			Date dinnerE, String updated) {
		super();
		this.imei = imei;
		this.beforeMealH = beforeMealH;
		this.beforeMealL = beforeMealL;
		this.afterMealH = afterMealH;
		this.afterMealL = afterMealL;
		this.beforeBedH = beforeBedH;
		this.beforeBedL = beforeBedL;
		this.breakfastS = breakfastS;
		this.breakfastE = breakfastE;
		this.lunchS = lunchS;
		this.lunchE = lunchE;
		this.dinnerS = dinnerS;
		this.dinnerE = dinnerE;
		this.updated = updated;
	}

	public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getBeforeMealH() {
        return beforeMealH;
    }

    public void setBeforeMealH(Integer beforeMealH) {
        this.beforeMealH = beforeMealH;
    }

    public Integer getBeforeMealL() {
        return beforeMealL;
    }

    public void setBeforeMealL(Integer beforeMealL) {
        this.beforeMealL = beforeMealL;
    }

    public Integer getAfterMealH() {
        return afterMealH;
    }

    public void setAfterMealH(Integer afterMealH) {
        this.afterMealH = afterMealH;
    }

    public Integer getAfterMealL() {
        return afterMealL;
    }

    public void setAfterMealL(Integer afterMealL) {
        this.afterMealL = afterMealL;
    }

    public Integer getBeforeBedH() {
        return beforeBedH;
    }

    public void setBeforeBedH(Integer beforeBedH) {
        this.beforeBedH = beforeBedH;
    }

    public Integer getBeforeBedL() {
        return beforeBedL;
    }

    public void setBeforeBedL(Integer beforeBedL) {
        this.beforeBedL = beforeBedL;
    }

    public Date getBreakfastS() {
        return breakfastS;
    }

    public void setBreakfastS(Date breakfastS) {
        this.breakfastS = breakfastS;
    }

    public Date getBreakfastE() {
        return breakfastE;
    }

    public void setBreakfastE(Date breakfastE) {
        this.breakfastE = breakfastE;
    }

    public Date getLunchS() {
        return lunchS;
    }

    public void setLunchS(Date lunchS) {
        this.lunchS = lunchS;
    }

    public Date getLunchE() {
        return lunchE;
    }

    public void setLunchE(Date lunchE) {
        this.lunchE = lunchE;
    }

    public Date getDinnerS() {
        return dinnerS;
    }

    public void setDinnerS(Date dinnerS) {
        this.dinnerS = dinnerS;
    }

    public Date getDinnerE() {
        return dinnerE;
    }

    public void setDinnerE(Date dinnerE) {
        this.dinnerE = dinnerE;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }
}