package com.kmhc.model.datacenter.model;

/**
 * Name: Cell.java
 * ProjectName: [kmhc-data-parser]
 * Package: [com.kmhc.model.pojo.Cell.java]
 * Description: 基站数据对象
 * 
 * @since JDK1.7
 * @see
 *
 * @author: xl
 * @date: 2015年11月11日 下午3:15:52
 *
 * Update-User: @author
 * Update-Time:
 * Update-Remark:
 * 
 * Check-User:
 * Check-Time:
 * Check-Remark:
 * 
 * Company: kmhc
 * Copyright: kmhc
 */
public class Cell {
    
    private String mcc;
    private String mnc;
    private String lac;
    private Integer cellid;
    private short rssi;
    
    public Cell(String mcc,String mnc,String lac,Integer cellid,short rssi){
        this.mcc = mcc ;
        this.mnc = mnc ;
        this.lac = lac ;
        this.cellid = cellid ;
        this.rssi = rssi ;
    }
    
    public Cell(short mcc,short mnc,short lac,short cellid,short rssi){
        this.mcc = String.valueOf(mcc);
        this.mnc = String.valueOf(mnc) ;
        this.lac = String.valueOf(lac) ;
        this.cellid = (int)cellid ;
        this.rssi = rssi ;
    }
    
    public Cell(){
    	
    }
    
    public String getMcc() {
        return mcc;
    }
    public void setMcc(String mcc) {
        this.mcc = mcc;
    }
    public String getMnc() {
        return mnc;
    }
    public void setMnc(String mnc) {
        this.mnc = mnc;
    }
    public String getLac() {
        return lac;
    }
    public void setLac(String lac) {
        this.lac = lac;
    }
    public Integer getCellid() {
        return cellid;
    }
    public void setCellid(Integer cellid) {
        this.cellid = cellid;
    }
    public short getRssi() {
        return rssi;
    }
    public void setRssi(short rssi) {
        this.rssi = rssi;
    }
    public String toString(){
        return mcc+","+mnc+","+lac+","+cellid.intValue()+","+String.valueOf(rssi-110);
    }
}