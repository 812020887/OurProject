package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.C3p0TestTable;
import java.util.List;

public interface C3p0TestTableMapper {
    int insert(C3p0TestTable record);

    List<C3p0TestTable> selectAll();
}