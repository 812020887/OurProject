package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.UsedFunction;
import java.util.List;

public interface UsedFunctionMapper {
    int deleteByPrimaryKey(Long usedFunctionId);

    int insert(UsedFunction record);

    UsedFunction selectByPrimaryKey(Long usedFunctionId);

    List<UsedFunction> selectAll();

    int updateByPrimaryKey(UsedFunction record);
}