package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingFall {
    private String imei;

    private Date updateTime;

    private String switchOn;

    private Integer level;

    private String phone1;

    private String phone2;

    private String phone3;

    private String updated;
    
    public MemberSettingFall() {
		super();
	}

	public MemberSettingFall(String imei) {
		super();
		this.imei = imei;
	}

	public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getSwitchOn() {
        return switchOn;
    }

    public void setSwitchOn(String switchOn) {
        this.switchOn = switchOn;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public String getPhone1() {
        return phone1;
    }

    public void setPhone1(String phone1) {
        this.phone1 = phone1;
    }

    public String getPhone2() {
        return phone2;
    }

    public void setPhone2(String phone2) {
        this.phone2 = phone2;
    }

    public String getPhone3() {
        return phone3;
    }

    public void setPhone3(String phone3) {
        this.phone3 = phone3;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }
}