package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.Blacklist;
import java.util.List;

public interface BlacklistMapper {
    int deleteByPrimaryKey(Long blacklistId);

    int insert(Blacklist record);

    Blacklist selectByPrimaryKey(Long blacklistId);

    List<Blacklist> selectAll();

    int updateByPrimaryKey(Blacklist record);
}