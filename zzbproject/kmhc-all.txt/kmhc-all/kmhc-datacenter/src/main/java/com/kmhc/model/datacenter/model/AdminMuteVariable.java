package com.kmhc.model.datacenter.model;

import java.util.Date;

public class AdminMuteVariable {
    private Integer id;

    private Long admin_id;

    private Short enable;

    private String sta;

    private String eta;

    private Short MON;

    private Short TUE;

    private Short WED;

    private Short THU;

    private Short FRI;

    private Short SAT;

    private Short SUN;

    private Date UPDATE_DATE;

    private Date CREATE_DATE;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Long getAdmin_id() {
        return admin_id;
    }

    public void setAdmin_id(Long admin_id) {
        this.admin_id = admin_id;
    }

    public Short getEnable() {
        return enable;
    }

    public void setEnable(Short enable) {
        this.enable = enable;
    }

    public String getSta() {
        return sta;
    }

    public void setSta(String sta) {
        this.sta = sta == null ? null : sta.trim();
    }

    public String getEta() {
        return eta;
    }

    public void setEta(String eta) {
        this.eta = eta == null ? null : eta.trim();
    }

    public Short getMON() {
        return MON;
    }

    public void setMON(Short MON) {
        this.MON = MON;
    }

    public Short getTUE() {
        return TUE;
    }

    public void setTUE(Short TUE) {
        this.TUE = TUE;
    }

    public Short getWED() {
        return WED;
    }

    public void setWED(Short WED) {
        this.WED = WED;
    }

    public Short getTHU() {
        return THU;
    }

    public void setTHU(Short THU) {
        this.THU = THU;
    }

    public Short getFRI() {
        return FRI;
    }

    public void setFRI(Short FRI) {
        this.FRI = FRI;
    }

    public Short getSAT() {
        return SAT;
    }

    public void setSAT(Short SAT) {
        this.SAT = SAT;
    }

    public Short getSUN() {
        return SUN;
    }

    public void setSUN(Short SUN) {
        this.SUN = SUN;
    }

    public Date getUPDATE_DATE() {
        return UPDATE_DATE;
    }

    public void setUPDATE_DATE(Date UPDATE_DATE) {
        this.UPDATE_DATE = UPDATE_DATE;
    }

    public Date getCREATE_DATE() {
        return CREATE_DATE;
    }

    public void setCREATE_DATE(Date CREATE_DATE) {
        this.CREATE_DATE = CREATE_DATE;
    }
}