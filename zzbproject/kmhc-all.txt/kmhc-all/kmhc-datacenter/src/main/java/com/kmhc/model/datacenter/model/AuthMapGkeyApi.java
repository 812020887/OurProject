package com.kmhc.model.datacenter.model;

public class AuthMapGkeyApi {
    private Long sno;

    private Long gkeyId;

    private Long apiId;

    private Byte enable;

    public Long getSno() {
        return sno;
    }

    public void setSno(Long sno) {
        this.sno = sno;
    }

    public Long getGkeyId() {
        return gkeyId;
    }

    public void setGkeyId(Long gkeyId) {
        this.gkeyId = gkeyId;
    }

    public Long getApiId() {
        return apiId;
    }

    public void setApiId(Long apiId) {
        this.apiId = apiId;
    }

    public Byte getEnable() {
        return enable;
    }

    public void setEnable(Byte enable) {
        this.enable = enable;
    }
}