package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.EmgM;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("emgMMapper")
public interface EmgMMapper {
    int deleteByPrimaryKey(@Param("emgKey") String emgKey, @Param("imei") String imei);

    int insert(EmgM record);
    
    int insertSelective(EmgM record);

    EmgM selectByPrimaryKey(@Param("emgKey") String emgKey, @Param("imei") String imei);

    List<EmgM> selectAll();

    int updateByPrimaryKey(EmgM record);
    
    List<EmgM> selectEmgByImeiWithLimit(@Param("imei") String imei, @Param("count") int count, @Param("index") int index);
    
    List<EmgM> selectFallByImeiWithLimit(@Param("imei") String imei, @Param("count") int count, @Param("index") int index);
}