package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberMsgReadtime {
    private String userAccount;

    private Date readTime1;

    private Date readTime2;

    private Date readTime3;

    public String getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(String userAccount) {
        this.userAccount = userAccount;
    }

    public Date getReadTime1() {
        return readTime1;
    }

    public void setReadTime1(Date readTime1) {
        this.readTime1 = readTime1;
    }

    public Date getReadTime2() {
        return readTime2;
    }

    public void setReadTime2(Date readTime2) {
        this.readTime2 = readTime2;
    }

    public Date getReadTime3() {
        return readTime3;
    }

    public void setReadTime3(Date readTime3) {
        this.readTime3 = readTime3;
    }
}