package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingBloodpressure {
    private String imei;

    private Date updateTime;

    private Integer bpsH;

    private Integer bpsL;

    private Integer bpdH;

    private Integer bpdL;

    private String updated;

    private Integer plusH;

    private Integer plusL;
    
    
    public MemberSettingBloodpressure() {
		super();
	}

	public MemberSettingBloodpressure(String imei) {
		super();
		this.imei = imei;
	}
	
	public MemberSettingBloodpressure(String imei, Integer bpsH, Integer bpsL,
			Integer bpdH, Integer bpdL, String updated) {
		super();
		this.imei = imei;
		this.bpsH = bpsH;
		this.bpsL = bpsL;
		this.bpdH = bpdH;
		this.bpdL = bpdL;
		this.updated = updated;
	}

	public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getBpsH() {
        return bpsH;
    }

    public void setBpsH(Integer bpsH) {
        this.bpsH = bpsH;
    }

    public Integer getBpsL() {
        return bpsL;
    }

    public void setBpsL(Integer bpsL) {
        this.bpsL = bpsL;
    }

    public Integer getBpdH() {
        return bpdH;
    }

    public void setBpdH(Integer bpdH) {
        this.bpdH = bpdH;
    }

    public Integer getBpdL() {
        return bpdL;
    }

    public void setBpdL(Integer bpdL) {
        this.bpdL = bpdL;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    public Integer getPlusH() {
        return plusH;
    }

    public void setPlusH(Integer plusH) {
        this.plusH = plusH;
    }

    public Integer getPlusL() {
        return plusL;
    }

    public void setPlusL(Integer plusL) {
        this.plusL = plusL;
    }
}