package com.kmhc.model.datacenter.model;

import java.math.BigDecimal;
import java.util.Date;

public class DeviceSettingGfenceSp {
    private String imei;

    private String fenceName;

    private BigDecimal longitude;

    private BigDecimal latitude;

    private String starttime;

    private String endtime;

    private Integer enable;

    private String address;

    private Integer radius;

    private Date updatetime;

    private Date createtime;

    private Integer interval;
    

    public DeviceSettingGfenceSp() {
		super();
	}
    
	public DeviceSettingGfenceSp(String imei, BigDecimal longitude,
			BigDecimal latitude, String starttime, String endtime,
			Integer enable, String address, Integer radius, Integer interval) {
		super();
		this.imei = imei;
		this.longitude = longitude;
		this.latitude = latitude;
		this.starttime = starttime;
		this.endtime = endtime;
		this.enable = enable;
		this.address = address;
		this.radius = radius;
		this.interval = interval;
	}



	public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getFenceName() {
        return fenceName;
    }

    public void setFenceName(String fenceName) {
        this.fenceName = fenceName;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public Integer getEnable() {
        return enable;
    }

    public void setEnable(Integer enable) {
        this.enable = enable;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getRadius() {
        return radius;
    }

    public void setRadius(Integer radius) {
        this.radius = radius;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Integer getInterval() {
        return interval;
    }

    public void setInterval(Integer interval) {
        this.interval = interval;
    }
}