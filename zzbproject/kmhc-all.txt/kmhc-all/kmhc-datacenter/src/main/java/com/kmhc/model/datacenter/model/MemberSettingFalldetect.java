package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingFalldetect {
    private Long memberId;

    private Byte detectSwitch;

    private Byte delayTimer;

    private Date scheduleFromTime;

    private Date scheduleToTime;

    private String scheduleWeek;

    private Byte scheduleEnable;

    private Date syncDate;

    private Date createDate;

    private Date updateDate;

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public Byte getDetectSwitch() {
        return detectSwitch;
    }

    public void setDetectSwitch(Byte detectSwitch) {
        this.detectSwitch = detectSwitch;
    }

    public Byte getDelayTimer() {
        return delayTimer;
    }

    public void setDelayTimer(Byte delayTimer) {
        this.delayTimer = delayTimer;
    }

    public Date getScheduleFromTime() {
        return scheduleFromTime;
    }

    public void setScheduleFromTime(Date scheduleFromTime) {
        this.scheduleFromTime = scheduleFromTime;
    }

    public Date getScheduleToTime() {
        return scheduleToTime;
    }

    public void setScheduleToTime(Date scheduleToTime) {
        this.scheduleToTime = scheduleToTime;
    }

    public String getScheduleWeek() {
        return scheduleWeek;
    }

    public void setScheduleWeek(String scheduleWeek) {
        this.scheduleWeek = scheduleWeek;
    }

    public Byte getScheduleEnable() {
        return scheduleEnable;
    }

    public void setScheduleEnable(Byte scheduleEnable) {
        this.scheduleEnable = scheduleEnable;
    }

    public Date getSyncDate() {
        return syncDate;
    }

    public void setSyncDate(Date syncDate) {
        this.syncDate = syncDate;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}