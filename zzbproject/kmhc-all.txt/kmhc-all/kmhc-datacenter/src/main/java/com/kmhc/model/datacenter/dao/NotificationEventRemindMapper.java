package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.NotificationEventRemind;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("notificationEventRemindMapper")
public interface NotificationEventRemindMapper {
    int deleteByPrimaryKey(Integer notificationId);

    int insert(NotificationEventRemind record);

    NotificationEventRemind selectByPrimaryKey(Integer notificationId);

    List<NotificationEventRemind> selectAll();

    int updateByPrimaryKey(NotificationEventRemind record);
}