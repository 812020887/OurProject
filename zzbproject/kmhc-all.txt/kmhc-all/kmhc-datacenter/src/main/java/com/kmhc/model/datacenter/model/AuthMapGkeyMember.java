package com.kmhc.model.datacenter.model;

public class AuthMapGkeyMember {
    private Long sno;

    private Long gkeyId;

    private Long memberId;

    private Byte enable;

    public Long getSno() {
        return sno;
    }

    public void setSno(Long sno) {
        this.sno = sno;
    }

    public Long getGkeyId() {
        return gkeyId;
    }

    public void setGkeyId(Long gkeyId) {
        this.gkeyId = gkeyId;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public Byte getEnable() {
        return enable;
    }

    public void setEnable(Byte enable) {
        this.enable = enable;
    }
}