package com.kmhc.model.datacenter.model;

import java.util.Date;
import java.util.List;

public class C100Params {
    private Integer id;

    private String user0;

    private String user1;

    private String user2;

    private String user3;

    private String user4;

    private String user5;

    private String dst;

    private Integer wmode;

    private Integer belltype;

    private Boolean calljt;

    private String ast;

    private Boolean rpton;

    private Integer volume;

    private String qtt;

    private String sysfuc;

    private Boolean calldisp;

    private Boolean callbelltype;

    private Boolean qttfcl;

    private Integer lang;

    private String callcode;

    private Date createTime;

    private Date updateTime;

    private String sn;

    private String username0;
    
    private String username1;
    
    private String username2;
    
    private String username3;
    
    private String username4;
    
    private String username5;
    
    private List<String> imeis;
    
	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUser0() {
        return user0;
    }

    public void setUser0(String user0) {
        this.user0 = user0;
    }

    public String getUser1() {
        return user1;
    }

    public void setUser1(String user1) {
        this.user1 = user1;
    }

    public String getUser2() {
        return user2;
    }

    public void setUser2(String user2) {
        this.user2 = user2;
    }

    public String getUser3() {
        return user3;
    }

    public void setUser3(String user3) {
        this.user3 = user3;
    }

    public String getUser4() {
        return user4;
    }

    public void setUser4(String user4) {
        this.user4 = user4;
    }

    public String getUser5() {
        return user5;
    }

    public void setUser5(String user5) {
        this.user5 = user5;
    }

    public String getDst() {
        return dst;
    }

    public void setDst(String dst) {
        this.dst = dst;
    }

    public Integer getWmode() {
        return wmode;
    }

    public void setWmode(Integer wmode) {
        this.wmode = wmode;
    }

    public Integer getBelltype() {
        return belltype;
    }

    public void setBelltype(Integer belltype) {
        this.belltype = belltype;
    }

    public Boolean getCalljt() {
        return calljt;
    }

    public void setCalljt(Boolean calljt) {
        this.calljt = calljt;
    }

    public String getAst() {
        return ast;
    }

    public void setAst(String ast) {
        this.ast = ast;
    }

    public Boolean getRpton() {
        return rpton;
    }

    public void setRpton(Boolean rpton) {
        this.rpton = rpton;
    }

    public Integer getVolume() {
        return volume;
    }

    public void setVolume(Integer volume) {
        this.volume = volume;
    }

    public String getQtt() {
        return qtt;
    }

    public void setQtt(String qtt) {
        this.qtt = qtt;
    }

    public String getSysfuc() {
        return sysfuc;
    }

    public void setSysfuc(String sysfuc) {
        this.sysfuc = sysfuc;
    }

    public Boolean getCalldisp() {
        return calldisp;
    }

    public void setCalldisp(Boolean calldisp) {
        this.calldisp = calldisp;
    }

    public Boolean getCallbelltype() {
        return callbelltype;
    }

    public void setCallbelltype(Boolean callbelltype) {
        this.callbelltype = callbelltype;
    }

    public Boolean getQttfcl() {
        return qttfcl;
    }

    public void setQttfcl(Boolean qttfcl) {
        this.qttfcl = qttfcl;
    }

    public Integer getLang() {
        return lang;
    }

    public void setLang(Integer lang) {
        this.lang = lang;
    }

    public String getCallcode() {
        return callcode;
    }

    public void setCallcode(String callcode) {
        this.callcode = callcode;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

	public String getUsername0() {
		return username0;
	}

	public void setUsername0(String username0) {
		this.username0 = username0;
	}

	public String getUsername1() {
		return username1;
	}

	public void setUsername1(String username1) {
		this.username1 = username1;
	}

	public String getUsername2() {
		return username2;
	}

	public void setUsername2(String username2) {
		this.username2 = username2;
	}

	public String getUsername3() {
		return username3;
	}

	public void setUsername3(String username3) {
		this.username3 = username3;
	}

	public String getUsername4() {
		return username4;
	}

	public void setUsername4(String username4) {
		this.username4 = username4;
	}

	public String getUsername5() {
		return username5;
	}

	public void setUsername5(String username5) {
		this.username5 = username5;
	}

	public List<String> getImeis() {
		return imeis;
	}

	public void setImeis(List<String> imeis) {
		this.imeis = imeis;
	}
    
}