package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrOxy;
import com.kmhc.model.datacenter.model.PsrTemp;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public interface PsrTempMapper {
    int insert(PsrTemp record);

    List<PsrTemp> selectAll();
    int selectByTempTime (PsrTemp record);

	List<PsrTemp> selectAllByImei(String imei);

	List<PsrTemp> selectCountDataByImei(String imei, Integer count, Integer index);

	List<PsrTemp> selectByDuring(String imei, String start, String end); 
}