package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.EfOptionI;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("efOptionIMapper")
public interface EfOptionIMapper {
    int deleteByPrimaryKey(String batchDetailKey);

    int insert(EfOptionI record);

    EfOptionI selectByPrimaryKey(String batchDetailKey);

    List<EfOptionI> selectAll();

    int updateByPrimaryKey(EfOptionI record);
}