package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.T9SleepSetting;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("t9SleepSettingMapper")
public interface T9SleepSettingMapper {
    int deleteByPrimaryKey(String imei);

    int insert(T9SleepSetting record);

    T9SleepSetting selectByPrimaryKey(String imei);

    List<T9SleepSetting> selectAll();

    int updateByPrimaryKey(T9SleepSetting record);
    
    int update(T9SleepSetting record);
}