package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.TrustPointM;
import java.util.List;

import org.springframework.stereotype.Repository;
@Repository("trustPointMMapper")
public interface TrustPointMMapper {
    int deleteByPrimaryKey(String imei);

    int insert(TrustPointM record);

    TrustPointM selectByPrimaryKey(String imei);

    List<TrustPointM> selectAll();

    int updateByPrimaryKey(TrustPointM record);
}