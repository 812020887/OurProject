package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.BearMediaMbe;
import java.util.List;

public interface BearMediaMbeMapper {
    int deleteByPrimaryKey(Long mbeId);

    int insert(BearMediaMbe record);

    BearMediaMbe selectByPrimaryKey(Long mbeId);

    List<BearMediaMbe> selectAll();

    int updateByPrimaryKey(BearMediaMbe record);
}