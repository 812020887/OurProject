package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.BearMediaMemberList;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BearMediaMemberListMapper {
    int deleteByPrimaryKey(@Param("memberId") Long memberId, @Param("mbeId") Long mbeId);

    int insert(BearMediaMemberList record);

    BearMediaMemberList selectByPrimaryKey(@Param("memberId") Long memberId, @Param("mbeId") Long mbeId);

    List<BearMediaMemberList> selectAll();

    int updateByPrimaryKey(BearMediaMemberList record);
}