package com.kmhc.model.datacenter.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import com.kmhc.model.datacenter.model.RPush;

@Repository("rPushMapper")
public interface RPushMapper {

	int insertSelective(RPush record);

	int updateByPrimaryKeySelective(RPush record);

	RPush selectByTocken(@Param("tocken") String tocken);

	List<RPush> selectAllByAccountWithUsing(@Param("account") String account);

	int updateOnLineTimeByTocken(@Param("tocken") String tocken);
}