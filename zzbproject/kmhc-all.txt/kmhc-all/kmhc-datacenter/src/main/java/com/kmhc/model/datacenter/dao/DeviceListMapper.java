package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.DeviceList;
import java.util.List;
import org.springframework.stereotype.Repository;

@Repository("deviceListMapper")
public interface DeviceListMapper extends IMapper{
    int deleteByPrimaryKey(String imei);

    int insert(DeviceList record);
    
    int insertSelective(DeviceList record);

    DeviceList selectByPrimaryKey(String imei);

    List<DeviceList> selectAll();

    int updateByPrimaryKey(DeviceList record);
    
    List<DeviceList> selectByLastImeiCode( Long lastNo );
    
    DeviceList selectBySn(String sn) ;
}