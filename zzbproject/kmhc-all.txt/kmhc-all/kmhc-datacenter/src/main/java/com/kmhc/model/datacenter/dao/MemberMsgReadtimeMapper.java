package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberMsgReadtime;
import java.util.List;

public interface MemberMsgReadtimeMapper {
    int deleteByPrimaryKey(String userAccount);

    int insert(MemberMsgReadtime record);

    MemberMsgReadtime selectByPrimaryKey(String userAccount);

    List<MemberMsgReadtime> selectAll();

    int updateByPrimaryKey(MemberMsgReadtime record);
}