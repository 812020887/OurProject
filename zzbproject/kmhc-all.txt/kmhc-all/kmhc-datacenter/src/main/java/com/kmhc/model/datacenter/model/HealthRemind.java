package com.kmhc.model.datacenter.model;

import java.util.Date;

public class HealthRemind {
    private Integer healthRemindId;

    private Integer remindType;

    private Integer createType;

    private Integer createId;

    private Date remindUpdate;

    private Date createDate;

    private String content;

    private String contentEn;

    private String contentJp;

    private String contentCn;

    public Integer getHealthRemindId() {
        return healthRemindId;
    }

    public void setHealthRemindId(Integer healthRemindId) {
        this.healthRemindId = healthRemindId;
    }

    public Integer getRemindType() {
        return remindType;
    }

    public void setRemindType(Integer remindType) {
        this.remindType = remindType;
    }

    public Integer getCreateType() {
        return createType;
    }

    public void setCreateType(Integer createType) {
        this.createType = createType;
    }

    public Integer getCreateId() {
        return createId;
    }

    public void setCreateId(Integer createId) {
        this.createId = createId;
    }

    public Date getRemindUpdate() {
        return remindUpdate;
    }

    public void setRemindUpdate(Date remindUpdate) {
        this.remindUpdate = remindUpdate;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getContentEn() {
        return contentEn;
    }

    public void setContentEn(String contentEn) {
        this.contentEn = contentEn;
    }

    public String getContentJp() {
        return contentJp;
    }

    public void setContentJp(String contentJp) {
        this.contentJp = contentJp;
    }

    public String getContentCn() {
        return contentCn;
    }

    public void setContentCn(String contentCn) {
        this.contentCn = contentCn;
    }
}