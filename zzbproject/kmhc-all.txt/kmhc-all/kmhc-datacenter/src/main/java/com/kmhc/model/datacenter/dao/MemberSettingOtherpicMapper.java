package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingOtherpic;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("memberSettingOtherpicMapper")
public interface MemberSettingOtherpicMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingOtherpic record);

    MemberSettingOtherpic selectByPrimaryKey(String imei);

    List<MemberSettingOtherpic> selectAll();

    int updateByPrimaryKey(MemberSettingOtherpic record);
}