package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberWifi;
import java.util.List;

public interface MemberWifiMapper {
    int deleteByPrimaryKey(Long wId);

    int insert(MemberWifi record);

    MemberWifi selectByPrimaryKey(Long wId);

    List<MemberWifi> selectAll();

    int updateByPrimaryKey(MemberWifi record);
}