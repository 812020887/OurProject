package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberMsgRemind {
    private Integer msgRemindId;

    private Integer sendType;

    private Long sendId;

    private String imei;

    private String imsi;

    private Integer remindNo;

    private Short checksum;

    private Integer enable;

    private String remindContent;

    private String remindContentUnicode;

    private Date enableTime;

    private Integer status;

    private Date remindUpdate;

    private Long memberId;

    public Integer getMsgRemindId() {
        return msgRemindId;
    }

    public void setMsgRemindId(Integer msgRemindId) {
        this.msgRemindId = msgRemindId;
    }

    public Integer getSendType() {
        return sendType;
    }

    public void setSendType(Integer sendType) {
        this.sendType = sendType;
    }

    public Long getSendId() {
        return sendId;
    }

    public void setSendId(Long sendId) {
        this.sendId = sendId;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public Integer getRemindNo() {
        return remindNo;
    }

    public void setRemindNo(Integer remindNo) {
        this.remindNo = remindNo;
    }

    public Short getChecksum() {
        return checksum;
    }

    public void setChecksum(Short checksum) {
        this.checksum = checksum;
    }

    public Integer getEnable() {
        return enable;
    }

    public void setEnable(Integer enable) {
        this.enable = enable;
    }

    public String getRemindContent() {
        return remindContent;
    }

    public void setRemindContent(String remindContent) {
        this.remindContent = remindContent;
    }

    public String getRemindContentUnicode() {
        return remindContentUnicode;
    }

    public void setRemindContentUnicode(String remindContentUnicode) {
        this.remindContentUnicode = remindContentUnicode;
    }

    public Date getEnableTime() {
        return enableTime;
    }

    public void setEnableTime(Date enableTime) {
        this.enableTime = enableTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getRemindUpdate() {
        return remindUpdate;
    }

    public void setRemindUpdate(Date remindUpdate) {
        this.remindUpdate = remindUpdate;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }
}