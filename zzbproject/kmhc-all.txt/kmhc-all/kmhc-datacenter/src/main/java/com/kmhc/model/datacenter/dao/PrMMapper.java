package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PrM;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("prMMapper")
public interface PrMMapper {
    int deleteByPrimaryKey(@Param("batchKey") String batchKey, @Param("imei") String imei);

    int insert(PrM record);
    
    int insertSelective(PrM record);

    PrM selectByPrimaryKey(@Param("batchKey") String batchKey, @Param("imei") String imei);

    List<PrM> selectAll();

    int updateByPrimaryKey(PrM record);
}