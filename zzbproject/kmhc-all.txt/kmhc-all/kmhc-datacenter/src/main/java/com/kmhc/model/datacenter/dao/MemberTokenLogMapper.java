package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberTokenLog;
import java.util.List;

public interface MemberTokenLogMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MemberTokenLog record);

    MemberTokenLog selectByPrimaryKey(Integer id);

    List<MemberTokenLog> selectAll();

    int updateByPrimaryKey(MemberTokenLog record);
}