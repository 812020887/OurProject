package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PushActionTypeGroup;
import java.util.List;

public interface PushActionTypeGroupMapper {
    int deleteByPrimaryKey(Byte groupId);

    int insert(PushActionTypeGroup record);

    PushActionTypeGroup selectByPrimaryKey(Byte groupId);

    List<PushActionTypeGroup> selectAll();

    int updateByPrimaryKey(PushActionTypeGroup record);
}