package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.CheckRI;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
@Repository("checkRIMapper")
public interface CheckRIMapper {
    int deleteByPrimaryKey(@Param("batchDetailKey") String batchDetailKey, @Param("imei") String imei);

    int insert(CheckRI record);

    CheckRI selectByPrimaryKey(@Param("batchDetailKey") String batchDetailKey, @Param("imei") String imei);

    List<CheckRI> selectAll();

    int updateByPrimaryKey(CheckRI record);
    
    List<CheckRI> selectByImeiWithLimit(@Param("imei") String imei, @Param("count") int count, @Param("index") int index);
    
    List<CheckRI> selectByDuring(@Param("imei") String imei, @Param("start") String start, @Param("end") String end);
}