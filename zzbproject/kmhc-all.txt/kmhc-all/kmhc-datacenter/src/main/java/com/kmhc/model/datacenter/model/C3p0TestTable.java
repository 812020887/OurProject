package com.kmhc.model.datacenter.model;

public class C3p0TestTable {
    private String a;

    public String getA() {
        return a;
    }

    public void setA(String a) {
        this.a = a;
    }
}