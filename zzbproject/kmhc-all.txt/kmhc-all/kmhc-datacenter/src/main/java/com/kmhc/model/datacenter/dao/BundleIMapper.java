package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.BundleI;
import com.sun.xml.internal.xsom.impl.scd.Iterators.Map;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("bundleIMapper")
public interface BundleIMapper {
	int deleteByPrimaryKey(@Param("account") String account, @Param("imei") String imei);

	int insert(BundleI record);

	BundleI selectByPrimaryKey(@Param("account") String account, @Param("imei") String imei);

	BundleI selectCurrentWearByAccount(@Param("account") String account);

	List<BundleI> selectAll();

	int updateByPrimaryKey(BundleI record);

	List<BundleI> selectAllByAccount(@Param("account") String account);

	List<BundleI> selectAllByImei(@Param("imei") String imei);

	List<Map<String, String>> queryMemberDetailByImei(@Param("arrImei") String[] arrImei);
}