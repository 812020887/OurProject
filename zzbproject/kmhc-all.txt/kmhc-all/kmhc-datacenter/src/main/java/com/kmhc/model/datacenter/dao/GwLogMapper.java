package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.GwLog;
import java.util.List;

public interface GwLogMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(GwLog record);

    GwLog selectByPrimaryKey(Integer id);

    List<GwLog> selectAll();

    int updateByPrimaryKey(GwLog record);
}