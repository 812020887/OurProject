package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingGeofence;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface MemberSettingGeofenceMapper {
    int deleteByPrimaryKey(@Param("gId") Integer gId, @Param("memberId") Long memberId);

    int insert(MemberSettingGeofence record);

    MemberSettingGeofence selectByPrimaryKey(@Param("gId") Integer gId, @Param("memberId") Long memberId);

    List<MemberSettingGeofence> selectAll();

    int updateByPrimaryKey(MemberSettingGeofence record);
}