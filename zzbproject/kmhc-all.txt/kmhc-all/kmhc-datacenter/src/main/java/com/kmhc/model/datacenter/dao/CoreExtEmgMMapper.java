package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.CoreExtEmgM;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CoreExtEmgMMapper {
    int deleteByPrimaryKey(@Param("emgKey") String emgKey, @Param("imei") String imei);

    int insert(CoreExtEmgM record);

    CoreExtEmgM selectByPrimaryKey(@Param("emgKey") String emgKey, @Param("imei") String imei);

    List<CoreExtEmgM> selectAll();

    int updateByPrimaryKey(CoreExtEmgM record);
}