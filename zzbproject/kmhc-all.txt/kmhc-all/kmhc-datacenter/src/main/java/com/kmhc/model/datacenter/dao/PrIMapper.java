package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PrI;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("prIMapper")
public interface PrIMapper {
    int deleteByPrimaryKey(@Param("batchKey") String batchKey, @Param("imei") String imei, @Param("itemno") Short itemno);

    int insert(PrI record);
    
    int insertSelective(PrI record);

    PrI selectByPrimaryKey(@Param("batchKey") String batchKey, @Param("imei") String imei, @Param("itemno") Short itemno);

    List<PrI> selectAll();

    int updateByPrimaryKey(PrI record);
    
    List<PrI> getPsrTop200();
    
    List<PrI> getPsrIByBatchKey(@Param("batchKey") String batchKey);
    
    List<PrI> getPrIByImeiWithLimit(@Param("imei") String imei, @Param("count") int count, @Param("index") int index);
    
    int selectByPrDate(PrI record);
}