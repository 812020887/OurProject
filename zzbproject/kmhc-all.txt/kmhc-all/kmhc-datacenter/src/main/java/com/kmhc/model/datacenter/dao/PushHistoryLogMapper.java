package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PushHistoryLog;
import java.util.List;

public interface PushHistoryLogMapper {
    int deleteByPrimaryKey(Long historyId);

    int insert(PushHistoryLog record);

    PushHistoryLog selectByPrimaryKey(Long historyId);

    List<PushHistoryLog> selectAll();

    int updateByPrimaryKey(PushHistoryLog record);
}