package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.GwTransferLog;
import java.util.List;

public interface GwTransferLogMapper {
    int insert(GwTransferLog record);

    List<GwTransferLog> selectAll();
}