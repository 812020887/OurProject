package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.ProductLogI;
import java.util.List;

public interface ProductLogIMapper {
    int deleteByPrimaryKey(Integer sno);

    int insert(ProductLogI record);

    ProductLogI selectByPrimaryKey(Integer sno);

    List<ProductLogI> selectAll();

    int updateByPrimaryKey(ProductLogI record);
}