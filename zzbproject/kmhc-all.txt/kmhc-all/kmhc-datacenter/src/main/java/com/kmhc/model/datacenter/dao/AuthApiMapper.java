package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AuthApi;
import java.util.List;

public interface AuthApiMapper {
    int deleteByPrimaryKey(Long sno);

    int insert(AuthApi record);

    AuthApi selectByPrimaryKey(Long sno);

    List<AuthApi> selectAll();

    int updateByPrimaryKey(AuthApi record);
}