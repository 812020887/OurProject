package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AuthHost;
import java.util.List;

public interface AuthHostMapper {
    int deleteByPrimaryKey(Long sno);

    int insert(AuthHost record);

    AuthHost selectByPrimaryKey(Long sno);

    List<AuthHost> selectAll();

    int updateByPrimaryKey(AuthHost record);
}