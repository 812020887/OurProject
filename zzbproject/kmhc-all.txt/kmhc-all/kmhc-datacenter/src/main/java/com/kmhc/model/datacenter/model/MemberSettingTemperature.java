package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingTemperature {
    private String imei;

    private Integer tempHigh;

    private Integer tempLow;

    private Date createDate;

    private Date updateDate;

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Integer getTempHigh() {
        return tempHigh;
    }

    public void setTempHigh(Integer tempHigh) {
        this.tempHigh = tempHigh;
    }

    public Integer getTempLow() {
        return tempLow;
    }

    public void setTempLow(Integer tempLow) {
        this.tempLow = tempLow;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}