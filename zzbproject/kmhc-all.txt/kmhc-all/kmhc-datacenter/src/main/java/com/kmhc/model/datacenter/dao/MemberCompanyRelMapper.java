package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberCompanyRel;
import java.util.List;

public interface MemberCompanyRelMapper {
    int deleteByPrimaryKey(Long id);

    int insert(MemberCompanyRel record);

    MemberCompanyRel selectByPrimaryKey(Long id);

    List<MemberCompanyRel> selectAll();

    int updateByPrimaryKey(MemberCompanyRel record);
}