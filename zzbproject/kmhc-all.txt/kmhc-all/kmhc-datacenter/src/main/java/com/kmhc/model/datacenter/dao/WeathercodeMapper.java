package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.Weathercode;
import java.util.List;

public interface WeathercodeMapper {
    int deleteByPrimaryKey(Integer sno);

    int insert(Weathercode record);

    Weathercode selectByPrimaryKey(Integer sno);

    List<Weathercode> selectAll();

    int updateByPrimaryKey(Weathercode record);
}