package com.kmhc.model.datacenter.model;

import java.util.Date;

public class MemberSettingHeartrate {
    private String imei;

    private Integer heartRateHigh;

    private Integer heartRateLow;

    private Double heartRateRisk;

    private Integer heartAge;

    private Date createDate;

    private Date updateDate;
    
    private int status;
    
    public MemberSettingHeartrate() {
		super();
	}

	public MemberSettingHeartrate(String imei, Integer heartRateHigh,
			Integer heartRateLow, Double heartRateRisk) {
		super();
		this.imei = imei;
		this.heartRateHigh = heartRateHigh;
		this.heartRateLow = heartRateLow;
		this.heartRateRisk = heartRateRisk;
	}



	public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Integer getHeartRateHigh() {
        return heartRateHigh;
    }

    public void setHeartRateHigh(Integer heartRateHigh) {
        this.heartRateHigh = heartRateHigh;
    }

    public Integer getHeartRateLow() {
        return heartRateLow;
    }

    public void setHeartRateLow(Integer heartRateLow) {
        this.heartRateLow = heartRateLow;
    }

    public Double getHeartRateRisk() {
        return heartRateRisk;
    }

    public void setHeartRateRisk(Double heartRateRisk) {
        this.heartRateRisk = heartRateRisk;
    }

    public Integer getHeartAge() {
        return heartAge;
    }

    public void setHeartAge(Integer heartAge) {
        this.heartAge = heartAge;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
}