package com.kmhc.model.datacenter.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.kmhc.model.datacenter.model.C100Params;
@Repository("c100ParamsMapper")
public interface C100ParamsMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(C100Params record);

    int insertSelective(C100Params record);

    C100Params selectByPrimaryKey(Integer id);
    
    C100Params selectBySn(String sn);
    
    C100Params selectByImei(String imei);
    
    List<C100Params> selectByImeis(C100Params record);

    int updateByPrimaryKeySelective(C100Params record);

    int updateByPrimaryKey(C100Params record);
}