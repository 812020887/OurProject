package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.SysSms;
import java.util.List;

public interface SysSmsMapper {
    int deleteByPrimaryKey(Long smsId);

    int insert(SysSms record);

    SysSms selectByPrimaryKey(Long smsId);

    List<SysSms> selectAll();

    int updateByPrimaryKey(SysSms record);
}