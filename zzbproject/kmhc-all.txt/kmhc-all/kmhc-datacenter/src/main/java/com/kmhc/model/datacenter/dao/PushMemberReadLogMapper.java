package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PushMemberReadLog;
import java.util.List;

public interface PushMemberReadLogMapper {
    int deleteByPrimaryKey(Long readId);

    int insert(PushMemberReadLog record);

    PushMemberReadLog selectByPrimaryKey(Long readId);

    List<PushMemberReadLog> selectAll();

    int updateByPrimaryKey(PushMemberReadLog record);
}