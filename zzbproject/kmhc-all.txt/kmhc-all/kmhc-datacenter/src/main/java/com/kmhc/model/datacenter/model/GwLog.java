package com.kmhc.model.datacenter.model;

import java.util.Date;

public class GwLog {
    private Integer id;

    private String clazz;

    private String method;

    private Date createtime;

    private String loglevel;

    private Integer precessed;

    private Integer gwfrom;

    private String thread;

    private String msg;

    public Integer getId() {
        return id;
    } 

    public void setId(Integer id) {
        this.id = id;
    }

    public String getClazz() {
        return clazz;
    }

    public void setClazz(String clazz) {
        this.clazz = clazz;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getLoglevel() {
        return loglevel;
    }

    public void setLoglevel(String loglevel) {
        this.loglevel = loglevel;
    }

    public Integer getPrecessed() {
        return precessed;
    }

    public void setPrecessed(Integer precessed) {
        this.precessed = precessed;
    }

    public Integer getGwfrom() {
        return gwfrom;
    }

    public void setGwfrom(Integer gwfrom) {
        this.gwfrom = gwfrom;
    }

    public String getThread() {
        return thread;
    }

    public void setThread(String thread) {
        this.thread = thread;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}