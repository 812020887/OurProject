package com.kmhc.model.datacenter.model;

import java.util.Date;

public class AngelFunction {
    private Long functionId;

    private Date createdTime;

    private String description;

    private String descriptionEn;

    private String descriptionCn;

    private String descriptionJp;

    private Date endTime;

    private String functionCode;

    private String functionName;

    private String functionNameEn;

    private String functionNameCn;

    private String functionNameJp;

    private String pic;

    private Integer price;

    private Date startTime;

    private Integer status;

    private Date updatedTime;

    private Long supplierId;

    private Long parent;

    private Integer type;

    private Integer functionSort;

    private Byte isNewTask;

    private String serviceId;

    private String isUsed;

    private String usedType;

    public Long getFunctionId() {
        return functionId;
    }

    public void setFunctionId(Long functionId) {
        this.functionId = functionId;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescriptionEn() {
        return descriptionEn;
    }

    public void setDescriptionEn(String descriptionEn) {
        this.descriptionEn = descriptionEn;
    }

    public String getDescriptionCn() {
        return descriptionCn;
    }

    public void setDescriptionCn(String descriptionCn) {
        this.descriptionCn = descriptionCn;
    }

    public String getDescriptionJp() {
        return descriptionJp;
    }

    public void setDescriptionJp(String descriptionJp) {
        this.descriptionJp = descriptionJp;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getFunctionCode() {
        return functionCode;
    }

    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }

    public String getFunctionName() {
        return functionName;
    }

    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }

    public String getFunctionNameEn() {
        return functionNameEn;
    }

    public void setFunctionNameEn(String functionNameEn) {
        this.functionNameEn = functionNameEn;
    }

    public String getFunctionNameCn() {
        return functionNameCn;
    }

    public void setFunctionNameCn(String functionNameCn) {
        this.functionNameCn = functionNameCn;
    }

    public String getFunctionNameJp() {
        return functionNameJp;
    }

    public void setFunctionNameJp(String functionNameJp) {
        this.functionNameJp = functionNameJp;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public Long getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Long supplierId) {
        this.supplierId = supplierId;
    }

    public Long getParent() {
        return parent;
    }

    public void setParent(Long parent) {
        this.parent = parent;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getFunctionSort() {
        return functionSort;
    }

    public void setFunctionSort(Integer functionSort) {
        this.functionSort = functionSort;
    }

    public Byte getIsNewTask() {
        return isNewTask;
    }

    public void setIsNewTask(Byte isNewTask) {
        this.isNewTask = isNewTask;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getIsUsed() {
        return isUsed;
    }

    public void setIsUsed(String isUsed) {
        this.isUsed = isUsed;
    }

    public String getUsedType() {
        return usedType;
    }

    public void setUsedType(String usedType) {
        this.usedType = usedType;
    }
}