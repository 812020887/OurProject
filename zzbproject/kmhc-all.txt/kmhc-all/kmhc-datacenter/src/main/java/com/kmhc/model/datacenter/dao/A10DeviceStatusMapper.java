package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.A10DeviceStatus;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository("a10DeviceStatusMapper")
public interface A10DeviceStatusMapper {
	int deleteByPrimaryKey(@Param("no") Integer no, @Param("imei") String imei);

    int insert(A10DeviceStatus record);

    A10DeviceStatus selectByPrimaryKey(@Param("no") Integer no, @Param("imei") String imei);

    List<A10DeviceStatus> selectAll();

    int updateByPrimaryKey(A10DeviceStatus record);
    
    A10DeviceStatus selectByImei(@Param("imei") String imei);

	int insertSelective(A10DeviceStatus a10DeviceStatus);

	int updateByPrimaryKeySelective(A10DeviceStatus a10DeviceStatus);

	Map selectMapByImei(String imei);
}