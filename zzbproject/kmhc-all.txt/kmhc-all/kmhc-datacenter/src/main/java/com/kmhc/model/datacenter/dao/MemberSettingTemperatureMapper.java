package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingTemperature;
import java.util.List;

public interface MemberSettingTemperatureMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingTemperature record);

    MemberSettingTemperature selectByPrimaryKey(String imei);

    List<MemberSettingTemperature> selectAll();

    int updateByPrimaryKey(MemberSettingTemperature record);
}