package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberGroupItem;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("memberGroupItemMapper")
public interface MemberGroupItemMapper {
    int deleteByPrimaryKey(Long itemId);

    int insert(MemberGroupItem record);

    MemberGroupItem selectByPrimaryKey(Long itemId);

    List<MemberGroupItem> selectAll();

    int updateByPrimaryKey(MemberGroupItem record);
}