package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.GwLogReturn;
import java.util.List;

public interface GwLogReturnMapper {
    int deleteByPrimaryKey(Long postid);

    int insert(GwLogReturn record);

    GwLogReturn selectByPrimaryKey(Long postid);

    List<GwLogReturn> selectAll();

    int updateByPrimaryKey(GwLogReturn record);
}