package com.kmhc.model.datacenter.model;

import java.math.BigDecimal;
import java.util.Date;

public class EmgITemp {
    private String emgDetailKey;

    private Short itemno;

    private String mcc;

    private String mnc;

    private String lac;

    private Integer cellid;

    private Short rssi;

    private String gpsNsLat;

    private BigDecimal gpsLat;

    private String gpsEwLng;

    private BigDecimal gpsLng;

    private String locStatus;

    private String isvalid;

    private Date createDate;

    private Date updateDate;

    public String getEmgDetailKey() {
        return emgDetailKey;
    }

    public void setEmgDetailKey(String emgDetailKey) {
        this.emgDetailKey = emgDetailKey;
    }

    public Short getItemno() {
        return itemno;
    }

    public void setItemno(Short itemno) {
        this.itemno = itemno;
    }

    public String getMcc() {
        return mcc;
    }

    public void setMcc(String mcc) {
        this.mcc = mcc;
    }

    public String getMnc() {
        return mnc;
    }

    public void setMnc(String mnc) {
        this.mnc = mnc;
    }

    public String getLac() {
        return lac;
    }

    public void setLac(String lac) {
        this.lac = lac;
    }

    public Integer getCellid() {
        return cellid;
    }

    public void setCellid(Integer cellid) {
        this.cellid = cellid;
    }

    public Short getRssi() {
        return rssi;
    }

    public void setRssi(Short rssi) {
        this.rssi = rssi;
    }

    public String getGpsNsLat() {
        return gpsNsLat;
    }

    public void setGpsNsLat(String gpsNsLat) {
        this.gpsNsLat = gpsNsLat;
    }

    public BigDecimal getGpsLat() {
        return gpsLat;
    }

    public void setGpsLat(BigDecimal gpsLat) {
        this.gpsLat = gpsLat;
    }

    public String getGpsEwLng() {
        return gpsEwLng;
    }

    public void setGpsEwLng(String gpsEwLng) {
        this.gpsEwLng = gpsEwLng;
    }

    public BigDecimal getGpsLng() {
        return gpsLng;
    }

    public void setGpsLng(BigDecimal gpsLng) {
        this.gpsLng = gpsLng;
    }

    public String getLocStatus() {
        return locStatus;
    }

    public void setLocStatus(String locStatus) {
        this.locStatus = locStatus;
    }

    public String getIsvalid() {
        return isvalid;
    }

    public void setIsvalid(String isvalid) {
        this.isvalid = isvalid;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}