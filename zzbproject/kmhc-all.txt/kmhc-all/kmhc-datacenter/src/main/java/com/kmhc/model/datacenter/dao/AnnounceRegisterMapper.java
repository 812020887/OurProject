package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.AnnounceRegister;
import java.util.List;

public interface AnnounceRegisterMapper {
    int deleteByPrimaryKey(Integer no);

    int insert(AnnounceRegister record);

    AnnounceRegister selectByPrimaryKey(Integer no);

    List<AnnounceRegister> selectAll();

    int updateByPrimaryKey(AnnounceRegister record);
}