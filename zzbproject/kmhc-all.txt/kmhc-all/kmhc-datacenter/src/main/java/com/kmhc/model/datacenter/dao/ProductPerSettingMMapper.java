package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.ProductPerSettingM;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("productPerSettingMMapper")
public interface ProductPerSettingMMapper {
    int deleteByPrimaryKey(String imei);

    int insert(ProductPerSettingM record);

    ProductPerSettingM selectByPrimaryKey(String imei);
    
    ProductPerSettingM selectBodyByImei(String imei);

    List<ProductPerSettingM> selectAll();

    int updateByPrimaryKey(ProductPerSettingM record);
    
    int updateByPrimaryKeySelective(ProductPerSettingM record);
    
    ProductPerSettingM selectByImeiAndVerityCode(@Param("imei") String imei,@Param("verity")String verity);
    @Transactional
    int updateVerity(@Param("imei")String imei,@Param("verify")String verity);
    
    int update(ProductPerSettingM record);
}