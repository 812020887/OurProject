package com.kmhc.model.datacenter.model;

import java.util.Date;

public class C100DeviceStatus {
    private Integer no;

    private Integer volagePrecent;

    private Integer volage;

    private Date lastUpdate;

    private String imei;

    public C100DeviceStatus(){} 
    
    public C100DeviceStatus(Integer volagePrecent,Integer volage,Date lastUpdate,String imei){
        this.volagePrecent = volagePrecent ;
        this.volage = volage ;
        this.lastUpdate = lastUpdate ;
        this.imei = imei ;
    }
    public Integer getNo() {
        return no;
    }

    public void setNo(Integer no) {
        this.no = no;
    }

    public Integer getVolagePrecent() {
        return volagePrecent;
    }

    public void setVolagePrecent(Integer volagePrecent) {
        this.volagePrecent = volagePrecent;
    }

    public Integer getVolage() {
        return volage;
    }

    public void setVolage(Integer volage) {
        this.volage = volage;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }
}