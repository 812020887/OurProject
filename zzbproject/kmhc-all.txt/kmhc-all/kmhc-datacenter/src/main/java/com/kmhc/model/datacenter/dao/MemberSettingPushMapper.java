package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingPush;
import java.util.List;

public interface MemberSettingPushMapper {
    int deleteByPrimaryKey(Long pushId);

    int insert(MemberSettingPush record);

    MemberSettingPush selectByPrimaryKey(Long pushId);

    List<MemberSettingPush> selectAll();

    int updateByPrimaryKey(MemberSettingPush record);
}