package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.PsrEvent;
import java.util.List;

public interface PsrEventMapper {
    int insert(PsrEvent record);

    List<PsrEvent> selectAll();
}