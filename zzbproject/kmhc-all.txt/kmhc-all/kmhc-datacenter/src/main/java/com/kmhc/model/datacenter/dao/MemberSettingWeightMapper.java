package com.kmhc.model.datacenter.dao;

import com.kmhc.model.datacenter.model.MemberSettingWeight;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("memberSettingWeightMapper")
public interface MemberSettingWeightMapper {
    int deleteByPrimaryKey(String imei);

    int insert(MemberSettingWeight record);

    MemberSettingWeight selectByPrimaryKey(String imei);

    List<MemberSettingWeight> selectAll();

    int updateByPrimaryKey(MemberSettingWeight record);
}